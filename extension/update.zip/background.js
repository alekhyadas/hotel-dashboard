/**
 * Background service worker. Runs the actual scan: for each destination
 * with a known site code, for each upcoming weekend, opens a small
 * background window pointed at the listing URL, waits for content.js to
 * report scraped hotel data, evaluates deals, and sends Telegram alerts.
 *
 * Destinations start with no code for either site. The first time you
 * manually search a destination on makemytrip.com or goibibo.com in your
 * normal browsing, content.js notices the resulting listing URL and calls
 * back here to save the code, see handleCodeLearned() below. After that,
 * scans build the URL directly and never need to touch the search box.
 */

importScripts("shared.js", "intel.js", "today.js");

const pendingRequests = new Map(); // windowId -> {resolve, timeoutId}

/**
 * Creates an alarm only if it does not already exist with the same period.
 * chrome.alarms.create() on an existing name RESTARTS its countdown, and this
 * extension reloads itself on every version bump, so a 12 hour alarm that gets
 * re-created each reload never fires if the extension is reloaded more often
 * than every 12 hours. That is exactly what stopped the full daily scan.
 */
function keepAlarm(name, info) {
  Promise.resolve(chrome.alarms.get ? chrome.alarms.get(name) : null)
    .then((existing) => {
      if (existing && Math.abs((existing.periodInMinutes || 0) - info.periodInMinutes) < 1e-6) return;
      chrome.alarms.create(name, info);
    })
    .catch(() => chrome.alarms.create(name, info));
}

// Runs twice a day on its own, chrome.alarms fires this as long as Chrome
// is open, no popup or dashboard needs to be open, no button needs
// clicking. Goibibo stays less frequent (every 3 days), its robots.txt
// explicitly disallows automated access, a stronger signal than MMT gives.
chrome.runtime.onInstalled.addListener(() => {
  keepAlarm("dailyScan", { periodInMinutes: 12 * 60 });
  keepAlarm("goibiboScan", { periodInMinutes: 3 * 24 * 60 });
  keepAlarm("selfUpdateCheck", { periodInMinutes: 0.5 });
  keepAlarm("scanWatchdog", { periodInMinutes: 3 });
  keepAlarm("pendingRequestHousekeeping", { periodInMinutes: 4 / 60 });
  // PROJECT_BRIEF.md Open Item #10, v1.35.0: same idea as dailyScan, once
  // a day is plenty since runAutomaticYoutubeCheck() itself caps how many
  // hotels it touches (see that function's comment for the quota math).
  keepAlarm("youtubeAutoCheck", { periodInMinutes: 24 * 60 });
  keepAlarm("lastMinuteSweep", { periodInMinutes: 90 });
  keepAlarm("alertQueueDrain", { periodInMinutes: 1 });
  keepAlarm("subscriberPoll", { periodInMinutes: 1 });
  keepAlarm("confirmDrain", { periodInMinutes: 1 });
  keepAlarm("digestCheck", { periodInMinutes: 30 });
  keepAlarm("helperTick", { periodInMinutes: 15 });
  keepAlarm("extPublishCheck", { periodInMinutes: 60 });
  kickExtensionPublish(); // a reload after an edit is exactly when there is something new to publish
  // If this reload happened mid-scan (an update, a crash, whatever),
  // there could be a scan still marked "running" with nothing left
  // alive to continue it, check immediately rather than waiting up to
  // 3 minutes for the next watchdog tick.
  checkScanWatchdog();
  checkFavoriteRefreshWatchdog();
  reconcileOrphanedWindows();
  migrateDatesFix().catch((e) => console.log("[migrate] failed:", e));
});

// Alarms persist across browser restarts, but re-creating them on startup
// too (chrome.alarms.create is idempotent by name) is a cheap safety net.
chrome.runtime.onStartup.addListener(() => {
  keepAlarm("dailyScan", { periodInMinutes: 12 * 60 });
  keepAlarm("goibiboScan", { periodInMinutes: 3 * 24 * 60 });
  keepAlarm("selfUpdateCheck", { periodInMinutes: 0.5 });
  keepAlarm("scanWatchdog", { periodInMinutes: 3 });
  keepAlarm("pendingRequestHousekeeping", { periodInMinutes: 4 / 60 });
  keepAlarm("youtubeAutoCheck", { periodInMinutes: 24 * 60 });
  keepAlarm("lastMinuteSweep", { periodInMinutes: 90 });
  keepAlarm("alertQueueDrain", { periodInMinutes: 1 });
  keepAlarm("subscriberPoll", { periodInMinutes: 1 });
  keepAlarm("confirmDrain", { periodInMinutes: 1 });
  keepAlarm("digestCheck", { periodInMinutes: 30 });
  keepAlarm("helperTick", { periodInMinutes: 15 });
  keepAlarm("extPublishCheck", { periodInMinutes: 60 });
  kickExtensionPublish();
  // A scan that was running when Chrome was last closed has definitely
  // had its background process die since, resume it right away instead
  // of waiting for the watchdog's next scheduled tick.
  checkScanWatchdog();
  checkFavoriteRefreshWatchdog();
  reconcileOrphanedWindows();
  migrateDatesFix().catch((e) => console.log("[migrate] failed:", e));
});

// PROJECT_BRIEF.md Open Item #11: pendingRequests (the map tracking
// which scrape/room-detail window belongs to which in-flight request)
// is in-memory only, by necessity, it has to reset to empty on a real
// service-worker restart so the watchdog is free to resume things. But
// nothing ever reconciled that against reality: if the service worker
// died at exactly the wrong moment (mid-scrape, window open, nothing
// left running to close it), the actual browser window it opened just
// sits there indefinitely, since chrome.windows.remove() is never
// called for a window pendingRequests never gets to hear about again.
// Rare (has to land on that exact timing), and just a leftover window
// rather than a data bug, which is why it was queued behind everything
// else, but a genuinely dangling visible window with no way to close
// itself is worth cleaning up.
//
// Right after onInstalled/onStartup, pendingRequests is GUARANTEED
// empty (it was just reset), so any window matching the exact,
// deliberately unusual footprint scrapeUrlWithMeta()/checkRoomDetail()
// always create it with (type "popup", ~1100x750, positioned at
// ~(20,20), never focused) can only be a leftover from before this
// restart, by construction, not something a real person would ever
// have open by hand at these exact tolerances. Also requires its tab to
// actually be on makemytrip.com/goibibo.com (or, since v1.43.8, the
// extension's own Google Maps lookup window), as a second, independent
// safety check, so this can't ever close an unrelated window even if
// someone's own window coincidentally landed in a similar spot.
async function reconcileOrphanedWindows() {
  let all;
  try {
    all = await chrome.windows.getAll({ populate: true });
  } catch (e) {
    console.log("[startup] could not enumerate windows to reconcile:", e);
    return;
  }
  let closed = 0;
  for (const win of all) {
    if (win.type !== "popup" || win.focused) continue;
    const looksAutoCreated =
      Math.abs((win.left ?? -9999) - 20) <= 60 &&
      Math.abs((win.top ?? -9999) - 20) <= 60 &&
      Math.abs((win.width ?? -9999) - 1100) <= 100 &&
      Math.abs((win.height ?? -9999) - 750) <= 100;
    if (!looksAutoCreated) continue;
    const tab = win.tabs && win.tabs[0];
    // v1.43.8: Google Maps added. Since v1.42 the Swipe card's free Google
    // lookup (lookupGoogleViaBrowser) opens the same kind of window, with the
    // same randomWindowGeometry() footprint, so it can be orphaned exactly
    // the same way, but this check only knew the two booking sites and left
    // it open forever. Maps rewrites its own address after loading (search
    // page to place page), so the ?dtjob=1 marker can't be relied on here;
    // the footprint check above is what keeps this from touching your own
    // windows (a popup-type, unfocused window at this exact size and spot is
    // only ever created by this extension).
    const onOurSites = tab && tab.url && /^https:\/\/((www\.)?(makemytrip|goibibo)\.com\/|www\.google\.com\/maps\/)/.test(tab.url);
    if (!onOurSites) continue;
    try {
      await chrome.windows.remove(win.id);
      closed++;
    } catch (e) {
      // already gone, nothing to do
    }
  }
  if (closed > 0) {
    console.log(`[startup] closed ${closed} leftover scrape window(s) from before this restart`);
    await logActivity("closed_orphaned_windows", { count: closed });
  }
}

// So you never have to manually click reload in chrome://extensions: every
// 30 seconds, check whether the manifest.json on disk has a newer version
// than what's currently running, and if so, reload automatically.
//
// This must NOT fire while a scan is running: reloading tears down the
// extension's connection to any content script currently mid-scrape,
// which throws "Cannot read properties of undefined (reading
// sendMessage')" in whatever window was open at that moment, and silently
// loses that scrape's result. So if a scan is active, the update is
// deferred, this check runs again in 30 seconds and will apply it as soon
// as the scan finishes.
async function checkForUpdate() {
  const r = await checkForUpdateInner();
  // Leave a trace of every check so "why didn't it reload?" can be answered
  // from stored data instead of guessing (service-worker console logs vanish).
  chrome.storage.local.set({ lastUpdateCheck: { at: new Date().toISOString(), ...r } }).catch(() => {});
  return r;
}

let reloadScheduled = false;
async function checkForUpdateInner() {
  // Returns what happened so the popup/dashboard (which call this the moment
  // they are opened, via the CHECK_FOR_UPDATE message) can tell the person:
  // {status: "reloading" | "current" | "deferred" | "error", diskVersion}.
  try {
    // This used to only check scanProgress.running, so a reload could
    // land in the middle of Quick Refresh Favorites instead, tearing
    // down that content-script connection exactly the same way and
    // silently losing that scrape too, just via a different progress
    // flag than the one this function actually checked.
    const { scanProgress, favoriteRefreshProgress } = await chrome.storage.local.get(["scanProgress", "favoriteRefreshProgress"]);
    if ((scanProgress && scanProgress.running) || (favoriteRefreshProgress && favoriteRefreshProgress.running)) {
      console.log("[auto-reload] update available but a scan or favorites refresh is running, deferring");
      return { status: "deferred" };
    }

    const resp = await fetch(chrome.runtime.getURL("manifest.json") + "?t=" + Date.now(), {
      cache: "no-store",
    });
    const diskManifest = await resp.json();
    const runningVersion = chrome.runtime.getManifest().version;
    if (diskManifest.version !== runningVersion) {
      console.log(`[auto-reload] ${runningVersion} -> ${diskManifest.version}, reloading`);
      // Reload on a short delay: when this was triggered by a click, the
      // caller's response has to get out before the worker is torn down.
      if (!reloadScheduled) {
        reloadScheduled = true;
        setTimeout(() => chrome.runtime.reload(), 250);
      }
      return { status: "reloading", diskVersion: diskManifest.version, runningVersion };
    }
    importEnrichment().catch((e) => console.log("[enrichment] failed:", e));
    return { status: "current", diskVersion: diskManifest.version };
  } catch (e) {
    console.log("[auto-reload] check failed:", e);
    return { status: "error", error: String(e) };
  }
}

let lastAlarmUpdateCheck = 0;
// Every time the worker wakes up, look for a newer version after a moment.
setTimeout(() => checkForUpdate(), 4000);

chrome.alarms.onAlarm.addListener((alarm) => {
  // Belt and braces: if the dedicated selfUpdateCheck alarm was ever lost
  // (Chrome may drop alarms on restart) any other alarm still triggers it.
  if (alarm.name !== "selfUpdateCheck" && Date.now() - lastAlarmUpdateCheck > 60000) {
    lastAlarmUpdateCheck = Date.now();
    checkForUpdate();
  }
  if (alarm.name === "dailyScan") startScan(["makemytrip"], { auto: true });
  if (alarm.name === "goibiboScan") startScan(["goibibo"], { auto: true });
  if (alarm.name === "lastMinuteSweep") runLastMinuteSweep();
  if (alarm.name === "alertQueueDrain") drainAlertQueue();
  if (alarm.name === "subscriberPoll") pollSubscriberBot();
  if (alarm.name === "confirmDrain") processConfirmations();
  if (alarm.name === "digestCheck") runMorningDigest();
  if (alarm.name === "helperTick") helperTick();
  if (alarm.name === "extPublishCheck") kickExtensionPublish();
  if (alarm.name === "postFixScan") runPostFixScan().catch((e) => console.log("[postfix] failed:", e));
  if (alarm.name === "selfUpdateCheck") checkForUpdate();
  if (alarm.name === "scanStepAlarm") runScanStep();
  if (alarm.name === "scanWatchdog") {
    checkScanWatchdog();
    checkFavoriteRefreshWatchdog();
  }
  if (alarm.name === "pendingRequestHousekeeping") housekeepPendingRequests();
  if (alarm.name === "youtubeAutoCheck") runAutomaticYoutubeCheck();
  if (alarm.name === "favoriteRefreshStepAlarm") runFavoriteRefreshStep();
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "GMAPS_RESULT") {
    handleGmapsResult(message, sender).catch((e) => console.log("[gmaps] save failed:", e));
  }
  if (message.type === "GOOGLE_PAGE_LOOKUP") {
    lookupGoogleViaBrowser(message.groupKey, message.hotelName, message.destination).then(sendResponse, () => sendResponse(null));
    return true;
  }
  if (message.type === "HELPER_SYNC_NOW") {
    (async () => {
      const s = await getSettings();
      if (isHelper(s)) {
        const pulled = await pullSharedState(s);
        const up = await uploadHelperData(s);
        sendResponse({ role: "helper", pulled, uploaded: up });
      } else {
        sendResponse({ role: "main", ...(await syncHelpers()) });
      }
    })();
    return true;
  }
  if (message.type === "PUBLISH_EXTENSION_NOW") {
    getSettings().then((s) => publishExtensionUpdate(s, { force: true })).then(sendResponse, (e) => sendResponse({ status: "error", error: String(e) }));
    return true;
  }
  if (message.type === "CLEAR_MMT_DATA") {
    // The dashboard's "Clear MakeMyTrip data" button. Also lifts the one-hour
    // back-off, since the point of clearing is to be able to scan again now.
    (async () => {
      const r = await clearMmtSiteData();
      if (r.ok) {
        const { siteCooldown = {} } = await chrome.storage.local.get("siteCooldown");
        delete siteCooldown.makemytrip;
        await chrome.storage.local.set({ siteCooldown });
      }
      sendResponse(r);
    })();
    return true;
  }
  if (message.type === "RELOAD_EXTENSION") {
    // The dashboard's Reload button. Delayed so this reply gets out before the worker goes down.
    sendResponse({ status: "reloading" });
    setTimeout(() => chrome.runtime.reload(), 250);
    return false;
  }
  if (message.type === "CHECK_FOR_UPDATE") {
    // Sent by the popup and dashboard the moment they open, so clicking the
    // extension picks up new code immediately instead of within 30 seconds.
    checkForUpdate().then(sendResponse);
    return true;
  }
  if (message.type === "CODE_LEARNED") {
    handleCodeLearned(message.site, message.destinationGuess, message.code);
  }
  if (message.type === "SCRAPE_RESULT") {
    if (message.debug) {
      chrome.storage.local.set({ lastDebug: { ...message.debug, at: new Date().toISOString() } });
    }
    const windowId = sender.tab && sender.tab.windowId;
    const pending = pendingRequests.get(windowId);
    if (pending) {
      pending.resolve({ listings: message.listings || [], debug: message.debug || null });
    } else if (sender.tab) {
      // Not one of our scan windows: a page you opened yourself.
      passiveIngest(message, sender).catch((e) => console.log("[passive] failed:", e));
    }
  }
  if (message.type === "ROOM_DETAIL_RESULT") {
    const windowId = sender.tab && sender.tab.windowId;
    const pending = pendingRequests.get(windowId);
    if (pending) {
      pending.resolve(message);
    }
  }
  if (message.type === "RUN_SCAN_NOW") {
    // Forward startScan()'s real result (now that it returns one, see
    // above) instead of always claiming { started: true }: a click that
    // got silently skipped because a different scan was already running
    // used to look identical to a genuine start from the popup's side.
    startScan(message.sites || ["makemytrip"], { staleOnly: !!message.staleOnly, destinationName: message.destinationName || null }).then((result) =>
      sendResponse(result || { started: true })
    );
    return true; // keep the message channel open for the async response
  }
  if (message.type === "STOP_SCAN") {
    (async () => {
      const { activeScan } = await chrome.storage.local.get("activeScan");
      if (!activeScan) {
        // Nothing left running to actually receive a stop flag, clear
        // the stale state directly instead of setting a flag nobody's
        // there to check.
        await logActivity("stop_clicked_on_zombie_scan", null);
        await updateProgress({
          running: false,
          finishedAt: new Date().toISOString(),
          currentLabel: "Stopped",
          stopRequested: false,
        });
      } else {
        await logActivity("stop_requested", null);
        await updateProgress({ stopRequested: true });
      }
      sendResponse({ stopping: true });
    })();
    return true;
  }
  if (message.type === "QUICK_REFRESH_FAVORITES") {
    startFavoriteRefresh({ destinationName: message.destinationName || null }).then((result) => sendResponse(result));
    return true;
  }
  if (message.type === "STOP_FAVORITE_REFRESH") {
    (async () => {
      const { activeFavoriteRefresh } = await chrome.storage.local.get("activeFavoriteRefresh");
      if (!activeFavoriteRefresh) {
        // Nothing left running to actually receive a stop flag, clear
        // the stale state directly instead of setting a flag nobody's
        // there to check.
        await logActivity("stop_clicked_on_zombie_favorite_refresh", null);
        await chrome.storage.local.set({
          favoriteRefreshProgress: {
            running: false,
            finishedAt: new Date().toISOString(),
            currentLabel: "Stopped",
            stopRequested: false,
          },
        });
      } else {
        await logActivity("favorite_refresh_stop_requested", null);
        const { favoriteRefreshProgress = {} } = await chrome.storage.local.get("favoriteRefreshProgress");
        await chrome.storage.local.set({ favoriteRefreshProgress: { ...favoriteRefreshProgress, stopRequested: true } });
      }
      sendResponse({ stopping: true });
    })();
    return true;
  }
  return false;
});

async function handleCodeLearned(site, destinationGuess, code) {
  const settings = await getSettings();
  const match = settings.destinations.find(
    (d) =>
      d.name.toLowerCase() === destinationGuess.toLowerCase() ||
      destinationGuess.toLowerCase().includes(d.searchTerm.toLowerCase())
  );
  if (!match) {
    console.log(`[learn] Got a ${site} code (${code}) for "${destinationGuess}" but it doesn't match any configured destination.`);
    return;
  }
  const field = site === "makemytrip" ? "mmtCode" : "goibiboCode";
  if (match[field] === code) return; // already known
  match[field] = code;
  await saveSettings(settings);
  console.log(`[learn] Learned ${site} code for ${match.name}: ${code}`);
  chrome.notifications.create({
    type: "basic",
    iconUrl: "icons/icon128.png",
    title: "Destination learned",
    message: `${match.name} is now set up for automatic ${site} scans.`,
  });
}

/**
 * Opens a small window, waits for content.js to scrape it, closes it,
 * and returns {listings, debug}.
 *
 * The window used to be minimized, then off-screen. Both may count as
 * hidden, which makes Chrome throttle the page's own rendering, and an
 * off-screen never-focused window is also a plausible thing for a site's
 * anti-bot layer to distrust. So it now opens small but genuinely
 * on-screen, the trade-off is a brief visible flash per check in exchange
 * for behaving like an ordinary window.
 */
function scrapeUrlWithMeta(url, timeoutMs) {
  const limit = timeoutMs || 75000;
  return new Promise(async (resolve) => {
    let win;
    try {
      win = await chrome.windows.create({
        url,
        type: "popup",
        ...randomWindowGeometry(),
        focused: false,
      });
    } catch (e) {
      console.log("[scan] could not open window:", e);
      resolve({ listings: [], debug: { error: String(e) } });
      return;
    }

    // Everything needed to resolve this request lives on one object,
    // stored in pendingRequests, read by BOTH content.js's normal
    // completion message and the periodic housekeeping alarm below.
    // Deliberately no setTimeout/setInterval here, those can die along
    // with the service worker and never fire again, which is what left
    // pages open and scans stuck for hours with nothing left to resolve
    // them. The alarm-driven housekeeper is what actually survives that.
    const entry = {
      settled: false,
      openedAt: Date.now(),
      timeoutMs: limit,
      stoppedPayload: { listings: [], debug: { stoppedByUser: true } },
      // Only ever the main scan, see checkRoomDetail() below for the
      // function that's shared between two different activities.
      kind: "scan",
    };

    entry.cleanupAndResolve = (payload) => {
      if (entry.settled) return;
      entry.settled = true;
      pendingRequests.delete(win.id);
      chrome.windows.remove(win.id).catch(() => {});
      resolve(payload);
    };

    entry.buildTimeoutPayload = async () => {
      // content.js never responded at all within the timeout, most
      // likely because the page redirected somewhere our manifest isn't
      // watching for, or the response wasn't a normal HTML page at all
      // (e.g. a raw JSON response, which Chrome can't inject a content
      // script into), so it never even ran. Grab whatever we still can
      // directly, rather than logging a "found 0" with zero explanation.
      let timeoutDebug = {
        timedOut: true,
        note: "content.js never responded within the timeout, likely redirected off the expected URL pattern, or the response wasn't a scriptable HTML page (e.g. raw JSON)",
      };
      try {
        const tabs = await chrome.tabs.query({ windowId: win.id });
        if (tabs[0]) {
          const results = await chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            func: () => ({
              url: location.href,
              title: document.title,
              visibilityState: document.visibilityState,
              hidden: document.hidden,
              bodyTextSample: (document.body ? document.body.innerText : "").slice(0, 800),
            }),
          });
          const result = results && results[0] && results[0].result;
          if (result) timeoutDebug = { ...result, ...timeoutDebug };
        }
      } catch (e) {
        // executeScript itself throwing (rather than just returning odd
        // data) is a strong signal this wasn't a normal page at all.
        timeoutDebug.scriptingError = String(e);
        console.log("[scan] timeout diagnostic failed:", e);
      }

      // Chrome's own JSON viewer shows a "Pretty-print" checkbox and
      // renders the raw response starting with { or [, this is a
      // specific, recognizable pattern worth naming rather than lumping
      // in with every other kind of timeout, since it points at a
      // particular cause (a site serving an API response instead of a
      // page for a URL opened without prior browsing context, or
      // possibly the site flagging automated traffic).
      const sample = (timeoutDebug.bodyTextSample || "").trim();
      if (/pretty-print/i.test(sample) || sample.startsWith("{") || sample.startsWith("[")) {
        timeoutDebug.likelyJsonResponse = true;
        await logActivity("json_response_instead_of_page", { url: timeoutDebug.url || url });
      } else {
        await logActivity("page_timed_out", { url: timeoutDebug.url || url });
      }

      await chrome.storage.local.set({
        lastDebug: { ...timeoutDebug, at: new Date().toISOString() },
      });
      return { listings: [], debug: timeoutDebug };
    };

    entry.resolve = (payload) => entry.cleanupAndResolve(payload);

    pendingRequests.set(win.id, entry);
  });
}

/**
 * Runs on a short periodic alarm (survives the service worker dying,
 * unlike setTimeout/setInterval) and does two jobs for every currently
 * open page: closes it if its own timeout has elapsed, and closes it if
 * a stop was requested. This is what actually makes Stop and the
 * per-page timeout reliable, a plain timer sitting inside a single
 * function call can die with the service worker and never fire again,
 * this alarm-driven check can't, it gets a fresh chance every ~4 seconds
 * regardless of what happened to whatever was waiting before it.
 */
async function housekeepPendingRequests() {
  if (pendingRequests.size === 0) return;

  const { scanProgress, favoriteRefreshProgress } = await chrome.storage.local.get([
    "scanProgress",
    "favoriteRefreshProgress",
  ]);
  // Each pending request is tagged with which activity opened it
  // (entry.kind), so stopping one doesn't also kill the other's still-
  // legitimately-running window. This used to be a single OR'd flag
  // applied to every pending request regardless of which activity owned
  // it, so stopping Quick Refresh Favorites while a scan happened to
  // also be running would silently kill the scan's window too.
  const scanStopped = !!(scanProgress && scanProgress.stopRequested);
  const favoritesStopped = !!(favoriteRefreshProgress && favoriteRefreshProgress.stopRequested);
  const now = Date.now();

  for (const [, pending] of [...pendingRequests.entries()]) {
    if (pending.settled) continue;
    const stopped = pending.kind === "favorites" ? favoritesStopped : scanStopped;
    if (stopped) {
      pending.cleanupAndResolve(pending.stoppedPayload);
    } else if (now - pending.openedAt > pending.timeoutMs) {
      const payload = await pending.buildTimeoutPayload();
      pending.cleanupAndResolve(payload);
    }
  }
}

// A plain setTimeout does NOT keep an MV3 service worker alive, Chrome can
// suspend it during an idle wait like this, which would silently kill the
// scan partway through with no error. chrome.alarms is designed to survive
// exactly this (it wakes the service worker back up when it fires), so the
// pauses between requests go through an alarm instead of setTimeout.
function delay(minSeconds, maxSeconds) {
  const seconds = minSeconds + Math.random() * (maxSeconds - minSeconds);
  const alarmName = `scanDelay_${Date.now()}_${Math.random().toString(36).slice(2)}`;
  return new Promise((resolve) => {
    const listener = (alarm) => {
      if (alarm.name === alarmName) {
        chrome.alarms.onAlarm.removeListener(listener);
        resolve();
      }
    };
    chrome.alarms.onAlarm.addListener(listener);
    chrome.alarms.create(alarmName, { delayInMinutes: seconds / 60 });
  });
}

/**
 * Keeps the popup's "Recent Listings" rolling log (recentScans, capped
 * at 100, most recent first) up to date. Used to only be inlined in
 * evaluateAndAlert() (the main scan), which meant Quick Refresh
 * Favorites -- a first-class scanning activity with its own progress
 * UI and Telegram alerts -- never showed up there at all, favorited
 * hotels you'd just refreshed looked like they hadn't been touched.
 * Pulled out so both callers share the identical bookkeeping instead
 * of drifting the way parallel paths keep doing in this project.
 */
async function recordRecentScan(listing, scannedAt) {
  const { recentScans = [] } = await chrome.storage.local.get("recentScans");
  recentScans.unshift({ ...listing, scannedAt });
  await chrome.storage.local.set({ recentScans: recentScans.slice(0, 100) });
}

/**
 * v1.44.6: the two judgements behind "lowest price ever" and "really good
 * deal", shared by the main scan (evaluateAndAlert) and Quick Refresh
 * Favorites so the two paths cannot drift. Pure apart from reading settings.
 * verifiedPrior = this stay's earlier verified price points (before this price).
 * -> {recordLow, goodDeal, fairInfo, reasons, recordLowExtra, goodDealExtra}
 */
function judgeLowAndGood(price, rating, reviewCount, verifiedPrior, existing, settings) {
  const fairInfo = fairPriceFor(verifiedPrior);
  // A cheap price on a badly reviewed hotel is not worth a ping.
  const poor = isPoorlyRated(rating, reviewCount);
  const recordLow = settings.alertRecordLow !== false && !poor
    ? detectRecordLow(verifiedPrior, price, { minBelowPrevPct: settings.recordLowMinBelowPct })
    : { fire: false };
  const goodDeal = settings.alertGoodDeals !== false && !poor
    ? evaluateGoodDeal(price, fairInfo, existing && existing.goodDealAlert, { minBelowPct: settings.goodDealBelowPct })
    : { fire: false, newState: !!(existing && existing.goodDealAlert) };
  const reasons = [];
  if (recordLow.fire) reasons.push(`🏆 Lowest price ever seen for this stay: ${formatINR(price)} (previous best ${formatINR(recordLow.prevLow)}, ${recordLow.belowPrevPct}% lower${recordLow.fair ? `, usual price ${formatINR(recordLow.fair)}` : ""})`);
  if (goodDeal.fire) reasons.push(`💰 ${goodDeal.belowPct}% below its usual price (${formatINR(fairInfo.fair)} usually, ${formatINR(price)} now)`);
  return {
    recordLow, goodDeal, fairInfo, reasons,
    recordLowExtra: recordLow.fire ? { dropPct: recordLow.belowFairPct ?? recordLow.belowPrevPct, refPrice: recordLow.fair ?? recordLow.prevLow, fairPrice: recordLow.fair } : {},
    goodDealExtra: goodDeal.fire ? { dropPct: goodDeal.belowPct, refPrice: fairInfo.fair, fairPrice: fairInfo.fair } : {},
  };
}

async function evaluateAndAlert(listing, settings) {
  let { blockedHotels = [] } = await chrome.storage.local.get("blockedHotels");
  const blockedEntry = blockedHotels.find(
    (b) => b.source === listing.source && b.hotelName === listing.hotelName && b.destination === listing.destination
  );
  let isBlocked = !!blockedEntry;

  // A hotel that was only PAUSED for going missing from listings is
  // listed again right now, so it comes back by itself (a hotel you
  // removed, or one stopped after 5+ weeks missing, stays removed).
  if (blockedEntry && blockedEntry.via === "missing-paused") {
    blockedHotels = blockedHotels.filter((b) => b !== blockedEntry);
    await chrome.storage.local.set({ blockedHotels });
    await logActivity("missing_hotel_returned", { hotelName: listing.hotelName, destination: listing.destination });
    isBlocked = false;
  }

  // A removed hotel (swiped left, or hidden) is no longer tracked at all:
  // nothing is written, no alert, no feed entry. Its existing history is
  // kept untouched, so restoring it later picks up where it left off.
  if (isBlocked) return;

  // Includes destination: two hotels sharing a name in different
  // destinations (not rare near Kolkata, chain-ish names repeat) used to
  // collide on this key and silently merge/overwrite each other's price
  // history, since source+hotelName+dates alone isn't a unique identity.
  const key = `hist:${listing.source}:${listing.hotelName}:${listing.destination}:${listing.checkin}:${listing.checkout}`;
  const store = await chrome.storage.local.get(key);
  const existing = store[key]; // {prices: [{price, at}], lowest, lowestAt, ...} or undefined

  // Compare only against points whose date was verified (see verifiedPoints in
  // intel.js): older points may be tonight's price filed under another date.
  const verifiedPrior = existing ? verifiedPoints(existing.prices) : [];
  const priorPrice = verifiedPrior.length ? verifiedPrior[verifiedPrior.length - 1].price : null;

  const reasons = [];
  let alertType = null;
  let alertExtra = {};
  if (listing.discountPct !== null && listing.discountPct >= settings.discountPctThreshold) {
    reasons.push(`${listing.discountPct}% off listed price`);
    alertType = "discount";
    alertExtra = { dropPct: listing.discountPct, refPrice: listing.originalPrice ?? null };
  }
  if (priorPrice && listing.discountedPrice < priorPrice) {
    const dropPct = Math.round(((priorPrice - listing.discountedPrice) / priorPrice) * 100);
    if (dropPct >= settings.priceDropPctThreshold) {
      reasons.push(`price dropped ${dropPct}% since last check (${formatINR(priorPrice)} -> ${formatINR(listing.discountedPrice)})`);
      alertType = "drop";
      alertExtra = { dropPct, refPrice: priorPrice };
    }
  }
  if (listing.isNewlyBuilt && !existing) {
    // only alert on newly built the first time we see this exact listing,
    // not on every single scan afterward
    reasons.push("Newly built property");
    if (!alertType) alertType = "new";
  }

  const now = new Date().toISOString();

  // Last-minute: a stay starting tonight / in the next few days that is now
  // cheaper than it was on an earlier day (or earlier today). This is the
  // case the generic price-drop rule can't see on its own, since it only
  // compares to the previous scan and never knows how close the stay is.
  const lm = detectLastMinuteDrop(verifiedPrior, listing.discountedPrice, listing.checkin, now, {
    lastMinuteDays: settings.lastMinuteDays,
    lastMinuteDropPct: settings.lastMinuteDropPct,
  });
  const lmDecision = shouldFireLastMinute(lm, listing.discountedPrice, now, existing && existing.lastMinuteAlert);
  if (lmDecision.fire) {
    reasons.unshift(
      `\u{1F525} Check-in ${leadLabel(lm.leadDays)}: ${formatINR(lm.refPrice)} -> ${formatINR(listing.discountedPrice)} (-${lm.dropPct}%, saves ${formatINR(lm.saving)}${lm.refKind === "same_day" ? ", dropped today" : " vs the last time we checked"})`
    );
    alertType = "last_minute";
    alertExtra = { dropPct: lm.dropPct, refPrice: lm.refPrice, leadDays: lm.leadDays };
  }

  // --- Judgement layer (v1.39): is this price actually good? ---
  const priorPrices = verifiedPrior;
  const fairInfo = fairPriceFor(priorPrices);
  const holiday = holidayFor(listing.checkin, listing.checkout, parseHolidayText(settings.holidayText != null ? settings.holidayText : DEFAULT_HOLIDAY_TEXT));

  // A sticker discount only counts if the price is also below what this
  // stay usually costs: "35% off" on an inflated price is not a deal.
  if (alertType === "discount" && fairInfo && listing.discountedPrice > fairInfo.fair * 1.02) {
    const i = reasons.findIndex((r) => /% off listed price/.test(r));
    if (i !== -1) reasons.splice(i, 1);
    alertType = reasons.length ? alertType : null;
    await logActivity("sticker_discount_ignored", { hotelName: listing.hotelName, price: listing.discountedPrice, fair: fairInfo.fair });
  }

  // A price far below the usual one is more likely a mistake than a deal:
  // raise it as an error fare (which is always re-checked before sending).
  if (isErrorFare(listing.discountedPrice, fairInfo)) {
    reasons.unshift(`\u{1F6A8} Possible error fare: ${formatINR(listing.discountedPrice)} vs its usual ${formatINR(fairInfo.fair)}. Check it fast, they usually fix these within hours.`);
    alertType = "error_fare";
    alertExtra = { dropPct: Math.round(((fairInfo.fair - listing.discountedPrice) / fairInfo.fair) * 100), refPrice: fairInfo.fair, fairPrice: fairInfo.fair };
  }

  // --- v1.44.6: "lowest ever" (must-know) and "really good deal" alerts ---
  const judged = judgeLowAndGood(listing.discountedPrice, listing.rating, listing.reviewCount, verifiedPrior, existing, settings);
  const goodDeal = judged.goodDeal;
  if (judged.recordLow.fire) await logActivity("record_low", { hotelName: listing.hotelName, destination: listing.destination, price: listing.discountedPrice, prevLow: judged.recordLow.prevLow });
  // An error fare or a last-minute drop is a louder headline; the record or
  // good-deal line still shows as a reason on it.
  if (!alertType || alertType === "new" || alertType === "drop" || alertType === "discount") {
    if (judged.recordLow.fire) { alertType = "record_low"; alertExtra = judged.recordLowExtra; }
    else if (judged.goodDeal.fire && !alertType) { alertType = "good_deal"; alertExtra = judged.goodDealExtra; }
  }
  // The record is the headline when it leads, so its line goes first.
  if (alertType === "record_low") reasons.unshift(...judged.reasons);
  else reasons.push(...judged.reasons);

  // The stored ledger keeps every point (legacy ones stay as history), the
  // judgement above only ever used the verified ones.
  const ledgerAfter = appendLedgerPoint(existing ? existing.prices : [], listing.discountedPrice, now, listing.checkin);
  const desperate = isDesperate(ledgerAfter);

  // Gold hotels (ones you have stayed at or filmed) get a louder alert on
  // even a small drop.
  const { goldHotels = {} } = await chrome.storage.local.get("goldHotels");
  const isGold = !!goldHotels[`${listing.source}:::${listing.hotelName}:::${listing.destination}`];
  if (isGold && priorPrice && listing.discountedPrice <= priorPrice * 0.95 && alertType !== "last_minute" && alertType !== "error_fare") {
    const pct = Math.round(((priorPrice - listing.discountedPrice) / priorPrice) * 100);
    reasons.unshift(`\u{1F947} Gold hotel dropped ${pct}% (${formatINR(priorPrice)} -> ${formatINR(listing.discountedPrice)})`);
    alertType = alertType || "drop";
    if (!alertExtra.dropPct) alertExtra = { dropPct: pct, refPrice: priorPrice };
  }

  if (reasons.length > 0) {
    if (desperate) reasons.push("\u{1F4C9} Dropped on 3 days in a row, it may fall further");
    if (holiday) reasons.push(fairInfo && listing.discountedPrice < fairInfo.fair ? `Cheap even for ${holiday}` : `Note: ${holiday} dates, higher prices are normal`);
    const why = buildWhyLine({
      price: listing.discountedPrice, fair: fairInfo && fairInfo.fair, rating: listing.rating ?? null, reviewCount: listing.reviewCount ?? null,
      holiday, lowestInDays: lowestInDays(priorPrices, listing.discountedPrice, Date.now()),
    });
    if (why) reasons.push(`Why: ${why}`);
    alertExtra = { ...alertExtra, fairPrice: fairInfo ? fairInfo.fair : null, holiday };
  }

  // The ledger keeps every observation (with how many days before check-in
  // it was seen), see LEDGER_MAX_POINTS in intel.js.
  const prices = ledgerAfter;

  // "Lowest" comes from verified points only, so a legacy mislabeled price
  // (or a scrape error like ₹818) can never be the lowest-ever.
  const verifiedLows = verifiedPrior.filter((p) => p.price >= 300);
  const priorLow = verifiedLows.length ? verifiedLows.reduce((a, b) => (b.price < a.price ? b : a)) : null;
  const lowestSoFar = priorLow ? Math.min(priorLow.price, listing.discountedPrice) : listing.discountedPrice;
  const lowestAt = priorLow && priorLow.price <= listing.discountedPrice ? priorLow.at : now;

  await chrome.storage.local.set({
    [key]: {
      // Spread the existing record first. This write used to build the
      // object from scratch, which dropped every field it didn't list:
      // YouTube results, amenities, AI star estimate, room-detail price,
      // and targetAlertSent (so price-target alerts forgot they had
      // already fired and could repeat on every scan).
      ...(existing || {}),
      destination: listing.destination,
      source: listing.source,
      hotelName: listing.hotelName,
      starRating: listing.starRating,
      rating: listing.rating ?? null,
      reviewCount: listing.reviewCount ?? null,
      checkin: listing.checkin,
      checkout: listing.checkout,
      url: listing.url,
      isNewlyBuilt: !!listing.isNewlyBuilt,
      imageUrl: listing.imageUrl || (existing && existing.imageUrl) || null,
      prices,
      originalPrice: listing.originalPrice ?? null,
      lowest: lowestSoFar,
      lowestAt,
      updatedAt: now,
      lastMinuteAlert: lmDecision.newState,
      goodDealAlert: goodDeal.newState,
      desperate,
    },
  });

  await recordRecentScan(listing, now);
  await checkWatches(listing, settings);

  if (reasons.length > 0 && !isBlocked) {
    await notifyDealEvent(alertType || "drop", listing, reasons, settings, alertExtra);
  }

  if (!isBlocked) {
    await checkPriceTargets(listing, settings);
  }
}

/**
 * Price-target alerts (PROJECT_BRIEF open item 4): a hotel-specific target
 * set on a favorite (favoriteHotels[].targetPrice) always wins over a
 * per-destination default (settings.destinationTargets), so tell someone
 * "alert me on Digha in general under X" while overriding one particular
 * favorite with its own number. The actual fire-once/re-arm decision is
 * evaluateTargetAlert() in shared.js, kept pure and unit-tested
 * separately from all this chrome.storage plumbing. Called from both
 * evaluateAndAlert() (the main scan) and runFavoriteRefreshStep() (Quick
 * Refresh Favorites), the only two places a price is ever written.
 */
async function checkPriceTargets(listing, settings) {
  if (isHelper(settings)) return;
  const { blockedHotels = [] } = await chrome.storage.local.get("blockedHotels");
  const isBlocked = blockedHotels.some(
    (b) => b.source === listing.source && b.hotelName === listing.hotelName && b.destination === listing.destination
  );
  if (isBlocked) return;

  const { favoriteHotels = [] } = await chrome.storage.local.get("favoriteHotels");
  const fav = favoriteHotels.find(
    (f) => f.source === listing.source && f.hotelName === listing.hotelName && f.destination === listing.destination
  );
  const destTarget = (settings.destinationTargets || []).find((t) => t.destination === listing.destination);
  const targetPrice = fav && fav.targetPrice != null ? fav.targetPrice : destTarget ? destTarget.targetPrice : null;
  if (targetPrice == null) return;

  const key = `hist:${listing.source}:${listing.hotelName}:${listing.destination}:${listing.checkin}:${listing.checkout}`;
  const { [key]: existing } = await chrome.storage.local.get(key);
  if (!existing) return; // evaluateAndAlert always writes this first, but guard anyway

  const { shouldAlert, newAlertedState } = evaluateTargetAlert(listing.discountedPrice, targetPrice, existing.targetAlertSent);
  if (newAlertedState !== !!existing.targetAlertSent) {
    await chrome.storage.local.set({ [key]: { ...existing, targetAlertSent: newAlertedState } });
  }
  if (shouldAlert) {
    const reasons = [`\u{1F3AF} Hit your target of ${formatINR(targetPrice)} (${fav && fav.targetPrice != null ? "this hotel's own target" : `${listing.destination} default`})`];
    await logActivity("price_target_hit", { hotelName: listing.hotelName, destination: listing.destination, targetPrice, price: listing.discountedPrice });
    await sendTelegramAlert(listing, reasons, settings);
    if (settings.whatsappEnabled) {
      await sendWhatsAppAlert(listing, reasons, settings);
    }
  }
}

/**
 * PROJECT_BRIEF.md Open Item #14: wires the Rare Deal badge (v1.28.0,
 * shared.js's computeRarityBadge()) into Telegram/WhatsApp, the one
 * major dashboard signal that was still "you'd only ever see it if you
 * looked", same as newly-built/all-time-low used to be before this.
 *
 * Unlike price-target alerts, rarity can't be decided from a single
 * listing mid-scan: computeRarityBadge() compares a hotel's cheapest
 * price against its OWN full history and its real same-tier peers in
 * the same destination, which only exists once loadTrackedHotelGroups()
 * builds the full group list. So this is checked once per finished
 * scan/favorites-refresh (see its call sites in finishScan()/
 * finishFavoriteRefresh()) against the full group list, not once per
 * hotel mid-scan the way checkPriceTargets() is. Costs one extra
 * loadTrackedHotelGroups() pass per finished run, not per hotel.
 *
 * Fire-once/re-arm state lives in its own rareDealAlertState map
 * (groupKey -> true while armed-and-fired), not on a per-date hist:
 * record like price-target alerts use: rarity is a per-HOTEL property
 * (it's about the hotel's cheapest date, which can itself change over
 * time), so tying the flag to one specific date's record would lose it
 * the moment a different date became the cheapest one.
 */
async function checkRareDealAlerts(settings) {
  let groups;
  try {
    groups = await loadTrackedHotelGroups();
  } catch (e) {
    console.log("[rare-deal] could not load tracked groups:", e);
    return;
  }
  const blockedSet = await getBlockedGroupKeys();
  const { rareDealAlertState = {} } = await chrome.storage.local.get("rareDealAlertState");
  const newState = { ...rareDealAlertState };
  let changed = false;

  for (const g of groups) {
    if (blockedSet.has(g.groupKey)) continue;
    const isRareDeal = !!(g.rarity && g.rarity.isRareDeal);
    const wasAlerted = !!rareDealAlertState[g.groupKey];
    const { shouldAlert, newAlertedState } = evaluateRareDealAlert(isRareDeal, wasAlerted);
    if (newAlertedState !== wasAlerted) {
      if (newAlertedState) newState[g.groupKey] = true;
      else delete newState[g.groupKey];
      changed = true;
    }
    if (shouldAlert) {
      const listing = {
        source: g.source,
        hotelName: g.hotelName,
        destination: g.destination,
        checkin: g.cheapest.checkin,
        checkout: g.cheapest.checkout,
        discountedPrice: g.cheapestPrice,
        originalPrice: g.cheapest.originalPrice,
        starRating: g.starRating,
        isNewlyBuilt: g.isNewlyBuilt,
        url: g.cheapest.url,
      };
      const reasons = [`\u{1F48E} Rare deal: ${g.rarity.reasons.join("; ")}`];
      await logActivity("rare_deal_alert", { hotelName: g.hotelName, destination: g.destination, price: g.cheapestPrice, reasons: g.rarity.reasons });
      await notifyDealEvent("rare", listing, reasons, settings, {});
    }
  }

  if (changed) {
    await chrome.storage.local.set({ rareDealAlertState: newState });
  }
}

/**
 * v1.44.8: market deals. After every finished scan (and every helper import)
 * the whole tracked set is compared stay by stay with comparable same-star
 * hotels in the same place on the SAME dates (marketDeals in today.js), so no
 * target price is needed and weekends and holidays are judged like with like.
 * A stay is told about once; it is armed again when it is back near the market,
 * or told about again if it falls a further 10%. At most marketDealDailyMax a
 * day, best first, so the first big scan cannot flood Telegram. A stay already
 * announced today under another alert type is not announced twice.
 */
async function checkMarketDeals(settings) {
  if (isHelper(settings) || settings.alertMarketDeals === false) return { skipped: true };
  const groups = await loadTrackedHotelGroups();
  const blockedSet = await getBlockedGroupKeys();
  const windows = parseHolidayText(settings.holidayText != null ? settings.holidayText : DEFAULT_HOLIDAY_TEXT);
  const nowMs = Date.now();
  const { candidates, evaluated } = marketDeals(groups, blockedSet, nowMs, windows, {
    belowPct: settings.marketDealBelowPct,
    minPeers: settings.marketDealMinPeers,
  });

  const stored = await chrome.storage.local.get(["marketDealState", "dealEvents"]);
  const day = toISODate(new Date(nowMs));
  const prev = stored.marketDealState || {};
  const armed = { ...(prev.armed || {}) }; // stayKey -> {price, at}
  let count = prev.day === day ? prev.count || 0 : 0;
  for (const k of Object.keys(armed)) {
    const parts = k.split("|");
    if (parts[parts.length - 2] < day) delete armed[k]; // the stay is in the past
    else if (evaluated[k] !== undefined && evaluated[k] < MARKET_DEFAULTS.rearmBelowPct) delete armed[k]; // back near the market
  }

  const max = settings.marketDealDailyMax ?? 6;
  const today = (stored.dealEvents || []).filter((e) => nowMs - new Date(e.at).getTime() < 24 * 3600000);
  let announced = 0;
  for (const c of candidates) {
    const was = armed[c.stayKey];
    if (was && c.price >= was.price * 0.9) continue; // told already; only a further 10% drop is news
    const seenToday = today.some((e) => e.hotelName === c.hotelName && e.destination === c.destination && e.checkin === c.checkin);
    if (seenToday) { armed[c.stayKey] = { price: c.price, at: new Date(nowMs).toISOString() }; continue; }
    if (count >= max) break;
    armed[c.stayKey] = { price: c.price, at: new Date(nowMs).toISOString() };
    count++;
    announced++;
    const listing = {
      source: c.source, hotelName: c.hotelName, destination: c.destination, checkin: c.checkin, checkout: c.checkout,
      discountedPrice: c.price, originalPrice: c.originalPrice, starRating: c.starRating, isNewlyBuilt: c.isNewlyBuilt,
      rating: c.rating, reviewCount: c.reviewCount, url: c.url,
    };
    await logActivity("market_deal", { hotelName: c.hotelName, destination: c.destination, price: c.price, belowPeersPct: c.belowPeersPct, peers: c.peerCount });
    await notifyDealEvent("market_deal", listing, marketDealReasons(c), settings, { dropPct: c.belowPeersPct, refPrice: c.peerMedian, holiday: c.holiday });
  }
  await chrome.storage.local.set({ marketDealState: { day, count, armed } });
  return { candidates: candidates.length, announced };
}

/**
 * PROJECT_BRIEF.md Open Item #10, v1.35.0: the dashboard's "Check YouTube
 * popularity" button (dashboard.js) only ever runs when someone happens to
 * have the dashboard open and clicks it, so most tracked hotels sat at
 * "Not checked" forever unless you remembered to go do it by hand. This
 * runs the exact same check/write-back logic automatically once a day via
 * the youtubeAutoCheck alarm, using checkYoutubeForHotel() from shared.js
 * (the same function the manual button calls, since v1.34.0's move of that
 * block out of dashboard.js), so there is only ever one implementation of
 * the matching/scoring rules to keep correct.
 *
 * Batch size (15/day) is my own judgment call, not user-specified: a
 * search.list call is a flat 100 quota units regardless of result count,
 * against a 10,000/day free quota, so 15 automatic checks costs 1,500
 * units and leaves comfortable headroom for manual button clicks the same
 * day. Documented here and in the README rather than assumed obvious.
 *
 * Same never-checked-first-then-oldest priority as the manual button, and
 * the same "mark it checked even with a zero-result match" behavior, so a
 * hotel with genuinely no video coverage doesn't get retried ahead of ones
 * that have never been checked at all.
 */
async function runAutomaticYoutubeCheck() {
  const { settings = {} } = await chrome.storage.local.get("settings");
  if (isHelper(settings)) return;
  const apiKey = settings?.youtubeApiKey || "";
  if (!apiKey) {
    console.log("[youtube-auto] no YouTube API key configured, skipping automatic check.");
    return;
  }

  let groups;
  try {
    groups = await loadTrackedHotelGroups();
  } catch (e) {
    console.log("[youtube-auto] could not load tracked groups:", e);
    return;
  }
  const blockedSet = await getBlockedGroupKeys();
  const visible = groups.filter((g) => !blockedSet.has(g.groupKey));

  const AUTO_YOUTUBE_BATCH_SIZE = 15;
  const prioritized = visible.slice().sort((a, b) => {
    const at = a.youtubeCheckedAt ? new Date(a.youtubeCheckedAt).getTime() : 0;
    const bt = b.youtubeCheckedAt ? new Date(b.youtubeCheckedAt).getTime() : 0;
    return at - bt;
  });
  const batch = prioritized.slice(0, AUTO_YOUTUBE_BATCH_SIZE);
  if (batch.length === 0) {
    console.log("[youtube-auto] nothing tracked to check.");
    return;
  }

  let checked = 0;
  let matched = 0;
  for (const g of batch) {
    try {
      const result = await checkYoutubeForHotel(g.hotelName, g.destination, apiKey);
      if (result.totalViews !== null) {
        matched++;
        for (const d of g.dates) {
          const { [d.key]: existing } = await chrome.storage.local.get(d.key);
          if (existing) {
            await chrome.storage.local.set({
              [d.key]: {
                ...existing,
                youtubeViews: result.totalViews,
                youtubeVideoCount: result.videoCount,
                youtubeVideoTitle: result.topTitle,
                youtubeVideoUrl: result.topUrl,
                youtubeTopShort: result.topShort,
                youtubeTopLong: result.topLong,
                youtubeShorts: result.shorts,
                youtubeLongForm: result.longForm,
                youtubeCheckedAt: new Date().toISOString(),
              },
            });
          }
        }
      } else {
        for (const d of g.dates) {
          const { [d.key]: existing } = await chrome.storage.local.get(d.key);
          if (existing) {
            await chrome.storage.local.set({
              [d.key]: { ...existing, youtubeCheckedAt: new Date().toISOString() },
            });
          }
        }
      }
      checked++;
    } catch (e) {
      console.log(`[youtube-auto] stopped early after ${checked}/${batch.length}:`, e.message);
      break;
    }
    // Same pacing as the manual button, no reason to hammer the API back
    // to back even though nobody is watching a status line this time.
    await new Promise((r) => setTimeout(r, 300));
  }

  console.log(`[youtube-auto] checked ${checked} hotel(s), ${matched} had a genuine match.`);
  await logActivity("youtube_auto_check", { checked, matched, batchSize: batch.length });
}

/**
 * WhatsApp Cloud API send, scaffolded for price-target alerts only (see
 * "both" in the alert-channel decision). SCAFFOLD, not verified live:
 * this sandbox has no network access to graph.facebook.com. One real
 * limitation worth knowing before relying on this: the Cloud API only
 * allows a free-form text message like this one within 24 hours of the
 * recipient last messaging your business number first ("the customer
 * service window"). Outside that window, WhatsApp silently rejects it
 * unless you send a pre-approved message template instead. For a
 * fully hands-off alert (no need to text the bot every day to keep the
 * window open), create a template in Meta Business Manager and switch
 * this function to the template send format
 * (type: "template", template: {name, language, components}) once
 * you've got one approved, rather than the free-form body used here.
 */
// ---------------------------------------------------------------------------
// Deal events + subscribers (the paid-alerts layer)
// ---------------------------------------------------------------------------

// Serializes every read-modify-write of dealEvents/subscribers/alertQueue:
// up to 3 scan windows can finish at once and would otherwise overwrite
// each other's updates to the same storage key.
let dealLock = Promise.resolve();
function withDealLock(fn) {
  const run = dealLock.then(fn, fn);
  dealLock = run.catch(() => {});
  return run;
}

/**
 * The one entry point for "something worth telling people about
 * happened": records it in the feed (dashboard + public deals.json),
 * tells the owner as before, then routes it to subscribers by plan.
 */
async function notifyDealEvent(type, listing, reasons, settings, extra = {}) {
  // A helper computer never sends anything: it records the event, the main
  // computer imports it and announces it (see syncHelpers).
  if (isHelper(settings)) {
    const ev = makeDealEvent(type, listing, reasons, extra);
    await withDealLock(() => recordDealEvent(ev));
    await logActivity("helper_event_recorded", { type, hotelName: ev.hotelName, price: ev.price });
    return;
  }
  // Weather for the stay (Open-Meteo, free). Failure just means no line.
  try {
    const w = await weatherLineFor(listing.destination, listing.checkin, listing.checkout);
    if (w) reasons = [...reasons, w];
  } catch (e) { /* no forecast, carry on */ }
  const event = makeDealEvent(type, listing, reasons, extra);

  // Confirm before alerting: a deal worth telling people about gets its
  // detail page re-checked a few minutes later, so a misread price (a
  // coupon banner, a stale card) never turns into a fake alert. Queued in
  // storage and drained by the confirmDrain alarm, so it survives the
  // service worker being recycled in between.
  if (settings.confirmBeforeAlert === true && listing.url && needsConfirmation(event)) {
    const dueAt = Date.now() + (settings.confirmDelayMinutes || 10) * 60000;
    await withDealLock(async () => {
      const { pendingConfirmations = [] } = await chrome.storage.local.get("pendingConfirmations");
      const rest = pendingConfirmations.filter((p) => p.event.id !== event.id);
      rest.push({ event, listing, reasons, dueAt, queuedAt: Date.now() });
      await chrome.storage.local.set({ pendingConfirmations: rest.slice(-30) });
    });
    await logActivity("deal_awaiting_confirmation", { hotelName: event.hotelName, price: event.price, type });
    return;
  }
  await deliverDealEvent(event, listing, reasons, settings);
}

/**
 * Re-checks queued deals that are due. Runs every minute. Waits while a
 * scan is running (a second window at the same time is what gets us
 * blocked) unless the deal has waited 30+ minutes, in which case it is
 * sent flagged as unverified rather than lost.
 */
let confirmInFlight = false;
async function processConfirmations(nowMs = Date.now()) {
  if (confirmInFlight) return;
  confirmInFlight = true;
  try {
    await processConfirmationsBody(nowMs);
  } finally {
    confirmInFlight = false;
  }
}

async function processConfirmationsBody(nowMs) {
  if (isHelper(await getSettings())) return;
  const { pendingConfirmations = [], scanProgress } = await chrome.storage.local.get(["pendingConfirmations", "scanProgress"]);
  const due = pendingConfirmations.filter((p) => p.dueAt <= nowMs);
  if (due.length === 0) return;
  const scanBusy = !!(scanProgress && scanProgress.running);
  const settings = await getSettings();

  for (const p of due) {
    const overdue = nowMs - p.dueAt > 30 * 60000;
    if (scanBusy && !overdue) continue;
    let verdict = "unverified";
    if (!scanBusy) {
      try {
        const r = await checkRoomDetail(p.listing.url, 20000, "confirm");
        verdict = confirmDecision(p.event.price, r.lowest);
      } catch (e) {
        verdict = "unverified";
      }
    }
    await withDealLock(async () => {
      const { pendingConfirmations: cur = [] } = await chrome.storage.local.get("pendingConfirmations");
      await chrome.storage.local.set({ pendingConfirmations: cur.filter((x) => x.event.id !== p.event.id) });
    });
    await logActivity("deal_confirmation", { hotelName: p.event.hotelName, price: p.event.price, verdict });
    if (verdict === "cancel") continue;
    const reasons = verdict === "unverified" ? [...p.reasons, "⚠ Could not re-verify, check the price before booking"] : [...p.reasons, "✓ Re-checked a few minutes later, price holds"];
    await deliverDealEvent({ ...p.event, reasons }, p.listing, reasons, settings);
  }
}

async function deliverDealEvent(event, listing, reasons, settings) {
  const type = event.type;
  await withDealLock(() => recordDealEvent(event));
  await logActivity("deal_event", { type, hotelName: event.hotelName, destination: event.destination, price: event.price, dropPct: event.dropPct, leadDays: event.leadDays });
  await sendTelegramAlert(listing, reasons, settings, OWNER_HEADLINES[type] || null);
  if (settings.whatsappEnabled && (type === "last_minute" || type === "rare" || type === "record_low")) {
    await sendWhatsAppAlert(listing, reasons, settings);
  }
  try {
    await postToChannel(event, settings);
  } catch (e) {
    console.log("[channel] post failed:", e);
    await logActivity("channel_post_failed", { error: String(e) });
  }
  try {
    await dispatchToSubscribers(event, settings);
  } catch (e) {
    console.log("[subscribers] dispatch failed:", e);
    await logActivity("subscriber_dispatch_failed", { error: String(e) });
  }
}

/**
 * Posts GREAT deals (see isGreatDeal in intel.js) to the public Telegram
 * channel, with a daily cap so the channel stays worth following. The
 * channel is the main way people subscribe: no per-person state, no
 * sign-up flow, Telegram handles joins and leaves. Needs the bot added to
 * the channel as an admin with permission to post.
 */
async function postToChannel(event, settings) {
  if (!settings.channelChatId || !settings.telegramBotToken) return;
  if (!isGreatDeal(event, { greatDealMinDropPct: settings.greatDealMinDropPct, channelMaxPerDay: settings.channelMaxPerDay })) return;
  await withDealLock(async () => {
    const { channelPostState } = await chrome.storage.local.get("channelPostState");
    const d = channelPostDecision(event, channelPostState, Date.now(), { channelMaxPerDay: settings.channelMaxPerDay });
    if (!d.post) {
      await logActivity("channel_post_skipped", { reason: d.reason, hotelName: event.hotelName });
      return;
    }
    // "Alert me if it drops more" button (needs the sign-up bot on, since the
    // watch is registered when the person presses Start in the bot).
    let extra = {};
    if (settings.subscriberBotEnabled) {
      const bot = await getBotUsername(settings);
      if (bot) {
        const code = shortCode(groupKeyOf(event));
        const { watchCodes = {} } = await chrome.storage.local.get("watchCodes");
        watchCodes[code] = { groupKey: groupKeyOf(event), hotelName: event.hotelName, destination: event.destination, checkin: event.checkin, price: event.price };
        const keys = Object.keys(watchCodes);
        for (const k of keys.slice(0, Math.max(0, keys.length - 300))) delete watchCodes[k];
        await chrome.storage.local.set({ watchCodes });
        extra = { reply_markup: { inline_keyboard: [[{ text: "🔔 Alert me if it drops more", url: `https://t.me/${bot}?start=w_${code}` }]] } };
      }
    }
    const r = await sendTelegramText(settings, settings.channelChatId, formatChannelPost(event), extra);
    if (r.ok) {
      await chrome.storage.local.set({ channelPostState: d.newState });
      await logActivity("channel_posted", { type: event.type, hotelName: event.hotelName, destination: event.destination, price: event.price });
    } else {
      await logActivity("channel_post_failed", { status: r.status, hint: r.status === 400 || r.status === 403 ? "Is the bot an admin of the channel, and is the channel id or @name right?" : undefined });
    }
  });
}

/** Sends plain text to one Telegram chat. Returns {ok, status}. */
async function sendTelegramText(settings, chatId, text, extra = {}) {
  if (!settings.telegramBotToken) return { ok: false, status: 0 };
  try {
    const resp = await fetch(`https://api.telegram.org/bot${settings.telegramBotToken}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text, ...extra }),
    });
    return { ok: resp.ok, status: resp.status };
  } catch (e) {
    return { ok: false, status: 0 };
  }
}

async function dispatchToSubscribers(event, settings) {
  if (!settings.telegramBotToken) return;
  await withDealLock(async () => {
    const { subscribers = [], alertQueue = [] } = await chrome.storage.local.get(["subscribers", "alertQueue"]);
    if (subscribers.length === 0) return;
    const nowMs = Date.now();
    const queue = [...alertQueue];
    let changed = false;
    for (const sub of subscribers) {
      const d = planDecision(sub, event, nowMs, { plansEnabled: settings.plansEnabled });
      if (d.action === "skip") continue;
      sub.sent = d.newSent;
      changed = true;
      if (d.action === "teaser") {
        const r = await sendTelegramText(settings, sub.telegramChatId, formatTeaserMessage(event, settings.upgradeUrl));
        if (r.status === 403) sub.active = false;
        continue;
      }
      const text = formatDealMessage(event, { delayed: d.delayed });
      if (d.sendAfterMs <= nowMs) {
        const r = await sendTelegramText(settings, sub.telegramChatId, text);
        if (r.status === 403) sub.active = false; // they blocked the bot
        if (r.ok) sub.lastSentAt = new Date().toISOString();
        else if (r.status !== 403) await logActivity("subscriber_send_failed", { subId: sub.id, status: r.status });
      } else {
        queue.push({ subId: sub.id, chatId: sub.telegramChatId, text, sendAfter: d.sendAfterMs, eventId: event.id });
      }
    }
    if (changed) await chrome.storage.local.set({ subscribers, alertQueue: queue.slice(-1000) });
  });
}

/** Sends delayed (free-plan) alerts once they're due. Runs every minute. */
async function drainAlertQueue() {
  if (isHelper(await getSettings())) return;
  const { alertQueue = [] } = await chrome.storage.local.get("alertQueue");
  if (alertQueue.length === 0) return;
  const nowMs = Date.now();
  if (!alertQueue.some((q) => q.sendAfter <= nowMs)) return;
  const settings = await getSettings();
  await withDealLock(async () => {
    const { alertQueue: fresh = [], subscribers = [] } = await chrome.storage.local.get(["alertQueue", "subscribers"]);
    const keep = [];
    for (const q of fresh) {
      if (q.sendAfter > nowMs) { keep.push(q); continue; }
      const sub = subscribers.find((s) => s.id === q.subId);
      if (!sub || !sub.active) continue;
      const r = await sendTelegramText(settings, q.chatId, q.text);
      if (r.status === 403) sub.active = false;
      else if (r.ok) sub.lastSentAt = new Date().toISOString();
    }
    await chrome.storage.local.set({ alertQueue: keep, subscribers });
  });
}

/**
 * Subscriber sign-up via the same Telegram bot (opt-in: settings.
 * subscriberBotEnabled). Anyone who messages the bot with /start becomes
 * a Free subscriber; the owner upgrades them from the dashboard's
 * Business tab. Uses getUpdates (no server needed), so this only works
 * while no webhook is set on the bot.
 */
async function pollSubscriberBot() {
  const settings = await getSettings();
  if (isHelper(settings)) return;
  if (!settings.subscriberBotEnabled || !settings.telegramBotToken) return;
  const { tgUpdateOffset = 0 } = await chrome.storage.local.get("tgUpdateOffset");
  let data;
  try {
    const resp = await fetch(`https://api.telegram.org/bot${settings.telegramBotToken}/getUpdates?offset=${tgUpdateOffset}&timeout=0&allowed_updates=%5B%22message%22%5D`);
    if (!resp.ok) return;
    data = await resp.json();
  } catch (e) {
    return;
  }
  for (const u of data.result || []) {
    const msg = u.message;
    const watchHandled = msg && msg.chat && msg.chat.type === "private" && typeof msg.text === "string"
      ? await handleWatchCommand(msg.text, String(msg.chat.id), [msg.from && msg.from.first_name, msg.from && msg.from.last_name].filter(Boolean).join(" ").slice(0, 60), settings)
      : false;
    if (!watchHandled && msg && msg.chat && msg.chat.type === "private" && typeof msg.text === "string" && String(msg.chat.id) !== String(settings.telegramChatId)) {
      await withDealLock(async () => {
        const { subscribers = [] } = await chrome.storage.local.get("subscribers");
        const chatId = String(msg.chat.id);
        let sub = subscribers.find((s) => s.id === chatId);
        const { reply, patch } = subscriberCommandReply(msg.text, sub || null, { planPrices: settings.planPrices, upgradeUrl: settings.upgradeUrl, plansEnabled: settings.plansEnabled });
        if (!sub) {
          sub = {
            id: chatId, telegramChatId: chatId, plan: "free", active: true, destinations: [], maxPrice: null,
            name: [msg.from && msg.from.first_name, msg.from && msg.from.last_name].filter(Boolean).join(" ").slice(0, 60) || chatId,
            createdAt: new Date().toISOString(), source: "bot",
          };
          subscribers.push(sub);
          await logActivity("subscriber_joined", { subId: chatId });
        }
        Object.assign(sub, patch);
        await chrome.storage.local.set({ subscribers });
        await sendTelegramText(settings, chatId, reply);
      });
    }
    await chrome.storage.local.set({ tgUpdateOffset: u.update_id + 1 });
  }
}

// ---------------------------------------------------------------------------
// v1.39: watches, weather, morning digest, missing hotels, passive collection
// ---------------------------------------------------------------------------

const groupKeyOf = (o) => `${o.source}:::${o.hotelName}:::${o.destination}`;

/** The bot's @username (needed for t.me deep links), fetched once and cached. */
async function getBotUsername(settings) {
  const { botUsername } = await chrome.storage.local.get("botUsername");
  if (botUsername) return botUsername;
  if (!settings.telegramBotToken) return null;
  try {
    const resp = await fetch(`https://api.telegram.org/bot${settings.telegramBotToken}/getMe`);
    const data = await resp.json();
    if (data.ok && data.result && data.result.username) {
      await chrome.storage.local.set({ botUsername: data.result.username });
      return data.result.username;
    }
  } catch (e) { /* offline, try next time */ }
  return null;
}

/**
 * "Alert me if it drops more" buttons under channel posts open the bot with
 * /start w_<code>; pollSubscriberBot() turns that into a watch on that exact
 * stay at that price. This is where a later, lower price on it is noticed.
 */
async function checkWatches(listing, settings) {
  const { watches = [] } = await chrome.storage.local.get("watches");
  if (watches.length === 0) return;
  const gk = groupKeyOf(listing);
  if (!watches.some((w) => w.groupKey === gk && !w.dead && watchTriggered(w, listing.discountedPrice, listing.checkin))) return;
  await withDealLock(async () => {
    const { watches: cur = [] } = await chrome.storage.local.get("watches");
    let changed = false;
    for (const w of cur) {
      if (w.groupKey !== gk || w.dead || !watchTriggered(w, listing.discountedPrice, listing.checkin)) continue;
      const text = [
        `\u{1F514} Price drop on a hotel you are watching`,
        `\u{1F3E8} ${listing.hotelName} (${listing.destination})`,
        `\u{1F4C5} ${listing.checkin} to ${listing.checkout}`,
        `\u{1F4B0} ${formatINR(w.basePrice)} -> ${formatINR(listing.discountedPrice)}`,
        listing.url || "",
      ].filter(Boolean).join("\n");
      const r = await sendTelegramText(settings, w.chatId, text);
      if (r.status === 403) w.dead = true;
      w.basePrice = listing.discountedPrice;
      w.lastAlertAt = new Date().toISOString();
      changed = true;
    }
    if (changed) await chrome.storage.local.set({ watches: cur });
  });
}

/** /start w_<code>, /mywatches and /unwatch from the bot. Returns true if it handled the message. */
async function handleWatchCommand(text, chatId, name, settings) {
  const m = /^\/start(?:@\w+)?\s+w_([a-z0-9]+)/i.exec(text);
  const isList = /^\/mywatches\b/i.test(text);
  const isUnwatch = /^\/unwatch\b/i.test(text);
  if (!m && !isList && !isUnwatch) return false;
  await withDealLock(async () => {
    const { watches = [], watchCodes = {}, subscribers = [] } = await chrome.storage.local.get(["watches", "watchCodes", "subscribers"]);
    if (m) {
      const info = watchCodes[m[1].toLowerCase()];
      if (!info) {
        await sendTelegramText(settings, chatId, "That deal link has expired. Open a newer post in the channel and tap the button again.");
        return;
      }
      if (!subscribers.some((s) => s.id === chatId)) {
        subscribers.push({ id: chatId, telegramChatId: chatId, plan: "free", active: true, destinations: [], maxPrice: null, name: name || chatId, createdAt: new Date().toISOString(), source: "bot" });
      }
      const rest = watches.filter((w) => !(w.chatId === chatId && w.groupKey === info.groupKey && w.checkin === info.checkin));
      rest.push({ chatId, groupKey: info.groupKey, hotelName: info.hotelName, destination: info.destination, checkin: info.checkin, basePrice: info.price, createdAt: new Date().toISOString() });
      await chrome.storage.local.set({ watches: rest.slice(-500), subscribers });
      await sendTelegramText(settings, chatId, `\u{1F514} Watching ${info.hotelName} (${info.destination}, ${info.checkin}) from ${formatINR(info.price)}. I will message you if it drops below ${formatINR(Math.floor(info.price * 0.97))}.\n\nSend /mywatches to see your watches, /unwatch to stop them all.`);
    } else if (isList) {
      const mine = watches.filter((w) => w.chatId === chatId && !w.dead);
      await sendTelegramText(settings, chatId, mine.length ? "Your watches:\n" + mine.map((w) => `• ${w.hotelName} (${w.checkin}) from ${formatINR(w.basePrice)}`).join("\n") : "You are not watching any hotels yet. Tap the button under a deal in the channel.");
    } else {
      await chrome.storage.local.set({ watches: watches.filter((w) => w.chatId !== chatId) });
      await sendTelegramText(settings, chatId, "All your watches are removed.");
    }
  });
  return true;
}

// --- weather ---

async function weatherLineFor(destination, checkin, checkout) {
  const coords = DESTINATION_COORDS[String(destination).toLowerCase()];
  if (!coords) return "";
  const { weatherCache = {} } = await chrome.storage.local.get("weatherCache");
  let entry = weatherCache[destination];
  if (!entry || Date.now() - entry.at > 3 * 3600000) {
    const resp = await fetch(openMeteoUrl(coords[0], coords[1]));
    if (!resp.ok) return "";
    entry = { at: Date.now(), days: parseOpenMeteo(await resp.json()) };
    weatherCache[destination] = entry;
    await chrome.storage.local.set({ weatherCache });
  }
  return weatherNote(entry.days, checkin, checkout);
}

// --- 8am digest ---

/**
 * One clean post a day with the best-value stays for the coming weekend, to
 * the channel and to you. Checked every 30 minutes rather than scheduled at
 * exactly 8:00, so a PC that was off at 8 still posts when Chrome opens.
 */
async function runMorningDigest() {
  const settings = await getSettings();
  if (isHelper(settings)) return;
  if (settings.digestEnabled === false || !settings.telegramBotToken) return;
  if (!settings.channelChatId && !settings.telegramChatId) return;
  const now = new Date();
  if (now.getHours() < (settings.digestHour ?? 8) || now.getHours() >= 20) return;
  const day = toISODate(now);
  const { lastDigestDay } = await chrome.storage.local.get("lastDigestDay");
  if (lastDigestDay === day) return;
  const groups = await loadTrackedHotelGroups();
  const blocked = await getBlockedGroupKeys();
  const weekend = upcomingWeekends(settings.nights, settings.checkinWeekday, 14, now)[0];
  if (!weekend) return;
  // v1.44.0: built from the same buildToday() picks as the dashboard's Today
  // tab and the popup (junk and unverified prices filtered, price drops first,
  // each with its reason and a booking link), so the phone and the screen never
  // disagree. The public channel gets the same picks without the personal
  // "to film" line.
  const state = await chrome.storage.local.get(["lastFullScanAt", "siteCooldown", "scanProgress"]);
  const today = buildToday({ groups, blocked, settings, state, nowMs: now.getTime() });
  const ownerText = formatTodayDigest(today);
  if (!ownerText) return;
  const channelText = formatTodayDigest(today, { film: false });
  if (settings.channelChatId && channelText) await sendTelegramText(settings, settings.channelChatId, channelText);
  if (settings.telegramChatId) await sendTelegramText(settings, settings.telegramChatId, ownerText);
  await chrome.storage.local.set({ lastDigestDay: day });
  await logActivity("morning_digest_posted", { weekend: weekend.checkin, picks: today.book[0].picks.length, drops: today.book[0].deals });
}

// --- missing hotels: pause after a week, stop after ~5 weeks ---

async function reconcileMissingHotels(settings) {
  const groups = await loadTrackedHotelGroups();
  const { blockedHotels = [], missingIgnore = {}, favoriteHotels = [], goldHotels = {} } = await chrome.storage.local.get(["blockedHotels", "missingIgnore", "favoriteHotels", "goldHotels"]);
  const favs = new Set(favoriteHotels.map(groupKeyOf));
  const nowMs = Date.now();
  let paused = 0, stopped = 0;
  const list = [...blockedHotels];
  for (const g of groups) {
    if (favs.has(g.groupKey) || goldHotels[g.groupKey]) continue; // hotels you care about are never auto-removed
    const dest = settings.destinations.find((d) => d.name === g.destination);
    const recent = !!(dest && dest.lastScannedAt && nowMs - new Date(dest.lastScannedAt).getTime() < 3 * 86400000);
    const seen = g.dates.map((d) => new Date(d.updatedAt).getTime()).filter((n) => Number.isFinite(n));
    if (seen.length === 0) continue;
    const stage = missingStage(Math.max(...seen), nowMs, recent);
    const entry = list.find((b) => groupKeyOf(b) === g.groupKey);
    if (entry) {
      if (entry.via === "missing-paused" && stage === "stopped") { entry.via = "missing-stopped"; stopped++; }
      continue;
    }
    if (stage === "active") continue;
    if (missingIgnore[g.groupKey] && nowMs - new Date(missingIgnore[g.groupKey]).getTime() < 90 * 86400000) continue; // restored by hand recently
    list.push({ source: g.source, hotelName: g.hotelName, destination: g.destination, blockedAt: new Date().toISOString(), via: stage === "stopped" ? "missing-stopped" : "missing-paused", lastSeen: new Date(Math.max(...seen)).toISOString() });
    if (stage === "stopped") stopped++; else paused++;
  }
  if (paused || stopped) {
    await chrome.storage.local.set({ blockedHotels: list });
    await logActivity("missing_hotels_reconciled", { paused, stopped });
  }
}

// --- passive collection: prices from your own browsing ---

/**
 * content.js reports what it scrapes on ANY MakeMyTrip listing page, including
 * the ones you open yourself. When there is no scan window waiting for it,
 * those prices are ingested like a scan result: free data from a real
 * session that can't be blocked.
 */
async function passiveIngest(message, sender) {
  const settings = await getSettings();
  if (settings.passiveCollect === false || scanStepInFlight) return;
  const listings = message.listings || [];
  if (listings.length < 3) return;
  let code = null;
  try {
    const u = new URL((message.debug && message.debug.url) || (sender.tab && sender.tab.url) || "");
    if (!/makemytrip\.com$/.test(u.hostname)) return;
    code = u.searchParams.get("city") || u.searchParams.get("locusId");
  } catch (e) { return; }
  const dest = settings.destinations.find((d) => d.mmtCode && d.mmtCode === code);
  if (!dest) return;
  const shown = message.debug && message.debug.displayedDates;
  const checkin = shown && shown.checkin, checkout = shown && shown.checkout;
  if (!checkin || !checkout) return;
  const { stepFreshness = {} } = await chrome.storage.local.get("stepFreshness");
  const key = stepKey({ site: "makemytrip", destinationName: dest.name, checkin });
  if (stepFreshness[key] && Date.now() - stepFreshness[key] < 30 * 60000) return; // just collected, a page refresh is not new data
  let count = 0;
  for (const l of listings) {
    if (l.starRating != null && l.starRating < settings.minStarRating) continue;
    await evaluateAndAlert({ ...l, destination: dest.name, checkin, checkout, requestedCheckin: checkin }, settings);
    count++;
  }
  stepFreshness[key] = Date.now();
  await chrome.storage.local.set({ stepFreshness });
  await logActivity("passive_collected", { destination: dest.name, checkin, count });
}

/** Slightly different window each time, inside the footprint reconcileOrphanedWindows() recognises. */
function randomWindowGeometry() {
  const r = (a, b) => Math.round(a + Math.random() * (b - a));
  return { left: r(10, 70), top: r(10, 70), width: r(1040, 1160), height: r(700, 800) };
}

// ---------------------------------------------------------------------------
// v1.40: helper computer. A second PC runs the same extension with
// deviceRole "helper": it scans only its share of destinations and uploads
// what it found to helper/<name>.json in your GitHub repo. The main PC
// imports those files (price history is merged point by point), and it is
// the one that sends every alert, so subscribers, the channel and the
// confirm-before-alert check all behave the same no matter which computer
// found the deal. The main PC also writes helper/_shared.json (destinations
// with their learned codes, removed and Gold hotels, thresholds, no
// credentials) which the helper reads, so it needs no setup beyond the
// GitHub token and repo.
// ---------------------------------------------------------------------------

const isHelper = (settings) => settings && settings.deviceRole === "helper";

async function setHelperStatus(patch) {
  const { helperStatus = {} } = await chrome.storage.local.get("helperStatus");
  await chrome.storage.local.set({ helperStatus: { ...helperStatus, ...patch } });
}

/** Helper: send the last 3 days of changes to GitHub. */
async function uploadHelperData(settings) {
  if (!isHelper(settings)) return { status: "not_helper" };
  if (!settings.githubToken || !settings.githubRepo) return { status: "no_github" };
  const all = await chrome.storage.local.get(null);
  const payload = buildHelperPayload(all, settings.deviceName, Date.now());
  const n = Object.keys(payload.records).length;
  if (n === 0 && payload.events.length === 0) return { status: "nothing_new" };
  try {
    await githubPutFile(settings.githubRepo, `helper/${payload.device}.json`, JSON.stringify(payload), `Helper ${payload.device} data`, settings.githubToken);
    await setHelperStatus({ lastUploadAt: payload.uploadedAt, lastUploadRecords: n, lastUploadEvents: payload.events.length, error: null });
    await logActivity("helper_uploaded", { device: payload.device, records: n, events: payload.events.length });
    return { status: "uploaded", records: n, events: payload.events.length };
  } catch (e) {
    await setHelperStatus({ error: String(e.message || e) });
    await logActivity("helper_upload_failed", { error: String(e) });
    return { status: "error", error: String(e.message || e) };
  }
}

/** Helper: read the main computer's shared state and apply it. */
async function pullSharedState(settings) {
  if (!isHelper(settings) || !settings.githubToken || !settings.githubRepo) return { status: "skipped" };
  try {
    const text = await githubGetFileRaw(settings.githubRepo, "helper/_shared.json", settings.githubToken);
    if (!text) return { status: "no_shared_state", hint: "The main computer has not written it yet. Turn on 'I use a helper computer' there." };
    const shared = JSON.parse(text);
    const current = await getSettings();
    await saveSettings(applySharedState(current, shared));
    await chrome.storage.local.set({ blockedHotels: shared.blockedHotels || [], goldHotels: shared.goldHotels || {} });
    await setHelperStatus({ lastPullAt: new Date().toISOString(), sharedWrittenAt: shared.writtenAt, error: null });
    return { status: "pulled", destinations: (shared.destinations || []).length };
  } catch (e) {
    await setHelperStatus({ error: String(e.message || e) });
    return { status: "error", error: String(e.message || e) };
  }
}

/** Main: write the shared state (only when it changed) and import every helper's upload. */
let helperSyncInFlight = false;
async function syncHelpers() {
  if (helperSyncInFlight) return { status: "busy" };
  helperSyncInFlight = true;
  try {
    const settings = await getSettings();
    if (isHelper(settings) || !settings.helpersEnabled) return { status: "disabled" };
    if (!settings.githubToken || !settings.githubRepo) return { status: "no_github" };
    const token = settings.githubToken, repo = settings.githubRepo;
    const stored = await chrome.storage.local.get(["blockedHotels", "goldHotels", "helperImported", "importedEventIds", "sharedHash"]);

    // 1. share state, only when it changed
    const shared = buildSharedState(settings, stored.blockedHotels, stored.goldHotels);
    const { writtenAt, ...stable } = shared;
    const hash = shortCode(JSON.stringify(stable));
    if (hash !== stored.sharedHash) {
      await githubPutFile(repo, "helper/_shared.json", JSON.stringify(shared), "Share state with helper computers", token);
      await chrome.storage.local.set({ sharedHash: hash });
    }

    // 2. import helper uploads
    const files = (await githubListDir(repo, "helper", token)).filter((f) => f.type === "file" && f.name.endsWith(".json") && !f.name.startsWith("_"));
    const imported = { ...(stored.helperImported || {}) };
    let knownIds = stored.importedEventIds || [];
    const summary = [];
    for (const f of files) {
      if (imported[f.name] && imported[f.name].sha === f.sha) continue;
      const text = await githubGetFileRaw(repo, f.path, token);
      if (!text) continue;
      const payload = JSON.parse(text);

      // price history: merge point by point with what is already here
      const keys = Object.keys(payload.records || {});
      const local = keys.length ? await chrome.storage.local.get(keys) : {};
      const merged = {};
      for (const k of keys) merged[k] = mergeHistRecords(local[k], payload.records[k]);
      if (keys.length) await chrome.storage.local.set(merged);

      // events: announce fresh ones through the normal path, record the rest quietly
      const blocked = new Set((stored.blockedHotels || []).map(groupKeyOf));
      const { dealEvents = [] } = await chrome.storage.local.get("dealEvents");
      const plan = planEventImport(payload.events, [...knownIds, ...dealEvents.map((e) => e.id)], blocked, Date.now());
      for (const e of plan.announce) {
        await notifyDealEvent(e.type, listingFromEvent(e), e.reasons || [], settings, { dropPct: e.dropPct, refPrice: e.refPrice, leadDays: e.leadDays, fairPrice: e.fairPrice, holiday: e.holiday });
      }
      for (const e of plan.silent) await withDealLock(() => recordDealEvent(e));
      knownIds = [...knownIds, ...plan.announce.map((e) => e.id), ...plan.silent.map((e) => e.id)].slice(-1000);

      imported[f.name] = { sha: f.sha, at: new Date().toISOString(), device: payload.device, records: keys.length, announced: plan.announce.length };
      summary.push({ device: payload.device, records: keys.length, announced: plan.announce.length });
      await logActivity("helper_imported", { device: payload.device, records: keys.length, announced: plan.announce.length });
    }
    await chrome.storage.local.set({ helperImported: imported, importedEventIds: knownIds });
    // New prices from a helper change the market: judge the merged data the same way a finished scan here does.
    if (summary.length) {
      try {
        await checkRareDealAlerts(settings);
        await checkMarketDeals(settings);
      } catch (e) {
        await logActivity("market_deal_check_failed", { error: String(e), after: "helper_import" });
      }
    }
    await setHelperStatus({ lastSyncAt: new Date().toISOString(), error: null, devices: Object.values(imported) });
    return { status: "synced", imported: summary, files: files.length };
  } catch (e) {
    await setHelperStatus({ error: String(e.message || e) });
    await logActivity("helper_sync_failed", { error: String(e) });
    return { status: "error", error: String(e.message || e) };
  } finally {
    helperSyncInFlight = false;
  }
}

// ---------------------------------------------------------------------------
// v1.44.2: publish this extension's own files so other computers can update.
// The main PC keeps extension/update.zip + extension/version.json in the GitHub
// repo current; tools/update-extension.ps1 on the other computer polls
// version.json hourly and copies the new files over its folder (Chrome cannot
// do that itself). The zip goes up first and version.json last, so nobody ever
// sees a version whose zip is not there yet.
// ---------------------------------------------------------------------------

async function setExtPublishStatus(patch) {
  const { extPublishStatus = {} } = await chrome.storage.local.get("extPublishStatus");
  await chrome.storage.local.set({ extPublishStatus: { ...extPublishStatus, ...patch, checkedAt: new Date().toISOString() } });
}

let extPublishInFlight = false;
async function publishExtensionUpdate(settings, { force = false } = {}) {
  if (isHelper(settings)) return { status: "helper" };
  if (settings.publishExtensionUpdates === false && !force) return { status: "disabled" };
  if (!settings.githubToken || !settings.githubRepo) return { status: "no_github" };
  if (extPublishInFlight) return { status: "busy" };
  extPublishInFlight = true;
  const repo = settings.githubRepo, token = settings.githubToken;
  try {
    const readBytes = async (p) => {
      const r = await fetch(chrome.runtime.getURL(p) + "?t=" + Date.now(), { cache: "no-store" });
      if (!r.ok) throw new Error(`cannot read ${p} (${r.status})`);
      return new Uint8Array(await r.arrayBuffer());
    };
    const readText = async (p) => new TextDecoder("utf-8").decode(await readBytes(p));

    // Only publish what is actually running: if the folder holds a newer
    // version than the loaded one, the 30-second self-reload is about to fire.
    const version = JSON.parse(await readText("manifest.json")).version;
    if (version !== chrome.runtime.getManifest().version) {
      await setExtPublishStatus({ state: "reload_pending", error: null });
      return { status: "reload_pending", version };
    }

    let remoteVersion = null;
    try { remoteVersion = JSON.parse(await githubGetFileRaw(repo, "extension/version.json", token)).version; } catch (e) { /* none yet */ }
    if (!force && remoteVersion === version) {
      await setExtPublishStatus({ state: "current", version, error: null });
      return { status: "current", version };
    }

    const names = await collectExtensionFiles(readText);
    const entries = [];
    for (const name of names) entries.push({ name, data: await readBytes(name) });
    const zip = await buildZip(entries, { compress: typeof CompressionStream === "function" ? deflateRawBytes : null });
    const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", zip));
    const sha256 = [...digest].map((b) => b.toString(16).padStart(2, "0")).join("");

    await githubPutBase64(repo, "extension/update.zip", bytesToBase64(zip), `Extension ${version}`, token);
    const info = { version, publishedAt: new Date().toISOString(), files: names.length, bytes: zip.length, sha256 };
    await githubPutFile(repo, "extension/version.json", JSON.stringify(info), `Extension ${version} is current`, token);
    await setExtPublishStatus({ state: "published", version, publishedAt: info.publishedAt, files: info.files, bytes: info.bytes, error: null });
    await logActivity("extension_published", { version, files: info.files, bytes: info.bytes });
    return { status: "published", ...info };
  } catch (e) {
    await setExtPublishStatus({ state: "error", error: String(e.message || e) });
    await logActivity("extension_publish_failed", { error: String(e) });
    return { status: "error", error: String(e.message || e) };
  } finally {
    extPublishInFlight = false;
  }
}

function kickExtensionPublish() {
  getSettings().then((s) => publishExtensionUpdate(s)).catch((e) => console.log("[ext-publish] failed:", e));
}

/** The alarm every 15 minutes: main imports, helper pulls state and uploads. */
async function helperTick() {
  const settings = await getSettings();
  if (isHelper(settings)) {
    await pullSharedState(settings);
    await uploadHelperData(settings);
  } else if (settings.helpersEnabled) {
    await syncHelpers();
  }
}

// ---------------------------------------------------------------------------
// v1.42: free Google Maps data (rating, photos, AI review summary, snippets)
// read from the Google Maps page itself by gmaps-content.js. The result lands
// in hotelMeta whether the page was opened by the Swipe card's lookup window
// or by hand / by a manual scan: the content script reports it, this saves it.
// ---------------------------------------------------------------------------

const GOOGLE_PHOTO_RE = /^https:\/\/lh\d\.(googleusercontent|ggpht)\.com\//;

/** Turns what the page reader reported into the hotelMeta entry, dropping anything malformed. */
function buildGoogleMeta(data, prior, nowIso) {
  if (!data || data.notFound) {
    // never wipe good data because one lookup missed
    if (prior && prior.googleRating != null) return { ...prior, googleLastMissAt: nowIso };
    return { googleNotFound: true, googleNote: String((data && data.reason) || "no result").slice(0, 80), googleCheckedAt: nowIso, googleSource: "browser" };
  }
  const photos = (data.photos || []).filter((u) => typeof u === "string" && GOOGLE_PHOTO_RE.test(u) && u.length < 600).slice(0, 5);
  const reviewList = (data.reviewList || []).filter((r) => r && typeof r.text === "string" && r.text.length >= 20).slice(0, 3)
    .map((r) => ({ text: r.text.slice(0, 280), when: String(r.when || "").slice(0, 30) }));
  const url = typeof data.url === "string" && /^https:\/\/www\.google\.com\/maps\/place\//.test(data.url) ? data.url.slice(0, 400) : null;
  return {
    googleRating: typeof data.rating === "number" && data.rating > 0 && data.rating <= 5 ? data.rating : null,
    googleReviews: Number.isFinite(data.reviews) ? data.reviews : null,
    googleUrl: url,
    googlePhotoUrls: photos,
    googleReviewList: reviewList,
    googleSummary: String(data.summary || "").slice(0, 600),
    googleMatchedName: String(data.name || "").slice(0, 120),
    googleCheckedAt: nowIso,
    googleDetailsAt: nowIso,
    googleSource: "browser",
  };
}

async function handleGmapsResult(message, sender) {
  const windowId = sender.tab && sender.tab.windowId;
  const pending = pendingRequests.get(windowId);
  if (message.groupKey) {
    await withDealLock(async () => {
      const { hotelMeta = {} } = await chrome.storage.local.get("hotelMeta");
      hotelMeta[message.groupKey] = buildGoogleMeta(message.data, hotelMeta[message.groupKey], new Date().toISOString());
      await chrome.storage.local.set({ hotelMeta });
    });
    await logActivity(message.data && message.data.notFound ? "google_lookup_missed" : "google_lookup_saved", {
      hotelName: message.hotelName, reason: message.data && message.data.reason,
      photos: message.data && message.data.photos ? message.data.photos.length : 0,
    });
  }
  if (pending) pending.resolve(message.data);
}

/**
 * Imports enrichment.json from the extension folder (Google Maps data and
 * MakeMyTrip photos collected by a manual scan outside the extension). Runs at
 * startup, after a reload and whenever the popup/dashboard asks for an update
 * check. Only a file with a newer generatedAt than the last import is applied,
 * and everything goes through the same validation as live lookups.
 */
async function importEnrichment() {
  let json;
  try {
    const r = await fetch(chrome.runtime.getURL("enrichment.json") + "?t=" + Date.now(), { cache: "no-store" });
    if (!r.ok) return { status: "none" };
    json = await r.json();
  } catch (e) {
    return { status: "none" };
  }
  const { enrichmentImportedAt } = await chrome.storage.local.get("enrichmentImportedAt");
  if (!json || !json.generatedAt || json.generatedAt <= (enrichmentImportedAt || "")) return { status: "current" };
  let google = 0, images = 0;
  await withDealLock(async () => {
    const { hotelMeta = {} } = await chrome.storage.local.get("hotelMeta");
    for (const [k, data] of Object.entries(json.google || {})) {
      hotelMeta[k] = buildGoogleMeta(data, hotelMeta[k], json.generatedAt);
      google++;
    }
    for (const [k, u] of Object.entries(json.images || {})) {
      if (typeof u === "string" && u.startsWith("https://") && u.length < 600) {
        hotelMeta[k] = { ...(hotelMeta[k] || {}), mmtImageUrl: u };
        images++;
      }
    }
    await chrome.storage.local.set({ hotelMeta, enrichmentImportedAt: json.generatedAt });
  });
  await logActivity("enrichment_imported", { google, images, generatedAt: json.generatedAt });
  return { status: "imported", google, images };
}

let gmapsChain = Promise.resolve();

/**
 * Opens one small window on the Google Maps search for the hotel and waits for
 * the page reader's report. Serialised with a pause between lookups so it
 * never looks like a burst; capped per day. Returns the saved hotelMeta entry
 * (or {capped:true}).
 */
function lookupGoogleViaBrowser(groupKey, hotelName, destination) {
  const run = gmapsChain.then(async () => {
    const settings = await getSettings();
    const today = toISODate(new Date());
    const { googleBrowserUsage } = await chrome.storage.local.get("googleBrowserUsage");
    const usage = googleBrowserUsage && googleBrowserUsage.day === today ? googleBrowserUsage : { day: today, count: 0 };
    if (usage.count >= (settings.googleBrowserDailyCap || 60)) return { capped: true };
    await chrome.storage.local.set({ googleBrowserUsage: { day: today, count: usage.count + 1 } });

    const q = encodeURIComponent(`${hotelName} ${destination}`);
    const url = `https://www.google.com/maps/search/${q}?hl=en&dtjob=1&dtkey=${encodeURIComponent(groupKey)}&dtname=${encodeURIComponent(hotelName)}&dtdest=${encodeURIComponent(destination)}`;
    await new Promise((resolve) => {
      (async () => {
        let win;
        try {
          win = await chrome.windows.create({ url, type: "popup", ...randomWindowGeometry(), focused: false });
        } catch (e) {
          resolve();
          return;
        }
        const entry = {
          settled: false,
          openedAt: Date.now(),
          timeoutMs: 50000,
          stoppedPayload: { notFound: true, reason: "stopped" },
          kind: "gmaps",
        };
        entry.cleanupAndResolve = () => {
          if (entry.settled) return;
          entry.settled = true;
          pendingRequests.delete(win.id);
          chrome.windows.remove(win.id).catch(() => {});
          resolve();
        };
        entry.buildTimeoutPayload = async () => {
          await handleGmapsResult({ groupKey, hotelName, destination, data: { notFound: true, reason: "timed out" } }, { tab: { windowId: -1 } });
          return { notFound: true };
        };
        entry.resolve = () => entry.cleanupAndResolve();
        pendingRequests.set(win.id, entry);
      })();
    });
    const { hotelMeta = {} } = await chrome.storage.local.get("hotelMeta");
    await delay(6, 12); // be unhurried between lookups
    return hotelMeta[groupKey] || null;
  });
  gmapsChain = run.catch(() => {});
  return run;
}

/**
 * One-time clean-up after the MakeMyTrip date bug (see MMT_DATE_FORMATS in
 * shared.js). Old price points stay as history but are never trusted again
 * (no dv flag). The deal feed built from them is moved aside, queued
 * confirmations and "already alerted" markers are dropped, and every scan
 * step is marked due so verified prices are collected straight away.
 */
async function migrateDatesFix() {
  const { datesFixMigratedAt, dealEvents = [] } = await chrome.storage.local.get(["datesFixMigratedAt", "dealEvents"]);
  if (datesFixMigratedAt) return false;
  await chrome.storage.local.set({
    dealEventsLegacy: dealEvents.slice(0, 500),
    dealEvents: [],
    pendingConfirmations: [],
    stepFreshness: {},
    rareDealAlertState: {},
    channelPostState: null,
    datesFixMigratedAt: new Date().toISOString(),
  });
  await logActivity("dates_fix_migrated", { movedEvents: dealEvents.length });
  return true;
}

// Every time the background process starts (install, browser start, a plain
// reload, or the system waking it), not only on install/startup events:
// the one-time clean-up must not depend on which of those happened.
migrateDatesFix().then(() => schedulePostFixRescan()).catch((e) => console.log("[migrate] failed:", e));

/**
 * One automatic full re-scan after a fix that makes earlier scans incomplete.
 * Bump RESCAN_TOKEN in a release that needs it. The marks that say "this page
 * was scanned recently" (stepFreshness) are cleared first, otherwise the smart
 * scan would skip exactly the pages the faulty scan had just (wrongly) filled
 * in. Runs once per token; the scan itself starts about 30 seconds later via an
 * alarm, so it survives the background process being recycled meanwhile.
 */
const RESCAN_TOKEN = "block-detect-1";
async function schedulePostFixRescan() {
  const { rescanToken } = await chrome.storage.local.get("rescanToken");
  if (rescanToken === RESCAN_TOKEN) return false;
  // The marks are always cleared. The scan is only scheduled if no full scan
  // finished in the last 3 hours (one that just ended would only be repeated).
  const { lastFullScanAt } = await chrome.storage.local.get("lastFullScanAt");
  const justScanned = !!lastFullScanAt && Date.now() - new Date(lastFullScanAt).getTime() < 3 * 3600000;
  await chrome.storage.local.set({ rescanToken: RESCAN_TOKEN, stepFreshness: {} });
  if (!justScanned) chrome.alarms.create("postFixScan", { delayInMinutes: 0.5 });
  await logActivity("post_fix_rescan_scheduled", { token: RESCAN_TOKEN, scanScheduled: !justScanned });
  return true;
}

async function runPostFixScan() {
  const settings = await getSettings();
  const sites = settings.sites && settings.sites.length ? settings.sites : ["makemytrip"];
  const r = await startScan(sites, {});
  await logActivity("post_fix_rescan_started", { started: !!(r && r.started), reason: r && r.reason });
}

async function sendWhatsAppAlert(listing, reasons, settings) {
  if (!settings.whatsappPhoneNumberId || !settings.whatsappAccessToken || !settings.whatsappRecipientNumber) {
    console.log("[whatsapp] enabled but not fully configured, skipping alert:", listing.hotelName);
    return;
  }
  const lines = [
    `${listing.isNewlyBuilt ? "\u{1F195} " : "\u{1F3E8} "}${listing.hotelName} (${listing.starRating || "?"}★)`,
    `\u{1F4CD} ${listing.destination} • ${listing.source}`,
    `\u{1F4C5} ${listing.checkin} to ${listing.checkout}`,
    listing.originalPrice
      ? `\u{1F4B0} ${formatINR(listing.originalPrice)} -> ${formatINR(listing.discountedPrice)}`
      : `\u{1F4B0} ${formatINR(listing.discountedPrice)}`,
    `✅ ${reasons.join("; ")}`,
  ];
  if (listing.url) lines.push(listing.url);
  const text = lines.join("\n");

  try {
    const resp = await fetch(`https://graph.facebook.com/v20.0/${settings.whatsappPhoneNumberId}/messages`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${settings.whatsappAccessToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        to: settings.whatsappRecipientNumber,
        type: "text",
        text: { body: text },
      }),
    });
    if (!resp.ok) {
      const errBody = await resp.text();
      console.log("[whatsapp] send failed:", resp.status, errBody);
      await logActivity("whatsapp_alert_failed", { status: resp.status, hotelName: listing.hotelName });
    }
  } catch (e) {
    console.log("[whatsapp] send failed:", e);
    await logActivity("whatsapp_alert_failed", { error: String(e), hotelName: listing.hotelName });
  }
}

// A must-know alert gets a headline on its own first line in the owner's chat
// (subscribers get one from formatDealMessage); ordinary alerts stay as they were.
const OWNER_HEADLINES = {
  record_low: "\u{1F3C6}\u{1F3C6} LOWEST PRICE EVER \u{1F3C6}\u{1F3C6}",
  good_deal: "\u{1F4B0} REALLY GOOD DEAL",
  market_deal: "\u{1F4B8} CHEAPER THAN SIMILAR HOTELS",
};

async function sendTelegramAlert(listing, reasons, settings, headline = null) {
  if (!settings.telegramBotToken || !settings.telegramChatId) {
    console.log("[telegram] not configured, skipping alert:", listing.hotelName);
    return;
  }
  const lines = [
    ...(headline ? [headline] : []),
    `${listing.isNewlyBuilt ? "\u{1F195} " : "\u{1F3E8} "}${listing.hotelName} (${listing.starRating || "?"}\u2605)`,
    `\u{1F4CD} ${listing.destination} \u2022 ${listing.source}`,
    `\u{1F4C5} ${listing.checkin} to ${listing.checkout}`,
    listing.originalPrice
      ? `\u{1F4B0} ${formatINR(listing.originalPrice)} -> ${formatINR(listing.discountedPrice)}`
      : `\u{1F4B0} ${formatINR(listing.discountedPrice)}`,
    `\u2705 ${reasons.join("; ")}`,
  ];
  if (listing.url) lines.push(listing.url);

  const text = lines.join("\n");
  const url = `https://api.telegram.org/bot${settings.telegramBotToken}/sendMessage`;
  try {
    const resp = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: settings.telegramChatId, text }),
    });
    // fetch() only rejects on a genuine network failure, never on Telegram
    // returning an error status (wrong/revoked bot token, bad chat ID,
    // bot blocked by the user, rate-limited, etc.), so this used to always
    // look like a successful send even when nothing was actually
    // delivered. sendWhatsAppAlert() (below) already checked resp.ok and
    // logged failures, this was the one alert path that never got the
    // same treatment, the "same bug, sibling path" pattern this project
    // keeps running into. Every real deal/price-target alert goes through
    // this one function, so a silent failure here meant the whole point
    // of the extension (telling you about a deal) could stop working with
    // zero trace anywhere.
    if (!resp.ok) {
      const errBody = await resp.text().catch(() => "");
      console.log("[telegram] send failed:", resp.status, errBody);
      await logActivity("telegram_alert_failed", { status: resp.status, hotelName: listing.hotelName, body: errBody.slice(0, 300) });
    }
  } catch (e) {
    console.log("[telegram] send failed:", e);
    await logActivity("telegram_alert_failed", { error: String(e), hotelName: listing.hotelName });
  }
}

/**
 * MakeMyTrip ignores date parameters in an unexpected format and quietly
 * serves its own default dates instead, which would mean tracking the
 * wrong dates forever without ever erroring. This tries each candidate
 * format once against a real destination and keeps whichever one the site
 * actually honours. Runs once, then the result is remembered.
 */
async function calibrateMmtDateFormat(settings) {
  const destination = settings.destinations.find((d) => d.mmtCode);
  if (!destination) return null;

  // a target a few weeks out, far from any plausible default
  const target = new Date();
  target.setDate(target.getDate() + 21);
  const checkinIso = toISODate(target);
  const checkoutTarget = new Date(target);
  checkoutTarget.setDate(checkoutTarget.getDate() + settings.nights);
  const checkoutIso = toISODate(checkoutTarget);

  for (const fmt of MMT_DATE_FORMATS) {
    const { scanProgress: liveProgress } = await chrome.storage.local.get("scanProgress");
    if (liveProgress && liveProgress.stopRequested) return null;

    await updateProgress({ currentLabel: `Working out MakeMyTrip's date format (trying ${fmt})...` });
    const url = buildMmtUrl(destination.mmtCode, checkinIso, checkoutIso, settings.adults, fmt);
    const result = await scrapeUrlWithMeta(url);
    const shown = result.debug && result.debug.displayedDates;
    if (shown && shown.checkin === checkinIso) {
      console.log(`[calibrate] MakeMyTrip honours date format ${fmt}`);
      return fmt;
    }
    console.log(`[calibrate] ${fmt} rejected, page showed ${shown ? shown.checkin : "nothing"}`);
    await delay(8, 15);
  }
  console.log("[calibrate] no date format worked, dates will be whatever the site defaults to");
  return null;
}

/**
 * A destination-scoped scan request that arrived while a different scan
 * was already running gets held here (rather than dropped) so it can
 * run on its own once the busy one finishes -- see the comment in
 * startScan()'s already-running guard for why this exists. De-duplicated
 * by destination name (clicking the same one twice while busy doesn't
 * queue it twice), capped so a person mashing several different
 * destinations' buttons can't grow this without bound.
 */
async function queuePendingDestinationScan(sites, destinationName) {
  const { pendingDestinationScans: existing = [] } = await chrome.storage.local.get("pendingDestinationScans");
  const withoutDuplicate = existing.filter((p) => p.destinationName.toLowerCase() !== destinationName.toLowerCase());
  withoutDuplicate.push({ sites, destinationName, queuedAt: new Date().toISOString() });
  await chrome.storage.local.set({ pendingDestinationScans: withoutDuplicate.slice(-5) });
}

/** Starts the oldest queued destination-scoped scan, if any. Called by
 * finishScan() so a queued request runs automatically, with nobody
 * having to notice a message and click again. */
async function drainPendingDestinationScan() {
  const { pendingDestinationScans: pending = [] } = await chrome.storage.local.get("pendingDestinationScans");
  if (pending.length === 0) return;
  const [next, ...rest] = pending;
  await chrome.storage.local.set({ pendingDestinationScans: rest });
  await logActivity("queued_destination_scan_starting", { destinationName: next.destinationName, sites: next.sites });
  // Awaited, but startScan() itself only awaits its own quick setup
  // before firing the actual step machine fire-and-forget (see its own
  // doc comment) -- so this still returns promptly, it just waits long
  // enough for scanProgress/activeScan to reflect the queued destination
  // before finishScan() (this function's caller) returns.
  await startScan(next.sites, { destinationName: next.destinationName });
}

/** Everything prioritizeSteps() needs to rank scan steps, read from storage once per scan start. */
async function buildScanContext(settings) {
  const { stepFreshness = {}, dealEvents = [], favoriteHotels = [] } = await chrome.storage.local.get(["stepFreshness", "dealEvents", "favoriteHotels"]);
  const nowMs = Date.now();
  const hotCutoff = nowMs - 48 * 3600000;
  return {
    nowMs,
    freshness: stepFreshness,
    volatility: destinationVolatility(dealEvents, nowMs),
    hotDestinations: new Set(dealEvents.filter((e) => new Date(e.at).getTime() >= hotCutoff).map((e) => e.destination)),
    favoriteDestinations: new Set(favoriteHotels.map((f) => f.destination)),
  };
}

/**
 * Cheap, frequent pass over only the stays starting tonight / in the next
 * few days (where prices move most and a drop is worth acting on), for the
 * few most promising destinations. Runs from the lastMinuteSweep alarm.
 * Does nothing while another scan is running; the regular scan already
 * covers those dates then.
 */
async function runLastMinuteSweep() {
  const settings = await getSettings();
  if (settings.lastMinuteSweepEnabled === false) return;
  const { scanProgress } = await chrome.storage.local.get("scanProgress");
  if (scanProgress && scanProgress.running) return;
  const sites = settings.sites && settings.sites.length ? settings.sites : ["makemytrip"];

  // Coverage guard. The sweep only looks at tonight and the next few days for
  // a handful of destinations. If no FULL scan has finished for 14 hours
  // (alarms missed because Chrome was closed or the PC asleep), run a full
  // smart scan instead of yet another sweep, so coverage can never quietly lapse.
  const { lastFullScanAt } = await chrome.storage.local.get("lastFullScanAt");
  const sinceFullMs = lastFullScanAt ? Date.now() - new Date(lastFullScanAt).getTime() : Infinity;
  if (sinceFullMs > 14 * 3600000) {
    await logActivity("coverage_scan_started", { hoursSinceFullScan: Number.isFinite(sinceFullMs) ? Math.round(sinceFullMs / 3600000) : null });
    await startScan(sites, { auto: true });
    return;
  }
  await startScan(sites, { lastMinute: true });
}

/**
 * Kicks off a scan: does one-time setup (build the step list, initialize
 * progress, calibrate MMT's date format if needed), then hands off to
 * runScanStep() to actually process steps one batch at a time. This
 * function itself returns quickly, it does NOT loop through all steps
 * here, that's the whole point, see the note on runScanStep() for why.
 */
async function startScan(sites, options = {}) {
  // A scan can legitimately run for hours, and the automatic alarm fires
  // every 12 hours regardless of whether the last one finished. Without
  // this guard, a slow scan could still be running when the next one
  // starts, two scans opening windows and writing scanProgress at once
  // would corrupt each other's state. Skip rather than queue, whatever's
  // already running will pick up the rest via destination rotation next
  // time anyway.
  const { scanProgress: existingProgress } = await chrome.storage.local.get("scanProgress");
  if (existingProgress && existingProgress.running) {
    console.log("[scan] a scan is already running, skipping this trigger");
    await logActivity("scan_skipped_already_running", { sites, completedSoFar: existingProgress.completed });
    // v1.31.0 made this honest (returning which destination is ACTUALLY
    // running instead of nothing), but honesty alone turned out not to
    // be enough: a person who clicks "Scan" on one destination while a
    // different one is running still has to notice the message and
    // remember to click again once it finishes, and reported this as
    // "nothing changed, it still scanned Digha instead of the one I
    // clicked". For a destination-SCOPED request specifically, queue it
    // instead of just dropping it -- finishScan() drains this queue and
    // starts the queued destination on its own, no second click needed.
    // An UNSCOPED ("scan everywhere") click isn't queued: the ordinary
    // destination-rotation sweep already covers everywhere on its own
    // next run, queueing it too would just duplicate that work.
    if (options.destinationName) {
      await queuePendingDestinationScan(sites, options.destinationName);
      return { started: false, reason: "queued", queued: true, scanProgress: existingProgress };
    }
    return { started: false, reason: "already_running", scanProgress: existingProgress };
  }

  // options.destinationName: scope this run to a single destination
  // ("scan this place again" from the popup's destination row), rather
  // than the usual every-learned-destination sweep. Matched
  // case-insensitively against settings.destinations' own names.
  const destinationFilter = options.destinationName ? options.destinationName.toLowerCase() : null;

  await migrateDatesFix().catch((e) => console.log("[migrate] failed:", e)); // never blocks a scan
  const settings = await getSettings();

  // Automatic triggers back off from a site that recently blocked us (see
  // siteCooldown, set in runScanStepBody). Manual scans always go ahead.
  if (options.auto || options.lastMinute) {
    const { siteCooldown = {} } = await chrome.storage.local.get("siteCooldown");
    const open = sites.filter((s) => !(siteCooldown[s] > Date.now()));
    if (open.length === 0) {
      await logActivity("scan_skipped_cooldown", { sites });
      return { started: false, reason: "cooldown" };
    }
    sites = open;
  }

  const weekends = upcomingWeekends(settings.nights, settings.checkinWeekday, settings.lookaheadDays);
  const quickWindow = settings.includeNext7Days ? next7DaysWindow(settings.nights) : [];
  // Tonight (lead 0) is a real last-minute opportunity: the generic
  // windows start tomorrow, which meant a same-day price drop could never
  // be seen at all.
  const tonight = settings.scanTonight !== false ? [todayWindow(settings.nights)] : [];
  let dateWindows = dedupeByCheckin(tonight, quickWindow, weekends);
  if (options.lastMinute) {
    const lmDays = settings.lastMinuteDays ?? LAST_MINUTE_DEFAULTS.lastMinuteDays;
    const base = new Date();
    dateWindows = [];
    for (let i = 0; i <= lmDays; i++) {
      const d = new Date(base.getFullYear(), base.getMonth(), base.getDate() + i);
      const out = new Date(d);
      out.setDate(out.getDate() + settings.nights);
      dateWindows.push({ checkin: toISODate(d), checkout: toISODate(out) });
    }
  }

  // A scan that only gets through a few destinations used to always start
  // over from the same first one next time, starving everything after it.
  // Ordering by whichever was touched longest ago (never-scanned counts as
  // oldest) means coverage rotates on its own, no manual reordering needed.
  const orderedDestinations = [...settings.destinations].sort((a, b) => {
    const at = a.lastScannedAt ? new Date(a.lastScannedAt).getTime() : 0;
    const bt = b.lastScannedAt ? new Date(b.lastScannedAt).getTime() : 0;
    return at - bt;
  });

  // staleOnly (manual catch-up scans only, off for the automatic ones)
  // skips anything touched in the last 24 hours entirely, for topping up
  // whatever's fallen behind without re-checking places just scanned.
  const STALE_THRESHOLD_MS = 24 * 60 * 60 * 1000;
  const now = Date.now();
  let candidateDestinations = options.staleOnly
    ? orderedDestinations.filter((d) => !d.lastScannedAt || now - new Date(d.lastScannedAt).getTime() > STALE_THRESHOLD_MS)
    : orderedDestinations;
  if (destinationFilter) {
    candidateDestinations = candidateDestinations.filter((d) => d.name.toLowerCase() === destinationFilter);
  }
  // This computer's own share of destinations (the other computer scans the rest).
  candidateDestinations = filterScanDestinations(candidateDestinations, settings.scanDestinations);

  // Round-robin across destinations for each date window, rather than
  // doing every date for one destination before touching the next, so
  // coverage broadens quickly instead of going deep on one place first.
  // Steps are kept minimal (no full destination object) since this whole
  // list gets persisted to storage and re-read on every single step.
  const learnedSteps = [];
  for (const site of sites) {
    const codeField = site === "makemytrip" ? "mmtCode" : "goibiboCode";
    const eligibleDestinations = candidateDestinations.filter((d) => d[codeField]);
    for (const w of dateWindows) {
      for (const destination of eligibleDestinations) {
        learnedSteps.push({
          site,
          destinationName: destination.name,
          code: destination[codeField],
          checkin: w.checkin,
          checkout: w.checkout,
        });
      }
    }
  }

  // Smart ordering: nearest stays first, then destinations that have been
  // moving, then whatever hasn't been looked at longest. Automatic runs
  // also skip steps checked recently enough (3h for stays within 3 days,
  // 12h within 2 weeks, 24h beyond), which cuts the page loads MakeMyTrip
  // sees and so how often it blocks. Manual and destination-scoped scans
  // keep every step, just reordered.
  if (settings.smartScan !== false && learnedSteps.length > 1) {
    const ctx = await buildScanContext(settings);
    const ordered = prioritizeSteps(learnedSteps, ctx, {
      skipFresh: !!(options.auto || options.lastMinute) && !destinationFilter,
      maxSteps: options.lastMinute ? (settings.lastMinuteMaxSteps || 6) : undefined,
    });
    learnedSteps.length = 0;
    learnedSteps.push(...ordered);
  }

  const startedAt = new Date().toISOString();

  // Only ever called when learnedSteps.length is already 0, so a set
  // destinationFilter always means the SAME thing here: either the name
  // doesn't match any known destination at all, or it matches one that
  // has no code learned for the site(s) being scanned (learnedSteps is
  // built per codeField, so this also covers "learned on MMT but
  // scanning Goibibo for it"). Checked before staleOnly/the generic
  // message so a destination-scoped run always gets an answer that
  // actually names the destination, not a generic one that would read
  // as if nothing anywhere is learned when other destinations clearly are.
  const nothingToScanReason = () => {
    if (destinationFilter) {
      return `No code learned yet for "${options.destinationName}" on ${sites.join("/")}, search it there once first.`;
    }
    if (options.auto || options.lastMinute) return "Nothing due, everything was checked recently";
    if (options.staleOnly) return "Nothing stale, everything's been checked in the last 24h";
    return "Nothing to scan, no destinations learned yet";
  };

  await chrome.storage.local.set({
    scanProgress: {
      running: true,
      sites,
      destinationName: options.destinationName || null,
      startedAt,
      finishedAt: null,
      total: learnedSteps.length,
      completed: 0,
      scanned: 0,
      stopRequested: false,
      lastStepAt: startedAt,
      currentLabel: learnedSteps.length ? "Starting..." : nothingToScanReason(),
      log: [],
    },
    activeScan: { sites, options, learnedSteps, stepIndex: 0, startedAt },
  });

  await logActivity("scan_started", { sites, staleOnly: !!options.staleOnly, destinationName: options.destinationName || null, totalSteps: learnedSteps.length });

  if (learnedSteps.length === 0) {
    const message = nothingToScanReason();
    await finishScan(false);
    return { started: false, reason: "nothing_to_scan", message };
  }

  // Work out MakeMyTrip's date format once, before scanning in earnest,
  // otherwise every result silently carries the site's default dates.
  // This runs once per cache (skipped once settings.mmtDateFormat is
  // set), a bounded handful of page loads, not the long-running part.
  if (sites.includes("makemytrip") && !settings.mmtDateFormat) {
    await updateProgress({ currentLabel: "Working out MakeMyTrip's date format..." });
    const fmt = await calibrateMmtDateFormat(settings);
    if (fmt) {
      settings.mmtDateFormat = fmt;
      await saveSettings(settings);
      await logActivity("mmt_date_format_calibrated", { format: fmt });
    } else {
      await logActivity("mmt_date_format_calibration_failed", null);
    }
  }

  runScanStep();
  return { started: true, total: learnedSteps.length };
}

/**
 * True when the page MakeMyTrip returned is its bot-block page rather than a
 * listing: the bare text "200-OK" (what you saw in the first screenshot), or a
 * known access-denied / captcha wording, with no hotel cards found. The old
 * check only looked for timeouts and raw JSON, but this page DOES run the
 * content script (it is a tiny HTML page), so a block looked like an empty
 * destination: the scan carried on through dozens of pages, recorded each as
 * done, and never cleared MakeMyTrip's cache or backed off.
 */
function isMmtBlockPage(debug) {
  if (!debug || debug.cardsFound > 0) return false;
  const text = String(debug.bodyTextSample || "").trim();
  if (/^200-?OK$/i.test(text)) return true;
  if (text.length < 400 && /access denied|captcha|unusual traffic|pardon our interruption|verify you are (a )?human|reference #\d/i.test(text)) return true;
  return false;
}

/**
 * Everything involved in checking one destination+date window: build the
 * URL, scrape it, filter and store results, optionally deep-check room
 * prices for the cheapest few.
 */
async function processStep(step, settings) {
  const { site, destinationName, code, checkin, checkout } = step;
  const label = `${site === "makemytrip" ? "MakeMyTrip" : "Goibibo"} \u2022 ${destinationName} \u2022 ${checkin} \u2192 ${checkout}`;

  const url =
    site === "makemytrip"
      ? buildMmtUrl(code, checkin, checkout, settings.adults, settings.mmtDateFormat)
      : buildGoibiboUrl(code, checkin, checkout, settings.adults, settings.rooms);

  console.log(`[scan] ${label}`);
  // give the page its full budget plus headroom for load and parse, so
  // the window is never closed out from under a scroll that's still
  // pulling in more hotels
  const pageTimeout = (settings.perPageSeconds + 35) * 1000;
  const { listings: rawListings, debug: scrapeDebug } = await scrapeUrlWithMeta(url, pageTimeout);
  // A page that never ran content.js and yielded nothing (raw "200-OK"
  // JSON body, timeout, scripting failure) is the site's anti-bot layer
  // refusing us, not an empty destination. runScanStepBody() backs off
  // and eventually aborts on repeated blocks rather than hammering on.
  const blocked = rawListings.length === 0 && (isMmtBlockPage(scrapeDebug) || !!(scrapeDebug && (scrapeDebug.timedOut || scrapeDebug.likelyJsonResponse || scrapeDebug.scriptingError)));
  if (blocked && isMmtBlockPage(scrapeDebug)) {
    await logActivity("mmt_block_page", { sample: String((scrapeDebug.bodyTextSample || "").trim()).slice(0, 80), label });
  }
  // Filter to the star rating floor here, keeping listings where the
  // star rating couldn't be read at all (null) rather than dropping
  // them, since that's a parsing gap, not evidence the hotel is below
  // the floor.
  const listings = rawListings.filter(
    (l) => l.starRating === null || l.starRating === undefined || l.starRating >= settings.minStarRating
  );

  // The page must tell us which dates it really priced (read from its own
  // URL). If it can't, the prices can't be filed under any date, so nothing
  // is recorded rather than recording a guess.
  if (listings.length > 0 && !listings.some((l) => l.pageCheckin && l.pageCheckout)) {
    await logActivity("scan_dates_unreadable", { label, found: listings.length });
    return { label, foundCount: 0, mismatched: 0, blocked: false, unreadable: true };
  }

  let mismatched = 0;
  for (const listing of listings) {
    if (!listing.pageCheckin || !listing.pageCheckout) continue;
    listing.destination = destinationName;
    // The dates the page actually displayed win over the ones we asked
    // for. If the site ignored our parameters, recording the requested
    // dates would attach real prices to dates they don't belong to,
    // which is worse than recording the date it actually priced.
    const actualCheckin = listing.pageCheckin || checkin;
    const actualCheckout = listing.pageCheckout || checkout;
    if (listing.pageCheckin && listing.pageCheckin !== checkin) mismatched++;
    listing.checkin = actualCheckin;
    listing.checkout = actualCheckout;
    listing.requestedCheckin = checkin;

    // Sites don't always show a "% off" badge even when there's clearly
    // a discount, so derive it from the struck-through original price
    // when it's missing.
    if ((listing.discountPct === null || listing.discountPct === undefined) &&
        listing.originalPrice && listing.originalPrice > listing.discountedPrice) {
      listing.discountPct = Math.round(
        ((listing.originalPrice - listing.discountedPrice) / listing.originalPrice) * 100
      );
    }

    await evaluateAndAlert(listing, settings);
  }

  // Opt-in, off by default: double-check the actual lowest room price
  // for the top few cheapest listings, since a listing card only shows
  // a "starting from" figure. Capped small on purpose, each one is a
  // full extra page load.
  if (settings.checkRoomDetailsForTopN > 0 && listings.length > 0) {
    const shortlist = listings
      .filter((l) => l.url)
      .slice()
      .sort((a, b) => a.discountedPrice - b.discountedPrice)
      .slice(0, settings.checkRoomDetailsForTopN);

    for (const listing of shortlist) {
      const { scanProgress: liveProgress2 } = await chrome.storage.local.get("scanProgress");
      if (liveProgress2 && liveProgress2.stopRequested) break;

      const result = await checkRoomDetail(listing.url);
      // Never trust a single layer, detail-content.js now filters this
      // at the source, but a value this low getting written here would
      // permanently poison the hotel's recorded lowest via Math.min,
      // which only ever ratchets down and never self-corrects.
      if (result.lowest !== null && result.lowest >= 300) {
        const key = `hist:${listing.source}:${listing.hotelName}:${listing.destination}:${listing.checkin}:${listing.checkout}`;
        const { [key]: existing } = await chrome.storage.local.get(key);
        if (existing) {
          await chrome.storage.local.set({
            [key]: {
              ...existing,
              roomDetailLowest: result.lowest,
              roomDetailCheckedAt: new Date().toISOString(),
              // Amenity badges only ever populate via this same opt-in
              // detail-page visit, see AMENITY_PATTERNS in shared.js.
              // Keep whatever was found even if empty (an empty result
              // still means "checked, nothing matched", worth keeping
              // distinct from "never checked" for a future diagnosis).
              amenities: Array.isArray(result.amenities) ? result.amenities : existing.amenities || [],
            },
          });
        }
      }
      await delay(settings.minDelaySeconds, settings.maxDelaySeconds);
    }
  }

  // MakeMyTrip only loads more hotels while the window is actually visible. A
  // scan window behind other windows counts as hidden to Chrome, and the page
  // then stops after its first handful of hotels. Such a page is recorded but
  // never counted as "done" (see the freshness marks in runScanStepBody).
  const hidden = !!(scrapeDebug && scrapeDebug.visibilityState === "hidden");
  return { label, foundCount: listings.length, mismatched, blocked, hidden };
}

/**
 * Processes exactly one batch, then either finishes the scan or
 * schedules the next batch via chrome.alarms and returns.
 *
 * This is the actual fix for scans dying silently: a service worker is
 * NOT allowed to run indefinitely, Chrome can and does kill it, and a
 * long-lived function sitting in an await chain for hours has no way to
 * survive that, it just stops, with nothing left running to even notice,
 * which is why Stop looked broken too, there was nothing left to receive
 * the request. Each call here does a small bounded unit of work (one
 * batch, well under the page timeout) and then genuinely returns,
 * letting the service worker be suspended if Chrome wants. The next
 * batch is triggered by a chrome.alarms alarm, which is a browser-level
 * mechanism that survives the service worker's death and reliably wakes
 * it back up, unlike anything living inside a single function call.
 */
// Set for the entire duration of a runScanStep() call, checked by the
// watchdog before it decides to resume "a stalled scan". Without this,
// a batch that legitimately runs long (checkRoomDetailsForTopN turns one
// batch into several sequential extra page loads, worst case several
// minutes for a batch of 3) could still exceed the watchdog's 4-minute
// STALL_THRESHOLD_MS even though the service worker never actually died,
// it was just busy, and the watchdog would call runScanStep() a SECOND
// time on top of the one still running, duplicating scraping/writes/
// alerts for the same batch. This flag resets to false on every fresh
// service worker instance (a real death IS what should let the watchdog
// resume), so it only ever suppresses the watchdog while this exact
// process is still genuinely alive and working.
let scanStepInFlight = false;

/** Clears HTTP cache + Cache Storage for makemytrip.com only. Cookies and
 * logins are left alone. */
async function clearMmtCache() {
  try {
    await chrome.browsingData.remove(
      { origins: ["https://www.makemytrip.com"] },
      { cache: true, cacheStorage: true }
    );
    await logActivity("mmt_cache_cleared", null);
  } catch (e) {
    console.log("[scan] could not clear MMT cache:", e);
    await logActivity("mmt_cache_clear_failed", { error: String(e) });
  }
}

/**
 * The full version of what you used to do by hand in Chrome's "Clear browsing
 * data" for makemytrip.com: cache, cookies, local storage, IndexedDB, service
 * workers. Cookies matter here: the "200-OK" block page is keyed on cookies
 * MakeMyTrip set earlier, so clearing only the cache can leave it stuck.
 * Only makemytrip.com is touched; every other site keeps its logins. It does
 * sign you out of makemytrip.com in this Chrome, which scanning doesn't need.
 */
const MMT_ORIGINS = ["https://www.makemytrip.com", "https://makemytrip.com"];
async function clearMmtSiteData() {
  try {
    await chrome.browsingData.remove(
      { origins: MMT_ORIGINS },
      { cache: true, cacheStorage: true, cookies: true, localStorage: true, indexedDB: true, serviceWorkers: true, fileSystems: true }
    );
    await logActivity("mmt_site_data_cleared", null);
    await chrome.storage.local.set({ lastMmtClear: { at: new Date().toISOString() } });
    return { ok: true };
  } catch (e) {
    console.log("[scan] could not clear MMT site data:", e);
    await logActivity("mmt_site_data_clear_failed", { error: String(e) });
    return { ok: false, error: String(e && e.message || e) };
  }
}

async function runScanStep() {
  if (scanStepInFlight) {
    console.log("[scan] runScanStep() called while a step is already in flight in this process, ignoring");
    return;
  }
  scanStepInFlight = true;
  try {
    await runScanStepBody();
  } catch (e) {
    // Chrome can tear down an MV3 service worker at any point, including
    // mid-await inside a step (a scrape or a storage write that was in
    // flight when it happened surfaces here as "No SW"). Every caller of
    // runScanStep() invokes it fire-and-forget with no .catch(), so
    // without this the failure escapes as an "Uncaught (in promise)"
    // error in chrome://extensions -- alarming, but usually a benign
    // race: checkScanWatchdog() already resumes a stalled scan on its
    // own next tick once a fresh worker instance exists, there's nothing
    // more to do here. Swallow it (best-effort logging, which can itself
    // throw for the exact same reason) rather than let it look like the
    // extension broke and needs a manual reload.
    console.log("[scan] step failed, likely the service worker being recycled mid-step:", e);
    try {
      await logActivity("scan_step_failed", { error: String(e) });
    } catch (e2) {
      console.log("[scan] could not even log the failure (worker likely fully gone):", e2);
    }
  } finally {
    scanStepInFlight = false;
  }
}

async function runScanStepBody() {
  const { activeScan } = await chrome.storage.local.get("activeScan");
  if (!activeScan) return;

  const { scanProgress } = await chrome.storage.local.get("scanProgress");
  if (!scanProgress || !scanProgress.running) return;

  if (scanProgress.stopRequested) {
    await finishScan(true);
    return;
  }

  if (activeScan.stepIndex >= activeScan.learnedSteps.length) {
    await finishScan(false);
    return;
  }

  // Mark activity now, before the batch runs, not just after, so the
  // watchdog can tell a step is genuinely in progress versus the whole
  // thing having silently died.
  await updateProgress({ lastStepAt: new Date().toISOString() });

  const settings = await getSettings();
  // After any block, drop to one page at a time: parallel windows against
  // a site that's already flagged us only make it worse.
  const blockStreak = scanProgress.blockStreak || 0;
  const concurrency = blockStreak > 0 ? 1 : Math.max(1, Math.min(3, settings.scanConcurrency || 1));
  const batch = activeScan.learnedSteps.slice(activeScan.stepIndex, activeScan.stepIndex + concurrency);

  // Mark destinations touched here, sequentially, before the concurrent
  // batch runs, so concurrent windows can't race on the same settings
  // write.
  const uniqueDestNames = [...new Set(batch.map((s) => s.destinationName))];
  let destChanged = false;
  for (const name of uniqueDestNames) {
    const di = settings.destinations.findIndex((d) => d.name === name);
    if (di !== -1) {
      settings.destinations[di].lastScannedAt = new Date().toISOString();
      destChanged = true;
    }
  }
  if (destChanged) await saveSettings(settings);

  await updateProgress({
    currentLabel: batch.length > 1
      ? `Scanning ${batch.length} at once: ${uniqueDestNames.join(", ")}`
      : `${batch[0].site === "makemytrip" ? "MakeMyTrip" : "Goibibo"} \u2022 ${batch[0].destinationName} \u2022 ${batch[0].checkin} \u2192 ${batch[0].checkout}`,
  });

  const results = await Promise.all(batch.map((step) => processStep(step, settings)));

  let batchScanned = 0;
  for (const r of results) {
    batchScanned += r.foundCount;
    await appendProgressLog(r.label, r.foundCount, r.mismatched, !!r.hidden);
  }

  // Blocked steps are retried (stepIndex stops at the first one) after a
  // cooldown, up to MAX_BLOCK_STREAK in a row, then the scan gives up.
  const firstBlocked = results.findIndex((r) => r.blocked);
  const anyBlocked = firstBlocked !== -1;
  const newBlockStreak = anyBlocked ? blockStreak + 1 : 0;
  const MAX_BLOCK_STREAK = 3;
  // Remember when each step last succeeded, so automatic scans can skip
  // recently-checked ones (see prioritizeSteps). Stays that have already
  // started are pruned so this map doesn't grow forever.
  {
    const { stepFreshness = {} } = await chrome.storage.local.get("stepFreshness");
    const todayIso = toISODate(new Date());
    for (const k of Object.keys(stepFreshness)) if (k.split("|")[2] < todayIso) delete stepFreshness[k];
    batch.forEach((st, i) => { if (!results[i].blocked && !results[i].unreadable && !results[i].hidden) stepFreshness[stepKey(st)] = Date.now(); });
    await chrome.storage.local.set({ stepFreshness });
  }
  const newStepIndex = activeScan.stepIndex + (anyBlocked ? firstBlocked : batch.length);
  await chrome.storage.local.set({ activeScan: { ...activeScan, stepIndex: newStepIndex } });
  await updateProgress({ blockStreak: newBlockStreak });
  if (anyBlocked) {
    await logActivity("scan_step_blocked", { label: results[firstBlocked].label, streak: newBlockStreak });
    // Clearing MMT's cache is what un-sticks it, so do that before the retry.
    if (batch.some((s, i) => results[i].blocked && s.site === "makemytrip")) {
      const { mmtClearAllOnBlock } = await getSettings();
      if (mmtClearAllOnBlock === false) await clearMmtCache();
      else await clearMmtSiteData();
    }
    if (newBlockStreak >= MAX_BLOCK_STREAK) {
      // Give the site a rest: automatic scans and last-minute sweeps skip
      // it for an hour (a manual scan still works).
      const { siteCooldown = {} } = await chrome.storage.local.get("siteCooldown");
      for (const [i, st] of batch.entries()) if (results[i].blocked) siteCooldown[st.site] = Date.now() + 60 * 60000;
      await chrome.storage.local.set({ siteCooldown });
      await finishScan(true, `Stopped: site is blocking requests (${newBlockStreak} in a row). Try again later.`);
      return;
    }
  }

  const { scanProgress: afterBatchProgress } = await chrome.storage.local.get("scanProgress");
  await updateProgress({
    scanned: (afterBatchProgress.scanned || 0) + batchScanned,
    lastStepAt: new Date().toISOString(),
  });

  if (afterBatchProgress && afterBatchProgress.stopRequested) {
    await finishScan(true);
    return;
  }

  if (newStepIndex >= activeScan.learnedSteps.length) {
    await finishScan(false);
    return;
  }

  // Schedule the next step via an alarm rather than awaiting a delay
  // ourselves, an alarm survives this process dying in between, a
  // setTimeout or await chain does not.
  let delaySeconds = settings.minDelaySeconds + Math.random() * (settings.maxDelaySeconds - settings.minDelaySeconds);
  if (anyBlocked) {
    // Exponential cooldown: 2, 4 minutes on top of the normal delay.
    delaySeconds += 60 * Math.pow(2, newBlockStreak);
    await updateProgress({ currentLabel: `Blocked, cooling down ${Math.round(delaySeconds / 60)} min before retry` });
  }
  chrome.alarms.create("scanStepAlarm", { delayInMinutes: Math.max(delaySeconds / 60, 0.05) });
}

/** Finalizes a scan: records history, publishes, marks it not running. */
async function finishScan(wasStopped, stopReason) {
  const { activeScan, scanProgress } = await chrome.storage.local.get(["activeScan", "scanProgress"]);
  const settings = await getSettings();
  const finishedAtMs = Date.now();
  const startedAt = activeScan ? activeScan.startedAt : (scanProgress ? scanProgress.startedAt : new Date().toISOString());
  const durationMs = finishedAtMs - new Date(startedAt).getTime();
  const scanned = scanProgress ? (scanProgress.scanned || 0) : 0;
  const sites = activeScan ? activeScan.sites : (scanProgress ? scanProgress.sites : []);
  const total = activeScan ? activeScan.learnedSteps.length : (scanProgress ? scanProgress.total : 0);
  const completed = scanProgress ? scanProgress.completed : 0;

  await chrome.storage.local.set({ lastScan: { at: new Date().toISOString(), sites, scanned } });

  const { scanHistory = [] } = await chrome.storage.local.get("scanHistory");
  scanHistory.unshift({
    sites, startedAt, finishedAt: new Date(finishedAtMs).toISOString(),
    durationMs, scanned, completed, total, stopped: !!wasStopped,
  });
  await chrome.storage.local.set({ scanHistory: scanHistory.slice(0, 10) });

  // Remember when the last FULL scan finished (not a sweep, not one destination)
  // so a sweep can notice when full coverage has lapsed (see runLastMinuteSweep).
  const opts = (activeScan && activeScan.options) || {};
  if (!wasStopped && !opts.lastMinute && !opts.destinationName && total >= 1) {
    await chrome.storage.local.set({ lastFullScanAt: new Date(finishedAtMs).toISOString() });
  }

  await logActivity(wasStopped ? "scan_stopped" : "scan_finished", { sites, scanned, completed, total, durationMs });

  // Auto-publish to GitHub Pages if it's configured, no button click
  // needed. Does nothing if GitHub settings are empty. Wrapped in a
  // timeout: a slow or hanging network call here shouldn't be able to
  // inflate how long a scan appears to take, or block it from finishing.
  await updateProgress({ currentLabel: "Publishing live dashboard..." });
  try {
    const publishResult = await Promise.race([
      publishSnapshotToGithub(settings),
      new Promise((_, reject) => setTimeout(() => reject(new Error("publish timed out after 30s")), 30000)),
    ]);
    if (publishResult.published) {
      console.log("[publish] live dashboard updated:", publishResult.url);
      await logActivity("published_live_dashboard", { url: publishResult.url });
    }
  } catch (e) {
    console.log("[publish] failed or timed out:", e);
    await logActivity("publish_failed", { error: String(e) });
  }

  // Once a day, piggybacking on however many scans happen to finish
  // that day, not tied to every single one. This is what makes backup
  // behave like a cloud service that keeps itself current in the
  // background rather than something you have to remember to click.
  // A helper computer never backs up (it only has its own share of the
  // data, and must not overwrite the main computer's backup).
  if (isHelper(settings)) {
    try {
      await uploadHelperData(settings);
    } catch (e) {
      console.log("[helper] upload failed:", e);
    }
  }
  if (settings.githubToken && settings.githubRepo && !isHelper(settings)) {
    try {
      const { lastAutoBackupAt } = await chrome.storage.local.get("lastAutoBackupAt");
      // Every 3 hours of scanning (it used to be daily): the price ledger
      // is the one thing that can't be re-created, so a fresh off-device
      // copy should never be more than a few hours behind.
      const hoursSinceBackup = lastAutoBackupAt
        ? (Date.now() - new Date(lastAutoBackupAt).getTime()) / (60 * 60 * 1000)
        : Infinity;
      if (hoursSinceBackup >= 3) {
        const backupResult = await Promise.race([
          backupToGithub(settings),
          new Promise((_, reject) => setTimeout(() => reject(new Error("backup timed out after 30s")), 30000)),
        ]);
        await chrome.storage.local.set({ lastAutoBackupAt: new Date().toISOString() });
        console.log("[backup] auto-backup completed:", backupResult.keyCount, "record(s)");
        await logActivity("auto_backup_completed", { keyCount: backupResult.keyCount });
      }
    } catch (e) {
      console.log("[backup] auto-backup failed:", e);
      await logActivity("auto_backup_failed", { error: String(e) });
    }
  }

  // PROJECT_BRIEF.md Open Item #14: the Rare Deal badge (v1.28.0) wasn't
  // wired into any alert channel. Checked here (once per finished scan,
  // not per hotel) rather than inline during processStep(), see
  // checkRareDealAlerts()'s own comment for why. Wrapped the same way
  // publish/backup are, above: a bug or a slow run here must not be able
  // to stop the scan from actually finishing.
  try {
    await checkRareDealAlerts(settings);
  } catch (e) {
    console.log("[rare-deal] alert check failed:", e);
    await logActivity("rare_deal_check_failed", { error: String(e) });
  }
  try {
    await checkMarketDeals(settings);
  } catch (e) {
    console.log("[market-deal] check failed:", e);
    await logActivity("market_deal_check_failed", { error: String(e) });
  }

  try {
    await reconcileMissingHotels(settings);
  } catch (e) {
    console.log("[missing] reconcile failed:", e);
  }

  // A scan with genuinely nothing to do (total === 0: no destinations
  // learned, everything already checked in the last 24h under
  // staleOnly, or a destination-scoped run whose destination has no
  // code learned) was always overwritten to the generic "Idle" here,
  // silently discarding the specific reason startScan() had just set as
  // scanProgress.currentLabel a moment earlier. Harmless before this
  // round (the generic messages were interchangeable with "Idle"
  // anyway), but it would have defeated the whole point of the new
  // destination-scoped "no code learned for X" message, so this now
  // preserves whatever reason was already there for the zero-steps
  // case, and only defaults to "Idle" for a run that actually did work.
  await updateProgress({
    running: false,
    finishedAt: new Date().toISOString(),
    currentLabel: wasStopped ? (stopReason || "Stopped") : total === 0 && scanProgress ? scanProgress.currentLabel : "Idle",
    stopRequested: false,
  });
  await chrome.storage.local.remove("activeScan");
  console.log(`[scan] ${wasStopped ? "stopped early" : "done"}, ${scanned} listing(s) scanned`);

  // A destination-scoped scan requested while this one was running got
  // queued instead of dropped (see startScan()'s already-running guard);
  // start it now that this run is actually done, no click needed. Not
  // when the person just hit Stop -- starting a new scan immediately
  // after that would defeat the point of stopping.
  if (!wasStopped) {
    await drainPendingDestinationScan();
  }
}

/**
 * Runs periodically regardless of scan state. If a scan claims to be
 * running but hasn't logged any activity in several minutes, far longer
 * than any single step should ever take, the background process that
 * was running it almost certainly died mid-step, which Chrome is
 * allowed to do at any time. This resumes it rather than leaving it
 * stuck showing "running" forever with nothing actually happening.
 */
async function checkScanWatchdog() {
  const { activeScan, scanProgress } = await chrome.storage.local.get(["activeScan", "scanProgress"]);
  if (!scanProgress || !scanProgress.running) return;

  if (!activeScan) {
    // Claims to be running with nothing to resume, almost certainly a
    // scan started before this step-tracking existed (an older version),
    // or otherwise corrupted. There's no state to continue from, so
    // stop pretending it's alive rather than leaving it stuck forever.
    console.log("[watchdog] scan marked running with no resumable state, clearing it");
    await logActivity("watchdog_cleared_zombie_scan", null);
    await updateProgress({
      running: false,
      finishedAt: new Date().toISOString(),
      currentLabel: "Stopped (recovered from a stuck state)",
      stopRequested: false,
    });
    return;
  }

  if (scanStepInFlight) {
    // A batch (possibly a long one, see checkRoomDetailsForTopN) is
    // still genuinely running in this same process, not stalled, just
    // busy. runScanStep() would ignore a call made while it's already
    // in flight anyway, but skip it here too so this doesn't log a
    // misleading "resuming" for a call that's actually a no-op.
    return;
  }

  const referenceTime = scanProgress.lastStepAt || scanProgress.startedAt;
  const stalledForMs = Date.now() - new Date(referenceTime).getTime();
  const STALL_THRESHOLD_MS = 4 * 60 * 1000;

  if (stalledForMs > STALL_THRESHOLD_MS) {
    await logActivity("watchdog_resumed_stalled_scan", { stalledForSeconds: Math.round(stalledForMs / 1000) });
    console.log(`[watchdog] scan appears stalled for ${Math.round(stalledForMs / 1000)}s, resuming`);
    runScanStep();
  }
}

/**
 * Opens a hotel's own detail page to double-check its actual lowest room
 * price, rather than trusting the listing card's headline figure. Only
 * called for a small shortlist per destination/date, see
 * settings.checkRoomDetailsForTopN, since every extra page visited adds
 * real time to an already long scan.
 */
function checkRoomDetail(url, timeoutMs = 20000, kind = "scan") {
  return new Promise(async (resolve) => {
    let win;
    try {
      win = await chrome.windows.create({ url, type: "popup", ...randomWindowGeometry(), focused: false });
    } catch (e) {
      resolve({ lowest: null, error: String(e) });
      return;
    }

    const entry = {
      settled: false,
      openedAt: Date.now(),
      timeoutMs,
      stoppedPayload: { lowest: null, stoppedByUser: true },
      // checkRoomDetail() is called from BOTH the main scan's optional
      // top-N room-detail check AND Quick Refresh Favorites, so unlike
      // scrapeUrlWithMeta this can't hardcode which one it belongs to,
      // the caller says. Stopping one activity must not also kill the
      // other's still-legitimately-running window (the actual bug: a
      // single OR'd stop flag used to apply to every pending request
      // regardless of which activity owned it).
      kind,
    };

    entry.cleanupAndResolve = (payload) => {
      if (entry.settled) return;
      entry.settled = true;
      pendingRequests.delete(win.id);
      chrome.windows.remove(win.id).catch(() => {});
      resolve(payload);
    };

    entry.buildTimeoutPayload = async () => ({ lowest: null, timedOut: true });
    entry.resolve = (payload) => entry.cleanupAndResolve(payload);

    pendingRequests.set(win.id, entry);
  });
}

/**
 * Re-checks only your favorited hotels' known pages directly, rather than
 * re-visiting every destination's full listing page. Much faster since
 * there's no page to search or scroll through, this goes straight to
 * hotels you've already found and marked, using their stored URLs. Does
 * NOT discover new hotels or new dates, it's a fast price refresh for the
 * ones you've already decided matter, run a real scan periodically to
 * keep finding new options.
 */
/** Same queueing as queuePendingDestinationScan()/drainPendingDestinationScan()
 * above, for Quick Refresh Favorites' own destination-scoped requests
 * (a separate storage key and queue, this activity's already-running
 * guard is independent of the scan's). */
async function queuePendingDestinationFavoriteRefresh(destinationName) {
  const { pendingDestinationFavoriteRefreshes: existing = [] } = await chrome.storage.local.get("pendingDestinationFavoriteRefreshes");
  const withoutDuplicate = existing.filter((d) => d.toLowerCase() !== destinationName.toLowerCase());
  withoutDuplicate.push(destinationName);
  await chrome.storage.local.set({ pendingDestinationFavoriteRefreshes: withoutDuplicate.slice(-5) });
}

async function drainPendingDestinationFavoriteRefresh() {
  const { pendingDestinationFavoriteRefreshes: pending = [] } = await chrome.storage.local.get("pendingDestinationFavoriteRefreshes");
  if (pending.length === 0) return;
  const [next, ...rest] = pending;
  await chrome.storage.local.set({ pendingDestinationFavoriteRefreshes: rest });
  await logActivity("queued_favorite_refresh_starting", { destinationName: next });
  await startFavoriteRefresh({ destinationName: next });
}

/**
 * Kicks off a favorites refresh: does one-time setup (build the step
 * list, initialize progress) then hands off to runFavoriteRefreshStep()
 * to process steps one at a time. Guards against a second refresh
 * starting while one's already running, which this never used to do,
 * two concurrent runs racing on the same favoriteRefreshProgress storage
 * key is exactly what could make Stop look like it does nothing: one
 * run finishes and writes "not running" while the other, invisible to
 * the UI, keeps going regardless.
 */
async function startFavoriteRefresh(options = {}) {
  const { favoriteRefreshProgress: existingProgress } = await chrome.storage.local.get("favoriteRefreshProgress");
  if (existingProgress && existingProgress.running) {
    console.log("[favorites] a refresh is already running, skipping this trigger");
    // Same parallel-path fix as startScan()'s already-running guard
    // (v1.32.0): a destination-scoped request made while busy is queued
    // instead of dropped, and finishFavoriteRefresh() starts it
    // automatically, no second click needed.
    if (options.destinationName) {
      await queuePendingDestinationFavoriteRefresh(options.destinationName);
      return { checked: 0, updated: 0, message: `A refresh is already running. ${options.destinationName} is queued and will start automatically once that finishes.`, queued: true };
    }
    return { checked: 0, updated: 0, message: "A refresh is already running." };
  }

  // options.destinationName: "refresh favorites of a particular
  // destination" from the popup's destination row, rather than every
  // favorite across every destination. Matched case-insensitively,
  // same as startScan()'s destinationFilter above.
  const destinationFilter = options.destinationName ? options.destinationName.toLowerCase() : null;
  const groups = await loadTrackedHotelGroups();
  const favorites = groups.filter((g) => g.isFavorite && (!destinationFilter || g.destination.toLowerCase() === destinationFilter));

  const steps = [];
  for (const g of favorites) {
    for (const d of g.dates) {
      if (d.url) steps.push({ source: g.source, hotelName: g.hotelName, destination: g.destination, checkin: d.checkin, checkout: d.checkout, url: d.url });
    }
  }

  const startedAt = new Date().toISOString();
  const destLabel = options.destinationName ? ` in ${options.destinationName}` : "";

  if (steps.length === 0) {
    const message =
      favorites.length === 0
        ? `No favorites marked yet${destLabel}.`
        : `Your favorites${destLabel} don't have a saved link yet, run a full scan first.`;
    await chrome.storage.local.set({
      favoriteRefreshProgress: {
        running: false,
        total: 0,
        completed: 0,
        updated: 0,
        destinationName: options.destinationName || null,
        startedAt,
        finishedAt: new Date().toISOString(),
        currentLabel: message,
        stopRequested: false,
        lastStepAt: startedAt,
      },
    });
    return { checked: 0, updated: 0, message };
  }

  await chrome.storage.local.set({
    favoriteRefreshProgress: {
      running: true,
      total: steps.length,
      completed: 0,
      updated: 0,
      destinationName: options.destinationName || null,
      startedAt,
      finishedAt: null,
      currentLabel: "Starting...",
      stopRequested: false,
      lastStepAt: startedAt,
    },
    activeFavoriteRefresh: { steps, stepIndex: 0, checked: 0, updated: 0, startedAt },
  });

  await logActivity("favorite_refresh_started", { total: steps.length, destinationName: options.destinationName || null });
  runFavoriteRefreshStep();
  return { checked: 0, updated: 0, message: `Started, checking ${steps.length} date(s)${destLabel}.` };
}

async function updateFavoriteRefreshProgress(patch) {
  const { favoriteRefreshProgress = {} } = await chrome.storage.local.get("favoriteRefreshProgress");
  await chrome.storage.local.set({ favoriteRefreshProgress: { ...favoriteRefreshProgress, ...patch } });
}

/**
 * Processes exactly one step, then either finishes or schedules the
 * next one via chrome.alarms and returns. Same reasoning as the main
 * scan's runScanStep(): a long-lived function sitting in an await chain
 * has no way to survive the service worker being killed mid-refresh,
 * this does a small bounded unit of work and genuinely returns each
 * time, relying on an alarm (which survives the service worker dying)
 * to trigger the next one.
 */
// Same guard as scanStepInFlight above, applied to the other activity
// that shares this exact watchdog-and-alarm design. Each of this one's
// own steps is short (a single checkRoomDetail call, well under the
// watchdog's stall threshold) so it's less exposed to the double-invoke
// race in practice, but it's the same shared pattern and the same fix.
let favoriteRefreshStepInFlight = false;

async function runFavoriteRefreshStep() {
  if (favoriteRefreshStepInFlight) {
    console.log("[favorites] runFavoriteRefreshStep() called while a step is already in flight in this process, ignoring");
    return;
  }
  favoriteRefreshStepInFlight = true;
  try {
    await runFavoriteRefreshStepBody();
  } catch (e) {
    // Same race as runScanStep() above (see its comment): the service
    // worker dying mid-step surfaces as "No SW" from whatever chrome.*
    // call happened to be in flight -- reported live in
    // updateFavoriteRefreshProgress() specifically, but it can just as
    // easily land on any other storage call in this step. Swallow it
    // instead of letting it escape as an uncaught rejection;
    // checkFavoriteRefreshWatchdog() resumes a stalled refresh on its
    // own next tick regardless.
    console.log("[favorites] step failed, likely the service worker being recycled mid-step:", e);
    try {
      await logActivity("favorite_refresh_step_failed", { error: String(e) });
    } catch (e2) {
      console.log("[favorites] could not even log the failure (worker likely fully gone):", e2);
    }
  } finally {
    favoriteRefreshStepInFlight = false;
  }
}

async function runFavoriteRefreshStepBody() {
  const { activeFavoriteRefresh } = await chrome.storage.local.get("activeFavoriteRefresh");
  if (!activeFavoriteRefresh) return;

  const { favoriteRefreshProgress } = await chrome.storage.local.get("favoriteRefreshProgress");
  if (!favoriteRefreshProgress || !favoriteRefreshProgress.running) return;

  if (favoriteRefreshProgress.stopRequested) {
    await finishFavoriteRefresh(true);
    return;
  }

  if (activeFavoriteRefresh.stepIndex >= activeFavoriteRefresh.steps.length) {
    await finishFavoriteRefresh(false);
    return;
  }

  await updateFavoriteRefreshProgress({ lastStepAt: new Date().toISOString() });

  const settings = await getSettings();
  const step = activeFavoriteRefresh.steps[activeFavoriteRefresh.stepIndex];
  await updateFavoriteRefreshProgress({ currentLabel: `${step.hotelName} \u2022 ${step.checkin} \u2192 ${step.checkout}` });

  let updated = activeFavoriteRefresh.updated;
  try {
    const result = await checkRoomDetail(step.url, 20000, "favorites");
    // This is the write path that was actually poisoning prices, a bad
    // value here becomes both the displayed current price AND, via
    // Math.min below, the permanent "lowest ever", which never
    // self-corrects once set too low. detail-content.js now filters
    // this at the source, but never trust a single layer for something
    // this easy to get permanently wrong.
    if (result.lowest !== null && result.lowest >= 300) {
      const key = `hist:${step.source}:${step.hotelName}:${step.destination}:${step.checkin}:${step.checkout}`;
      const { [key]: existing } = await chrome.storage.local.get(key);
      if (existing) {
        const now = new Date().toISOString();
        // Same last-minute logic as the main scan (evaluateAndAlert); this
        // path used to only ever feed price-target alerts, so a favorite's
        // tonight/tomorrow price falling never told anyone.
        const lm = detectLastMinuteDrop(existing.prices, result.lowest, step.checkin, now, {
          lastMinuteDays: settings.lastMinuteDays,
          lastMinuteDropPct: settings.lastMinuteDropPct,
        });
        const lmDecision = shouldFireLastMinute(lm, result.lowest, now, existing.lastMinuteAlert);
        // Lowest-ever / really-good-deal, judged against the verified history before this reading (v1.44.6, same helper as the main scan).
        const judged = judgeLowAndGood(result.lowest, existing.rating, existing.reviewCount, verifiedPoints(existing.prices), existing, settings);
        const prices = appendLedgerPoint(existing.prices, result.lowest, now, step.checkin);
        const lowestSoFar = Math.min(existing.lowest, result.lowest);
        await chrome.storage.local.set({
          [key]: {
            ...existing,
            lastMinuteAlert: lmDecision.newState,
            goodDealAlert: judged.goodDeal.newState,
            prices,
            lowest: lowestSoFar,
            lowestAt: lowestSoFar < existing.lowest ? now : existing.lowestAt,
            updatedAt: now,
            amenities: Array.isArray(result.amenities) ? result.amenities : existing.amenities || [],
          },
        });
        updated++;

        // Same discountPct derivation evaluateAndAlert() (the main scan)
        // uses when a site doesn't show its own "% off" badge, so a
        // favorite refreshed via this path gets the same discount info
        // in Recent Listings as one found by a normal scan.
        const discountPct =
          existing.originalPrice && existing.originalPrice > result.lowest
            ? Math.round(((existing.originalPrice - result.lowest) / existing.originalPrice) * 100)
            : null;

        const refreshedListing = {
          source: step.source,
          hotelName: step.hotelName,
          destination: existing.destination,
          checkin: step.checkin,
          checkout: step.checkout,
          discountedPrice: result.lowest,
          originalPrice: existing.originalPrice,
          discountPct,
          isNewlyBuilt: existing.isNewlyBuilt,
          starRating: existing.starRating,
          rating: existing.rating ?? null,
          reviewCount: existing.reviewCount ?? null,
          url: step.url,
        };

        // Real gap: this write path (hist: update above) never fed
        // recentScans at all, so the popup's "Recent Listings" panel --
        // including its "last scanned" timestamp -- silently never
        // reflected a Quick Refresh Favorites run, only full/
        // destination-scoped scans. Same shared helper evaluateAndAlert()
        // uses, see recordRecentScan()'s own comment.
        await recordRecentScan(refreshedListing, now);

        await checkPriceTargets(refreshedListing, settings);

        if (lmDecision.fire) {
          const reasons = [
            `\u{1F525} Favorite, check-in ${leadLabel(lm.leadDays)}: ${formatINR(lm.refPrice)} -> ${formatINR(result.lowest)} (-${lm.dropPct}%, saves ${formatINR(lm.saving)})`,
          ];
          await notifyDealEvent("last_minute", refreshedListing, [...reasons, ...judged.reasons], settings, { dropPct: lm.dropPct, refPrice: lm.refPrice, leadDays: lm.leadDays });
        } else if (judged.recordLow.fire) {
          await logActivity("record_low", { hotelName: step.hotelName, destination: existing.destination, price: result.lowest, prevLow: judged.recordLow.prevLow });
          await notifyDealEvent("record_low", refreshedListing, judged.reasons, settings, judged.recordLowExtra);
        } else if (judged.goodDeal.fire) {
          await notifyDealEvent("good_deal", refreshedListing, judged.reasons, settings, judged.goodDealExtra);
        }
      }
    }
  } catch (e) {
    console.log("[favorites] step failed:", e);
  }

  const checked = activeFavoriteRefresh.checked + 1;
  const newStepIndex = activeFavoriteRefresh.stepIndex + 1;
  await chrome.storage.local.set({
    activeFavoriteRefresh: { ...activeFavoriteRefresh, stepIndex: newStepIndex, checked, updated },
  });
  await updateFavoriteRefreshProgress({ completed: checked, updated, lastStepAt: new Date().toISOString() });

  const { favoriteRefreshProgress: afterStepProgress } = await chrome.storage.local.get("favoriteRefreshProgress");
  if (afterStepProgress && afterStepProgress.stopRequested) {
    await finishFavoriteRefresh(true);
    return;
  }
  if (newStepIndex >= activeFavoriteRefresh.steps.length) {
    await finishFavoriteRefresh(false);
    return;
  }

  // This used to pace at 5-10 seconds, 2-4x faster than the main scan's
  // already-deliberate pacing. Fast enough, across enough checks in one
  // sitting, to plausibly exhaust or corrupt this browser profile's own
  // connection pool for the site, a real-world case of exactly that
  // happened after a 200-favorite run. Using the same settings as the
  // main scan now, one dial controls the pace everywhere, scheduled via
  // an alarm rather than awaited directly for the same survivability
  // reason as the main scan.
  const delaySeconds = settings.minDelaySeconds + Math.random() * (settings.maxDelaySeconds - settings.minDelaySeconds);
  chrome.alarms.create("favoriteRefreshStepAlarm", { delayInMinutes: Math.max(delaySeconds / 60, 0.05) });
}

async function finishFavoriteRefresh(wasStopped) {
  const { activeFavoriteRefresh, favoriteRefreshProgress } = await chrome.storage.local.get([
    "activeFavoriteRefresh",
    "favoriteRefreshProgress",
  ]);
  const checked = activeFavoriteRefresh ? activeFavoriteRefresh.checked : favoriteRefreshProgress ? favoriteRefreshProgress.completed : 0;
  const updated = activeFavoriteRefresh ? activeFavoriteRefresh.updated : favoriteRefreshProgress ? favoriteRefreshProgress.updated : 0;
  const total = favoriteRefreshProgress ? favoriteRefreshProgress.total : 0;

  await chrome.storage.local.set({
    favoriteRefreshProgress: {
      running: false,
      total,
      completed: checked,
      updated,
      finishedAt: new Date().toISOString(),
      currentLabel: wasStopped ? "Stopped" : "Idle",
      stopRequested: false,
    },
  });
  await chrome.storage.local.remove("activeFavoriteRefresh");
  await logActivity(wasStopped ? "favorite_refresh_stopped" : "favorite_refresh_finished", { checked, updated, total });
  console.log(`[favorites] ${wasStopped ? "stopped early" : "done"}, checked ${checked}, updated ${updated}`);

  // Same rare-deal check finishScan() does (see checkRareDealAlerts()'s
  // comment): favorites are exactly the hotels this alert matters most
  // for, and a refresh updates real prices just as much as a full scan
  // does, so it deserves the same check rather than only firing after a
  // full destination sweep.
  if (updated > 0) {
    try {
      const settings = await getSettings();
      await checkRareDealAlerts(settings);
      await checkMarketDeals(settings);
    } catch (e) {
      console.log("[rare-deal] alert check failed:", e);
      await logActivity("rare_deal_check_failed", { error: String(e) });
    }
  }

  if (!wasStopped) {
    await drainPendingDestinationFavoriteRefresh();
  }
}

/**
 * Same self-healing as the main scan's watchdog, applied to favorites
 * refresh: force-clears a zombie state with nothing to resume from
 * (an older version, or otherwise corrupted), and resumes a refresh
 * that claims to be running but hasn't logged any activity in minutes,
 * far longer than a single step should ever take.
 */
async function checkFavoriteRefreshWatchdog() {
  const { activeFavoriteRefresh, favoriteRefreshProgress } = await chrome.storage.local.get([
    "activeFavoriteRefresh",
    "favoriteRefreshProgress",
  ]);
  if (!favoriteRefreshProgress || !favoriteRefreshProgress.running) return;

  if (!activeFavoriteRefresh) {
    console.log("[watchdog] favorite refresh marked running with no resumable state, clearing it");
    await logActivity("watchdog_cleared_zombie_favorite_refresh", null);
    await chrome.storage.local.set({
      favoriteRefreshProgress: {
        ...favoriteRefreshProgress,
        running: false,
        finishedAt: new Date().toISOString(),
        currentLabel: "Stopped (recovered from a stuck state)",
        stopRequested: false,
      },
    });
    return;
  }

  if (favoriteRefreshStepInFlight) return;

  const referenceTime = favoriteRefreshProgress.lastStepAt || favoriteRefreshProgress.startedAt;
  const stalledForMs = Date.now() - new Date(referenceTime).getTime();
  const STALL_THRESHOLD_MS = 4 * 60 * 1000;

  if (stalledForMs > STALL_THRESHOLD_MS) {
    console.log(`[watchdog] favorite refresh appears stalled for ${Math.round(stalledForMs / 1000)}s, resuming`);
    await logActivity("watchdog_resumed_stalled_favorite_refresh", { stalledForSeconds: Math.round(stalledForMs / 1000) });
    runFavoriteRefreshStep();
  }
}

/**
 * A running, timestamped log of what the extension actually did, kept
 * separate from the scan progress log (which only covers the current
 * scan and resets each time). This is for after-the-fact diagnosis,
 * "when did it actually stall", "how often is a page timing out",
 * that kind of question, exportable as CSV from the dashboard so it can
 * be shared or opened in Excel.
 */
async function logActivity(event, details) {
  const { activityLog = [] } = await chrome.storage.local.get("activityLog");
  activityLog.push({ at: new Date().toISOString(), event, details: details || null });
  // Capped so this can't grow without bound, oldest entries drop off.
  await chrome.storage.local.set({ activityLog: activityLog.slice(-3000) });
}

async function updateProgress(patch) {
  const { scanProgress = {} } = await chrome.storage.local.get("scanProgress");
  await chrome.storage.local.set({ scanProgress: { ...scanProgress, ...patch } });
}

async function appendProgressLog(label, foundCount, mismatchedCount = 0, hidden = false) {
  const { scanProgress = {} } = await chrome.storage.local.get("scanProgress");
  const log = [
    { at: new Date().toISOString(), label, found: foundCount, mismatched: mismatchedCount, hidden },
    ...(scanProgress.log || []),
  ].slice(0, 50);
  await chrome.storage.local.set({
    scanProgress: { ...scanProgress, log, completed: (scanProgress.completed || 0) + 1 },
  });
}
