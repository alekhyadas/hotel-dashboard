/**
 * Runs on MakeMyTrip and Goibibo hotel-listing pages, whether you navigated
 * there yourself or the extension opened the window for a scheduled scan.
 *
 * SCRAPING APPROACH
 * Earlier versions guessed CSS class names ("div[class*='htlCard']" etc).
 * That kept failing, these sites use generated class names that change, and
 * guessing them blind doesn't work. This version is structural instead:
 *
 *   1. Find every element on the page whose text is a rupee price.
 *   2. Walk up from each one until hitting a container that also holds an
 *      image and a link, that's a hotel card, whatever it happens to be
 *      called.
 *   3. Discard containers that contain other containers, so we keep the
 *      individual cards rather than the list wrapping all of them.
 *
 * Nothing here depends on class names, so it survives the site restyling.
 *
 * DATES
 * MakeMyTrip appears to ignore date parameters passed in the URL and fall
 * back to its own defaults. So rather than trusting the dates we asked
 * for, this reads the dates the page is actually showing and reports them
 * back, and background.js records those. Better a correct price for the
 * wrong date than a wrong price for the right one.
 */

/**
 * If the extension reloads while this content script is still running
 * (an update landing mid-scrape, or the page staying open longer than
 * expected), chrome.runtime becomes undefined and a plain sendMessage
 * call throws an uncaught error. This just lets that attempt fail
 * quietly, there's nothing useful to do with a message once the
 * extension on the other end is already gone.
 */
function safeSendMessage(message) {
  try {
    if (chrome.runtime && chrome.runtime.id) {
      chrome.runtime.sendMessage(message);
    }
  } catch (e) {
    console.log("[content] extension context gone, dropping message:", e);
  }
}

const SITE = location.hostname.includes("goibibo") ? "goibibo" : "makemytrip";

const PRICE_RE = /[\u20b9]\s?([\d,]{3,})/;

function parsePriceValue(text) {
  const m = PRICE_RE.exec(text || "");
  if (!m) return null;
  const digits = m[1].replace(/,/g, "");
  return /^\d+$/.test(digits) ? parseInt(digits, 10) : null;
}

/**
 * Star rating shows up two ways: as text ("4 Star") or as filled star
 * glyphs (four filled stars, with empty ones for the rest). Earlier
 * versions only handled the text form, which is why star filtering never
 * actually worked.
 */
function parseStarRating(text) {
  if (!text) return null;
  const textual = /(\d(?:\.\d)?)\s*[Ss]tar/.exec(text);
  if (textual) return Math.round(parseFloat(textual[1]));

  const filled = (text.match(/\u2605/g) || []).length;
  const empty = (text.match(/\u2606/g) || []).length;
  // only trust glyph counting when it looks like a rating scale
  if (filled > 0 && filled + empty >= 3 && filled + empty <= 5) return filled;
  return null;
}

/**
 * Guest rating and review volume, e.g. a card showing "Very Good 4.2
 * (2196 Ratings)". Both matter: a high score from a handful of reviews is
 * far weaker evidence than a slightly lower one from hundreds, so the
 * dashboard filters on volume as well as score.
 *
 * Care is needed pulling the score out, listing cards are full of decimals
 * that aren't ratings ("1.7 km drive to the beach"), so this only accepts
 * a number that's either on a line of its own or sits right after a rating
 * word, and never one followed by a unit.
 */
function parseRating(text) {
  if (!text) return { rating: null, reviewCount: null };

  let reviewCount = null;
  const countMatch = /\(?\s*([\d,]{2,})\s*(?:Ratings?|Reviews?)\s*\)?/i.exec(text);
  if (countMatch) {
    const n = parseInt(countMatch[1].replace(/,/g, ""), 10);
    if (Number.isFinite(n)) reviewCount = n;
  }

  let rating = null;
  const worded = /(?:Excellent|Very\s+Good|Good|Average|Fair|Poor)\s*[:\-]?\s*([1-5](?:\.\d)?)\b(?!\s*(?:km|kms|m|mins?|minutes?))/i.exec(text);
  if (worded) {
    rating = parseFloat(worded[1]);
  } else {
    for (const line of text.split("\n")) {
      const solo = /^\s*([1-5]\.\d)\s*$/.exec(line.trim());
      if (solo) {
        rating = parseFloat(solo[1]);
        break;
      }
    }
  }

  if (rating !== null && (rating < 1 || rating > 5)) rating = null;
  return { rating, reviewCount };
}

/**
 * Some MakeMyTrip links appear to have their raw href written as
 * "/www.makemytrip.com/hotels/..." (the domain repeated as a path
 * segment), which .href resolves faithfully into a broken double-domain
 * URL rather than fixing it, since it IS technically what the link says.
 * This strips that duplication specifically.
 */
function sanitizeUrl(url) {
  if (!url) return url;
  try {
    const u = new URL(url);
    const hostEscaped = u.hostname.replace(/\./g, "\\.");
    const dupRe = new RegExp(`^/${hostEscaped}(/.*)$`, "i");
    const m = dupRe.exec(u.pathname);
    if (m) u.pathname = m[1];
    return u.toString();
  } catch (e) {
    return url;
  }
}

function parseDiscountPct(text) {
  const m = /(\d{1,3})\s*%\s*(?:off|OFF)/.exec(text || "");
  return m ? parseInt(m[1], 10) : null;
}

/**
 * The discount from the two PRICES on the card. The "NN% off" in the card text
 * is unreliable: it also matches offers that have nothing to do with the room
 * rate ("50% off on 2 sessions of couple's Spa" was reported as a 50% price
 * discount). Only a struck-through original price counts.
 */
function computeDiscountPct(originalPrice, discountedPrice) {
  if (!originalPrice || !discountedPrice || originalPrice <= discountedPrice) return null;
  return Math.round(((originalPrice - discountedPrice) / originalPrice) * 100);
}

function detectNewlyBuilt(text) {
  return (text || "")
    .split("\n")
    .map((l) => l.trim())
    .some((l) => /^new(ly\s*built)?$/i.test(l));
}

/** Leaf elements whose own text contains a rupee amount. */
function findPriceElements() {
  const out = [];
  if (!document.body) return out;
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT);
  let node = walker.currentNode;
  while (node) {
    if (node.children.length === 0) {
      const t = node.textContent || "";
      if (PRICE_RE.test(t)) out.push(node);
    }
    node = walker.nextNode();
  }
  return out;
}

/** Walk up from a price element to the enclosing hotel card. */
function findCardFor(priceEl) {
  let node = priceEl;
  for (let i = 0; i < 14; i++) {
    node = node.parentElement;
    if (!node || node === document.body) return null;
    const text = node.innerText || "";
    const hasImg = node.querySelector("img");
    const hasLink = node.querySelector("a[href]");
    if (hasImg && hasLink && text.length > 40 && text.length < 2000) {
      return node;
    }
  }
  return null;
}

function findCards() {
  const found = new Set();
  for (const priceEl of findPriceElements()) {
    const card = findCardFor(priceEl);
    if (card) found.add(card);
  }
  const arr = Array.from(found);
  // Keep only innermost containers, drop any that wrap another candidate,
  // otherwise a list wrapper counts as one giant "card".
  return arr.filter((c) => !arr.some((other) => other !== c && c.contains(other)));
}

/**
 * A card usually shows several prices: the struck-through original, the
 * actual price, and smaller lines like taxes. Picks them apart by style
 * rather than by guessing which number is which:
 *   - line-through styling  -> the original price
 *   - text mentioning tax   -> ignore
 *   - largest font size     -> the real, headline price
 */
/**
 * Struck-through detection has to cope with a few variations: the
 * line-through may sit on the price element or on an ancestor, it may
 * be expressed via <del>/<s>/<strike> tags instead of CSS, and browsers
 * differ over whether it lands in textDecorationLine or textDecoration.
 * Checking all of those is cheap and avoids silently mistaking the
 * original price for the payable one.
 */
function isStruckThrough(el) {
  let node = el;
  for (let i = 0; i < 4 && node; i++) {
    const tag = node.tagName;
    if (tag === "DEL" || tag === "S" || tag === "STRIKE") return true;
    const style = window.getComputedStyle(node);
    const line = (style.textDecorationLine || "") + " " + (style.textDecoration || "");
    if (line.includes("line-through")) return true;
    node = node.parentElement;
  }
  return false;
}

// A real MakeMyTrip room price is essentially never below this, rooms
// bookable on the platform start well above it. A number smaller than
// this is almost certainly a discount amount, cashback figure, or coupon
// badge, not the actual price, no matter how prominently it's styled.
const MIN_PLAUSIBLE_PRICE = 300;

function extractPrices(card) {
  const candidates = [];
  const walker = document.createTreeWalker(card, NodeFilter.SHOW_ELEMENT);
  let node = walker.currentNode;
  while (node) {
    if (node.children.length === 0) {
      const text = node.textContent || "";
      const value = parsePriceValue(text);
      if (value !== null) {
        const style = window.getComputedStyle(node);
        const parentText = node.parentElement ? node.parentElement.innerText || "" : "";
        const context = (text + " " + parentText).slice(0, 160).toLowerCase();
        // TAX_RE lives in shared.js now, word-boundaried: the old
        // unanchored /tax|fee/ matched "fee" as a substring of "coffee"
        // and "toffee" in nearby unrelated text (an amenity mention next
        // to a real price was enough to wrongly exclude it).
        const isTax = TAX_RE.test(context);
        // Promo badges ("Flat ₹150 Off", "₹100 Cashback") can be styled
        // MORE prominently than the actual price, which is exactly what
        // broke "biggest font wins" as the sole rule. Explicitly
        // excluding anything discount-flavoured fixes that directly,
        // rather than hoping font size happens to sort it out.
        // PROMO_RE lives in shared.js now, so this and detail-content.js's
        // own promo filter can't quietly diverge again. It's also now
        // word-boundaried: an unanchored "off" used to also match
        // "coffee", "office", "toffee" and "cutoff" in nearby unrelated
        // text, wrongly excluding real, non-promotional prices.
        const isPromo = PROMO_RE.test(context);
        const nearPerNight = /per\s*night|\/\s*night/.test(context);
        candidates.push({
          value,
          struck: isStruckThrough(node),
          isTax,
          isPromo,
          nearPerNight,
          fontSize: parseFloat(style.fontSize) || 0,
        });
      }
    }
    node = walker.nextNode();
  }

  const original = candidates
    .filter((c) => c.struck && !c.isTax && !c.isPromo)
    .sort((a, b) => b.value - a.value)[0];

  // Non-promotional, non-tax, and above the plausibility floor, no
  // exceptions, regardless of styling.
  const plausible = candidates.filter(
    (c) => !c.struck && !c.isTax && !c.isPromo && c.value >= MIN_PLAUSIBLE_PRICE
  );

  // A candidate explicitly tagged "per night" is much stronger evidence
  // than font size, prefer it when one exists.
  const perNightMatch = plausible.filter((c) => c.nearPerNight).sort((a, b) => b.fontSize - a.fontSize)[0];
  const payable = perNightMatch || plausible.sort((a, b) => b.fontSize - a.fontSize || b.value - a.value)[0];

  return {
    originalPrice: original ? original.value : null,
    discountedPrice: payable ? payable.value : null,
    // v2.2.4: every price-looking number on the card and how it was judged, kept with the listing so a suspicious drop can be checked later
    candidates: candidates.slice(0, 12).map((c) => ({ v: c.value, struck: c.struck, tax: c.isTax, promo: c.isPromo, night: c.nearPerNight, fs: c.fontSize })),
  };
}

/** The hotel name is usually the most prominent link or heading text. */
function extractHotelName(card) {
  const heading = card.querySelector("h1, h2, h3, h4");
  if (heading && (heading.innerText || "").trim().length > 2) {
    return heading.innerText.trim().split("\n")[0].slice(0, 120);
  }
  const links = Array.from(card.querySelectorAll("a[href]"))
    .map((a) => (a.innerText || "").trim().split("\n")[0])
    .filter((t) => t.length > 3 && t.length < 120 && !/^\u20b9/.test(t));
  if (links.length) {
    return links.sort((a, b) => b.length - a.length)[0];
  }
  const firstLine = (card.innerText || "").split("\n").map((l) => l.trim()).filter(Boolean)[0];
  return (firstLine || "Unknown").slice(0, 120);
}

/**
 * Reads the check-in/check-out the page is actually showing. MakeMyTrip
 * ignores dates passed via URL and uses its own defaults, so the requested
 * dates can't be trusted, the displayed ones are the truth.
 */
function readDisplayedDates() {
  // First choice: the dates in the page's own URL. MakeMyTrip rewrites the
  // address to the dates it really used, and no longer prints them in the
  // page text, so reading text here returned nothing and every scan was
  // trusted to have shown the dates it asked for (it often had not).
  if (/makemytrip/.test(location.hostname)) {
    const fromUrl = mmtDatesFromUrl(location.search);
    if (fromUrl) return { ...fromUrl, rawSample: [fromUrl.checkin, fromUrl.checkout], source: "url" };
  }
  const text = document.body ? document.body.innerText || "" : "";
  const dateRe = /(?:[A-Z][a-z]{2},\s*)?(\d{1,2})\s+([A-Z][a-z]{2})\s+(\d{4})/g;
  const found = [];
  let m;
  while ((m = dateRe.exec(text)) !== null && found.length < 6) {
    found.push({ day: m[1], mon: m[2], year: m[3], raw: m[0] });
  }
  const months = { Jan: "01", Feb: "02", Mar: "03", Apr: "04", May: "05", Jun: "06",
                   Jul: "07", Aug: "08", Sep: "09", Oct: "10", Nov: "11", Dec: "12" };
  const toIso = (d) => {
    const mm = months[d.mon];
    if (!mm) return null;
    return `${d.year}-${mm}-${String(d.day).padStart(2, "0")}`;
  };
  return {
    checkin: found[0] ? toIso(found[0]) : null,
    checkout: found[1] ? toIso(found[1]) : null,
    rawSample: found.slice(0, 2).map((f) => f.raw),
  };
}

/**
 * The hotel photo on a listing card. Handles lazy-loaded images (the real
 * URL sits in data-src or srcset until it scrolls into view) and carousels
 * that use background-image instead of an <img>.
 */
function extractImageUrl(card) {
  const candidates = [];
  for (const img of card.querySelectorAll("img")) {
    const r = img.getBoundingClientRect();
    const srcset = img.getAttribute("srcset") || "";
    const fromSet = srcset.split(",").map((s) => s.trim().split(/\s+/)[0]).filter(Boolean).pop();
    const src = img.currentSrc || img.getAttribute("data-src") || img.getAttribute("data-lazy-src") || fromSet || img.src;
    candidates.push({ src, w: r.width || img.naturalWidth || 0, h: r.height || img.naturalHeight || 0 });
  }
  for (const el of card.querySelectorAll('[style*="background-image"]')) {
    const m = /url\(["']?(https:[^"')]+)["']?\)/i.exec(el.getAttribute("style") || "");
    if (m) {
      const r = el.getBoundingClientRect();
      candidates.push({ src: m[1], w: r.width || 0, h: r.height || 0 });
    }
  }
  return pickBestImage(candidates);
}

function scrapeListings() {
  const cards = findCards();
  const results = [];
  const seenNames = new Set();
  const displayed = readDisplayedDates();

  for (const card of cards.slice(0, 200)) {
    const text = card.innerText || "";
    const { originalPrice, discountedPrice, candidates: priceCandidates } = extractPrices(card);
    if (discountedPrice === null) continue;

    const name = extractHotelName(card);
    if (seenNames.has(name)) continue;
    seenNames.add(name);

    const { rating, reviewCount } = parseRating(text);

    let href = null;
    const link = card.tagName === "A" ? card : card.querySelector("a[href]");
    if (link) {
      href = sanitizeUrl(link.href);
    }

    results.push({
      source: SITE,
      hotelName: name,
      starRating: parseStarRating(text),
      rating,
      reviewCount,
      pageCheckin: displayed.checkin,
      pageCheckout: displayed.checkout,
      originalPrice,
      discountedPrice,
      ...(typeof TripTools !== "undefined" ? { quote: TripTools.readQuote(text, discountedPrice, TripTools.urlContext(location.search, displayed)) } : {}),
      discountPct: computeDiscountPct(originalPrice, discountedPrice),
      isNewlyBuilt: detectNewlyBuilt(text),
      imageUrl: extractImageUrl(card),
      url: href,
      snap: { text: text.replace(/\s+/g, " ").slice(0, 420), cands: priceCandidates },
    });
  }

  return results;
}

/**
 * Star ratings often aren't real text at all, they're icons (SVG or an
 * icon font), which parseStarRating's text search can't see, innerText
 * strips markup out entirely. This scans for anything that LOOKS like a
 * star icon structurally: elements whose class name mentions "star",
 * <svg> elements, and star-related <img> tags, so a fix can be built from
 * real markup instead of guessing.
 */
function findStarLikeElements(card) {
  const results = [];
  const all = card.querySelectorAll("*");
  for (const el of all) {
    const cls = (el.getAttribute("class") || "").toLowerCase();
    const alt = (el.getAttribute("alt") || "").toLowerCase();
    if (cls.includes("star") || alt.includes("star")) {
      results.push({
        tag: el.tagName,
        class: el.getAttribute("class") || null,
        alt: el.getAttribute("alt") || null,
        isSvg: el.tagName === "svg" || el.tagName === "SVG",
      });
    }
  }
  return results.slice(0, 20);
}

function gatherDebugInfo() {
  const priceEls = findPriceElements();
  const cards = findCards();
  return {
    url: location.href,
    title: document.title,
    visibilityState: document.visibilityState,
    priceElementsFound: priceEls.length,
    cardsFound: cards.length,
    displayedDates: readDisplayedDates(),
    samplePriceTexts: priceEls.slice(0, 8).map((el) => (el.textContent || "").trim().slice(0, 60)),
    sampleCardText: cards[0] ? (cards[0].innerText || "").slice(0, 400) : null,
    sampleCardHTML: cards[0] ? cards[0].innerHTML.slice(0, 2500) : null,
    starLikeElements: cards[0] ? findStarLikeElements(cards[0]) : [],
    // v2.0.12: the page's own count ("124 Properties in Mandarmani"), to tell a full list from the first handful
    expectedCount: (() => { const m = new RegExp("([0-9,]+)"+String.fromCharCode(92)+"s+Propert(?:y|ies)"+String.fromCharCode(92)+"s+in", "i").exec(document.body ? document.body.innerText : ""); return m ? parseInt(m[1].replace(/,/g, ""), 10) : null; })(),
    bodyTextSample: (document.body ? document.body.innerText : "").slice(0, 1200),
  };
}

function extractCode() {
  const params = new URLSearchParams(location.search);
  if (SITE === "makemytrip") {
    return params.get("city") || params.get("locusId");
  }
  const match = /hotels-in-([a-z0-9-]+?)(?:-ct)?\/?$/i.exec(location.pathname);
  return match ? match[1] : null;
}

function guessDestinationName() {
  const heading = document.querySelector("h1, h2");
  if (heading && heading.innerText) {
    const m = /(?:in|In)\s+([A-Za-z ]{3,40})/.exec(heading.innerText);
    if (m) return m[1].trim();
  }
  const titleMatch = /(?:in|In)\s+([A-Za-z ]{3,40})/.exec(document.title || "");
  if (titleMatch) return titleMatch[1].trim();
  return document.title || "";
}

/** Polls until cards appear or we give up. */
function waitForCards(maxWaitMs, intervalMs) {
  return new Promise((resolve) => {
    const start = Date.now();
    const check = () => {
      if (findCards().length > 0) return resolve(true);
      if (Date.now() - start >= maxWaitMs) return resolve(false);
      setTimeout(check, intervalMs);
    };
    check();
  });
}

/**
 * Scrolls until the page stops producing new hotel cards, rather than a
 * fixed number of scrolls. These listings lazy-load as you go, so a fixed
 * count either wastes time on short pages or truncates long ones. Stops
 * on three consecutive rounds with no new cards, or when the time budget
 * runs out, whichever comes first.
 */
function scrollUntilStable(budgetMs) {
  return new Promise((resolve) => {
    const start = Date.now();
    let lastCount = findCards().length;
    let lastHeight = document.body.scrollHeight;
    let stableRounds = 0;
    let rounds = 0;

    // MakeMyTrip only loads the next batch of hotels while you scroll steadily
    // a screen at a time. A single jump to the bottom (what this used to do)
    // loaded only the first 5 or so: a page that says "127 properties" gave us
    // 5. Measured live in Oct 2026: steady steps of about one screen every
    // half second loaded 98 of 127 in 25 seconds, the jump loaded 5.
    const step = () => {
      const elapsed = Date.now() - start;
      if (elapsed >= budgetMs || stableRounds >= 6) {
        window.scrollTo(0, 0);
        return resolve({ rounds, finalCount: findCards().length, stoppedEarly: stableRounds >= 6, height: document.body.scrollHeight });
      }

      window.scrollBy({ top: Math.round(window.innerHeight * (0.9 + Math.random() * 0.25)), behavior: "instant" });
      rounds++;

      setTimeout(() => {
        const count = findCards().length;
        const height = document.body.scrollHeight;
        if (count > lastCount || height > lastHeight + 50) {
          stableRounds = 0;
          lastCount = Math.max(count, lastCount);
          lastHeight = height;
        } else {
          stableRounds++;
        }
        step();
      }, 420 + Math.random() * 260);
    };

    step();
  });
}

/** Per-page time budget, configurable from the popup. */
async function getPerPageBudgetMs() {
  try {
    const { settings } = await chrome.storage.local.get("settings");
    const seconds = settings && settings.perPageSeconds ? settings.perPageSeconds : 40;
    return seconds * 1000;
  } catch (e) {
    return 40000;
  }
}

(async function main() {
  try {
    // Not a fixed 2 seconds every time: a real person is never that regular.
    await new Promise((r) => setTimeout(r, 1800 + Math.random() * 1400));

    const bodyTextSample = (document.body?.innerText || "").slice(0, 1200);
    if (hotelBlockPageKind({ bodyTextSample }) === "200-ok") {
      const debug = gatherDebugInfo();
      if (hotelBlockPageKind(debug) === "200-ok") {
        safeSendMessage({ type: "SCRAPE_RESULT", listings: [], debug });
        return;
      }
    }

    const code = extractCode();
    if (code) {
      safeSendMessage({
        type: "CODE_LEARNED",
        site: SITE,
        destinationGuess: guessDestinationName(),
        code,
      });
    }

    const budgetMs = await getPerPageBudgetMs();
    const appeared = await waitForCards(12000, 1000);

    let scrollStats = null;
    if (appeared) {
      // reserve a little of the budget for the final parse
      scrollStats = await scrollUntilStable(Math.max(5000, budgetMs - 6000));
      await new Promise((r) => setTimeout(r, 1500));
    }

    const listings = scrapeListings();
    safeSendMessage({
      type: "SCRAPE_RESULT",
      listings,
      // always send diagnostics, not just on failure, so a scan that
      // "works" but returns suspiciously little is still explainable
      debug: { ...gatherDebugInfo(), scrollStats },
    });
  } catch (err) {
    let debug = { error: String(err && err.stack ? err.stack : err) };
    try {
      debug = { ...gatherDebugInfo(), error: String(err && err.stack ? err.stack : err) };
    } catch (_) {}
    safeSendMessage({ type: "SCRAPE_RESULT", listings: [], debug });
  }
})();
