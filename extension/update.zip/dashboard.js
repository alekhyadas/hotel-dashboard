let allGroups = [];

// Comparison drawer (PROJECT_BRIEF open item 2): groupKeys currently
// selected for side-by-side comparison, capped at 3, a 4th column would
// stop being scannable at a glance, which is the whole point of this
// over just reading the table.
const MAX_COMPARE = 3;
let compareSelection = new Set();

// A high score from a handful of reviews is weak evidence; these are the
// thresholds the "trustworthy reviews only" filter and the well-reviewed
// KPI both use.
const TRUSTWORTHY_MIN_RATING = 4.0;
const TRUSTWORTHY_MIN_REVIEWS = 200;
const YOUTUBE_POPULAR_THRESHOLD = 50000;

// loadTrackedHotelGroups() and the GitHub publish helpers now live in
// shared.js, so background.js's automatic publish and this page's manual
// publish always use the exact same logic.

function isTrustworthy(r) {
  return r.rating !== null && r.reviewCount !== null &&
    r.rating >= TRUSTWORTHY_MIN_RATING && r.reviewCount >= TRUSTWORTHY_MIN_REVIEWS;
}

function isAtLowest(r) {
  return r.current <= r.lowest && !r.isLikelyBadScrape;
}

function renderKpis(groups) {
  const cheapest = groups.slice().sort((a, b) => a.cheapestPrice - b.cheapestPrice)[0];
  if (cheapest) {
    document.getElementById("kpi-cheapest").textContent = formatINR(cheapest.cheapestPrice);
    document.getElementById("kpi-cheapest-sub").textContent =
      `${cheapest.hotelName} \u2022 ${cheapest.destination} \u2022 ${cheapest.cheapest.checkin}`;
  }
  document.getElementById("kpi-at-low").textContent = groups.filter((g) => g.everAtLowest).length;
  document.getElementById("kpi-rare-deals").textContent = groups.filter((g) => g.rarity && g.rarity.isRareDeal).length;
  document.getElementById("kpi-newly-built").textContent = groups.filter((g) => g.isNewlyBuilt).length;
  document.getElementById("kpi-well-reviewed").textContent = groups.filter(isTrustworthy).length;
  document.getElementById("kpi-youtube-popular").textContent =
    groups.filter((g) => g.youtubeViews !== null && g.youtubeViews >= YOUTUBE_POPULAR_THRESHOLD).length;
}

function populateDestinationFilter(groups) {
  const select = document.getElementById("filter-destination");
  const existing = new Set(Array.from(select.options).map((o) => o.value));
  for (const d of [...new Set(groups.map((g) => g.destination))].sort()) {
    if (!existing.has(d)) {
      const opt = document.createElement("option");
      opt.value = d;
      opt.textContent = d;
      select.appendChild(opt);
    }
  }
}

async function getBlockedSet() {
  const { blockedHotels = [] } = await chrome.storage.local.get("blockedHotels");
  return new Set(blockedHotels.map((b) => `${b.source}:::${b.hotelName}:::${b.destination}`));
}

// For the KPIs with no existing checkbox filter to reuse.
let kpiQuickFilter = null; // 'atLowest' | 'youtubePopular' | 'rareDeal' | null

function setKpiQuickFilter(filter) {
  kpiQuickFilter = kpiQuickFilter === filter ? null : filter;
  renderKpiActiveStates();
  rerender();
}

function toggleCheckboxFilter(checkboxId) {
  const cb = document.getElementById(checkboxId);
  cb.checked = !cb.checked;
  renderKpiActiveStates();
  rerender();
}

function renderKpiActiveStates() {
  document.getElementById("kpi-at-low").closest(".kpi").classList.toggle("kpi-active", kpiQuickFilter === "atLowest");
  document.getElementById("kpi-rare-deals").closest(".kpi").classList.toggle("kpi-active", kpiQuickFilter === "rareDeal");
  document.getElementById("kpi-youtube-popular").closest(".kpi").classList.toggle("kpi-active", kpiQuickFilter === "youtubePopular");
  document.getElementById("kpi-newly-built").closest(".kpi").classList.toggle("kpi-active", document.getElementById("filter-newly-built").checked);
  document.getElementById("kpi-well-reviewed").closest(".kpi").classList.toggle("kpi-active", document.getElementById("filter-quality").checked);
}

document.getElementById("kpi-at-low").closest(".kpi").addEventListener("click", () => setKpiQuickFilter("atLowest"));
document.getElementById("kpi-rare-deals").closest(".kpi").addEventListener("click", () => setKpiQuickFilter("rareDeal"));
document.getElementById("kpi-youtube-popular").closest(".kpi").addEventListener("click", () => setKpiQuickFilter("youtubePopular"));
document.getElementById("kpi-newly-built").closest(".kpi").addEventListener("click", () => toggleCheckboxFilter("filter-newly-built"));
document.getElementById("kpi-well-reviewed").closest(".kpi").addEventListener("click", () => toggleCheckboxFilter("filter-quality"));

// Set by clicking a table header, takes priority over the dropdown
// until the dropdown itself is used again. Column clicks toggle
// direction on repeat clicks of the same column.
let columnSortOverride = null;

const COLUMN_SORT_DEFAULT_DIRECTION = {
  hotel: "asc",
  starTier: "desc",
  destination: "asc",
  checkin: "asc",
  lowest: "asc",
  lowestEver: "asc",
  rating: "desc",
  youtube: "desc",
  tracking: "desc",
};

function starTierValue(g) {
  return g.manualStarTier || g.starRating || g.aiEstimatedStarTier || 0;
}

function setColumnSort(field) {
  if (columnSortOverride && columnSortOverride.field === field) {
    columnSortOverride.direction = columnSortOverride.direction === "asc" ? "desc" : "asc";
  } else {
    columnSortOverride = { field, direction: COLUMN_SORT_DEFAULT_DIRECTION[field] || "asc" };
  }
  renderSortIndicators();
  rerender();
}

function renderSortIndicators() {
  document.querySelectorAll("th.sortable").forEach((th) => {
    th.classList.remove("sort-asc", "sort-desc");
    if (columnSortOverride && columnSortOverride.field === th.dataset.sort) {
      th.classList.add(columnSortOverride.direction === "asc" ? "sort-asc" : "sort-desc");
    }
  });
}

// Set by the weekend quick-filter buttons, null means no override.
let weekendFilter = null;

/** Friday of the nearest weekend, today included if today is already Fri/Sat/Sun. */
function startOfThisWeekend(today = new Date()) {
  const d = new Date(today);
  d.setHours(0, 0, 0, 0);
  const dow = d.getDay(); // 0=Sun..6=Sat
  if (dow === 0) d.setDate(d.getDate() - 2);
  else if (dow === 6) d.setDate(d.getDate() - 1);
  else d.setDate(d.getDate() + (5 - dow));
  return d;
}

function weekendDateRange(which) {
  const friday = startOfThisWeekend();
  if (which === "next") friday.setDate(friday.getDate() + 7);
  const sunday = new Date(friday);
  sunday.setDate(sunday.getDate() + 2);
  return { start: toISODateLocal(friday), end: toISODateLocal(sunday) };
}

function toISODateLocal(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function setWeekendFilter(which) {
  weekendFilter = weekendFilter === which ? null : which;
  document.querySelectorAll(".weekend-filter-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.weekend === weekendFilter);
  });
  rerender();
}

function applyFiltersAndSort(groups, blockedSet, showBlocked) {
  const searchText = document.getElementById("search-hotel-name").value.trim().toLowerCase();
  const destFilter = document.getElementById("filter-destination").value;
  const starFilter = document.getElementById("filter-star").value;
  const sortBy = document.getElementById("sort-by").value;
  const qualityOnly = document.getElementById("filter-quality").checked;
  const newlyBuiltOnly = document.getElementById("filter-newly-built").checked;
  const favoritesOnly = document.getElementById("filter-favorites").checked;

  const filtered = groups.filter((g) => {
    const blocked = blockedSet.has(g.groupKey);
    if (showBlocked) return blocked;
    if (blocked) return false;
    if (searchText && !g.hotelName.toLowerCase().includes(searchText)) return false;
    if (destFilter && g.destination !== destFilter) return false;
    if (starFilter && (!g.starRating || g.starRating < parseInt(starFilter, 10))) return false;
    if (qualityOnly && !isTrustworthy(g)) return false;
    if (newlyBuiltOnly && !g.isNewlyBuilt) return false;
    if (favoritesOnly && !g.isFavorite) return false;
    if (kpiQuickFilter === "atLowest" && !g.everAtLowest) return false;
    if (kpiQuickFilter === "rareDeal" && !(g.rarity && g.rarity.isRareDeal)) return false;
    if (kpiQuickFilter === "youtubePopular" && !(g.youtubeViews >= YOUTUBE_POPULAR_THRESHOLD)) return false;
    if (weekendFilter) {
      const { start, end } = weekendDateRange(weekendFilter);
      const hasMatchingDate = g.dates.some((d) => d.checkin >= start && d.checkin <= end);
      if (!hasMatchingDate) return false;
    }
    return true;
  });

  if (columnSortOverride) {
    const dir = columnSortOverride.direction === "desc" ? -1 : 1;
    switch (columnSortOverride.field) {
      case "hotel":
        filtered.sort((a, b) => dir * a.hotelName.localeCompare(b.hotelName));
        break;
      case "starTier":
        filtered.sort((a, b) => dir * (starTierValue(a) - starTierValue(b)));
        break;
      case "destination":
        filtered.sort((a, b) => dir * a.destination.localeCompare(b.destination));
        break;
      case "checkin":
        filtered.sort((a, b) => dir * (a.cheapest.checkin || "").localeCompare(b.cheapest.checkin || ""));
        break;
      case "lowest":
        filtered.sort((a, b) => dir * (a.cheapestPrice - b.cheapestPrice));
        break;
      case "lowestEver":
        filtered.sort((a, b) => dir * (a.lowestEver - b.lowestEver));
        break;
      case "rating":
        filtered.sort((a, b) => dir * ((a.rating || 0) - (b.rating || 0)) || dir * ((a.reviewCount || 0) - (b.reviewCount || 0)));
        break;
      case "youtube":
        filtered.sort((a, b) => dir * ((a.youtubeViews || 0) - (b.youtubeViews || 0)));
        break;
      case "tracking":
        filtered.sort((a, b) => dir * (a.dates.length - b.dates.length));
        break;
    }
    return filtered;
  }

  switch (sortBy) {
    case "lowest":
      filtered.sort((a, b) => a.cheapestPrice - b.cheapestPrice);
      break;
    case "value":
      filtered.sort((a, b) => {
        const av = a.rating ? a.cheapestPrice / a.rating : Infinity;
        const bv = b.rating ? b.cheapestPrice / b.rating : Infinity;
        return av - bv;
      });
      break;
    case "discount":
      filtered.sort((a, b) => (a.cheapestPrice - a.lowestEver) - (b.cheapestPrice - b.lowestEver));
      break;
    case "rating":
      filtered.sort((a, b) => (b.rating || 0) - (a.rating || 0) || (b.reviewCount || 0) - (a.reviewCount || 0));
      break;
    case "youtube":
      filtered.sort((a, b) => (b.youtubeViews || 0) - (a.youtubeViews || 0));
      break;
    case "checkin":
      filtered.sort((a, b) => (a.cheapest.checkin || "").localeCompare(b.cheapest.checkin || ""));
      break;
  }

  return filtered;
}

/**
 * A tiny inline trend line from stored price history, so a glance tells
 * you whether a price has been drifting up, down, or sitting flat,
 * without opening the row. Colored green/red only when there's an actual
 * net move, grey when it's basically flat.
 */
function sparklineSvg(priceHistory) {
  if (!priceHistory || priceHistory.length < 2) return "";
  const values = priceHistory.map((p) => p.price);
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;
  const w = 56, h = 18;
  const points = values
    .map((v, i) => `${((i / (values.length - 1)) * w).toFixed(1)},${(h - ((v - min) / range) * h).toFixed(1)}`)
    .join(" ");
  const netChange = values[values.length - 1] - values[0];
  // CSS variables, not fixed hex: this was hardcoded and completely
  // bypassed the whole v1.25.0 dark-mode fix, a falling-price sparkline
  // rendered at ~2.6:1 contrast against the dark card background,
  // nearly invisible, since inline SVG presentation attributes DO
  // resolve var(...) the same as any other CSS value once the element
  // is actually in the page (confirmed with a real Chromium render).
  const color = netChange < 0 ? "var(--price-low-text)" : netChange > 0 ? "var(--badge-red-text)" : "var(--muted-2)";
  return `<svg width="${w}" height="${h}" class="sparkline" title="Price over the last ${values.length} checks"><polyline points="${points}" fill="none" stroke="${color}" stroke-width="1.6"/></svg>`;
}

const STALE_DATA_MS = 3 * 24 * 60 * 60 * 1000;

/**
 * A price that hasn't been rechecked in days shouldn't look identical to
 * one confirmed minutes ago, that's exactly what makes an old, already-
 * fixed bug look like it's still happening, there's no way to tell stale
 * data from a live problem just by looking at a number.
 */
function stalenessBadge(updatedAt) {
  if (!updatedAt) return "";
  const ageMs = Date.now() - new Date(updatedAt).getTime();
  if (ageMs < STALE_DATA_MS) return "";
  const days = Math.floor(ageMs / (24 * 60 * 60 * 1000));
  return `<div class="badge badge-stale" title="Last confirmed ${formatDate(updatedAt)}, not rescanned since">\u23f3 ${days}d old</div>`;
}

/**
 * "Normally ₹5,000, you'd pay ₹3,000" only means something when there's
 * an actual original price to compare against, not when we've simply
 * never seen anything more expensive.
 */
function priceRealityCheck(g) {
  const original = g.cheapest.originalPrice;
  if (!original || original <= g.cheapestPrice) return "";
  const pct = Math.round(((original - g.cheapestPrice) / original) * 100);
  return `<div class="reality-check">Normally ${formatINR(original)}, you'd pay ${pct}% less</div>`;
}

const SHORT_MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const SHORT_DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

/**
 * "2026-09-20 to 2026-09-22" forces a mental calendar lookup to know if
 * it's even a weekend. Weekend vloggers care about that instantly, so
 * spell it out: "Sep 20 - Sep 22 (Fri-Sun)".
 */
function formatDateRangeWithWeekend(checkin, checkout) {
  if (!checkin || !checkout) return `${checkin || "?"} to ${checkout || "?"}`;
  const dayName = (iso) => {
    const d = new Date(iso + "T12:00:00");
    return { label: `${SHORT_MONTHS[d.getMonth()]} ${d.getDate()}`, dow: SHORT_DAYS[d.getDay()] };
  };
  const inD = dayName(checkin);
  const outD = dayName(checkout);
  return `${inD.label} - ${outD.label} (${inD.dow}-${outD.dow})`;
}

function formatPublishedDate(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  const now = new Date();
  const diffDays = Math.max(0, Math.floor((now - d) / (1000 * 60 * 60 * 24)));
  const dateStr = d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
  let ago;
  if (diffDays < 30) ago = `${diffDays}d ago`;
  else if (diffDays < 365) ago = `${Math.round(diffDays / 30)}mo ago`;
  else ago = `${(diffDays / 365).toFixed(1)}y ago`;
  return `${dateStr} (${ago})`;
}

/**
 * One row per video actually found (a hotel can contribute up to two:
 * its best Short and its best long-form video), rather than folding
 * everything into a single number on the main table. This is what "add
 * a section" was asking for: video, creator with subs, type, views,
 * posted date, and the channel's average long-form performance so a
 * single lucky viral video doesn't look the same as a channel that
 * consistently performs well.
 */
/**
 * A channel that hasn't uploaded in 6 months is a different kind of
 * signal from one posting regularly, even with the same overall
 * long-form average, one viral video years ago and then silence reads
 * very differently from a channel still actively putting out content.
 */
/**
 * v1.26.0 rewrite. The old table had one row PER VIDEO (a hotel with
 * both a Short and a long-form match got two separate rows), grouped by
 * destination and sorted destination-then-type-then-views. That answers
 * "show me everything", but it's the wrong shape for the two actual
 * questions this page exists for: "which hotels get regularly covered
 * with videos that do well" and "which hotels win on long-form views
 * specifically" (a harder signal than Shorts, whose view counts are
 * cheaper and more algorithm-boosted). Answering either meant manually
 * scanning past destination headers and interleaved Shorts rows. Now:
 * one row per hotel (both its best videos side by side, so you can
 * actually compare a single hotel's own Shorts vs long-form), and a
 * sort control whose options are literally those two questions plus a
 * simple total-views option, instead of a fixed destination grouping.
 */
let videoSortBy = "longform";

/**
 * Data written before this version only ever kept the single best video
 * per format (youtubeTopLong/youtubeTopShort). Data written from this
 * version on keeps the FULL list of every genuinely-matched video
 * (youtubeLongForm/youtubeShorts). Falling back to a synthesized
 * one-item list from the old fields means a hotel checked before this
 * shipped still renders sensibly (as if it only ever had one video
 * found) until it's re-checked, rather than showing nothing.
 */
function longFormList(g) {
  if (g.youtubeLongForm && g.youtubeLongForm.length) return g.youtubeLongForm;
  return g.youtubeTopLong ? [g.youtubeTopLong] : [];
}
function shortsList(g) {
  if (g.youtubeShorts && g.youtubeShorts.length) return g.youtubeShorts;
  return g.youtubeTopShort ? [g.youtubeTopShort] : [];
}
function avgViews(list) {
  if (!list || list.length === 0) return null;
  return list.reduce((sum, v) => sum + v.views, 0) / list.length;
}

/**
 * v1.27.0: this used to take a single "best" video and show only that.
 * Report: "why does it say creator of one? are you tracking just one
 * creator" \u2014 no, but the table only ever showed the single top-viewed
 * match, which looked exactly like it. Now it takes every genuinely-
 * matched video for that hotel/format: the top one still leads the
 * cell (it's still the most useful single thing to click), but when
 * there's more than one, the actual count and their average views are
 * shown right under it, across however many different creators they
 * came from.
 */
function videoCellHtml(videos) {
  const list = videos || [];
  if (list.length === 0) return '<span class="muted small">No genuine match found</span>';
  const top = list[0];
  const extra =
    list.length > 1
      ? `<div class="muted small">+${list.length - 1} more found &middot; avg ${formatViews(Math.round(avgViews(list)))} views across all ${list.length}</div>`
      : "";
  return `
    <a class="view-link" href="${escapeAttr(top.url)}" target="_blank">${escapeHtml((top.title || "Untitled").slice(0, 70))}</a>
    <div class="muted small">${escapeHtml(top.channelTitle || "Unknown")} &middot; ${formatViews(top.views)} views &middot; ${formatPublishedDate(top.publishedAt)}</div>
    ${extra}
  `;
}

function videoCoverageRow(g, idx) {
  return `
    <tr class="hotel-row" data-idx="${idx}">
      <td class="num">${idx + 1}</td>
      <td>${escapeHtml(g.hotelName)}</td>
      <td class="muted">${escapeHtml(g.destination)}</td>
      <td>${videoCellHtml(longFormList(g))}</td>
      <td>${videoCellHtml(shortsList(g))}</td>
      <td class="num" title="Distinct videos found that genuinely name-check this hotel, not just channel activity in general">${g.youtubeVideoCount ? `${g.youtubeVideoCount} video${g.youtubeVideoCount === 1 ? "" : "s"}` : "\u2014"}</td>
    </tr>
  `;
}

/**
 * Extracted as its own pure function (rather than inline in the .sort()
 * call) specifically so it can be tested directly against fixed hotel
 * objects in tests/test_video_coverage_sort.js, the same reasoning as
 * shouldRetryWithNearTermDate being its own function: a decision this
 * central to what the page is FOR shouldn't only ever be exercised by
 * eyeballing the rendered table.
 */
function videoCoverageSortComparator(sortBy) {
  return (a, b) => {
    if (sortBy === "videocount") {
      // "Regular coverage": most distinct genuinely-matched videos
      // first, ties broken by total views so two equally-covered
      // hotels still order by which one's actually being watched.
      return (b.youtubeVideoCount || 0) - (a.youtubeVideoCount || 0) || (b.youtubeViews || 0) - (a.youtubeViews || 0);
    }
    if (sortBy === "totalviews") {
      return (b.youtubeViews || 0) - (a.youtubeViews || 0);
    }
    const aLongAvg = avgViews(longFormList(a)) ?? -1;
    const bLongAvg = avgViews(longFormList(b)) ?? -1;
    if (sortBy === "destination") {
      // "By location": group hotels in the same destination together,
      // ranked within each destination by the same long-form-average
      // signal as the default sort.
      const destCompare = (a.destination || "").localeCompare(b.destination || "");
      return destCompare !== 0 ? destCompare : bLongAvg - aLongAvg;
    }
    // "longform" (default): average views across EVERY genuinely-matched
    // long-form video, not just the single best one, so a hotel with
    // three solid long-form videos outranks one with a single lucky
    // hit. A hotel with no long-form match at all sorts to the bottom
    // regardless of how big its Shorts are, this view is specifically
    // about who wins on the harder signal.
    return bLongAvg - aLongAvg;
  };
}

function renderVideoCoverage(groups) {
  const section = document.getElementById("video-coverage-section");
  const body = document.getElementById("video-coverage-body");
  const withVideo = groups.filter((g) => longFormList(g).length || shortsList(g).length);

  if (withVideo.length === 0) {
    section.classList.add("hidden");
    return;
  }
  section.classList.remove("hidden");

  const sorted = [...withVideo].sort(videoCoverageSortComparator(videoSortBy));

  body.innerHTML = sorted.map((g, idx) => videoCoverageRow(g, idx)).join("");

  body.querySelectorAll(".hotel-row").forEach((tr) => {
    tr.addEventListener("click", () => openVideoModal(sorted[parseInt(tr.dataset.idx, 10)]));
  });
  // Without this, clicking a video's own link both opens it in a new tab
  // AND pops the modal in this one, since the click bubbles up to the
  // row handler right above.
  body.querySelectorAll(".hotel-row a.view-link").forEach((a) => {
    a.addEventListener("click", (e) => e.stopPropagation());
  });
}

document.getElementById("video-sort-by").addEventListener("change", (e) => {
  videoSortBy = e.target.value;
  const blockedSet = allGroups._blockedSet || new Set();
  renderVideoCoverage(allGroups.filter((g) => !blockedSet.has(g.groupKey)));
});

function renderSpotlight(groups) {
  const section = document.getElementById("spotlight-section");
  const list = document.getElementById("spotlight-list");
  const newlyBuilt = groups.filter((g) => g.isNewlyBuilt).sort((a, b) => a.cheapestPrice - b.cheapestPrice);

  if (newlyBuilt.length === 0) {
    section.classList.add("hidden");
    return;
  }
  section.classList.remove("hidden");
  list.innerHTML = newlyBuilt.slice(0, 6).map((g) => `
    <div class="spotlight-card">
      <div class="spotlight-name">${escapeHtml(g.hotelName)}</div>
      <div class="muted small">${escapeHtml(g.destination)} \u2022 ${g.cheapest.checkin}</div>
      <div class="spotlight-price">${formatINR(g.cheapestPrice)}</div>
      ${g.rating ? `<div class="muted small">${g.rating.toFixed(1)} \u2605 (${(g.reviewCount || 0).toLocaleString("en-IN")} reviews)</div>` : ""}
    </div>
  `).join("");
}

function formatViews(n) {
  if (n === null || n === undefined) return "";
  if (n >= 1000000) return (n / 1000000).toFixed(1).replace(/\.0$/, "") + "M";
  if (n >= 1000) return (n / 1000).toFixed(1).replace(/\.0$/, "") + "K";
  return String(n);
}

/**
 * Star tier display priority: your own manual correction beats
 * everything, then the actual scraped rating, then the AI estimate,
 * each one clearly labeled so it's never mistaken for verified data.
 * Click "fix" to set or clear a manual value yourself.
 */
function starTierCell(g, idx) {
  let display;
  if (g.manualStarTier) {
    display = `<span class="stars">${"\u2605".repeat(g.manualStarTier)}</span><span class="muted small"> (you)</span>`;
  } else if (g.starRating) {
    display = `<span class="stars">${"\u2605".repeat(g.starRating)}</span>`;
  } else if (g.aiEstimatedStarTier) {
    display = `<span class="stars stars-ai-estimate" title="AI estimate from price and reviews, not a verified rating (confidence: ${escapeHtml(g.aiEstimatedStarConfidence || "unknown")})">${"\u2605".repeat(g.aiEstimatedStarTier)}</span>`;
  } else {
    display = '<span class="muted small">unrated</span>';
  }
  return `${display}<button class="fix-star-btn" data-idx="${idx}" title="Set this yourself if you know better">fix</button>`;
}

function ratingCell(r) {
  if (r.rating === null) return '<span class="muted">no rating</span>';
  const trust = isTrustworthy(r);
  const volumeNote = r.reviewCount === null
    ? ""
    : `<span class="review-count${trust ? "" : " thin"}">${r.reviewCount.toLocaleString("en-IN")} reviews</span>`;
  return `<span class="rating-score">${r.rating.toFixed(1)}</span>${volumeNote}`;
}

async function blockHotel(group) {
  const { blockedHotels = [] } = await chrome.storage.local.get("blockedHotels");
  blockedHotels.push({
    source: group.source,
    hotelName: group.hotelName,
    destination: group.destination,
    blockedAt: new Date().toISOString(),
  });
  await chrome.storage.local.set({ blockedHotels });
  showToast(`Hidden: ${group.hotelName}`);
  await refresh();
}

async function unblockHotel(group) {
  const { blockedHotels = [] } = await chrome.storage.local.get("blockedHotels");
  const filtered = blockedHotels.filter(
    (b) => !(b.source === group.source && b.hotelName === group.hotelName && b.destination === group.destination)
  );
  await chrome.storage.local.set({ blockedHotels: filtered });
  showToast(`Unhidden: ${group.hotelName}`);
  await refresh();
}

async function toggleFavorite(group) {
  const { favoriteHotels = [] } = await chrome.storage.local.get("favoriteHotels");
  const key = (h) => `${h.source}:::${h.hotelName}:::${h.destination}`;
  const groupKey = key(group);
  const exists = favoriteHotels.some((f) => key(f) === groupKey);
  const updated = exists
    ? favoriteHotels.filter((f) => key(f) !== groupKey)
    : [...favoriteHotels, { source: group.source, hotelName: group.hotelName, destination: group.destination, favoritedAt: new Date().toISOString() }];
  await chrome.storage.local.set({ favoriteHotels: updated });
  showToast(exists ? `Removed from favorites: ${group.hotelName}` : `\u2605 Favorited: ${group.hotelName}`);
  await refresh();
}

/**
 * Sets or clears a per-hotel price-target alert (PROJECT_BRIEF open item
 * 4). Only meaningful on a favorite, since favoriteHotels is where it's
 * stored, alongside toggleFavorite() above. A prompt() rather than a full
 * modal, this is a single number, building a whole form for it would be
 * more UI than the task needs.
 */
async function setTargetPrice(group) {
  const { favoriteHotels = [] } = await chrome.storage.local.get("favoriteHotels");
  const key = (h) => `${h.source}:::${h.hotelName}:::${h.destination}`;
  const groupKey = key(group);
  const fav = favoriteHotels.find((f) => key(f) === groupKey);
  if (!fav) return; // must be favorited first, the target-btn only renders for favorites anyway

  const current = fav.targetPrice != null ? String(fav.targetPrice) : "";
  const input = prompt(
    `Alert me when ${group.hotelName}'s price drops to or below (in ₹):\n\nLeave blank to clear this hotel's own target and fall back to the destination default, if any.`,
    current
  );
  if (input === null) return; // cancelled

  const trimmed = input.trim();
  if (trimmed === "") {
    delete fav.targetPrice;
    showToast(`Cleared this hotel's target for ${group.hotelName}`);
  } else {
    const value = parseInt(trimmed.replace(/[^\d]/g, ""), 10);
    if (!Number.isFinite(value) || value < 300) {
      showToast("Enter a plausible rupee amount (300 or more)", "error");
      return;
    }
    fav.targetPrice = value;
    showToast(`Target set: alert when ${group.hotelName} hits ${formatINR(value)} or below`);
  }
  await chrome.storage.local.set({ favoriteHotels });
  await refresh();
}

let showingBlocked = false;

function renderTable(groups) {
  const body = document.getElementById("deals-body");
  const emptyState = document.getElementById("empty-state");
  body.innerHTML = "";

  if (groups.length === 0) {
    emptyState.textContent = showingBlocked
      ? "No hidden hotels."
      : "Nothing tracked yet. Run a scan from the extension popup first.";
    emptyState.classList.remove("hidden");
    return;
  }
  emptyState.classList.add("hidden");

  groups.forEach((g, idx) => {
    const rowId = `hotel-row-${idx}`;
    const tr = document.createElement("tr");
    tr.className = "hotel-row";
    tr.dataset.target = rowId;

    tr.innerHTML = `
      <td class="compare-cell">
        <input type="checkbox" class="compare-checkbox" data-groupkey="${escapeAttr(g.groupKey)}" title="Select to compare" ${compareSelection.has(g.groupKey) ? "checked" : ""} />
      </td>
      <td>
        <span class="expand-arrow">\u25b8</span>
        <button class="fav-btn${g.isFavorite ? " fav-on" : ""}" data-favidx="${idx}" title="${g.isFavorite ? "Remove favorite" : "Mark favorite"}">${g.isFavorite ? "\u2764\ufe0f" : "\ud83e\udd0d"}</button>
        ${g.isFavorite ? `<button class="target-btn" data-idx="${idx}" title="${g.targetPrice != null ? "Change target price" : "Set a target price alert"}">\u{1F3AF}</button>` : ""}
        <span class="hotel-name">${escapeHtml(g.hotelName)}</span>
        ${g.isNewlyBuilt ? '<span class="badge badge-new">NEW BUILD</span>' : ""}
        ${g.rarity && g.rarity.isRareDeal ? `<span class="badge badge-rare" title="${escapeAttr(g.rarity.reasons.join("; "))}">\u{1F48E} Rare deal</span>` : ""}
        ${g.hasFlaggedDates ? `<span class="badge badge-warn" title="One or more tracked dates for this hotel show a price that looks like a bad scrape, expand to see which. Excluded from this hotel's cheapest price and all-time-low badge.">⚠ check dates</span>` : ""}
        ${g.effectiveTargetPrice != null ? `<div class="badge badge-target" title="${g.targetPriceSource === "hotel" ? "This hotel's own target" : g.destination + " default target"}">\u{1F3AF} ${formatINR(g.effectiveTargetPrice)}</div>` : ""}
        ${(g.amenities || []).map((a) => `<span class="badge badge-amenity">${escapeHtml(a)}</span>`).join("")}
      </td>
      <td class="star-tier-cell" data-idx="${idx}">${starTierCell(g, idx)}</td>
      <td>
        ${escapeHtml(g.destination)}
        <span class="badge badge-source">${escapeHtml(g.source)}</span>
        ${transitEstimate(g.destination) ? `<div class="muted small" title="Typical travel time from Kolkata, a rough estimate, not a live check">\u{1F686} ${escapeHtml(transitEstimate(g.destination))}</div>` : ""}
      </td>
      <td class="nowrap">${formatDateRangeWithWeekend(g.cheapest.checkin, g.cheapest.checkout)}</td>
      <td class="num">
        ${g.cheapest.url
          ? `<a class="price-link${g.everAtLowest ? " price-low" : ""}" href="${escapeAttr(g.cheapest.url)}" target="_blank" title="Open the booking page">${formatINR(g.cheapestPrice)}</a>`
          : `<span class="price${g.everAtLowest ? " price-low" : ""}">${formatINR(g.cheapestPrice)}</span>`}
        ${sparklineSvg(g.cheapest.priceHistory)}
        ${g.everAtLowest ? '<div class="badge badge-low">\u{1F525} All-time low</div>' : ""}
        ${priceRealityCheck(g)}
        ${stalenessBadge(g.cheapest.updatedAt)}
      </td>
      <td class="num">${g.everAtLowest ? '<span class="muted">\u2014</span>' : formatINR(g.lowestEver)}</td>
      <td>${ratingCell(g)}</td>
      <td class="num">${g.youtubeViews !== null ? `<button class="vlog-views-btn" data-idx="${idx}" title="Click to see the videos found for this hotel">\u{1F3A5} ${formatViews(g.youtubeViews)}${g.youtubeVideoCount > 1 ? ` (${g.youtubeVideoCount}v)` : ""}</button>` : '<span class="muted">\u2014</span>'}</td>
      <td class="muted small nowrap tracking-cell" title="Click this row to see prices for all ${g.dates.length} tracked date${g.dates.length > 1 ? "s" : ""}">${g.dates.length} date${g.dates.length > 1 ? "s" : ""} \u25b8 view</td>
      <td>
        ${g.cheapest.url ? `<a class="view-link" href="${escapeAttr(g.cheapest.url)}" target="_blank">View</a>` : ""}
        <button class="block-btn" data-action="${showingBlocked ? "unblock" : "block"}" data-idx="${idx}">
          ${showingBlocked ? "Unhide" : "Hide"}
        </button>
      </td>
    `;
    body.appendChild(tr);

    const detailTr = document.createElement("tr");
    detailTr.id = rowId;
    detailTr.className = "detail-row hidden";
    const detailTd = document.createElement("td");
    detailTd.colSpan = 11;

    // Color-coded by this hotel's own price range across its tracked
    // dates, not some fixed rupee amount, a "cheap" night at a luxury
    // resort and a budget stay mean very different absolute numbers.
    const datePrices = g.dates.map((d) => d.current);
    const minDatePrice = Math.min(...datePrices);
    const priceRange = Math.max(...datePrices) - minDatePrice || 1;
    const priceTierClass = (price) => {
      const ratio = (price - minDatePrice) / priceRange;
      if (ratio <= 0.33) return "price-tier-low";
      if (ratio >= 0.66) return "price-tier-high";
      return "price-tier-mid";
    };

    detailTd.innerHTML = `
      ${g.aiReviewSummary ? `<p class="review-summary"><strong>Review insight (AI, inferred from rating patterns, not actual review text):</strong> ${escapeHtml(g.aiReviewSummary)}</p>` : ""}
      <table class="sub-table">
        <thead><tr><th>Dates</th><th class="num">Price</th><th class="num">Lowest seen</th><th>Last checked</th><th></th></tr></thead>
        <tbody>
          ${g.dates.map((d) => `
            <tr class="${priceTierClass(d.current)}">
              <td>${d.checkin} \u2192 ${d.checkout}</td>
              <td class="num">${formatINR(d.current)}${isAtLowest(d) ? '<span class="badge badge-low">lowest</span>' : ""}${d.isLikelyBadScrape ? `<span class="badge badge-warn" title="Much lower than this hotel's other tracked dates, most likely a promo/cashback banner mis-read as the room price rather than a real discount. Excluded from this hotel's cheapest price and all-time-low badge. A future refresh should correct it.">⚠ looks off</span>` : ""}
                ${d.roomDetailLowest !== null ? `<div class="muted small">room page: ${formatINR(d.roomDetailLowest)}</div>` : ""}
              </td>
              <td class="num">${formatINR(d.lowest)}</td>
              <td class="muted small">${formatDate(d.updatedAt)}</td>
              <td>${d.url ? `<a class="view-link" href="${escapeAttr(d.url)}" target="_blank">View</a>` : ""}</td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    `;
    detailTr.appendChild(detailTd);
    body.appendChild(detailTr);

    tr.addEventListener("click", (e) => {
      if (e.target.closest("a, button")) return;
      detailTr.classList.toggle("hidden");
      tr.querySelector(".expand-arrow").textContent = detailTr.classList.contains("hidden") ? "\u25b8" : "\u25be";
    });
  });

  body.querySelectorAll(".block-btn").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const g = groups[parseInt(btn.dataset.idx, 10)];
      if (btn.dataset.action === "block") blockHotel(g);
      else unblockHotel(g);
    });
  });

  body.querySelectorAll(".fav-btn").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const g = groups[parseInt(btn.dataset.favidx, 10)];
      toggleFavorite(g);
    });
  });

  body.querySelectorAll(".target-btn").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const g = groups[parseInt(btn.dataset.idx, 10)];
      setTargetPrice(g);
    });
  });

  body.querySelectorAll(".compare-checkbox").forEach((cb) => {
    cb.addEventListener("click", (e) => e.stopPropagation());
    cb.addEventListener("change", () => {
      const key = cb.dataset.groupkey;
      if (cb.checked) {
        if (compareSelection.size >= MAX_COMPARE) {
          cb.checked = false;
          showToast(`Compare up to ${MAX_COMPARE} hotels at a time`, "error");
          return;
        }
        compareSelection.add(key);
      } else {
        compareSelection.delete(key);
      }
      renderCompareBar();
    });
  });

  body.querySelectorAll(".vlog-views-btn").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const g = groups[parseInt(btn.dataset.idx, 10)];
      openVideoModal(g);
    });
  });

  body.querySelectorAll(".fix-star-btn").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const idx = parseInt(btn.dataset.idx, 10);
      const g = groups[idx];
      const cell = document.querySelector(`.star-tier-cell[data-idx="${idx}"]`);
      cell.innerHTML = `
        <select class="star-override-select">
          <option value="">Unrated / clear</option>
          <option value="3">3\u2605</option>
          <option value="4">4\u2605</option>
          <option value="5">5\u2605</option>
        </select>
      `;
      const select = cell.querySelector("select");
      select.value = g.manualStarTier ? String(g.manualStarTier) : "";
      select.focus();
      select.addEventListener("click", (ev) => ev.stopPropagation());
      select.addEventListener("change", async () => {
        const tier = select.value ? parseInt(select.value, 10) : null;
        await setManualStarTier(g, tier);
        showToast(tier ? `Set ${g.hotelName} to ${tier}\u2605` : `Cleared your star tier for ${g.hotelName}`);
        await refresh();
      });
      select.addEventListener("blur", () => {
        // if they clicked away without changing anything, put the
        // normal display back instead of leaving the dropdown sitting
        // there
        if (cell.contains(select)) cell.innerHTML = starTierCell(g, idx);
      });
    });
  });
}

function formatDate(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  return d.toLocaleDateString("en-IN", { day: "2-digit", month: "short" }) +
    " " + d.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" });
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str ?? "";
  return div.innerHTML;
}

function escapeAttr(str) {
  return (str ?? "").replace(/"/g, "&quot;");
}

async function loadDebugInfo() {
  const { lastDebug } = await chrome.storage.local.get("lastDebug");
  const section = document.getElementById("debug-section");
  if (!lastDebug) {
    section.classList.add("hidden");
    return;
  }
  section.classList.remove("hidden");
  document.getElementById("debug-content").textContent = JSON.stringify(lastDebug, null, 2);
}

document.getElementById("copy-debug").addEventListener("click", async () => {
  const text = document.getElementById("debug-content").textContent;
  await navigator.clipboard.writeText(text);
  const btn = document.getElementById("copy-debug");
  const original = btn.textContent;
  btn.textContent = "Copied";
  setTimeout(() => (btn.textContent = original), 1500);
});

function rerender() {
  const blockedSet = allGroups._blockedSet || new Set();
  renderTable(applyFiltersAndSort(allGroups, blockedSet, showingBlocked));
  renderKpiActiveStates();
}

async function refresh() {
  allGroups = await loadTrackedHotelGroups();
  const blockedSet = await getBlockedSet();
  allGroups._blockedSet = blockedSet;

  populateDestinationFilter(allGroups);
  renderKpis(allGroups.filter((g) => !blockedSet.has(g.groupKey)));
  renderSpotlight(allGroups.filter((g) => !blockedSet.has(g.groupKey)));
  renderVideoCoverage(allGroups.filter((g) => !blockedSet.has(g.groupKey)));
  rerender();
  renderCompareBar();
  await loadDebugInfo();
  await renderActivityLogCount();
  await renderLastAutoBackup();

  const uniqueHotels = allGroups.length;
  const totalDateRows = allGroups.reduce((sum, g) => sum + g.dates.length, 0);
  const blockedCount = blockedSet.size;
  document.getElementById("summary-line").textContent =
    `${uniqueHotels} hotels tracked across ${totalDateRows} date combinations` +
    (blockedCount ? ` \u2022 ${blockedCount} hidden` : "");

  const toggleBtn = document.getElementById("toggle-blocked");
  if (toggleBtn) {
    toggleBtn.textContent = showingBlocked ? "Back to tracked hotels" : `Hidden hotels (${blockedCount})`;
  }
}

// githubGetSha/githubPutFile/publishSnapshotToGithub now live in shared.js.

document.getElementById("publish-dashboard").addEventListener("click", async () => {
  const status = document.getElementById("publish-status");
  const settings = await getSettings();

  if (!settings.githubToken || !settings.githubRepo) {
    status.textContent = "Add a GitHub token and repo (username/repo-name) in the popup's Settings first.";
    return;
  }
  if (!/^[^/\s]+\/[^/\s]+$/.test(settings.githubRepo)) {
    status.textContent = 'Repo should look like "username/repo-name", no extra slashes or spaces.';
    return;
  }

  status.textContent = "Publishing...";
  try {
    const result = await publishSnapshotToGithub(settings);
    status.innerHTML = `Published. View it at <a href="${escapeAttr(result.url)}" target="_blank">${escapeHtml(result.url)}</a>`;
    showToast("Live dashboard published");
  } catch (e) {
    status.textContent = "Publish failed: " + e.message;
    showToast("Publish failed: " + e.message, "error");
  }
});

document.getElementById("backup-now").addEventListener("click", async () => {
  const status = document.getElementById("backup-status");
  const settings = await getSettings();

  if (!settings.githubToken || !settings.githubRepo) {
    status.textContent = "Add a GitHub token and repo (username/repo-name) in the popup's Settings first.";
    return;
  }

  status.textContent = "Backing up...";
  try {
    const result = await backupToGithub(settings);
    status.textContent = `Backed up ${result.keyCount} record(s) just now.`;
    showToast("Backed up to GitHub");
  } catch (e) {
    status.textContent = "Backup failed: " + e.message;
    showToast("Backup failed: " + e.message, "error");
  }
});

document.getElementById("restore-now").addEventListener("click", async () => {
  const status = document.getElementById("backup-status");
  const settings = await getSettings();

  if (!settings.githubToken || !settings.githubRepo) {
    status.textContent = "Add a GitHub token and repo (username/repo-name) in the popup's Settings first.";
    return;
  }

  // This overwrites local data with whatever the backup contains, worth
  // a real confirmation rather than a stray click quietly wiping out
  // anything tracked only on this PC since the last backup.
  const confirmed = confirm(
    "This replaces this PC's tracked hotels, favorites, hidden hotels, and settings with whatever's in the backup. Anything tracked here since the last backup will be lost. Continue?"
  );
  if (!confirmed) return;

  status.textContent = "Restoring...";
  try {
    const result = await restoreFromGithub(settings);
    status.textContent = `Restored ${result.keyCount} record(s) from a backup made ${formatDate(result.backedUpAt)}.`;
    showToast("Restored from backup");
    await refresh();
  } catch (e) {
    status.textContent = "Restore failed: " + e.message;
    showToast("Restore failed: " + e.message, "error");
  }
});

/**
 * A near-term check-in date (a week out, 2 nights), the same kind of date
 * a manual confirming search on google.com/travel/hotels would default
 * to. Used as a fallback query date, see callSerpApiForHotel below.
 */
function nearTermDateWindow(today = new Date()) {
  const checkin = new Date(today);
  checkin.setDate(checkin.getDate() + 7);
  const checkout = new Date(checkin);
  checkout.setDate(checkout.getDate() + 2);
  return { checkin: toISODate(checkin), checkout: toISODate(checkout) };
}

/** Pure so the retry decision is unit-testable without mocking fetch. */
function shouldRetryWithNearTermDate(primaryResult, originalCheckin, nearTermCheckin) {
  return primaryResult.lowestPrice === null && nearTermCheckin !== originalCheckin;
}

/**
 * Calls SerpApi's Google Hotels engine for one hotel, one specific key,
 * one specific date pair, and tries to pull out a lowest price. Built
 * defensively: my own environment can't reach serpapi.com to verify the
 * exact current response shape before shipping this, so it tries the
 * field names SerpApi's docs describe, and if none of them match, says
 * so plainly and includes the raw response in the console rather than
 * silently showing a wrong number.
 */
async function callSerpApiForHotelWithDates(g, apiKey, checkin, checkout) {
  const query = encodeURIComponent(`${g.hotelName} ${g.destination}`);
  const url = `https://serpapi.com/search.json?engine=google_hotels&q=${query}&check_in_date=${checkin}&check_out_date=${checkout}&adults=2&currency=INR&gl=in&hl=en&api_key=${encodeURIComponent(apiKey)}`;

  const resp = await fetch(url);
  const data = await resp.json();
  if (!resp.ok || data.error) {
    const err = new Error(data.error || `SerpApi request failed (${resp.status})`);
    err.httpStatus = resp.status;
    throw err;
  }

  // Kept for the whole batch, not just the console, so the raw response
  // can actually be inspected and shared afterward instead of needing
  // devtools open at the exact moment something looks wrong. Keyed by
  // date too now, since a hotel can appear here twice (the original
  // query and the near-term retry below).
  window._lastSerpApiResponses = window._lastSerpApiResponses || {};
  window._lastSerpApiResponses[`${g.hotelName} (${checkin})`] = { query: `${g.hotelName} ${g.destination}`, checkin, checkout, data };

  const properties = data.properties || [];
  if (properties.length === 0) {
    console.log("[serpapi] no properties in response for", g.hotelName, "dates:", checkin, "to", checkout, data);
    return {
      lowestPrice: null,
      checkin,
      checkout,
      note: `No properties returned for ${checkin} \u2192 ${checkout}, worth comparing against a manual Google Hotels search for the same dates specifically, not just the hotel name`,
    };
  }

  // No fallback to "closest guess" here, same reasoning as the YouTube
  // video matching fix: a guessed match can be a genuinely different
  // hotel with a genuinely different price, and a small footnote is
  // easy to miss next to a confident-looking number. Reusing the same
  // distinctive-word check rather than a second, separately-tuned one.
  const genuineMatch = properties.find((p) => isGenuineVideoMatch(g.hotelName, g.destination, p.name));

  if (!genuineMatch) {
    console.log("[serpapi] no confident match for", g.hotelName, "candidates were:", properties.map((p) => p.name));
    return {
      lowestPrice: null,
      checkin,
      checkout,
      note: `No confident match among ${properties.length} result${properties.length === 1 ? "" : "s"} returned, not shown rather than risk a different property's price`,
    };
  }

  const price =
    genuineMatch?.rate_per_night?.extracted_lowest ??
    genuineMatch?.total_rate?.extracted_lowest ??
    genuineMatch?.extracted_price ??
    null;

  if (price === null) {
    console.log("[serpapi] couldn't find a price field on the matched property for", g.hotelName, genuineMatch);
  }

  return {
    lowestPrice: price,
    checkin,
    checkout,
    note: price === null ? "Price field not found, see browser console for the raw response" : "",
  };
}

/**
 * PROJECT_BRIEF's open "not found" mystery: a hotel confirmed well-indexed
 * on Google still came back "not found", and the leading, previously
 * untested hypothesis was that the query used the hotel's cheapest
 * tracked date, which can be a month or more out, while a manual
 * confirming search defaults to near-term dates that Google Hotels
 * actually has pricing loaded for. This tries the original tracked date
 * first (unchanged behaviour), and only if that comes back empty, retries
 * once with a near-term date purely to tell "genuinely not indexed on
 * Google" apart from "not indexed THAT FAR OUT", a much less alarming
 * finding. Costs one extra SerpApi search only when the first attempt
 * found nothing. Still can't be verified against live SerpApi from this
 * sandbox (no network access to serpapi.com here), the branching logic
 * itself is covered by test_serpapi_retry.js, but whether this actually
 * resolves real "not found" cases needs a live run with your own keys.
 */
async function callSerpApiForHotel(g, apiKey) {
  const primary = await callSerpApiForHotelWithDates(g, apiKey, g.cheapest.checkin, g.cheapest.checkout);
  if (primary.lowestPrice !== null) return primary;

  const nearTerm = nearTermDateWindow();
  if (!shouldRetryWithNearTermDate(primary, g.cheapest.checkin, nearTerm.checkin)) return primary;

  const retry = await callSerpApiForHotelWithDates(g, apiKey, nearTerm.checkin, nearTerm.checkout);
  if (retry.lowestPrice !== null) {
    return {
      ...retry,
      note: `Not found for your tracked dates (${g.cheapest.checkin} \u2192 ${g.cheapest.checkout}), but found for a near-term date (${nearTerm.checkin} \u2192 ${nearTerm.checkout}) shown here instead. Google Hotels likely just hasn't loaded pricing that far ahead for this property yet, not a real "not listed" gap.`,
      usedNearTermFallback: true,
    };
  }

  // Neither date worked, still genuinely worth a manual check.
  return primary;
}

/**
 * Tries each configured key in turn, starting from wherever the last
 * successful call left off (settings.serpApiKeyIndex), rather than
 * always starting at key #1 and re-discovering the same exhausted keys
 * on every single hotel. Any failure (auth, quota, anything) is treated
 * as "try the next key", since SerpApi's exact error wording for a
 * used-up free tier isn't something I could verify without a live call.
 */
async function checkSerpApiHotel(g, settings) {
  const keys = settings.serpApiKeys || [];
  if (keys.length === 0) throw new Error("No SerpApi keys configured");

  const startIndex = settings.serpApiKeyIndex || 0;
  let lastError = null;

  for (let attempt = 0; attempt < keys.length; attempt++) {
    const idx = (startIndex + attempt) % keys.length;
    try {
      const result = await callSerpApiForHotel(g, keys[idx]);
      if (idx !== settings.serpApiKeyIndex) {
        settings.serpApiKeyIndex = idx;
        await saveSettings(settings);
      }
      return { ...result, keyIndex: idx };
    } catch (e) {
      console.log(`[serpapi] key #${idx + 1} of ${keys.length} failed (${e.message}), trying the next one`);
      lastError = e;
    }
  }

  throw lastError || new Error("All configured SerpApi keys failed");
}

async function logSerpApiUsage(hotelName, price, keyIndex) {
  const { activityLog = [] } = await chrome.storage.local.get("activityLog");
  activityLog.push({ at: new Date().toISOString(), event: "serpapi_check", details: { hotelName, price, keyIndex } });
  await chrome.storage.local.set({ activityLog: activityLog.slice(-3000) });
}

document.getElementById("run-serpapi-check").addEventListener("click", async () => {
  const status = document.getElementById("serpapi-status");
  const table = document.getElementById("serpapi-table");
  const body = document.getElementById("serpapi-body");
  const settings = await getSettings();

  if (!settings.serpApiKeys || settings.serpApiKeys.length === 0) {
    status.textContent = "Add at least one SerpApi key in the popup's Settings first.";
    return;
  }

  const batchSize = Math.max(1, Math.min(20, parseInt(document.getElementById("serpapi-batch-size").value, 10) || 5));
  // Favorites only, not "favorites first then whatever's in view", a
  // limited free allowance across possibly many hotels should go toward
  // the ones actually worth cross-checking, not backfilled with
  // whatever the current table filter happens to show.
  const blockedSet = allGroups._blockedSet || new Set();
  const favorites = allGroups.filter((g) => g.isFavorite && !blockedSet.has(g.groupKey));
  const batch = favorites.slice(0, batchSize);

  if (batch.length === 0) {
    status.textContent = "No favorites to check, mark some hotels as favorites first (the star icon on the Hotels tab).";
    return;
  }

  table.classList.remove("hidden");
  body.innerHTML = "";
  let done = 0;

  for (const g of batch) {
    status.textContent = `Checking ${g.hotelName} (${++done}/${batch.length})...`;
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${escapeHtml(g.hotelName)}<div class="muted small">${escapeHtml(g.destination)}</div></td>
      <td class="num">${formatINR(g.cheapestPrice)}</td>
      <td class="num">checking...</td>
      <td></td>
    `;
    body.appendChild(row);
    const cells = row.querySelectorAll("td");

    try {
      const result = await checkSerpApiHotel(g, settings);
      cells[2].textContent = result.lowestPrice !== null ? formatINR(result.lowestPrice) : "not found";
      cells[3].textContent =
        (result.note || "") + (settings.serpApiKeys.length > 1 ? ` (key #${result.keyIndex + 1})` : "");
      await logSerpApiUsage(g.hotelName, result.lowestPrice, result.keyIndex);
    } catch (e) {
      cells[2].textContent = "error";
      cells[3].textContent = e.message;
    }

    // A courtesy pace for someone else's API too, not just our usual
    // scraping targets.
    await new Promise((r) => setTimeout(r, 1500));
  }

  status.textContent = `Checked ${batch.length} hotel(s), used ${batch.length} of your monthly SerpApi searches.`;
  showToast(`SerpApi check done: ${batch.length} hotel(s)`);
  document.getElementById("copy-serpapi-debug").classList.remove("hidden");
});

document.getElementById("copy-serpapi-debug").addEventListener("click", async () => {
  const btn = document.getElementById("copy-serpapi-debug");
  const responses = window._lastSerpApiResponses || {};
  try {
    await navigator.clipboard.writeText(JSON.stringify(responses, null, 2));
    const original = btn.textContent;
    btn.textContent = "Copied";
    setTimeout(() => { btn.textContent = original; }, 1500);
  } catch (e) {
    console.log("[serpapi] copy failed:", e);
    btn.textContent = "Copy failed, see browser console";
  }
});

// parseISO8601Duration/SHORT_MAX_SECONDS/GENERIC_HOTEL_WORDS/
// isGenericHotelWord/significantWords/isGenuineVideoMatch/
// checkYoutubeForHotel/emptyYoutubeResult moved to shared.js in
// v1.34.0 so background.js's automatic daily YouTube check (see
// PROJECT_BRIEF.md Open Item #10, now built) can call the exact
// same matching/scoring logic this manual button always has, rather
// than a second reimplementation drifting from this one. Nothing
// about this button's own behavior changed, it's just borrowing the
// same functions from shared.js now (loaded before this file, see
// dashboard.html).

document.getElementById("check-youtube").addEventListener("click", async () => {
  const status = document.getElementById("youtube-status");
  const { settings } = await chrome.storage.local.get("settings");
  const apiKey = settings?.youtubeApiKey || "";

  if (!apiKey) {
    status.textContent = "Add a YouTube Data API key in the popup's Settings first (free tier from Google Cloud Console).";
    return;
  }

  const blockedSet = allGroups._blockedSet || new Set();
  const inView = applyFiltersAndSort(allGroups, blockedSet, false);
  // Never-checked first, then whichever was checked longest ago, same
  // rotation idea as destinations, otherwise repeated clicks just churn
  // through the same top-sorted handful forever and everything else
  // never gets covered.
  const prioritized = inView.slice().sort((a, b) => {
    const at = a.youtubeCheckedAt ? new Date(a.youtubeCheckedAt).getTime() : 0;
    const bt = b.youtubeCheckedAt ? new Date(b.youtubeCheckedAt).getTime() : 0;
    return at - bt;
  });
  // search.list is a flat 100 units regardless of result count, and the
  // free daily quota is 10,000, so 20 per click stays comfortably inside
  // even a few clicks a day.
  const batch = prioritized.slice(0, 20);
  if (batch.length === 0) {
    status.textContent = "Nothing in view to check, adjust the filters or run a scan first.";
    return;
  }

  let done = 0;
  for (const g of batch) {
    status.textContent = `Checking ${g.hotelName} (${++done}/${batch.length})...`;
    try {
      const result = await checkYoutubeForHotel(g.hotelName, g.destination, apiKey);
      if (result.totalViews !== null) {
        // apply to every date row for this hotel, since it's a property-level signal
        for (const d of g.dates) {
          const { [d.key]: existing } = await chrome.storage.local.get(d.key);
          if (existing) {
            await chrome.storage.local.set({
              [d.key]: {
                ...existing,
                youtubeViews: result.totalViews,
                youtubeVideoCount: result.videoCount,
                youtubeVideoTitle: result.topTitle,
                youtubeVideoUrl: result.topUrl,
                youtubeTopShort: result.topShort,
                youtubeTopLong: result.topLong,
                youtubeShorts: result.shorts,
                youtubeLongForm: result.longForm,
                youtubeCheckedAt: new Date().toISOString(),
              },
            });
          }
        }
      } else {
        // still mark it checked even with no results, so it doesn't get
        // retried ahead of hotels that have never been checked at all
        for (const d of g.dates) {
          const { [d.key]: existing } = await chrome.storage.local.get(d.key);
          if (existing) {
            await chrome.storage.local.set({
              [d.key]: { ...existing, youtubeCheckedAt: new Date().toISOString() },
            });
          }
        }
      }
    } catch (e) {
      status.textContent = `Stopped: ${e.message}`;
      return;
    }
    await new Promise((r) => setTimeout(r, 300));
  }

  status.textContent = `Checked ${batch.length} hotel(s).`;
  showToast(`YouTube check done: ${batch.length} hotel(s)`);
  await refresh();
});

function buildAiPrompt(groups) {
  const candidates = groups.slice(0, 25).map((g) => ({
    hotel: g.hotelName,
    destination: g.destination,
    star_rating: g.starRating,
    guest_rating: g.rating,
    review_count: g.reviewCount,
    newly_built: g.isNewlyBuilt,
    youtube_total_views: g.youtubeViews,
    youtube_video_count: g.youtubeVideoCount,
    cheapest_price_inr: g.cheapestPrice,
    cheapest_dates: `${g.cheapest.checkin} to ${g.cheapest.checkout}`,
    lowest_ever_seen_inr: g.lowestEver,
    is_rare_deal: !!(g.rarity && g.rarity.isRareDeal),
  }));

  return `You're helping a travel vlogger in Kolkata pick which resort to visit next, from hotels already scanned from MakeMyTrip and Goibibo. Here is the tracked data as JSON:

${JSON.stringify(candidates, null, 2)}

Recommend the top 3-5 options. For each, give the hotel name, destination, price and dates, and a short reason. Weigh guest rating together with review count, a high rating from very few reviews (under ~150-200) is weak evidence and should be flagged as such, not treated as a top pick. youtube_total_views is summed across multiple matching videos (see youtube_video_count), a high total (tens of thousands or more) is a strong signal the place is visually appealing and worth filming, weigh that heavily where present, it matters more than a slightly better price. is_rare_deal means the price is unusually low either against this hotel's own history or against same-tier peers in the same destination, not just self-reported as a discount, treat it as a genuinely strong signal. Prioritize newly built properties when they're close in price and reasonably reviewed. Keep it concise, plain text, no markdown headers.`;
}

async function callGemini(apiKey, prompt) {
  const resp = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key=${encodeURIComponent(apiKey)}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] }),
    }
  );
  const data = await resp.json();
  if (!resp.ok) throw new Error(data.error?.message || `Gemini request failed (${resp.status})`);
  const text = data.candidates?.[0]?.content?.parts?.map((p) => p.text).join("") || "";
  if (!text) throw new Error("Gemini returned an empty response, check the API key and try again.");
  return text;
}

document.getElementById("estimate-stars").addEventListener("click", async () => {
  const status = document.getElementById("estimate-stars-status");
  const { settings } = await chrome.storage.local.get("settings");
  const apiKey = settings?.aiApiKey || "";
  const provider = settings?.aiProvider || "none";

  if (provider !== "gemini" || !apiKey) {
    status.textContent = "Set the AI provider to Google Gemini and add your API key in the popup's Settings first.";
    return;
  }

  const blockedSet = allGroups._blockedSet || new Set();
  const inView = applyFiltersAndSort(allGroups, blockedSet, false);
  const unrated = inView.filter((g) => g.starRating === null).slice(0, 30);

  if (unrated.length === 0) {
    status.textContent = "Nothing unrated in view to estimate.";
    return;
  }

  status.textContent = `Asking Gemini about ${unrated.length} unrated hotel(s)...`;

  const candidates = unrated.map((g) => ({
    name: g.hotelName,
    destination: g.destination,
    price_inr: g.cheapestPrice,
    guest_rating: g.rating,
    review_count: g.reviewCount,
  }));

  const prompt = `Estimate the likely official star classification (3, 4, or 5) for these Indian hotels/resorts, which have no star rating listed. This is a rough ESTIMATE for personal travel planning, not a verified classification, be conservative.

${JSON.stringify(candidates, null, 2)}

Base it on typical Indian hotel pricing: under \u20b91,500/night rarely reaches 4-star, \u20b91,500-3,500 is typically 3-4 star, above \u20b93,500 with strong reviews often indicates 4-5 star. A high guest rating backed by very few reviews (under ~150) is weak evidence, lower your confidence accordingly. Use null for estimated_tier if there isn't enough signal to guess with at least medium confidence.

Respond with ONLY a JSON array, no markdown formatting, no explanation, in exactly this shape:
[{"name": "...", "estimated_tier": 3, "confidence": "medium"}, ...]`;

  try {
    const text = await callGemini(apiKey, prompt);
    const cleaned = text.replace(/```json|```/g, "").trim();
    const results = JSON.parse(cleaned);

    for (const r of results) {
      if (!r.name || r.estimated_tier === null || r.estimated_tier === undefined) continue;
      const match = unrated.find((g) => g.hotelName === r.name);
      if (!match) continue;
      for (const d of match.dates) {
        const { [d.key]: existing } = await chrome.storage.local.get(d.key);
        if (existing) {
          await chrome.storage.local.set({
            [d.key]: {
              ...existing,
              aiEstimatedStarTier: r.estimated_tier,
              aiEstimatedStarConfidence: r.confidence || null,
            },
          });
        }
      }
    }
    const estimated = results.filter((r) => r.estimated_tier).length;
    status.textContent = `Estimated ${estimated} of ${unrated.length} hotel(s), the rest didn't have enough signal to guess confidently.`;
    showToast(`Estimated ${estimated} star tier(s)`);
    await refresh();
  } catch (e) {
    status.textContent = "Couldn't get estimates: " + e.message;
  }
});

/**
 * AI review summaries (PROJECT_BRIEF open item 5). Deliberately built
 * from data already scraped (star rating, guest rating, review count,
 * price, amenity badges), NOT from actual review text: scraping real
 * review snippets would need new per-hotel-detail-page selectors this
 * environment can't verify live (same risk as the amenity badges), and a
 * half-verified review scraper feeding an LLM summary compounds two
 * unverified layers instead of one. This gives a real, useful first pass
 * (an inferred pro/caution from the rating pattern itself, explicitly
 * labeled as inference) without that compounded risk. Scraping actual
 * review text remains a real follow-up if this first pass isn't enough,
 * see the README entry for this feature.
 */
document.getElementById("get-review-summaries").addEventListener("click", async () => {
  const status = document.getElementById("review-summaries-status");
  const { settings } = await chrome.storage.local.get("settings");
  const apiKey = settings?.aiApiKey || "";
  const provider = settings?.aiProvider || "none";

  if (provider !== "gemini" || !apiKey) {
    status.textContent = "Set the AI provider to Google Gemini and add your API key in the popup's Settings first.";
    return;
  }

  const blockedSet = allGroups._blockedSet || new Set();
  const inView = applyFiltersAndSort(allGroups, blockedSet, false);
  const candidates = inView.filter((g) => g.rating !== null && g.reviewCount !== null && !g.aiReviewSummary).slice(0, 20);

  if (candidates.length === 0) {
    status.textContent = "Nothing in view needs one (either no rating data yet, or already summarized).";
    return;
  }

  status.textContent = `Asking Gemini about ${candidates.length} hotel(s)...`;

  const payload = candidates.map((g) => ({
    name: g.hotelName,
    destination: g.destination,
    star_rating: g.starRating,
    guest_rating: g.rating,
    review_count: g.reviewCount,
    price_inr: g.cheapestPrice,
    amenities: g.amenities,
  }));

  const prompt = `You're summarizing likely guest sentiment for Indian resort/hotel listings, based ONLY on their star rating, guest rating, review count, price, and detected amenities. You do NOT have the actual review text, be explicit that this is inferred from the rating pattern, not real reviews.

${JSON.stringify(payload, null, 2)}

For each hotel, write one or two short sentences: a plausible pro and a plausible caution, based on how a rating/review-count/price combination like this usually reads (e.g. a high rating from very few reviews is promising but unproven; a mid rating with thousands of reviews suggests a reliably average stay; a high price with no amenities detected is worth flagging). Stay honest about this being an inference, not a claim about actual guest experiences.

Respond with ONLY a JSON array, no markdown formatting, no explanation, in exactly this shape:
[{"name": "...", "summary": "..."}, ...]`;

  try {
    const text = await callGemini(apiKey, prompt);
    const cleaned = text.replace(/```json|```/g, "").trim();
    const results = JSON.parse(cleaned);

    let applied = 0;
    for (const r of results) {
      if (!r.name || !r.summary) continue;
      const match = candidates.find((g) => g.hotelName === r.name);
      if (!match) continue;
      for (const d of match.dates) {
        const { [d.key]: existing } = await chrome.storage.local.get(d.key);
        if (existing) {
          await chrome.storage.local.set({ [d.key]: { ...existing, aiReviewSummary: r.summary } });
        }
      }
      applied++;
    }
    status.textContent = `Added a review insight for ${applied} of ${candidates.length} hotel(s), click a row to see it.`;
    showToast(`Review insights added for ${applied} hotel(s)`);
    await refresh();
  } catch (e) {
    status.textContent = "Couldn't get insights: " + e.message;
  }
});

async function callGrok(apiKey, prompt) {
  const resp = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({ model: "grok-beta", messages: [{ role: "user", content: prompt }] }),
  });
  const data = await resp.json();
  if (!resp.ok) throw new Error(data.error?.message || `Grok request failed (${resp.status})`);
  const text = data.choices?.[0]?.message?.content || "";
  if (!text) throw new Error("Grok returned an empty response, check the API key and try again.");
  return text;
}

/**
 * Turns the activity log into a CSV Excel can open directly. Built by
 * hand rather than pulling in a library, this is simple enough (three
 * columns, values that need escaping are rare) not to need one.
 */
function activityLogToCsv(entries) {
  const escapeCsv = (val) => {
    const s = val === null || val === undefined ? "" : typeof val === "object" ? JSON.stringify(val) : String(val);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const header = "Date,Time,Event,Details\n";
  const rows = entries
    .map((e) => {
      const d = new Date(e.at);
      const date = d.toLocaleDateString("en-IN");
      const time = d.toLocaleTimeString("en-IN");
      return [escapeCsv(date), escapeCsv(time), escapeCsv(e.event), escapeCsv(e.details)].join(",");
    })
    .join("\n");
  return header + rows;
}

async function renderActivityLogCount() {
  const { activityLog = [] } = await chrome.storage.local.get("activityLog");
  document.getElementById("activity-log-count").textContent = `${activityLog.length} event(s) logged`;
}

async function renderLastAutoBackup() {
  const { lastAutoBackupAt } = await chrome.storage.local.get("lastAutoBackupAt");
  const status = document.getElementById("backup-status");
  if (lastAutoBackupAt && !status.textContent) {
    status.textContent = `Last automatic backup: ${formatDate(lastAutoBackupAt)}.`;
  }
}

// Feature: export the actual tracked hotel/price data (not just the
// activity log, which is diagnostics only and never had the real data
// itself). Excludes hidden/blocked hotels, same as what the Hotels tab
// and the published live dashboard show by default -- if you hid a
// hotel, it stays out of this record too, consistent with everywhere
// else "hidden" already means something.
document.getElementById("export-tracked-hotels").addEventListener("click", async () => {
  const blockedSet = await getBlockedSet();
  const visibleGroups = allGroups.filter((g) => !blockedSet.has(g.groupKey));
  const countEl = document.getElementById("export-hotels-count");
  if (visibleGroups.length === 0) {
    countEl.textContent = "Nothing tracked yet.";
    return;
  }
  const csv = trackedHotelsToCsv(visibleGroups);
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `hotel-tracker-data-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  const dateCount = visibleGroups.reduce((sum, g) => sum + g.dates.length, 0);
  countEl.textContent = `Exported ${visibleGroups.length} hotel(s), ${dateCount} tracked date(s).`;
});

document.getElementById("export-activity-log").addEventListener("click", async () => {
  const { activityLog = [] } = await chrome.storage.local.get("activityLog");
  if (activityLog.length === 0) {
    document.getElementById("activity-log-count").textContent = "Nothing logged yet.";
    return;
  }
  const csv = activityLogToCsv(activityLog);
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `hotel-tracker-activity-log-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
});

async function renderTravelpayoutsFields() {
  const settings = await getSettings();
  document.getElementById("travelpayouts-token").value = settings.travelpayoutsApiToken || "";
  document.getElementById("travelpayouts-marker").value = settings.travelpayoutsMarker || "";
}

document.getElementById("save-travelpayouts").addEventListener("click", async () => {
  const settings = await getSettings();
  settings.travelpayoutsApiToken = document.getElementById("travelpayouts-token").value.trim();
  settings.travelpayoutsMarker = document.getElementById("travelpayouts-marker").value.trim();
  await saveSettings(settings);
  const status = document.getElementById("travelpayouts-status");
  status.textContent = "Saved. Not used anywhere yet, see the note above.";
  setTimeout(() => (status.textContent = ""), 3000);
});

document.getElementById("get-ai-picks").addEventListener("click", async () => {
  const output = document.getElementById("ai-output");
  output.classList.remove("hidden");

  const { settings } = await chrome.storage.local.get("settings");
  const provider = settings?.aiProvider || "none";
  const apiKey = settings?.aiApiKey || "";

  if (provider === "none") {
    output.textContent = "Set an AI provider and API key in the extension popup's Settings first.";
    return;
  }
  if (!apiKey) {
    output.textContent = `Add your ${provider === "gemini" ? "Gemini" : "Grok"} API key in the popup's Settings first.`;
    return;
  }

  const blockedSet = allGroups._blockedSet || new Set();
  const visible = applyFiltersAndSort(allGroups, blockedSet, false);
  if (visible.length === 0) {
    output.textContent = "Nothing in view to analyze, adjust the filters or run a scan first.";
    return;
  }

  output.textContent = "Asking " + (provider === "gemini" ? "Gemini" : "Grok") + "...";
  try {
    const prompt = buildAiPrompt(visible);
    const text = provider === "gemini" ? await callGemini(apiKey, prompt) : await callGrok(apiKey, prompt);
    output.textContent = text;
  } catch (e) {
    output.textContent = "Couldn't get a response: " + e.message;
  }
});

["filter-destination", "filter-star", "sort-by", "filter-quality", "filter-newly-built", "filter-favorites"].forEach((id) => {
  document.getElementById(id).addEventListener("change", () => {
    if (id === "sort-by") {
      // Using the dropdown directly should take back control from
      // whatever column was last clicked, otherwise the override would
      // silently keep winning and the dropdown would look broken.
      columnSortOverride = null;
      renderSortIndicators();
    }
    rerender();
  });
});
document.querySelectorAll("th.sortable").forEach((th) => {
  th.addEventListener("click", () => setColumnSort(th.dataset.sort));
});
document.getElementById("search-hotel-name").addEventListener("input", rerender);
document.querySelectorAll(".weekend-filter-btn").forEach((btn) => {
  btn.addEventListener("click", () => setWeekendFilter(btn.dataset.weekend));
});
document.getElementById("refresh").addEventListener("click", refresh);
document.getElementById("toggle-blocked").addEventListener("click", () => {
  showingBlocked = !showingBlocked;
  rerender();
  refresh();
});

/** Simple, dependency-free toast: appears, sits for a moment, fades. */
function showToast(message, type = "success") {
  const container = document.getElementById("toast-container");
  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => toast.classList.add("toast-visible"), 10);
  setTimeout(() => {
    toast.classList.remove("toast-visible");
    setTimeout(() => toast.remove(), 300);
  }, 2800);
}

/** One card per video found for this hotel, reusing the same fields the Video coverage table shows. */
function videoCard(video, type) {
  if (!video) return "";
  return `
    <div class="video-card">
      <div class="video-card-type">${type}</div>
      <a href="${escapeAttr(video.url)}" target="_blank" class="video-card-title">${escapeHtml(video.title || "Untitled")}</a>
      <div class="muted small">${escapeHtml(video.channelTitle || "Unknown creator")} \u2022 ${video.channelSubs !== null ? formatViews(video.channelSubs) + " subs" : "subs hidden"}</div>
      <div class="muted small">${formatViews(video.views)} views \u2022 posted ${formatPublishedDate(video.publishedAt)}</div>
    </div>
  `;
}

/**
 * v1.27.0: used to render at most two cards (the single best Short and
 * the single best long-form video). Now renders every genuinely-matched
 * video for that format, each with its own creator, plus a heading with
 * the count and average views whenever there's more than one, this is
 * the "show the details when opened" half of gathering all of them.
 */
function videoListSectionHtml(label, list) {
  if (!list || list.length === 0) return "";
  const heading =
    list.length > 1
      ? `<h3 class="video-section-heading">${label} · ${list.length} found, avg ${formatViews(Math.round(avgViews(list)))} views</h3>`
      : `<h3 class="video-section-heading">${label}</h3>`;
  return heading + list.map((v) => videoCard(v, label)).join("");
}

function openVideoModal(g) {
  document.getElementById("video-modal-title").textContent = g.hotelName;
  const body = document.getElementById("video-modal-body");
  const html = videoListSectionHtml("Long-form", longFormList(g)) + videoListSectionHtml("Shorts", shortsList(g));
  body.innerHTML = html || '<p class="hint">No video details saved for this one yet.</p>';
  document.getElementById("video-modal-overlay").classList.remove("hidden");
}

function closeVideoModal() {
  document.getElementById("video-modal-overlay").classList.add("hidden");
}

document.getElementById("video-modal-close").addEventListener("click", closeVideoModal);
document.getElementById("video-modal-overlay").addEventListener("click", (e) => {
  if (e.target.id === "video-modal-overlay") closeVideoModal();
});

/**
 * Comparison drawer (PROJECT_BRIEF open item 2). Renders whatever's
 * currently selected via the compare-checkbox column, looked up from
 * allGroups by groupKey rather than kept as a separate list of objects,
 * so it always reflects the latest refresh() rather than a stale copy
 * made at selection time.
 */
function renderCompareBar() {
  const bar = document.getElementById("compare-bar");
  const label = document.getElementById("compare-bar-label");
  const openBtn = document.getElementById("compare-bar-open");
  if (compareSelection.size === 0) {
    bar.classList.add("hidden");
    return;
  }
  bar.classList.remove("hidden");
  label.textContent = `${compareSelection.size} selected to compare`;
  openBtn.disabled = compareSelection.size < 2;
  openBtn.title = compareSelection.size < 2 ? "Select at least 2 to compare" : "";
}

const COMPARE_ATTRIBUTES = [
  { label: "Destination", get: (g) => `${g.destination} (${g.source})` },
  { label: "Cheapest price", get: (g) => formatINR(g.cheapestPrice) },
  { label: "Cheapest dates", get: (g) => `${g.cheapest.checkin} → ${g.cheapest.checkout}` },
  { label: "Lowest ever seen", get: (g) => (g.everAtLowest ? "At its lowest now" : formatINR(g.lowestEver)) },
  { label: "Rare deal", get: (g) => (g.rarity && g.rarity.isRareDeal ? `Yes — ${g.rarity.reasons.join("; ")}` : "No") },
  { label: "Star tier", get: (g) => (g.manualStarTier || g.starRating ? `${g.manualStarTier || g.starRating}★` : g.aiEstimatedStarTier ? `~${g.aiEstimatedStarTier}★ (AI est.)` : "Unrated") },
  { label: "Guest rating", get: (g) => (g.rating !== null ? `${g.rating.toFixed(1)} (${(g.reviewCount || 0).toLocaleString("en-IN")} reviews)` : "—") },
  { label: "Newly built", get: (g) => (g.isNewlyBuilt ? "Yes" : "—") },
  { label: "YouTube views", get: (g) => (g.youtubeViews !== null ? `${formatViews(g.youtubeViews)}${g.youtubeVideoCount > 1 ? ` (${g.youtubeVideoCount} videos)` : ""}` : "Not checked") },
  { label: "Amenities", get: (g) => ((g.amenities || []).length ? g.amenities.join(", ") : "None detected") },
  { label: "Transit from Kolkata", get: (g) => transitEstimate(g.destination) || "—" },
  { label: "Target price alert", get: (g) => (g.effectiveTargetPrice != null ? formatINR(g.effectiveTargetPrice) : "Not set") },
];

function openCompareModal() {
  const groups = allGroups.filter((g) => compareSelection.has(g.groupKey));
  const body = document.getElementById("compare-modal-body");
  if (groups.length < 2) {
    body.innerHTML = '<p class="hint">Select at least 2 hotels from the checkboxes in the Hotels tab first.</p>';
  } else {
    body.innerHTML = `
      <table class="sub-table compare-table">
        <thead>
          <tr><th></th>${groups.map((g) => `<th>${escapeHtml(g.hotelName)}</th>`).join("")}</tr>
        </thead>
        <tbody>
          ${COMPARE_ATTRIBUTES.map(
            (attr) => `
            <tr>
              <td class="muted small">${attr.label}</td>
              ${groups.map((g) => `<td>${escapeHtml(String(attr.get(g)))}</td>`).join("")}
            </tr>
          `
          ).join("")}
        </tbody>
      </table>
    `;
  }
  document.getElementById("compare-modal-overlay").classList.remove("hidden");
}

function closeCompareModal() {
  document.getElementById("compare-modal-overlay").classList.add("hidden");
}

document.getElementById("compare-bar-open").addEventListener("click", openCompareModal);
document.getElementById("compare-bar-clear").addEventListener("click", () => {
  compareSelection.clear();
  renderCompareBar();
  rerender();
});
document.getElementById("compare-modal-close").addEventListener("click", closeCompareModal);
document.getElementById("compare-modal-overlay").addEventListener("click", (e) => {
  if (e.target.id === "compare-modal-overlay") closeCompareModal();
});

document.querySelectorAll(".tab-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    const target = btn.dataset.tab;
    document.querySelectorAll(".tab-panel").forEach((panel) => {
      panel.classList.toggle("hidden", panel.dataset.panel !== target);
    });
  });
});

/**
 * Applied as early as possible (before the first render) to avoid a
 * flash of the light theme on load for someone who's chosen dark.
 */
async function applyTheme() {
  const { theme } = await chrome.storage.local.get("theme");
  const isDark = theme !== "light";
  document.documentElement.dataset.theme = isDark ? "dark" : "light";
  const btn = document.getElementById("theme-toggle");
  if (btn) btn.textContent = isDark ? "\u2600\ufe0f Light" : "\ud83c\udf19 Dark";
}

document.getElementById("theme-toggle").addEventListener("click", async () => {
  const isDark = document.documentElement.dataset.theme === "dark";
  await chrome.storage.local.set({ theme: isDark ? "light" : "dark" });
  await applyTheme();
});

// Same as the popup: opening the dashboard picks up a new version at once.
// An open extension page dies when the extension reloads, so refresh it.
chrome.runtime.sendMessage({ type: "CHECK_FOR_UPDATE" }).then((r) => {
  if (r && r.status === "reloading") setTimeout(() => location.reload(), 1500);
}).catch(() => {});

applyTheme();
refresh();
renderTravelpayoutsFields();
