/**
 * Runs on individual hotel detail pages (not listing pages). Only fires
 * when background.js opens one specifically to double-check room pricing
 * for a shortlisted hotel, see checkRoomDetailsForTopN in the README.
 *
 * A listing card shows one "starting from" price. The detail page usually
 * shows several room types at different prices, this finds the actual
 * cheapest one rather than trusting the card's headline figure.
 *
 * EXPERIMENTAL: unlike content.js, this hasn't been validated against a
 * real detail page (I don't have network access to test it), only against
 * the same kind of simulated structure that content.js was tested with.
 * If it comes back empty, the debug info it sends will show why.
 */

const PRICE_RE = /[\u20b9]\s?([\d,]{3,})/;

// Same floor as content.js uses for listing pages. This file never had
// one at all, which is the actual bug: a page that loads as raw JSON
// (see content.js and background.js for the JSON-response issue) can
// contain a small, unrelated number, a fee, a discount amount, whatever
// happens to be in that payload, formatted with a rupee sign, and with
// no floor this file accepted it uncritically as a real room price.
const MIN_PLAUSIBLE_PRICE = 300;

/** See content.js for why this exists, same reload-mid-scrape scenario. */
function safeSendMessage(message) {
  try {
    if (chrome.runtime && chrome.runtime.id) {
      chrome.runtime.sendMessage(message);
    }
  } catch (e) {
    console.log("[detail-content] extension context gone, dropping message:", e);
  }
}

function parsePriceValue(text) {
  const m = PRICE_RE.exec(text || "");
  if (!m) return null;
  const digits = m[1].replace(/,/g, "");
  return /^\d+$/.test(digits) ? parseInt(digits, 10) : null;
}

function isStruckThrough(el) {
  let node = el;
  for (let i = 0; i < 4 && node; i++) {
    const tag = node.tagName;
    if (tag === "DEL" || tag === "S" || tag === "STRIKE") return true;
    const style = window.getComputedStyle(node);
    const line = (style.textDecorationLine || "") + " " + (style.textDecoration || "");
    if (line.includes("line-through")) return true;
    node = node.parentElement;
  }
  return false;
}

// PROMO_RE now lives in shared.js (loaded before this file, see
// manifest.json), shared with content.js's extractPrices() on listing
// pages, so the two can't quietly diverge again the way they did before:
// this file had NO promo filter at all until v1.24.1, which was the
// actual bug behind hotels showing an implausible "all-time low" that
// never moved (a detail page's own promo banner for a small rupee amount
// cleared the >=300 floor easily and then won Math.min() outright over
// the real room price). It was also unanchored ("off" without a word
// boundary) until v1.27.0, matching "coffee"/"office"/"toffee".

function findAllPrices() {
  const results = [];
  if (!document.body) return results;
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT);
  let node = walker.currentNode;
  while (node) {
    if (node.children.length === 0) {
      const text = node.textContent || "";
      const value = parsePriceValue(text);
      if (value !== null && value >= MIN_PLAUSIBLE_PRICE) {
        const parentText = node.parentElement ? node.parentElement.innerText || "" : "";
        const context = (text + " " + parentText).slice(0, 160);
        // TAX_RE and PROMO_RE both live in shared.js now, shared with
        // content.js. TAX_RE is word-boundaried: the old unanchored
        // /tax|fee/ matched "fee" as a substring of "coffee"/"toffee".
        const isTax = TAX_RE.test(context);
        const isPromo = PROMO_RE.test(context);
        if (!isTax && !isPromo && !isStruckThrough(node)) {
          results.push(value);
        }
      }
    }
    node = walker.nextNode();
  }
  return results;
}

function waitAndScrape(maxWaitMs, intervalMs) {
  return new Promise((resolve) => {
    const start = Date.now();
    const check = () => {
      const prices = findAllPrices();
      if (prices.length > 0 || Date.now() - start >= maxWaitMs) {
        return resolve(prices);
      }
      setTimeout(check, intervalMs);
    };
    check();
  });
}

(async function main() {
  try {
    // Chrome's own JSON viewer, shown when a page loads as raw JSON
    // instead of an actual page, has a distinctive "Pretty-print"
    // checkbox. Catching this directly, not just relying on the price
    // floor, means a JSON payload that happens to contain a plausible
    // 3+ digit number near a rupee sign still can't slip through.
    const bodySample = (document.body ? document.body.innerText : "").slice(0, 300);
    if (/pretty-print/i.test(bodySample) || bodySample.trim().startsWith("{") || bodySample.trim().startsWith("[")) {
      safeSendMessage({
        type: "ROOM_DETAIL_RESULT",
        lowest: null,
        error: "Page loaded as raw JSON, not an actual hotel page, nothing extracted",
        url: location.href,
      });
      return;
    }

    await new Promise((r) => setTimeout(r, 1500));
    const prices = await waitAndScrape(8000, 1000);
    const lowest = prices.length ? Math.min(...prices) : null;

    // Amenity/couple-friendly badges (PROJECT_BRIEF open item 3), reusing
    // findAmenitiesInText from shared.js (loaded first, see manifest.json).
    // A plain text-keyword scan rather than a CSS selector, same
    // defensive reasoning as the price extraction above: it survives a
    // markup change that would break a selector. Still UNVERIFIED against
    // a real detail page, see shared.js's comment on AMENITY_PATTERNS.
    const amenities = document.body ? findAmenitiesInText(document.body.innerText) : [];

    safeSendMessage({
      type: "ROOM_DETAIL_RESULT",
      lowest,
      priceCount: prices.length,
      amenities,
      url: location.href,
    });
  } catch (err) {
    safeSendMessage({
      type: "ROOM_DETAIL_RESULT",
      lowest: null,
      error: String(err && err.stack ? err.stack : err),
      url: location.href,
    });
  }
})();
