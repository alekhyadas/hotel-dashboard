/**
 * Deal Feed + Business tabs of the extension dashboard.
 *
 * Deal Feed: every drop the extension has detected (newest first), with
 * last-minute deals pinned, a full price-ledger chart per stay, and the
 * data-safety panel (off-device backup status, full-backup download,
 * restore-from-file).
 *
 * Business: the paid-alerts side. Plans, subscribers, alert rules, MRR.
 *
 * Plain script loaded after dashboard.js, so it reuses that file's globals
 * (escapeHtml, escapeAttr, formatDate, showToast, getBlockedSet) and
 * shared.js / intel.js (getSettings, formatINR, PLANS, ...).
 */
(function () {
  const $ = (id) => document.getElementById(id);
  installErrorCapture("dashboard");

  const TYPE_BADGE = {
    record_low: "feed-badge-teal",
    good_deal: "feed-badge-green",
    market_deal: "feed-badge-green",
    last_minute: "feed-badge-red",
    rare: "feed-badge-teal",
    drop: "feed-badge-green",
    discount: "feed-badge-amber",
    new: "feed-badge-blue",
  };

  function timeAgo(iso) {
    const mins = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
    if (mins < 1) return "just now";
    if (mins < 60) return `${mins}m ago`;
    const h = Math.round(mins / 60);
    if (h < 48) return `${h}h ago`;
    return `${Math.round(h / 24)}d ago`;
  }

  function leadChip(lead) {
    if (lead == null) return "";
    const label = lead <= 0 ? "Check-in tonight" : lead === 1 ? "Check-in tomorrow" : `Check-in in ${lead} days`;
    return `<span class="feed-chip ${lead <= 1 ? "feed-chip-hot" : ""}">${label}</span>`;
  }

  // ------------------------------------------------------------------ feed

  let feedEvents = [];

  async function loadFeed() {
    const blocked = await getBlockedSet();
    const all = await loadDealEvents();
    feedEvents = all.filter((e) => !blocked.has(`${e.source}:::${e.hotelName}:::${e.destination}`));
  }

  function renderFeedKpis(ledger) {
    const now = Date.now();
    const day = feedEvents.filter((e) => now - new Date(e.at).getTime() < 86400000);
    const today = toISODate(new Date());
    const liveLm = feedEvents.filter((e) => e.type === "last_minute" && e.checkin >= today && now - new Date(e.at).getTime() < 48 * 3600000);
    const week = feedEvents.filter((e) => now - new Date(e.at).getTime() < 7 * 86400000 && e.dropPct);
    const best = week.reduce((b, e) => (!b || e.dropPct > b.dropPct ? e : b), null);

    $("fk-day").textContent = String(day.length);
    $("fk-lm").textContent = String(liveLm.length);
    $("fk-best").textContent = best ? `-${best.dropPct}%` : "—";
    $("fk-best-sub").textContent = best ? `${best.hotelName}, ${best.destination}` : "No drops this week yet";
    $("fk-ledger").textContent = ledger.points.toLocaleString("en-IN");
    $("fk-ledger-sub").textContent = ledger.records
      ? `${ledger.records.toLocaleString("en-IN")} ${ledger.records === 1 ? "stay" : "stays"} tracked${ledger.oldest ? ", since " + ledger.oldest.slice(0, 10) : ""}`
      : "Nothing tracked yet";
  }

  async function ledgerStats() {
    const all = await chrome.storage.local.get(null);
    let records = 0, points = 0, oldest = null;
    for (const [k, v] of Object.entries(all)) {
      if (!k.startsWith("hist:") || !v || !Array.isArray(v.prices)) continue;
      records++;
      points += v.prices.length;
      if (v.prices[0] && v.prices[0].at && (!oldest || v.prices[0].at < oldest)) oldest = v.prices[0].at;
    }
    return { records, points, oldest, lastBackup: all.lastAutoBackupAt || null, queued: (all.alertQueue || []).length };
  }

  function populateFeedFilters() {
    const dests = [...new Set(feedEvents.map((e) => e.destination))].sort();
    const sel = $("feed-filter-destination");
    const cur = sel.value;
    sel.innerHTML = `<option value="">All destinations</option>` + dests.map((d) => `<option>${escapeHtml(d)}</option>`).join("");
    sel.value = dests.includes(cur) ? cur : "";
  }

  function feedCard(e) {
    const t = DEAL_EVENT_TYPES[e.type] || DEAL_EVENT_TYPES.drop;
    const url = typeof sanitizeUrl === "function" ? sanitizeUrl(e.url) : null;
    const key = `hist:${e.source}:${e.hotelName}:${e.destination}:${e.checkin}:${e.checkout}`;
    const from = e.refPrice && e.refPrice > e.price ? `<s class="feed-was">${formatINR(e.refPrice)}</s> ` : "";
    return `<article class="feed-card ${e.type === "last_minute" ? "feed-card-hot" : ""}">
      <div class="feed-card-top">
        <span class="feed-badge ${TYPE_BADGE[e.type] || ""}">${t.emoji} ${t.label}</span>
        ${leadChip(e.leadDays)}
        <span class="feed-time">${timeAgo(e.at)}</span>
      </div>
      <h3 class="feed-hotel">${escapeHtml(e.hotelName)}${e.starRating ? ` <span class="feed-stars">${e.starRating}★</span>` : ""}</h3>
      <div class="feed-meta">${escapeHtml(e.destination)} • ${escapeHtml(e.source)} • ${escapeHtml(e.checkin)} to ${escapeHtml(e.checkout)}</div>
      <div class="feed-price-row">
        <div class="feed-price">${from}${formatINR(e.price)}</div>
        ${e.dropPct ? `<div class="feed-pct">-${e.dropPct}%</div>` : ""}
      </div>
      <div class="feed-actions">
        <button class="secondary-btn" data-history="${escapeAttr(key)}">Price history</button>
        ${url ? `<a class="feed-link" href="${escapeAttr(url)}" target="_blank" rel="noopener noreferrer">Open listing</a>` : ""}
      </div>
    </article>`;
  }

  function renderFeedList() {
    const type = $("feed-filter-type").value;
    const dest = $("feed-filter-destination").value;
    const range = $("feed-filter-range").value;
    const cutoff = range === "all" ? 0 : Date.now() - Number(range) * 3600000;
    const rows = feedEvents.filter((e) =>
      (!type || e.type === type) && (!dest || e.destination === dest) && new Date(e.at).getTime() >= cutoff);
    const list = $("feed-list");
    $("feed-empty").classList.toggle("hidden", rows.length > 0);
    // Last-minute first (they expire), then newest.
    const sorted = [...rows].sort((a, b) => (b.type === "last_minute") - (a.type === "last_minute") || new Date(b.at) - new Date(a.at));
    list.innerHTML = sorted.slice(0, 120).map(feedCard).join("");
  }

  // Full-history chart for one stay. Points seen within 3 days of check-in
  // are drawn larger and in the accent colour, so "what did it cost last
  // minute, historically" is visible at a glance.
  function historyChart(prices, checkin) {
    const W = 560, H = 200, P = { l: 52, r: 12, t: 14, b: 26 };
    const pts = prices.filter((p) => p.price >= 300).map((p) => ({ ...p, ts: new Date(p.at).getTime() }));
    if (pts.length < 2) return `<p class="hint">Not enough history yet, this needs at least two scans.</p>`;
    const minT = pts[0].ts, maxT = pts[pts.length - 1].ts || minT + 1;
    const vals = pts.map((p) => p.price);
    const minP = Math.min(...vals), maxP = Math.max(...vals), span = maxP - minP || 1;
    const x = (t) => P.l + ((t - minT) / (maxT - minT || 1)) * (W - P.l - P.r);
    const y = (v) => P.t + (1 - (v - minP) / span) * (H - P.t - P.b);
    const line = pts.map((p) => `${x(p.ts).toFixed(1)},${y(p.price).toFixed(1)}`).join(" ");
    const dots = pts.map((p) => {
      const lead = p.lead != null ? p.lead : leadDays(checkin, p.at);
      const hot = lead <= 3;
      return `<circle cx="${x(p.ts).toFixed(1)}" cy="${y(p.price).toFixed(1)}" r="${hot ? 4 : 2.4}" class="${hot ? "hist-dot-hot" : "hist-dot"}"><title>${escapeHtml(formatINR(p.price))} • ${escapeHtml(new Date(p.at).toLocaleString("en-IN"))} • ${lead <= 0 ? "check-in day" : lead + " day(s) before check-in"}</title></circle>`;
    }).join("");
    const lowY = y(minP), highY = y(maxP);
    const fmtDay = (t) => new Date(t).toLocaleDateString("en-IN", { day: "numeric", month: "short" });
    return `<svg viewBox="0 0 ${W} ${H}" class="hist-chart" role="img" aria-label="Price history">
      <line x1="${P.l}" x2="${W - P.r}" y1="${lowY}" y2="${lowY}" class="hist-grid"/>
      <line x1="${P.l}" x2="${W - P.r}" y1="${highY}" y2="${highY}" class="hist-grid"/>
      <text x="${P.l - 6}" y="${lowY + 4}" text-anchor="end" class="hist-axis">${escapeHtml(formatINR(minP))}</text>
      <text x="${P.l - 6}" y="${highY + 4}" text-anchor="end" class="hist-axis">${escapeHtml(formatINR(maxP))}</text>
      <text x="${P.l}" y="${H - 6}" class="hist-axis">${fmtDay(minT)}</text>
      <text x="${W - P.r}" y="${H - 6}" text-anchor="end" class="hist-axis">${fmtDay(maxT)}</text>
      <polyline points="${line}" fill="none" class="hist-line"/>
      ${dots}
    </svg>`;
  }

  async function openHistory(key) {
    const { [key]: rec } = await chrome.storage.local.get(key);
    const body = $("history-modal-body");
    if (!rec) {
      body.innerHTML = `<p class="hint">No stored history for this stay (it may have been restored from an older backup).</p>`;
    } else {
      const real = rec.prices.filter((p) => p.price >= 300);
      const vals = real.map((p) => p.price);
      const avg = vals.length ? Math.round(vals.reduce((a, b) => a + b, 0) / vals.length) : null;
      const lastMin = real.filter((p) => (p.lead != null ? p.lead : leadDays(rec.checkin, p.at)) <= 3);
      const lmLow = lastMin.length ? Math.min(...lastMin.map((p) => p.price)) : null;
      $("history-modal-title").textContent = `${rec.hotelName}, ${rec.destination}`;
      body.innerHTML = `
        <p class="hint">${escapeHtml(rec.checkin)} to ${escapeHtml(rec.checkout)} • ${real.length} checks recorded. Larger dots = seen within 3 days of check-in.</p>
        ${historyChart(rec.prices, rec.checkin)}
        <div class="hist-stats">
          <div><b>${formatINR(Math.min(...vals))}</b><span>lowest ever</span></div>
          <div><b>${avg ? formatINR(avg) : "—"}</b><span>average</span></div>
          <div><b>${formatINR(Math.max(...vals))}</b><span>highest</span></div>
          <div><b>${lmLow ? formatINR(lmLow) : "—"}</b><span>lowest last-minute</span></div>
        </div>`;
    }
    $("history-modal-overlay").classList.remove("hidden");
  }

  // ----------------------------------------------------------- data safety

  function renderSafety(ledger) {
    const el = $("safety-status");
    const when = ledger.lastBackup ? `${formatDate(ledger.lastBackup)} (${timeAgo(ledger.lastBackup)})` : "never";
    el.innerHTML = `Off-device backup (GitHub): <b>${escapeHtml(when)}</b>. Runs after scans, at most every 3 hours. `
      + `${ledger.points.toLocaleString("en-IN")} price points are kept (up to 365 per stay), and a restore merges with what's already here, so an old backup can never erase newer prices.`;
  }

  $("safety-backup-now").addEventListener("click", async () => {
    const btn = $("safety-backup-now");
    btn.disabled = true;
    try {
      const settings = await getSettings();
      const r = await backupToGithub(settings);
      await chrome.storage.local.set({ lastAutoBackupAt: new Date().toISOString() });
      showToast(`Backed up ${r.keyCount} records to GitHub`);
    } catch (e) {
      showToast(String(e.message || e), "error");
    }
    btn.disabled = false;
    refreshFeedTab();
  });

  $("safety-download").addEventListener("click", async () => {
    const backup = await buildFullBackup();
    const blob = new Blob([JSON.stringify(backup)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `hotel-tracker-full-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast(`Saved ${backup.keyCount} records`);
  });

  $("safety-import").addEventListener("change", async (ev) => {
    const file = ev.target.files && ev.target.files[0];
    ev.target.value = "";
    if (!file) return;
    try {
      const parsed = JSON.parse(await file.text());
      if (!parsed || typeof parsed.data !== "object") throw new Error("That file isn't a backup made by this extension.");
      const n = Object.keys(parsed.data).length;
      if (!confirm(`Import ${n} records from this backup? Price history is merged with what you have now, nothing is deleted.`)) return;
      const settings = await getSettings();
      await applyBackupData(parsed.data, settings);
      showToast(`Imported ${n} records`);
      refresh();
      refreshFeedTab();
      renderBusiness();
    } catch (e) {
      showToast(String(e.message || e), "error");
    }
  });

  // -------------------------------------------------------------- business

  async function loadSubscribers() {
    const { subscribers = [] } = await chrome.storage.local.get("subscribers");
    return subscribers;
  }

  async function updateSubscriber(id, mutate) {
    const subs = await loadSubscribers(); // re-read: the background also writes counters here
    const i = subs.findIndex((s) => s.id === id);
    if (i === -1) return;
    if (mutate === null) subs.splice(i, 1);
    else mutate(subs[i]);
    await chrome.storage.local.set({ subscribers: subs });
  }

  function subRow(s, nowMs) {
    const eff = effectivePlanKey(s, nowMs);
    const expired = s.plan !== "free" && eff === "free";
    const planOpts = Object.keys(PLANS).map((k) => `<option value="${k}" ${s.plan === k ? "selected" : ""}>${PLANS[k].label}</option>`).join("");
    return `<tr data-sub="${escapeAttr(s.id)}" class="${s.active ? "" : "sub-inactive"}">
      <td><b>${escapeHtml(s.name || s.id)}</b><div class="hint">${escapeHtml(s.telegramChatId || "")}${s.source === "bot" ? " • joined via bot" : ""}</div></td>
      <td><select data-f="plan">${planOpts}</select>${expired ? `<div class="hint sub-warn">expired, treated as Free</div>` : ""}</td>
      <td><input type="date" data-f="expiresAt" value="${escapeAttr((s.expiresAt || "").slice(0, 10))}" /></td>
      <td><input type="text" data-f="destinations" value="${escapeAttr((s.destinations || []).join(", "))}" placeholder="all" /></td>
      <td><input type="number" data-f="maxPrice" value="${s.maxPrice || ""}" placeholder="any" min="0" step="500" /></td>
      <td class="num">${s.sent && s.sent.day === toISODate(new Date()) ? s.sent.count : 0}</td>
      <td>${s.lastSentAt ? timeAgo(s.lastSentAt) : "—"}</td>
      <td><label class="sub-toggle"><input type="checkbox" data-f="active" ${s.active ? "checked" : ""} /> on</label>
          <button class="secondary-btn" data-del="1">Remove</button></td>
    </tr>`;
  }

  async function renderBusiness() {
    const settings = await getSettings();
    const subs = await loadSubscribers();
    const nowMs = Date.now();
    const sum = summarizeSubscribers(subs, nowMs, settings.planPrices || {});
    const { alertQueue = [] } = await chrome.storage.local.get("alertQueue");
    $("bk-active").textContent = String(sum.active);
    $("bk-active-sub").textContent = `${sum.total} total, ${sum.total - sum.active} paused`;
    $("bk-paid").textContent = String(sum.pro + sum.vip);
    $("bk-paid-sub").textContent = `${sum.pro} Pro, ${sum.vip} VIP${sum.expiringSoon ? `, ${sum.expiringSoon} expiring this week` : ""}`;
    $("bk-free").textContent = String(sum.free);
    $("bk-free-sub").textContent = "Upgrade candidates";
    $("bk-mrr").textContent = formatINR(sum.mrr);
    $("bk-mrr-sub").textContent = `${alertQueue.length} delayed alert(s) queued`;

    $("sub-body").innerHTML = subs.length
      ? subs.map((s) => subRow(s, nowMs)).join("")
      : `<tr><td colspan="8" class="hint">No subscribers yet. Turn on the sign-up bot below, share your bot's link, and anyone who sends /start joins as Free.</td></tr>`;

    $("rule-lmdays").value = settings.lastMinuteDays;
    $("rule-lmdrop").value = settings.lastMinuteDropPct;
    $("rule-sweep").checked = settings.lastMinuteSweepEnabled !== false;
    $("rule-tonight").checked = settings.scanTonight !== false;
    $("rule-smart").checked = settings.smartScan !== false;
    $("rule-bot").checked = !!settings.subscriberBotEnabled;
    $("rule-price-pro").value = (settings.planPrices && settings.planPrices.pro) ?? PLANS.pro.price;
    $("rule-price-vip").value = (settings.planPrices && settings.planPrices.vip) ?? PLANS.vip.price;
    $("rule-upgrade").value = settings.upgradeUrl || "";
    $("rule-plans").checked = !!settings.plansEnabled;
    $("rule-recordlow").checked = settings.alertRecordLow !== false;
    $("rule-gooddeals").checked = settings.alertGoodDeals !== false;
    $("rule-gooddealpct").value = settings.goodDealBelowPct ?? 25;
    $("rule-marketdeals").checked = settings.alertMarketDeals !== false;
    $("rule-marketdealpct").value = settings.marketDealBelowPct ?? 25;
    $("rule-role").value = settings.deviceRole === "helper" ? "helper" : "main";
    $("rule-devname").value = settings.deviceName || "";
    $("rule-scandests").value = (settings.scanDestinations || []).join(", ");
    $("rule-helpers").checked = !!settings.helpersEnabled;
    $("rule-helpers-row").hidden = settings.deviceRole === "helper";
    $("publish-ext-row").hidden = settings.deviceRole === "helper";
    $("rule-publish-ext").checked = settings.publishExtensionUpdates !== false;
    $("publish-ext-repo").textContent = settings.githubRepo || "username/repo-name";
    renderHelperStatus();
    renderPublishStatus();
    $("rule-confirm").checked = settings.confirmBeforeAlert !== false;
    $("rule-passive").checked = settings.passiveCollect !== false;
    $("rule-digest").checked = settings.digestEnabled !== false;
    $("rule-digesthour").value = settings.digestHour ?? 8;
    $("rule-holidays").value = settings.holidayText != null ? settings.holidayText : DEFAULT_HOLIDAY_TEXT;
    $("rule-channel").value = settings.channelChatId || "";
    $("rule-greatpct").value = settings.greatDealMinDropPct ?? 25;
    $("rule-channelmax").value = settings.channelMaxPerDay ?? 8;
    $("rule-gkey").value = settings.googlePlacesApiKey || "";
    $("rule-gcap").value = settings.googleDailyCap ?? 30;
    $("rule-gextras").checked = settings.googleFetchExtras !== false;
    $("rule-gsource").value = settings.googleSource === "api" ? "api" : "browser";
  }

  $("sub-body").addEventListener("change", async (ev) => {
    const tr = ev.target.closest("tr[data-sub]");
    const f = ev.target.dataset.f;
    if (!tr || !f) return;
    const v = ev.target.type === "checkbox" ? ev.target.checked : ev.target.value;
    await updateSubscriber(tr.dataset.sub, (s) => {
      if (f === "plan") s.plan = v;
      else if (f === "active") s.active = v;
      else if (f === "expiresAt") s.expiresAt = v ? new Date(v + "T23:59:59").toISOString() : null;
      else if (f === "destinations") s.destinations = String(v).split(",").map((x) => x.trim()).filter(Boolean);
      else if (f === "maxPrice") s.maxPrice = Number(v) > 0 ? Number(v) : null;
    });
    // Choosing a paid plan with no expiry: default to 30 days so it can't run free forever by accident.
    if (f === "plan" && v !== "free") {
      await updateSubscriber(tr.dataset.sub, (s) => {
        if (!s.expiresAt) s.expiresAt = new Date(Date.now() + 30 * 86400000).toISOString();
      });
    }
    renderBusiness();
  });

  $("sub-body").addEventListener("click", async (ev) => {
    const btn = ev.target.closest("[data-del]");
    if (!btn) return;
    const tr = btn.closest("tr[data-sub]");
    if (!confirm("Remove this subscriber? They stop getting alerts.")) return;
    await updateSubscriber(tr.dataset.sub, null);
    renderBusiness();
  });

  $("sub-add").addEventListener("click", async () => {
    const chat = $("sub-add-chat").value.trim();
    const name = $("sub-add-name").value.trim();
    if (!/^-?\d{5,}$/.test(chat)) { showToast("Enter their numeric Telegram chat ID", "error"); return; }
    const subs = await loadSubscribers();
    if (subs.some((s) => s.id === chat)) { showToast("Already a subscriber", "error"); return; }
    subs.push({ id: chat, telegramChatId: chat, name: name || chat, plan: "free", active: true, destinations: [], maxPrice: null, createdAt: new Date().toISOString(), source: "manual" });
    await chrome.storage.local.set({ subscribers: subs });
    $("sub-add-chat").value = "";
    $("sub-add-name").value = "";
    renderBusiness();
  });

  $("rules-save").addEventListener("click", async () => {
    const settings = await getSettings();
    const num = (id, fallback, min, max) => {
      const n = Number($(id).value);
      return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
    };
    settings.lastMinuteDays = Math.round(num("rule-lmdays", 3, 0, 7));
    settings.lastMinuteDropPct = num("rule-lmdrop", 10, 3, 60);
    settings.lastMinuteSweepEnabled = $("rule-sweep").checked;
    settings.scanTonight = $("rule-tonight").checked;
    settings.smartScan = $("rule-smart").checked;
    settings.subscriberBotEnabled = $("rule-bot").checked;
    settings.planPrices = { pro: num("rule-price-pro", 199, 0, 100000), vip: num("rule-price-vip", 499, 0, 100000) };
    settings.plansEnabled = $("rule-plans").checked;
    settings.alertRecordLow = $("rule-recordlow").checked;
    settings.alertGoodDeals = $("rule-gooddeals").checked;
    settings.goodDealBelowPct = num("rule-gooddealpct", 25, 10, 70);
    settings.alertMarketDeals = $("rule-marketdeals").checked;
    settings.marketDealBelowPct = num("rule-marketdealpct", 25, 10, 70);
    settings.deviceRole = $("rule-role").value === "helper" ? "helper" : "main";
    const rawName = $("rule-devname").value.trim();
    settings.deviceName = rawName ? safeDeviceName(rawName) : "";
    settings.scanDestinations = $("rule-scandests").value.split(",").map((x) => x.trim()).filter(Boolean);
    settings.helpersEnabled = $("rule-helpers").checked;
    settings.publishExtensionUpdates = $("rule-publish-ext").checked;
    if (settings.deviceRole === "helper" && !settings.deviceName) { showToast("Give this helper computer a name", "error"); return; }
    settings.confirmBeforeAlert = $("rule-confirm").checked;
    settings.passiveCollect = $("rule-passive").checked;
    settings.digestEnabled = $("rule-digest").checked;
    settings.digestHour = Math.round(num("rule-digesthour", 8, 5, 12));
    const holidayText = $("rule-holidays").value;
    settings.holidayText = holidayText.trim() === DEFAULT_HOLIDAY_TEXT.trim() ? null : holidayText;
    const ch = $("rule-channel").value.trim();
    settings.channelChatId = /^(@[A-Za-z][A-Za-z0-9_]{4,}|-?d{6,})$/.test(ch) ? ch : "";
    if (ch && !settings.channelChatId) showToast("Channel must look like @yourchannel or a -100... id", "error");
    settings.greatDealMinDropPct = num("rule-greatpct", 25, 10, 80);
    settings.channelMaxPerDay = Math.round(num("rule-channelmax", 8, 1, 50));
    settings.googlePlacesApiKey = $("rule-gkey").value.trim();
    settings.googleDailyCap = Math.round(num("rule-gcap", 30, 0, 500));
    settings.googleFetchExtras = $("rule-gextras").checked;
    settings.googleSource = $("rule-gsource").value === "api" ? "api" : "browser";
    const up = $("rule-upgrade").value.trim();
    settings.upgradeUrl = /^https:\/\//i.test(up) ? up : "";
    await saveSettings(settings);
    showToast("Saved");
    renderBusiness();
  });

  async function renderHelperStatus() {
    const { helperStatus = {} } = await chrome.storage.local.get("helperStatus");
    const settings = await getSettings();
    const when = (iso) => (iso ? `${formatDate(iso)} (${timeAgo(iso)})` : "never");
    let line;
    if (settings.deviceRole === "helper") {
      line = `Helper "${settings.deviceName || "?"}": last upload ${when(helperStatus.lastUploadAt)}${helperStatus.lastUploadRecords != null ? `, ${helperStatus.lastUploadRecords} records` : ""}. Last pulled state from the main computer ${when(helperStatus.lastPullAt)}.`;
    } else if (settings.helpersEnabled) {
      const devs = (helperStatus.devices || []).map((d) => `${d.device} (imported ${timeAgo(d.at)}, ${d.records} records)`).join(", ");
      line = `Last sync ${when(helperStatus.lastSyncAt)}. Helpers: ${devs || "none seen yet"}.`;
    } else {
      line = "No helper computer in use.";
    }
    if (!settings.githubToken || !settings.githubRepo) line += " Problem: this computer has no GitHub token or repo yet. Open the extension popup, go to Settings, paste both, and save.";
    if (helperStatus.error) line += ` Problem: ${helperStatus.error}`;
    $("helper-status").textContent = line;
    renderDevicePill(settings);
  }

  /** Header badge on every tab: Main or Helper, so you never have to hunt for which computer this is. */
  function renderDevicePill(settings) {
    const pill = $("device-pill");
    if (!pill) return;
    const helper = settings.deviceRole === "helper";
    const where = (settings.scanDestinations || []).length ? ` · scans ${(settings.scanDestinations || []).join(", ")}` : helper ? "" : " · scans everything";
    pill.textContent = helper ? `Helper: ${settings.deviceName || "unnamed"}${where}` : `Main computer${settings.helpersEnabled ? " (+ helpers)" : ""}${where}`;
    pill.classList.toggle("device-pill-helper", helper);
  }

  async function refreshDevicePill() {
    try { renderDevicePill(await getSettings()); } catch (e) { /* header badge is a convenience */ }
  }

  $("device-pill").addEventListener("click", () => {
    const tab = document.querySelector('.tab-btn[data-tab="business"]');
    if (tab) tab.click();
    const card = $("this-computer");
    if (card) card.scrollIntoView({ block: "start" });
  });

  /** Reload the extension itself (new code, re-read settings), then this page. */
  async function reloadExtension() {
    const { scanProgress, favoriteRefreshProgress } = await chrome.storage.local.get(["scanProgress", "favoriteRefreshProgress"]);
    const busy = (scanProgress && scanProgress.running) || (favoriteRefreshProgress && favoriteRefreshProgress.running);
    if (busy && !confirm("A scan is running. Reloading now stops it mid-way and loses the page being scraped. Reload anyway?")) return;
    showToast("Reloading the extension...");
    try { await chrome.runtime.sendMessage({ type: "RELOAD_EXTENSION" }); } catch (e) { /* worker may already be going down */ }
    setTimeout(() => location.reload(), 1500);
  }
  $("reload-ext").addEventListener("click", reloadExtension);
  $("helper-reload").addEventListener("click", reloadExtension);
  $("rules-save-device").addEventListener("click", () => $("rules-save").click());

  // Publishing this extension's files for other computers (v1.44.2).
  async function renderPublishStatus() {
    const { extPublishStatus: st } = await chrome.storage.local.get("extPublishStatus");
    const el = $("publish-ext-status");
    if (!st) { el.textContent = "Nothing checked yet. It runs about a minute after the extension loads, then every hour."; return; }
    const checked = st.checkedAt ? `Checked ${timeAgo(st.checkedAt)}. ` : "";
    if (st.state === "published") el.textContent = `${checked}Published version ${st.version} (${st.files} files, ${Math.round(st.bytes / 1024)} KB) ${timeAgo(st.publishedAt)}.`;
    else if (st.state === "current") el.textContent = `${checked}Version ${st.version} is already what the repo has.`;
    else if (st.state === "reload_pending") el.textContent = `${checked}The folder holds a newer version than the one running; it publishes after the reload.`;
    else if (st.state === "error") el.textContent = `${checked}Problem: ${st.error}`;
    else el.textContent = checked;
  }

  $("publish-ext-now").addEventListener("click", async () => {
    $("publish-ext-now").disabled = true;
    try {
      const r = await chrome.runtime.sendMessage({ type: "PUBLISH_EXTENSION_NOW" });
      if (r && r.status === "helper") showToast("A helper computer does not publish updates", "error");
      else if (r && r.status === "no_github") showToast("Add your GitHub token and repo in the popup Settings first", "error");
      else if (r && r.status === "error") showToast("Publish problem, see the line under the button", "error");
      else if (r && r.status === "reload_pending") showToast("A newer version is about to load, try again in a minute", "error");
      else showToast(`Published version ${r && r.version}`);
    } catch (e) {
      showToast("Could not reach the background process", "error");
    }
    $("publish-ext-now").disabled = false;
    renderPublishStatus();
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.extPublishStatus) renderPublishStatus();
  });

  // Tools tab: one block of text saying how this computer is doing (v2.0.0). Keys are shown as yes/no only and anything token-shaped is redacted.
  $("diag-copy").addEventListener("click", async () => {
    $("diag-copy").disabled = true;
    try {
      const settings = await getSettings();
      const state = await chrome.storage.local.get(["lastFullScanAt", "siteCooldown", "scanProgress", "dealEvents", "channelPostState", "helperStatus", "extPublishStatus", "extLatest", "errorLog", "activityLog", "lastMmtClear", "alertSuppressed", "ownerPingState", "ownerDigestQueue", "ownerDigestState"]);
      state.runningVersion = chrome.runtime.getManifest().version;
      const groups = await loadTrackedHotelGroups();
      const blocked = await getBlockedSet();
      const t = buildToday({ groups, blocked, settings, state, nowMs: Date.now() });
      const text = buildDiagnostics({ version: state.runningVersion, settings, state, hotels: groups.length, nowMs: Date.now(), health: t.health });
      $("diag-out").value = text;
      $("diag-out").hidden = false;
      try { await navigator.clipboard.writeText(text); showToast("Diagnostics copied. Paste them into your message."); }
      catch (e) { $("diag-out").select(); showToast("Press Ctrl+C to copy the selected text", "error"); }
    } catch (e) {
      showToast(`Could not build the diagnostics: ${e.message || e}`, "error");
    }
    $("diag-copy").disabled = false;
  });

  // Tools tab: wipe makemytrip.com's cache, cookies and site data (what you did by hand on a block).
  async function renderMmtClearStatus() {
    const settings = await getSettings();
    const { lastMmtClear } = await chrome.storage.local.get("lastMmtClear");
    $("mmt-clear-auto").checked = settings.mmtClearAllOnBlock !== false;
    $("mmt-clear-status").textContent = lastMmtClear ? `Last cleared ${formatDate(lastMmtClear.at)} (${timeAgo(lastMmtClear.at)}).` : "Not cleared yet.";
  }

  $("mmt-clear-now").addEventListener("click", async () => {
    const { scanProgress } = await chrome.storage.local.get("scanProgress");
    if (scanProgress && scanProgress.running && !confirm("A scan is running. Clearing now can break the page it has open. Clear anyway?")) return;
    $("mmt-clear-now").disabled = true;
    try {
      const r = await chrome.runtime.sendMessage({ type: "CLEAR_MMT_DATA" });
      if (r && r.ok) showToast("MakeMyTrip data cleared. Start a scan again.");
      else showToast(`Could not clear: ${(r && r.error) || "no answer from the background process"}`, "error");
    } catch (e) {
      showToast("Could not reach the background process", "error");
    }
    $("mmt-clear-now").disabled = false;
    renderMmtClearStatus();
  });

  $("mmt-clear-auto").addEventListener("change", async () => {
    const settings = await getSettings();
    settings.mmtClearAllOnBlock = $("mmt-clear-auto").checked;
    await saveSettings(settings);
    showToast(settings.mmtClearAllOnBlock ? "On a block, all MakeMyTrip data is cleared" : "On a block, only the cache is cleared");
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.lastMmtClear) renderMmtClearStatus();
  });
  renderMmtClearStatus();

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.settings) refreshDevicePill();
  });
  refreshDevicePill();

  // Setup code (v1.44.5): connect a computer, or back up logins, without retyping tokens.
  function syncSetupMode() {
    const helper = $("sc-mode").value === "helper";
    $("sc-name-row").hidden = !helper;
    $("sc-dests-row").hidden = !helper;
  }
  $("sc-mode").addEventListener("change", syncSetupMode);
  syncSetupMode();

  $("sc-create").addEventListener("click", async () => {
    const status = $("sc-status");
    try {
      const settings = await getSettings();
      const bundle = buildSetupBundle(settings, {
        mode: $("sc-mode").value,
        deviceName: $("sc-name").value,
        scanDestinations: $("sc-dests").value.split(","),
      });
      $("sc-out").value = await encryptSetupBundle(bundle, $("sc-pass").value);
      $("sc-out").hidden = false;
      $("sc-copy").hidden = false;
      status.textContent = bundle.mode === "helper"
        ? `Code ready for the new helper "${bundle.deviceName}". Copy it, then on that computer paste it under "2." with the same passphrase.`
        : "Code ready. It holds all your keys. Copy it and keep it somewhere safe (notes or a password manager), and remember the passphrase: neither can be recovered.";
    } catch (e) {
      showToast(String(e.message || e), "error");
    }
  });

  $("sc-copy").addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText($("sc-out").value);
      showToast("Code copied");
    } catch (e) {
      $("sc-out").select();
      showToast("Press Ctrl+C to copy the selected code", "error");
    }
  });

  $("sc-connect").addEventListener("click", async () => {
    const status = $("sc-status");
    $("sc-connect").disabled = true;
    try {
      const bundle = await decryptSetupBundle($("sc-in").value, $("sc-pass2").value);
      const becomesHelper = bundle.deviceRole === "helper";
      const what = becomesHelper
        ? `This computer will become the HELPER "${bundle.deviceName}", scanning ${(bundle.scanDestinations || []).join(", ") || "everything"}, using GitHub repo ${bundle.githubRepo}. Continue?`
        : `This will fill in this computer's GitHub details and all the keys in the code (${bundle.githubRepo}). Continue?`;
      if (!confirm(what)) { $("sc-connect").disabled = false; return; }
      const settings = await getSettings();
      await saveSettings(applySetupBundle(settings, bundle));
      $("sc-in").value = "";
      $("sc-pass2").value = "";
      status.textContent = becomesHelper ? "Connected as a helper. Getting the main computer's settings now..." : "Connected. Your keys are filled in; use Tools > Restore from GitHub if you also want your data back.";
      showToast("Connected");
      renderBusiness();
      if (becomesHelper) {
        const r = await chrome.runtime.sendMessage({ type: "HELPER_SYNC_NOW" }).catch(() => null);
        const pulled = r && r.pulled && r.pulled.status;
        status.textContent = pulled === "pulled" ? "Connected as a helper and the main computer's settings arrived. Start a scan from the popup (Scan on a destination)."
          : pulled === "no_shared_state" ? "Connected as a helper. The main computer has not shared its settings yet: on it, tick 'I use a helper computer', Save and Sync now."
          : "Connected as a helper. If the line under 'This computer' still says never after a minute, press Sync now.";
        renderHelperStatus();
      }
    } catch (e) {
      status.textContent = "";
      showToast(String(e.message || e), "error");
    }
    $("sc-connect").disabled = false;
  });

  $("helper-sync").addEventListener("click", async () => {
    $("helper-sync").disabled = true;
    try {
      const r = await chrome.runtime.sendMessage({ type: "HELPER_SYNC_NOW" });
      if (r && r.status === "disabled") showToast("Turn on 'I use a helper computer' and Save first", "error");
      else if (r && (r.status === "no_github" || (r.uploaded && r.uploaded.status === "no_github") || (r.pulled && r.pulled.status === "skipped"))) showToast("Add your GitHub token and repo in the extension popup, Settings, first", "error");
      else if (r && r.pulled && r.pulled.status === "no_shared_state") showToast("The main computer has not shared its state yet: on the main PC tick 'I use a helper computer', Save, then Sync now", "error");
      else if (r && r.status === "no_github") showToast("Add your GitHub token and repo in the popup Settings first", "error");
      else if (r && (r.status === "error" || (r.uploaded && r.uploaded.status === "error") || (r.pulled && r.pulled.status === "error"))) showToast("Sync problem, see the line under the button", "error");
      else showToast("Synced");
    } catch (e) {
      showToast("Could not reach the background process", "error");
    }
    $("helper-sync").disabled = false;
    renderHelperStatus();
  });

  $("channel-test").addEventListener("click", async () => {
    const settings = await getSettings();
    if (!settings.telegramBotToken) { showToast("Add your Telegram bot token in the popup first", "error"); return; }
    if (!settings.channelChatId) { showToast("Save a channel first", "error"); return; }
    const resp = await fetch(`https://api.telegram.org/bot${settings.telegramBotToken}/sendMessage`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: settings.channelChatId, text: "✅ Test post: the deal bot can post here. Real deals will look like this one, only great deals get posted." }),
    }).catch(() => null);
    if (resp && resp.ok) showToast("Test post sent, check your channel");
    else showToast(resp && resp.status === 400 ? "Telegram says no such channel: check the @name" : resp && resp.status === 403 ? "Bot is not an admin of that channel yet" : "Could not reach Telegram", "error");
  });

  // ---------------------------------------------------------------- wiring

  async function refreshFeedTab() {
    await loadFeed();
    const ledger = await ledgerStats();
    populateFeedFilters();
    renderFeedKpis(ledger);
    renderSafety(ledger);
    renderFeedList();
  }

  ["feed-filter-type", "feed-filter-destination", "feed-filter-range"].forEach((id) => $(id).addEventListener("change", renderFeedList));
  $("feed-list").addEventListener("click", (ev) => {
    const b = ev.target.closest("[data-history]");
    if (b) openHistory(b.dataset.history);
  });
  $("history-modal-close").addEventListener("click", () => $("history-modal-overlay").classList.add("hidden"));
  $("history-modal-overlay").addEventListener("click", (e) => {
    if (e.target.id === "history-modal-overlay") e.target.classList.add("hidden");
  });

  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      if (btn.dataset.tab === "feed") refreshFeedTab();
      if (btn.dataset.tab === "business") renderBusiness();
    });
  });

  // Live: new events show up without a reload while the tab is open.
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.dealEvents && !$("feed-panel").classList.contains("hidden")) refreshFeedTab();
    if (changes.dealEvents) updateHeaderBadge();
  });

  async function updateHeaderBadge() {
    const events = await loadDealEvents();
    const fresh = events.filter((e) => Date.now() - new Date(e.at).getTime() < 86400000).length;
    const btn = document.querySelector('.tab-btn[data-tab="feed"]');
    if (btn) btn.textContent = fresh ? `Deal Feed (${fresh})` : "Deal Feed";
  }

  // Shared with swipe.js (the swipe cards draw the same history chart).
  window.HotelCharts = { historyChart };

  updateHeaderBadge();
})();
