/**
 * Google Maps page reader (content script, only acts on pages opened with
 * ?dtjob=1 by this extension: the Swipe card's lookup window, or a manual
 * scan). It finds the right place in the search results (by NAME, since the
 * first result is often a different hotel), reads rating, review count,
 * photos, Google's review summary and a few review snippets, and sends them
 * to the background script. Free: it reads the page in your own Chrome, no
 * API key. Google's terms forbid automated access, so this is meant for
 * low-volume personal use (a few lookups at a time, paced), not bulk.
 *
 * Verified against the real Google Maps page structure (Oct 2026):
 *   place panel   [role="main"][aria-label="<hotel name>"] with tab buttons
 *   rating        [role="img"][aria-label="4.8 stars "], "879 reviews"
 *   photos        [role="region"][aria-label^="Photos of"] img (lh3.googleusercontent.com)
 *   reviews       button[role="tab"][aria-label^="Reviews"] then top-level [data-review-id]
 * Google changes class names often, which is why none are used here.
 */
(function () {
  const params = new URLSearchParams(location.search);
  const job = params.get("dtjob")
    ? { key: params.get("dtkey") || "", name: params.get("dtname") || "", dest: params.get("dtdest") || "" }
    : null;
  if (!job && !globalThis.__DT_TEST) return;

  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  async function until(fn, timeoutMs, stepMs = 300) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
      const v = fn();
      if (v) return v;
      await wait(stepMs);
    }
    return null;
  }

  const panelFor = () => {
    const main = document.querySelector('[role="main"][aria-label]');
    return main && main.querySelector('button[role="tab"]') ? main : null;
  };

  /** Bigger version of a Google photo URL (they end in =w408-h306-k-no style size codes). */
  function bigPhoto(src) {
    return src.replace(/=[wsh]\d[^/?]*$/, "=w640-h420-k-no");
  }

  function readPhotos(main) {
    const seen = new Set();
    const out = [];
    const imgs = main.querySelectorAll('[role="region"][aria-label^="Photos of"] img, button[aria-label^="Photo of"] img');
    for (const img of imgs) {
      const src = img.currentSrc || img.src || "";
      if (!/^https:\/\/lh\d\.(googleusercontent|ggpht)\.com\//.test(src)) continue;
      if (/googleusercontent\.com\/(a|a-)\//.test(src)) continue; // a reviewer's profile picture, not the hotel
      const base = src.replace(/=[wsh]\d[^/?]*$/, "");
      if (seen.has(base)) continue;
      seen.add(base);
      out.push(bigPhoto(src));
      if (out.length >= 5) break;
    }
    return out;
  }

  function readRating(main) {
    let rating = null, reviews = null;
    for (const el of main.querySelectorAll('[role="img"][aria-label]')) {
      const l = el.getAttribute("aria-label") || "";
      let m = /^([\d.]+)\s+stars?\s*$/i.exec(l);
      if (m && rating === null) rating = parseFloat(m[1]);
      m = /^([\d,]+)\s+reviews?$/i.exec(l);
      if (m && reviews === null) reviews = parseInt(m[1].replace(/,/g, ""), 10);
    }
    if (reviews === null) {
      const m = /([\d,]+)\s+reviews?\b/i.exec(main.innerText || "");
      if (m) reviews = parseInt(m[1].replace(/,/g, ""), 10);
    }
    return { rating, reviews };
  }

  /** Google's own AI summary of the reviews, the best one-paragraph answer to "is it any good". */
  function readSummary(main) {
    const marker = [...main.querySelectorAll("*")].find((e) => e.children.length === 0 && /Summarized with Gemini/i.test(e.textContent));
    if (!marker) return "";
    let node = marker;
    for (let i = 0; i < 4 && node; i++, node = node.parentElement) {
      const line = (node.innerText || "").split("\n").map((s) => s.trim()).find((s) => s.length > 60);
      if (line) return line.slice(0, 600);
    }
    return "";
  }

  function readReviews(main, limit = 3) {
    const blocks = [...document.querySelectorAll("[data-review-id]")].filter((e) => !e.parentElement.closest("[data-review-id]"));
    const out = [];
    for (const b of blocks) {
      const spans = [...b.querySelectorAll("span")].filter((s) => s.querySelector("span") === null).map((s) => s.textContent.trim());
      const text = spans.filter((t) => t.length >= 40 && !/^\d+ (photo|review)/i.test(t)).sort((a, c) => c.length - a.length)[0];
      const wm = /\b(?:a|an|\d+)\s+(?:day|week|month|year)s?\s+ago\b/i.exec(b.innerText || "");
      const when = wm ? wm[0] : "";
      if (!text || out.some((r) => r.text === text.slice(0, 280))) continue;
      out.push({ text: text.replace(/\s+/g, " ").slice(0, 280), when });
      if (out.length >= limit) break;
    }
    return out;
  }

  async function openReviews(main) {
    const tab = main.querySelector('button[role="tab"][aria-label^="Reviews"]');
    if (!tab) return;
    tab.click();
    await until(() => main.querySelector("[data-review-id]") || /Google review summary/i.test(main.innerText), 8000);
    const scroller = [...main.querySelectorAll("div")].filter((d) => d.scrollHeight > d.clientHeight + 100 && getComputedStyle(d).overflowY !== "visible").sort((a, c) => c.scrollHeight - a.scrollHeight)[0];
    if (scroller) {
      for (let i = 0; i < 2; i++) {
        scroller.scrollTop = scroller.scrollHeight;
        await wait(900);
      }
    }
  }

  async function run() {
    let main = await until(panelFor, 5000);
    if (!main) {
      const links = await until(() => {
        const a = [...document.querySelectorAll('a[href*="/maps/place/"][aria-label]')];
        return a.length ? a : null;
      }, 12000);
      if (!links) return { notFound: true, reason: "no results" };
      const hit = links.find((a) => googleNameMatch(job.name, job.dest, a.getAttribute("aria-label")));
      if (!hit) return { notFound: true, reason: "no result matched the name", tried: links.slice(0, 3).map((a) => a.getAttribute("aria-label")) };
      hit.click();
      main = await until(panelFor, 12000);
      if (!main) return { notFound: true, reason: "place panel did not open" };
    } else if (!googleNameMatch(job.name, job.dest, main.getAttribute("aria-label") || "")) {
      return { notFound: true, reason: "opened place has a different name", tried: [main.getAttribute("aria-label")] };
    }
    const name = main.getAttribute("aria-label");
    await wait(1200); // let the photo strip and rating settle
    const { rating, reviews } = readRating(main);
    const photos = readPhotos(main);
    await openReviews(main);
    return {
      name, rating, reviews,
      photos,
      summary: readSummary(main),
      reviewList: readReviews(main),
      url: location.href.split("?")[0],
    };
  }

  globalThis.__dtGmapsRun = run;
  if (!job) return;

  // A marker on the page itself (the tab title gets rewritten by Maps), so a
  // manual scan can tell whether the reader ran and how it ended.
  const mark = (state) => document.documentElement.setAttribute("data-dt-gmaps", state);
  mark("started");

  run()
    .catch((e) => ({ notFound: true, reason: "reader error: " + String(e).slice(0, 120) }))
    .then((data) => {
      mark(data.notFound ? "none:" + (data.reason || "") : "ok:" + (data.name || ""));
      try {
        chrome.runtime.sendMessage({ type: "GMAPS_RESULT", groupKey: job.key, hotelName: job.name, destination: job.dest, data });
        document.documentElement.setAttribute("data-dt-sent", "1");
      } catch (e) {
        mark("senderror:" + String(e).slice(0, 60)); // extension reloaded while reading, the lookup is simply lost
      }
    });
})();
