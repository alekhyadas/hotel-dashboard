/**
 * Insights tab: the "what should I do?" views built from the ledger.
 *   - Cheapest-weekend calendar per destination (heatmap vs that place's normal)
 *   - Book now or wait, per destination, from how prices behave near check-in
 *   - Best value stays for the coming weekend
 *   - Hotels nobody has filmed yet (from the YouTube checks already done)
 *   - Desperate hotels (3 price drops in a row)
 * Plain script loaded after dashboard.js; uses its allGroups and the pure
 * functions in intel.js.
 */
(function () {
  const $ = (id) => document.getElementById(id);

  function idxClass(i) { return i < 0.9 ? "idx-low" : i > 1.1 ? "idx-high" : "idx-ok"; }
  function fmtDay(iso) { return new Date(iso + "T00:00:00").toLocaleDateString("en-IN", { day: "numeric", month: "short" }); }

  function renderCalendar(groups) {
    const idx = weekendIndex(groups, toISODate(new Date()));
    const dests = Object.keys(idx).sort();
    if (dests.length === 0) {
      $("ins-calendar").innerHTML = `<p class="hint">Needs 3 or more tracked hotels in a destination on the same dates. It fills in as scans collect data.</p>`;
      return;
    }
    $("ins-calendar").innerHTML = dests.map((d) => `
      <div class="cal-row">
        <div class="cal-dest">${escapeHtml(d)}</div>
        <div class="cal-cells">${idx[d].map((c) => `<div class="cal-cell ${idxClass(c.index)}" title="${escapeAttr(fmtDay(c.date) + ": typical " + formatINR(c.median) + " (" + Math.round((c.index - 1) * 100) + "% vs this place's normal)")}"><b>${escapeHtml(fmtDay(c.date))}</b><span>${escapeHtml(formatINR(c.median))}</span></div>`).join("")}</div>
      </div>`).join("");
  }

  async function renderWaitOrBook(groups) {
    const all = await chrome.storage.local.get(null);
    const byDest = {};
    for (const [k, v] of Object.entries(all)) {
      if (k.startsWith("hist:") && v && Array.isArray(v.prices)) (byDest[v.destination] = byDest[v.destination] || []).push(v);
    }
    const rows = Object.keys(byDest).sort().map((d) => {
      const curve = leadCurve(byDest[d]);
      const a = bookAdvice(curve);
      const cls = a.advice === "wait" ? "adv-wait" : a.advice === "book" ? "adv-book" : "adv-none";
      const label = a.advice === "wait" ? "Wait" : a.advice === "book" ? "Book early" : a.advice === "either" ? "Either" : "Learning";
      const near = curve["0-3"].ratio, far = curve["8-14"].ratio;
      return `<div class="adv-row"><div class="cal-dest">${escapeHtml(d)}</div><span class="adv-pill ${cls}">${label}</span><div class="adv-text">${escapeHtml(a.text)}${a.advice !== "not_enough_data" && near != null && far != null ? ` <span class="hint">(last 3 days ${Math.round((near - 1) * 100)}% vs its median, 8 to 14 days out ${Math.round((far - 1) * 100)}%)</span>` : ""}</div></div>`;
    });
    $("ins-wait").innerHTML = rows.length ? rows.join("") : `<p class="hint">No history yet.</p>`;
  }

  function renderValue(groups, blocked, settings) {
    const weekend = upcomingWeekends(settings.nights, settings.checkinWeekday, 14)[0];
    const rows = groups.filter((g) => !blocked.has(g.groupKey)).map((g) => {
      const d = g.dates.find((x) => weekend && x.checkin === weekend.checkin && !x.isLikelyBadScrape && x.verified !== false && x.current >= 800) || (!weekend ? g.cheapest : null);
      return d ? { g, d, v: valueScore({ ...g, cheapestPrice: d.current }) } : null;
    }).filter(Boolean).sort((a, b) => b.v - a.v).slice(0, 8);
    $("ins-value").innerHTML = rows.length
      ? rows.map((r, i) => `<div class="val-row"><span class="val-rank">${i + 1}</span><div><b>${escapeHtml(r.g.hotelName)}</b><div class="hint">${escapeHtml(r.g.destination)}${r.g.rating != null ? ` • rated ${r.g.rating}` : ""}${(r.g.amenities || []).length ? ` • ${escapeHtml(r.g.amenities.slice(0, 3).join(", "))}` : ""}</div></div><div class="val-price">${formatINR(r.d.current)}</div></div>`).join("")
      : `<p class="hint">No tracked hotels have prices for the coming weekend (${weekend ? weekend.checkin : "?"}) yet.</p>`;
  }

  function renderFilm(groups, blocked) {
    const gap = filmGapList(groups.filter((g) => !blocked.has(g.groupKey)));
    const unchecked = groups.filter((g) => !g.youtubeCheckedAt && !blocked.has(g.groupKey)).length;
    $("ins-film").innerHTML = (gap.length
      ? gap.map((g) => `<div class="val-row"><span class="val-rank">\u{1F3AC}</span><div><b>${escapeHtml(g.hotelName)}</b><div class="hint">${escapeHtml(g.destination)}${g.rating != null ? ` • rated ${g.rating}` : ""}${g.isNewlyBuilt ? " • newly built" : ""} • ${g.youtubeVideoCount ?? 0} video(s) found</div></div><div class="val-price">${formatINR(g.cheapestPrice)}</div></div>`).join("")
      : `<p class="hint">No hotel is both well rated (or new) and uncovered on YouTube yet.</p>`)
      + (unchecked ? `<p class="hint">${unchecked} tracked hotels have not had a YouTube check yet, so they cannot be listed here. Run "Check YouTube popularity" on the Videos tab.</p>` : "");
  }

  async function renderDesperate() {
    const all = await chrome.storage.local.get(null);
    const today = toISODate(new Date());
    const blocked = new Set((all.blockedHotels || []).map((b) => `${b.source}:::${b.hotelName}:::${b.destination}`));
    const rows = Object.entries(all).filter(([k, v]) => k.startsWith("hist:") && v && v.desperate && v.checkin >= today && !blocked.has(`${v.source}:::${v.hotelName}:::${v.destination}`))
      .map(([k, v]) => v).sort((a, b) => a.checkin.localeCompare(b.checkin)).slice(0, 10);
    $("ins-desperate").innerHTML = rows.length
      ? rows.map((v) => { const last = v.prices[v.prices.length - 1].price; const first = v.prices[Math.max(0, v.prices.length - 4)].price; return `<div class="val-row"><span class="val-rank">\u{1F4C9}</span><div><b>${escapeHtml(v.hotelName)}</b><div class="hint">${escapeHtml(v.destination)} • ${escapeHtml(v.checkin)} • falling ${formatINR(first)} to ${formatINR(last)}</div></div><div class="val-price">${formatINR(last)}</div></div>`; }).join("")
      : `<p class="hint">None right now. A hotel shows up here after its price falls on 3 separate days in a row.</p>`;
  }

  async function renderInsights() {
    if (typeof allGroups === "undefined" || allGroups.length === 0) await refresh();
    const blocked = await getBlockedSet();
    renderCalendar(allGroups.filter((g) => !blocked.has(g.groupKey)));
    renderWaitOrBook(allGroups);
    renderValue(allGroups, blocked, await getSettings());
    renderFilm(allGroups, blocked);
    renderDesperate();
  }

  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", () => { if (btn.dataset.tab === "insights") renderInsights(); });
  });
})();
