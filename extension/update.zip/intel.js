/**
 * Deal intelligence: the price ledger, last-minute drop detection, smart
 * scan ordering, the deal-event model and the subscriber/plan engine
 * (the pieces a paid alert service would be built on).
 *
 * Everything in the first half is PURE (no chrome.*), so it's unit-tested
 * in tests/test_intel.js the same way evaluateTargetAlert() is. The small
 * storage helpers at the bottom are the only chrome.storage users.
 *
 * Loaded after shared.js (needs toISODate/formatINR) by background.js
 * (importScripts) and the dashboard page (<script>).
 */

// ---------------------------------------------------------------------------
// Price ledger
// ---------------------------------------------------------------------------

// Every scan of a (hotel, dates) record appends one point. This used to be
// capped at 30, which threw away history after a few weeks. 365 keeps a
// year of twice-daily checks, and each point is ~40 bytes (unlimitedStorage
// is on), so it's cheap. `lead` = calendar days between the scan and the
// check-in date: it's what makes "this is a last-minute price" answerable
// from history alone, long after the fact.
const LEDGER_MAX_POINTS = 365;

/** Whole calendar days from isoA to isoB (YYYY-MM-DD), DST-proof. */
function daysBetweenISO(isoA, isoB) {
  const [ya, ma, da] = isoA.split("-").map(Number);
  const [yb, mb, db] = isoB.split("-").map(Number);
  return Math.round((Date.UTC(yb, mb - 1, db) - Date.UTC(ya, ma - 1, da)) / 86400000);
}

/** Days from the (local) calendar day of `atIso` until `checkin`. 0 = same day. */
function leadDays(checkin, atIso) {
  return daysBetweenISO(toISODate(new Date(atIso)), checkin);
}

/**
 * dv: 1 marks a point whose check-in date was VERIFIED (read from the page's
 * own URL). Before v1.43 MakeMyTrip was being asked for dates in a format it
 * ignores, so most older points are tonight's price filed under another date;
 * they carry no dv and are kept only as history, never used for comparisons.
 */
function appendLedgerPoint(prices, price, atIso, checkin) {
  const out = (prices || []).slice(-(LEDGER_MAX_POINTS - 1));
  out.push({ price, at: atIso, lead: leadDays(checkin, atIso), dv: 1 });
  return out;
}

/** Only the points whose date was verified. Everything that compares prices uses these. */
function verifiedPoints(prices) {
  return (prices || []).filter((p) => p && p.dv === 1);
}

/**
 * Union of two price histories (by timestamp), oldest first. Used when a
 * backup is restored over data that has newer scans: neither side's points
 * are lost.
 */
function mergePriceHistories(a, b) {
  const byAt = new Map();
  for (const p of [...(a || []), ...(b || [])]) {
    if (p && typeof p.price === "number" && p.at) byAt.set(p.at, p);
  }
  return [...byAt.values()].sort((x, y) => new Date(x.at) - new Date(y.at)).slice(-LEDGER_MAX_POINTS);
}

/** Merge a restored hist: record into an existing local one without losing newer scans. */
function mergeHistRecords(local, restored) {
  if (!local) return restored;
  if (!restored) return local;
  const newer = (local.updatedAt || "") >= (restored.updatedAt || "") ? local : restored;
  const older = newer === local ? restored : local;
  const prices = mergePriceHistories(local.prices, restored.prices);
  const real = prices.filter((p) => p.price >= 300).map((p) => p.price);
  const lowest = real.length ? Math.min(...real) : newer.lowest;
  const lowestPoint = prices.find((p) => p.price === lowest);
  return { ...older, ...newer, prices, lowest, lowestAt: lowestPoint ? lowestPoint.at : newer.lowestAt };
}

/** Backup-size control: drop interior points of a run of identical prices, keeping the first and last. */
function compactPriceHistory(prices) {
  if (!prices || prices.length < 3) return prices || [];
  const out = [];
  for (let i = 0; i < prices.length; i++) {
    const prev = prices[i - 1], next = prices[i + 1];
    const interiorOfRun = prev && next && prev.price === prices[i].price && next.price === prices[i].price;
    if (!interiorOfRun) out.push(prices[i]);
  }
  return out;
}

// ---------------------------------------------------------------------------
// Last-minute drop detection
// ---------------------------------------------------------------------------

const LAST_MINUTE_DEFAULTS = {
  lastMinuteDays: 3,       // lead 0 (tonight) .. N days ahead counts as last-minute
  lastMinuteDropPct: 10,   // drop vs the reference price needed to fire
};

/**
 * Is `newPrice` a meaningful DROP, for a stay that starts within a few days?
 *
 * The reference is what this same stay cost on an EARLIER calendar day (the
 * case of "tracked it on the 20th, it's cheaper now it's nearly the day"),
 * or earlier today (a flash drop, e.g. just after midnight). Prices from
 * the same scan batch are never compared to themselves.
 *
 * Returns null when it isn't a last-minute drop, else
 * {leadDays, refPrice, refAt, dropPct, saving, refKind, weekHigh}.
 */
function detectLastMinuteDrop(prices, newPrice, checkin, nowIso, opts = {}) {
  const days = opts.lastMinuteDays ?? LAST_MINUTE_DEFAULTS.lastMinuteDays;
  const minPct = opts.lastMinuteDropPct ?? LAST_MINUTE_DEFAULTS.lastMinuteDropPct;
  if (typeof newPrice !== "number" || newPrice < 300) return null;
  const lead = leadDays(checkin, nowIso);
  if (lead < 0 || lead > days) return null;

  const today = toISODate(new Date(nowIso));
  const real = (prices || []).filter((p) => typeof p.price === "number" && p.price >= 300 && p.at);
  const earlierDay = real.filter((p) => toISODate(new Date(p.at)) < today);
  const earlierToday = real.filter((p) => toISODate(new Date(p.at)) === today);

  const candidates = [];
  if (earlierDay.length) {
    const p = earlierDay[earlierDay.length - 1];
    candidates.push({ ref: p.price, at: p.at, kind: "earlier_day" });
  }
  if (earlierToday.length) {
    const p = earlierToday[earlierToday.length - 1];
    candidates.push({ ref: p.price, at: p.at, kind: "same_day" });
  }
  let best = null;
  for (const c of candidates) {
    if (c.ref <= newPrice) continue;
    const pct = ((c.ref - newPrice) / c.ref) * 100;
    if (!best || pct > best.pct) best = { ...c, pct };
  }
  if (!best || best.pct < minPct) return null;

  const weekAgo = new Date(nowIso).getTime() - 7 * 86400000;
  const weekPrices = real.filter((p) => new Date(p.at).getTime() >= weekAgo).map((p) => p.price);
  return {
    leadDays: lead,
    refPrice: best.ref,
    refAt: best.at,
    refKind: best.kind,
    dropPct: Math.round(best.pct),
    saving: best.ref - newPrice,
    weekHigh: weekPrices.length ? Math.max(...weekPrices) : best.ref,
  };
}

/**
 * Fire-once-per-day (and again only if it falls a further 5%) decision for
 * last-minute alerts, so a stay that stays cheap all day doesn't ping on
 * every scan. `state` is the record's stored {price, day} or undefined.
 */
function shouldFireLastMinute(detection, newPrice, nowIso, state) {
  if (!detection) return { fire: false, newState: state };
  const day = toISODate(new Date(nowIso));
  const fire = !state || state.day !== day || newPrice <= state.price * 0.95;
  return { fire, newState: fire ? { price: newPrice, day } : state };
}

function leadLabel(lead) {
  if (lead <= 0) return "TONIGHT";
  if (lead === 1) return "tomorrow";
  return `in ${lead} days`;
}

// ---------------------------------------------------------------------------
// Deal events (the single record every alert channel + the feed is built from)
// ---------------------------------------------------------------------------

const DEAL_EVENT_TYPES = {
  record_low:  { label: "Lowest price ever", emoji: "\u{1F3C6}", rank: 7 },
  good_deal:   { label: "Well below its usual price", emoji: "\u{1F4B0}", rank: 3 },
  error_fare:  { label: "Possible error fare", emoji: "🚨", rank: 6 },
  last_minute: { label: "Last-minute", emoji: "\u{1F525}", rank: 5 },
  rare:        { label: "Rare deal",   emoji: "\u{1F48E}", rank: 4 },
  drop:        { label: "Price drop",  emoji: "\u{1F4C9}", rank: 3 },
  discount:    { label: "Big discount",emoji: "\u{1F3F7}️", rank: 2 },
  new:         { label: "Newly built", emoji: "\u{1F195}", rank: 1 },
};

const MAX_DEAL_EVENTS = 500;

function makeDealEvent(type, listing, reasons, extra = {}, nowIso = new Date().toISOString()) {
  const price = listing.discountedPrice;
  return {
    id: [type, listing.source, listing.hotelName, listing.destination, listing.checkin, price, nowIso.slice(0, 13)].join("|"),
    at: nowIso,
    type,
    hotelName: listing.hotelName,
    destination: listing.destination,
    source: listing.source,
    starRating: listing.starRating ?? null,
    checkin: listing.checkin,
    checkout: listing.checkout,
    price,
    refPrice: extra.refPrice ?? listing.originalPrice ?? null,
    dropPct: extra.dropPct ?? listing.discountPct ?? null,
    leadDays: extra.leadDays ?? leadDays(listing.checkin, nowIso),
    isNewlyBuilt: !!listing.isNewlyBuilt,
    rating: listing.rating ?? null,
    reviewCount: listing.reviewCount ?? null,
    fairPrice: extra.fairPrice ?? null,
    holiday: extra.holiday ?? null,
    url: listing.url || null,
    reasons: reasons || [],
  };
}

/** Newest first, de-duplicated by id, capped. Returns a new array. */
function addDealEvent(events, event) {
  const rest = (events || []).filter((e) => e.id !== event.id);
  return [event, ...rest].slice(0, MAX_DEAL_EVENTS);
}

function formatDealMessage(event, opts = {}) {
  const t = DEAL_EVENT_TYPES[event.type] || DEAL_EVENT_TYPES.drop;
  const lines = [];
  const headline = event.type === "last_minute"
    ? `${t.emoji} LAST-MINUTE DEAL, check-in ${leadLabel(event.leadDays)}`
    : `${t.emoji} ${t.label.toUpperCase()}`;
  lines.push(opts.delayed ? `${headline} (delayed alert, Pro members get these instantly)` : headline);
  lines.push(`\u{1F3E8} ${event.hotelName} (${event.starRating || "?"}★)`);
  lines.push(`\u{1F4CD} ${event.destination} • ${event.source}`);
  if (event.rating != null) lines.push(`⭐ ${event.rating}${event.reviewCount ? ` (${event.reviewCount} reviews)` : ""}`);
  lines.push(`\u{1F4C5} ${event.checkin} to ${event.checkout}`);
  lines.push(event.refPrice && event.refPrice > event.price
    ? `\u{1F4B0} ${formatINR(event.refPrice)} -> ${formatINR(event.price)}${event.dropPct ? ` (-${event.dropPct}%)` : ""}`
    : `\u{1F4B0} ${formatINR(event.price)}`);
  for (const r of event.reasons || []) lines.push(`✅ ${r}`);
  if (event.url) lines.push(event.url);
  return lines.join("\n");
}

function formatTeaserMessage(event, upgradeUrl) {
  const t = DEAL_EVENT_TYPES[event.type] || DEAL_EVENT_TYPES.drop;
  return [
    `\u{1F512} A ${t.label.toLowerCase()} just dropped in ${event.destination}${event.dropPct ? ` (-${event.dropPct}%)` : ""}.`,
    `Pro members saw it instantly with the hotel, dates and link.`,
    upgradeUrl ? `Upgrade: ${upgradeUrl}` : `Send /plan to see how to upgrade.`,
  ].join("\n");
}

// ---------------------------------------------------------------------------
// Plans + subscribers (the paid-alerts engine)
// ---------------------------------------------------------------------------

const ALL_EVENT_TYPES = Object.keys(DEAL_EVENT_TYPES);

// price = monthly INR, editable in the dashboard (settings.planPrices).
const PLANS = {
  free: { label: "Free", price: 0,   delayMinutes: 720, dailyCap: 2,  types: ["drop", "rare", "new", "record_low"], teasers: 1 },
  pro:  { label: "Pro",  price: 199, delayMinutes: 0,   dailyCap: 20, types: ["drop", "rare", "new", "discount", "last_minute", "error_fare", "record_low", "good_deal"], teasers: 0 },
  vip:  { label: "VIP",  price: 499, delayMinutes: 0,   dailyCap: 60, types: ALL_EVENT_TYPES, teasers: 0 },
};

function effectivePlanKey(sub, nowMs) {
  const key = PLANS[sub.plan] ? sub.plan : "free";
  if (key !== "free" && sub.expiresAt && new Date(sub.expiresAt).getTime() < nowMs) return "free";
  return key;
}

/**
 * What should happen to `event` for `sub` right now?
 * -> {action: "send"|"teaser"|"skip", sendAfterMs, reason, planKey, newSent}
 * Pure: the caller persists newSent onto the subscriber.
 */
function planDecision(sub, event, nowMs, opts = {}) {
  // plansEnabled === false (the default while the product is free): every
  // subscriber gets the VIP experience, nothing is delayed or gated.
  // Paying tiers are a switch away, not a rebuild.
  const planKey = opts.plansEnabled === false ? "vip" : effectivePlanKey(sub, nowMs);
  const plan = PLANS[planKey];
  const day = toISODate(new Date(nowMs));
  const sent = sub.sent && sub.sent.day === day ? { ...sub.sent } : { day, count: 0, teasers: 0 };
  const skip = (reason) => ({ action: "skip", reason, planKey, newSent: sent });

  if (!sub.active || !sub.telegramChatId) return skip("inactive");
  const dests = (sub.destinations || []).map((d) => d.toLowerCase());
  if (dests.length && !dests.includes(String(event.destination).toLowerCase())) return skip("destination_filter");
  if (sub.maxPrice && event.price > sub.maxPrice) return skip("over_budget");
  if (sub.minDropPct && event.dropPct != null && event.dropPct < sub.minDropPct && event.type !== "new") return skip("below_min_drop");

  if (!plan.types.includes(event.type)) {
    if (sent.teasers < (plan.teasers || 0)) {
      return { action: "teaser", reason: "plan_gate", planKey, newSent: { ...sent, teasers: sent.teasers + 1 } };
    }
    return skip("plan_gate");
  }
  if (sent.count >= plan.dailyCap) return skip("daily_cap");
  return {
    action: "send",
    sendAfterMs: nowMs + plan.delayMinutes * 60000,
    delayed: plan.delayMinutes > 0,
    reason: "ok",
    planKey,
    newSent: { ...sent, count: sent.count + 1 },
  };
}

/** Subscriber-count/revenue summary for the Business tab. Counts before revenue. */
function summarizeSubscribers(subs, nowMs, planPrices = {}) {
  const out = { total: subs.length, active: 0, free: 0, pro: 0, vip: 0, expiringSoon: 0, mrr: 0 };
  for (const s of subs) {
    if (!s.active) continue;
    out.active++;
    const key = effectivePlanKey(s, nowMs);
    out[key]++;
    if (key !== "free") {
      out.mrr += planPrices[key] ?? PLANS[key].price;
      if (s.expiresAt) {
        const left = new Date(s.expiresAt).getTime() - nowMs;
        if (left >= 0 && left < 7 * 86400000) out.expiringSoon++;
      }
    }
  }
  return out;
}

// ---------------------------------------------------------------------------
// Smart scan ordering
// ---------------------------------------------------------------------------

function stepKey(step) {
  return `${step.site}|${step.destinationName}|${step.checkin}`;
}

/** How long a step's data counts as fresh: the nearer the stay, the faster prices move. */
function minRescanHours(lead) {
  if (lead <= 3) return 3;
  if (lead <= 14) return 12;
  return 24;
}

/**
 * Higher = scan sooner. Urgency (how close the stay is) dominates, then
 * destinations that have been moving recently, favorites' destinations,
 * and how long since this exact step was last checked.
 * ctx = {nowMs, freshness: {stepKey: ms}, volatility: {dest: 0..1},
 *        hotDestinations: Set, favoriteDestinations: Set}
 */
function scoreScanStep(step, ctx) {
  const lead = daysBetweenISO(toISODate(new Date(ctx.nowMs)), step.checkin);
  let s;
  if (lead <= 0) s = 100;
  else if (lead <= 3) s = 85 - lead * 5;
  else if (lead <= 7) s = 55;
  else if (lead <= 14) s = 35;
  else s = Math.max(5, 25 - lead / 4);

  s += (ctx.volatility[step.destinationName] || 0) * 25;
  if (ctx.hotDestinations && ctx.hotDestinations.has(step.destinationName)) s += 15;
  if (ctx.favoriteDestinations && ctx.favoriteDestinations.has(step.destinationName)) s += 10;

  const last = ctx.freshness[stepKey(step)];
  s += last ? Math.min((ctx.nowMs - last) / 3600000, 72) / 72 * 30 : 35;
  return s;
}

/**
 * Sorts by score and (when skipFresh) drops steps checked more recently
 * than minRescanHours(lead). Stable for equal scores. Pure.
 */
function prioritizeSteps(steps, ctx, opts = {}) {
  const today = toISODate(new Date(ctx.nowMs));
  let list = steps.map((step, i) => ({ step, i, score: scoreScanStep(step, ctx) }));
  if (opts.skipFresh) {
    list = list.filter(({ step }) => {
      const last = ctx.freshness[stepKey(step)];
      if (!last) return true;
      const lead = daysBetweenISO(today, step.checkin);
      return (ctx.nowMs - last) / 3600000 >= minRescanHours(lead);
    });
  }
  list.sort((a, b) => b.score - a.score || a.i - b.i);
  let out = list.map((x) => x.step);
  if (opts.maxSteps) out = out.slice(0, opts.maxSteps);
  return out;
}

/** 0..1 per destination from how many drop-type events it produced in the last `days`. */
function destinationVolatility(events, nowMs, days = 14) {
  const cutoff = nowMs - days * 86400000;
  const counts = {};
  for (const e of events || []) {
    if (new Date(e.at).getTime() >= cutoff) counts[e.destination] = (counts[e.destination] || 0) + 1;
  }
  const out = {};
  for (const [d, n] of Object.entries(counts)) out[d] = Math.min(1, n / 5);
  return out;
}

/** Window for tonight (lead 0): last-minute scans start here, the weekly windows never include it. */
function todayWindow(nights, today = new Date()) {
  const start = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  const checkout = new Date(start);
  checkout.setDate(checkout.getDate() + nights);
  return { checkin: toISODate(start), checkout: toISODate(checkout) };
}

// ---------------------------------------------------------------------------
// Storage helpers (the only chrome.storage users in this file)
// ---------------------------------------------------------------------------

async function loadDealEvents() {
  const { dealEvents = [] } = await chrome.storage.local.get("dealEvents");
  return dealEvents;
}

/** Records the event in the feed. Not serialized: callers run it via notifyDealEvent's lock. */
async function recordDealEvent(event) {
  const events = await loadDealEvents();
  await chrome.storage.local.set({ dealEvents: addDealEvent(events, event) });
}

/** Last N public-safe events for the published deals.json feed. */
function publicFeed(events, limit = 100) {
  return (events || []).slice(0, limit).map((e) => ({
    id: e.id, at: e.at, type: e.type, hotelName: e.hotelName, destination: e.destination,
    source: e.source, starRating: e.starRating, checkin: e.checkin, checkout: e.checkout,
    price: e.price, refPrice: e.refPrice, dropPct: e.dropPct, leadDays: e.leadDays,
    isNewlyBuilt: e.isNewlyBuilt, url: e.url,
  }));
}

// ---------------------------------------------------------------------------
// Subscriber bot commands (pure: returns what to say and what to change)
// ---------------------------------------------------------------------------

/**
 * Interprets one Telegram message from a subscriber. `sub` is their stored
 * record or null (first contact). Returns {reply, patch} where patch is
 * merged into the subscriber (created if new). Free text gets the help
 * text rather than being ignored, so nobody is left wondering if it works.
 */
function subscriberCommandReply(text, sub, opts = {}, nowMs = Date.now()) {
  const raw = String(text || "").trim();
  const [cmdRaw, ...rest] = raw.split(/\s+/);
  const cmd = cmdRaw.toLowerCase().replace(/@\w+$/, "");
  const arg = rest.join(" ").trim();
  const prices = opts.planPrices || {};
  const help = [
    "Commands:",
    "/plan - your plan and how to upgrade",
    "/destinations Digha, Puri - only these places (or /destinations all)",
    "/budget 5000 - only stays up to this price (or /budget off)",
    "/stop - pause alerts, /start to resume",
  ].join("\n");

  if (cmd === "/start" && opts.plansEnabled === false) {
    return {
      patch: { active: true },
      reply: [
        "\u{1F44B} You're in. I send hotel price drops for weekend getaways from Kolkata, free for everyone right now.",
        "You get every alert as it happens, including last-minute deals.",
        "",
        help,
      ].join("\n"),
    };
  }
  if (cmd === "/start") {
    return {
      patch: { active: true },
      reply: [
        "\u{1F44B} You're in. I send hotel price drops for weekend getaways from Kolkata.",
        `Free plan: up to ${PLANS.free.dailyCap} alerts a day, delayed by ${PLANS.free.delayMinutes / 60}h.`,
        `Pro (Rs ${prices.pro ?? PLANS.pro.price}/mo): instant alerts, last-minute deals, ${PLANS.pro.dailyCap} a day.`,
        "",
        help,
      ].join("\n"),
    };
  }
  if (cmd === "/stop") return { patch: { active: false }, reply: "Alerts paused. Send /start any time to resume." };
  if (cmd === "/plan" && opts.plansEnabled === false) {
    return { patch: {}, reply: "Everything is free for everyone right now: instant alerts, all deal types, last-minute included." };
  }
  if (cmd === "/plan") {
    const key = sub ? effectivePlanKey(sub, nowMs) : "free";
    const p = PLANS[key];
    const lines = [
      `Your plan: ${p.label}${sub && sub.expiresAt && key !== "free" ? ` (until ${String(sub.expiresAt).slice(0, 10)})` : ""}`,
      `Alerts: ${p.dailyCap}/day, ${p.delayMinutes ? `delayed ${p.delayMinutes / 60}h` : "instant"}`,
      `Includes: ${p.types.map((t) => DEAL_EVENT_TYPES[t].label).join(", ")}`,
    ];
    if (key === "free") {
      lines.push(`Pro: Rs ${prices.pro ?? PLANS.pro.price}/mo, VIP: Rs ${prices.vip ?? PLANS.vip.price}/mo`);
      lines.push(opts.upgradeUrl ? `Upgrade: ${opts.upgradeUrl}` : "Reply to the person who sent you this bot to upgrade.");
    }
    return { patch: {}, reply: lines.join("\n") };
  }
  if (cmd === "/destinations") {
    if (!arg || /^(all|any|everywhere)$/i.test(arg)) return { patch: { destinations: [] }, reply: "Watching all destinations." };
    const list = arg.split(/[,;]+/).map((x) => x.trim()).filter(Boolean).slice(0, 10);
    return { patch: { destinations: list }, reply: `Watching: ${list.join(", ")}` };
  }
  if (cmd === "/budget") {
    if (!arg || /^(off|none|any)$/i.test(arg)) return { patch: { maxPrice: null }, reply: "No budget limit." };
    const n = Number(arg.replace(/[^\d]/g, ""));
    if (!n || n < 500) return { patch: {}, reply: "Send a number like /budget 5000" };
    return { patch: { maxPrice: n }, reply: `Only stays up to Rs ${n}.` };
  }
  return { patch: {}, reply: help };
}

// ---------------------------------------------------------------------------
// Channel quality gate: only GREAT deals go to the public channel
// ---------------------------------------------------------------------------

const CHANNEL_DEFAULTS = {
  greatDealMinDropPct: 25, // drop/discount must be at least this to count as great
  greatLastMinutePct: 15,  // last-minute needs a bit more than the generic 10%
  channelMaxPerDay: 8,     // quality over volume: a noisy channel gets muted
  minPrice: 800,           // below this it's a basic room / mis-scrape, not a deal
};

/**
 * Is this event worth posting to the public channel? Rare deals always
 * (they already passed a strict statistical test), last-minute drops of
 * 15%+, ordinary drops/discounts of 25%+. Newly-built-only events never
 * (that's a vlogging signal, not a deal). Hotels with a poor guest rating
 * are held back no matter how cheap: a deal on a bad hotel is not a deal.
 */
function isGreatDeal(event, opts = {}) {
  const o = { ...CHANNEL_DEFAULTS, ...opts };
  if (!event || typeof event.price !== "number" || event.price < o.minPrice) return false;
  if (event.rating != null && event.reviewCount != null && event.reviewCount >= 10 && event.rating < 3.5) return false;
  if (event.type === "rare" || event.type === "error_fare" || event.type === "record_low") return true;
  if (event.type === "last_minute") return (event.dropPct || 0) >= o.greatLastMinutePct;
  if (event.type === "drop" || event.type === "discount" || event.type === "good_deal") return (event.dropPct || 0) >= o.greatDealMinDropPct;
  return false;
}

/**
 * Daily cap + de-duplication for channel posts. state = {day, count, keys}
 * (keys = hotel|checkin posted today, so the same stay isn't posted twice
 * for two different reasons). Returns {post, newState, reason}.
 */
function channelPostDecision(event, state, nowMs, opts = {}) {
  const o = { ...CHANNEL_DEFAULTS, ...opts };
  const day = toISODate(new Date(nowMs));
  const cur = state && state.day === day ? state : { day, count: 0, keys: [] };
  const key = `${event.source}|${event.hotelName}|${event.destination}|${event.checkin}`;
  if (cur.keys.includes(key)) return { post: false, newState: cur, reason: "duplicate" };
  if (cur.count >= o.channelMaxPerDay) return { post: false, newState: cur, reason: "daily_cap" };
  return { post: true, newState: { day, count: cur.count + 1, keys: [...cur.keys, key].slice(-50) }, reason: "ok" };
}

function formatChannelPost(event) {
  const base = formatDealMessage(event);
  return `${base}\n\n\u{1F514} Free deal alerts for Kolkata weekend getaways. Tap the channel name to follow.`;
}

// ---------------------------------------------------------------------------
// Junk scoring: which tracked hotels are not worth anyone's attention
// ---------------------------------------------------------------------------

const JUNK_SUGGEST_THRESHOLD = 50;

/**
 * 0..100 "probably not worth tracking" with the reasons, so the swipe queue
 * can put the obvious rejects first and a person can clear them in
 * seconds. group = a loadTrackedHotelGroups() entry. Newly built
 * properties are exempt from the "no reviews" penalties (they have none yet).
 */
function junkScore(group) {
  const reasons = [];
  let score = 0;
  const add = (pts, why) => { score += pts; reasons.push(why); };
  const rating = group.rating, reviews = group.reviewCount;
  const tier = group.manualStarTier ?? group.starRating ?? group.aiEstimatedStarTier ?? null;

  if (rating != null && reviews != null && reviews >= 15 && rating < 3.5) add(55, `Low guest rating: ${rating} from ${reviews} reviews`);
  else if (rating != null && reviews != null && reviews >= 100 && rating < 3.9) add(25, `Mediocre rating: ${rating} from ${reviews} reviews`);
  if (!group.isNewlyBuilt) {
    if (rating == null && (reviews == null || reviews === 0)) add(25, "No guest rating at all");
    else if (reviews != null && reviews < 5) add(12, `Only ${reviews} review(s), not enough to trust`);
  }
  if (tier != null && tier < 3) add(30, `Only ${tier} star`);
  if (/\b(hostel|dorm|dormitory|bunk|lodge|dharamshala|guest\s?house)\b/i.test(group.hotelName || "")) add(30, "Looks like a hostel / basic lodge");
  if (typeof group.cheapestPrice === "number" && group.cheapestPrice < 800) add(25, `Very cheap (${formatINR(group.cheapestPrice)}), probably a basic room`);
  if (group.hasFlaggedDates) add(15, "Some prices look mis-scraped");
  return { score: Math.min(100, score), reasons, suggestRemove: score >= JUNK_SUGGEST_THRESHOLD };
}

// ---------------------------------------------------------------------------
// Google rating lookup (Places API "New" Text Search, your own API key)
// ---------------------------------------------------------------------------

/**
 * Stricter than the YouTube matcher: a hotel whose whole name is generic
 * words ("The Resort") can never be confirmed from a single shared word,
 * so it needs the full normalised name to match.
 */
function googleNameMatch(hotelName, destination, placeName) {
  const norm = (s) => String(s || "").toLowerCase().replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
  const destWords = new Set(significantWords(destination));
  const sig = significantWords(hotelName).filter((w) => !destWords.has(w));
  const place = norm(placeName);
  if (sig.length === 0) return norm(hotelName) === place;
  // every distinctive word must appear (not just one): "Sea Pearl Resort" must not match "Sea View Resort"
  return sig.every((w) => place.includes(w));
}

function pickGooglePlace(places, hotelName, destination) {
  for (const p of places || []) {
    const name = p.displayName && p.displayName.text;
    if (name && typeof p.rating === "number" && googleNameMatch(hotelName, destination, name)) {
      return {
        rating: p.rating, reviews: p.userRatingCount ?? null, url: p.googleMapsUri || null, matchedName: name,
        // photo resource names (not URLs: a URL needs the API key, built at display time) and up to 3 review snippets
        photos: (p.photos || []).map((ph) => ph && ph.name).filter(Boolean).slice(0, 4),
        reviewList: (p.reviews || []).slice(0, 3).map((r) => ({
          rating: r.rating ?? null,
          text: String((r.text && r.text.text) || (r.originalText && r.originalText.text) || "").replace(/\s+/g, " ").trim().slice(0, 260),
          author: (r.authorAttribution && r.authorAttribution.displayName) || "",
          when: r.relativePublishTimeDescription || "",
        })).filter((r) => r.text),
      };
    }
  }
  return null;
}

/**
 * One Text Search call (billed by Google at the tier of the most expensive
 * field requested, rating is one, see the README for the cost note).
 * Returns {rating, reviews, url, matchedName} or null when nothing
 * genuinely matched; throws on HTTP errors so callers can stop on a bad key.
 */
async function fetchGoogleRating(hotelName, destination, apiKey, extras = false) {
  const resp = await fetch("https://places.googleapis.com/v1/places:searchText", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Goog-Api-Key": apiKey,
      // photos + reviews put the call in a pricier Google tier, so only when asked for
      "X-Goog-FieldMask": "places.displayName,places.rating,places.userRatingCount,places.googleMapsUri" + (extras ? ",places.photos,places.reviews" : ""),
    },
    body: JSON.stringify({ textQuery: `${hotelName}, ${destination}, India`, maxResultCount: 3 }),
  });
  if (!resp.ok) {
    const body = await resp.text().catch(() => "");
    throw new Error(`Google Places ${resp.status}: ${body.slice(0, 160)}`);
  }
  const data = await resp.json();
  return pickGooglePlace(data.places, hotelName, destination);
}

// ---------------------------------------------------------------------------
// Confirm before alerting
// ---------------------------------------------------------------------------

/**
 * Decide what to do with a deal after re-checking its detail page.
 * lowestNow = the lowest plausible price found on the re-check (null if the
 * page could not be read). Within 5% of (or below) the alerted price means
 * it holds. Clearly higher means the first reading was wrong (a coupon
 * banner, a stale card) and the alert is dropped. Unreadable means we
 * cannot tell: send it, flagged, rather than silently lose a real deal.
 */
function confirmDecision(alertedPrice, lowestNow) {
  if (typeof lowestNow !== "number" || lowestNow < 300) return "unverified";
  return lowestNow <= alertedPrice * 1.05 ? "confirmed" : "cancel";
}

/** Which events are worth the extra page load of a re-check. */
function needsConfirmation(event) {
  return event.type === "last_minute" || event.type === "rare" || isGreatDeal(event);
}

// ---------------------------------------------------------------------------
// v1.39: fair price, holidays, desperate hotels, error fares, missing hotels,
// weather, digest, watches, calendar, value, lead curve, film gaps
// ---------------------------------------------------------------------------

function medianOf(values) {
  const v = values.filter((x) => typeof x === "number").sort((a, b) => a - b);
  if (v.length === 0) return null;
  const mid = Math.floor(v.length / 2);
  return v.length % 2 ? v[mid] : (v[mid - 1] + v[mid]) / 2;
}

/**
 * "Fair price" of one stay: the median of everything it has cost so far
 * (needs minPoints observations, default 6, so one or two scans never
 * define "normal"). Sticker discounts are judged against this, not against
 * the site's own crossed-out price.
 */
function fairPriceFor(prices, minPoints = 6) {
  const real = (prices || []).filter((p) => typeof p.price === "number" && p.price >= 300).map((p) => p.price);
  if (real.length < minPoints) return null;
  return { fair: Math.round(medianOf(real)), n: real.length };
}

/** A price at or under 40% of the usual one is more likely a mistake (by the hotel or the scrape) than a deal. */
function isErrorFare(price, fairInfo, ratio = 0.4, minPoints = 8) {
  return !!(fairInfo && fairInfo.n >= minPoints && typeof price === "number" && price >= 300 && price <= fairInfo.fair * ratio);
}

/**
 * Three price drops in a row (one reading per calendar day, each drop at
 * least 2%): the hotel is probably not filling up.
 */
function isDesperate(prices) {
  const byDay = new Map();
  for (const p of prices || []) {
    if (typeof p.price === "number" && p.price >= 300 && p.at) byDay.set(toISODate(new Date(p.at)), p.price);
  }
  const days = [...byDay.entries()].sort((a, b) => a[0].localeCompare(b[0])).map((e) => e[1]);
  if (days.length < 4) return false;
  const last = days.slice(-4);
  for (let i = 1; i < last.length; i++) if (last[i] > last[i - 1] * 0.98) return false;
  return true;
}

// Editable in the Business tab. Dates are my best knowledge, not an official
// calendar: check Durga Puja and Diwali against the real almanac for the year.
const DEFAULT_HOLIDAY_TEXT = [
  "2026-10-16..2026-10-21 Durga Puja",
  "2026-11-07..2026-11-09 Diwali and Kali Puja",
  "2026-12-24..2027-01-02 Christmas and New Year",
  "2027-01-23..2027-01-26 Republic Day long weekend",
  "2027-08-13..2027-08-15 Independence Day weekend",
].join("\n");

function parseHolidayText(text) {
  const out = [];
  for (const line of String(text || "").split(/\r?\n/)) {
    const m = /^\s*(\d{4}-\d{2}-\d{2})\s*\.\.\s*(\d{4}-\d{2}-\d{2})\s+(.+?)\s*$/.exec(line);
    if (m && m[1] <= m[2]) out.push({ from: m[1], to: m[2], name: m[3] });
  }
  return out;
}

/** The holiday a stay overlaps, or null. */
function holidayFor(checkin, checkout, windows) {
  for (const w of windows || []) {
    if (checkin <= w.to && (checkout || checkin) >= w.from) return w.name;
  }
  return null;
}

/** One plain sentence on why this price is good, built only from real numbers. */
function buildWhyLine(info) {
  const parts = [];
  if (info.fair && info.price < info.fair) {
    parts.push(`${Math.round(((info.fair - info.price) / info.fair) * 100)}% under its usual ${formatINR(info.fair)}`);
  }
  if (info.lowestInDays && info.lowestInDays >= 7) parts.push(`lowest in ${info.lowestInDays} days of tracking`);
  if (info.rating != null) parts.push(`rated ${info.rating}${info.reviewCount ? ` by ${info.reviewCount} guests` : ""}`);
  if (info.holiday && info.fair && info.price < info.fair) parts.push(`cheap even for ${info.holiday}`);
  return parts.length ? parts.join(", ") : "";
}

/** Days of tracking if this price is the lowest the ledger has ever recorded (needs 5+ points), else null. */
function lowestInDays(prices, price, nowMs) {
  const real = (prices || []).filter((p) => typeof p.price === "number" && p.price >= 300 && p.at);
  if (real.length < 5) return null;
  if (real.some((p) => p.price <= price)) return null;
  return Math.max(1, Math.round((nowMs - new Date(real[0].at).getTime()) / 86400000));
}

/**
 * "Lowest ever" for one stay (one hotel, one pair of dates), v1.44.6. The new
 * price must be clearly under EVERY verified earlier price, not just a tick
 * lower, and there must be enough history for "ever" to mean something:
 * at least minPoints readings over at least minDays different days (the very
 * first scans are always "the lowest so far"). When the stay has a usual price
 * it must also be well under that, so a hotel that merely wobbles around its
 * normal price never counts. Needs no stored flag: once this price is in the
 * history it is the new low, so the same price can't fire twice and only a
 * further clear drop can.
 * -> {fire, prevLow, prevLowAt, belowPrevPct, belowFairPct}
 */
/** Options with undefined/null/NaN left out, so a missing setting falls back to the default instead of overriding it. */
function definedOnly(opts) {
  const out = {};
  for (const [k, v] of Object.entries(opts || {})) if (v !== undefined && v !== null && v !== "" && !Number.isNaN(v)) out[k] = Number(v);
  return out;
}

function detectRecordLow(verifiedPrior, price, opts = {}) {
  const o = { minPoints: 5, minDays: 3, minBelowPrevPct: 5, minBelowFairPct: 10, ...definedOnly(opts) };
  const none = { fire: false };
  if (typeof price !== "number" || price < 300) return none;
  const real = (verifiedPrior || []).filter((p) => p && typeof p.price === "number" && p.price >= 300 && p.at);
  if (real.length < o.minPoints) return none;
  const days = new Set(real.map((p) => toISODate(new Date(p.at))));
  if (days.size < o.minDays) return none;
  const prev = real.reduce((a, b) => (b.price < a.price ? b : a));
  const belowPrevPct = ((prev.price - price) / prev.price) * 100;
  if (belowPrevPct < o.minBelowPrevPct) return none;
  const fairInfo = fairPriceFor(real);
  const belowFairPct = fairInfo ? ((fairInfo.fair - price) / fairInfo.fair) * 100 : null;
  if (belowFairPct !== null && belowFairPct < o.minBelowFairPct) return none;
  return { fire: true, prevLow: prev.price, prevLowAt: prev.at, belowPrevPct: Math.round(belowPrevPct), belowFairPct: belowFairPct === null ? null : Math.round(belowFairPct), fair: fairInfo ? fairInfo.fair : null };
}

/**
 * "A really good deal" (v1.44.6): the price is at least minBelowPct under what
 * this stay usually costs (its median, needs 6+ verified readings), whatever
 * the hotel did since the last scan. Fires once per dip and re-arms when the
 * price climbs back to within rearmBelowPct of usual (same fire-once pattern as
 * price targets), so a steadily cheap stay is one alert, not one per scan.
 * -> {fire, newState, belowPct}
 */
function evaluateGoodDeal(price, fairInfo, wasAlerted, opts = {}) {
  const o = { minBelowPct: 25, rearmBelowPct: 10, ...definedOnly(opts) };
  const was = !!wasAlerted;
  if (!fairInfo || typeof price !== "number" || price < 300) return { fire: false, newState: was };
  const belowPct = ((fairInfo.fair - price) / fairInfo.fair) * 100;
  if (belowPct >= o.minBelowPct) return { fire: !was, newState: true, belowPct: Math.round(belowPct) };
  if (belowPct < o.rearmBelowPct) return { fire: false, newState: false };
  return { fire: false, newState: was };
}

/** A cheap price on a badly reviewed hotel is not a deal worth interrupting anyone for. */
function isPoorlyRated(rating, reviewCount) {
  return rating != null && reviewCount != null && reviewCount >= 10 && rating < 3.5;
}

/**
 * Missing-hotel stages, computed from how long ago any of its dates was seen
 * in a listing while its destination WAS being scanned (so a place we simply
 * stopped scanning never loses its hotels). Active -> paused at 7 days
 * (hidden, comes back by itself the moment a scan lists it again) ->
 * stopped at 37 days (a permanent removal until you restore it).
 */
function missingStage(lastSeenMs, nowMs, destScannedRecently, opts = {}) {
  const pausedAfter = opts.pausedAfterDays ?? 7;
  const stoppedAfter = opts.stoppedAfterDays ?? 37;
  if (!destScannedRecently || !lastSeenMs) return "active";
  const days = (nowMs - lastSeenMs) / 86400000;
  if (days >= stoppedAfter) return "stopped";
  if (days >= pausedAfter) return "paused";
  return "active";
}

// --- weather (Open-Meteo, free, no key) ---

const DESTINATION_COORDS = {
  digha: [21.6275, 87.5093], mandarmani: [21.6667, 87.7], darjeeling: [27.041, 88.2663], sundarbans: [22.16, 88.8],
  puri: [19.8135, 85.8312], kolkata: [22.5726, 88.3639], gangtok: [27.3389, 88.6065], purulia: [23.332, 86.3649],
  shantiniketan: [23.6833, 87.6833], "west bengal": [22.9868, 87.855],
};

function openMeteoUrl(lat, lon) {
  return `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&daily=precipitation_sum,wind_speed_10m_max,weather_code&timezone=Asia%2FKolkata&forecast_days=16`;
}

function parseOpenMeteo(json) {
  const d = json && json.daily;
  if (!d || !Array.isArray(d.time)) return [];
  return d.time.map((date, i) => ({
    date,
    precip: d.precipitation_sum ? d.precipitation_sum[i] : null,
    wind: d.wind_speed_10m_max ? d.wind_speed_10m_max[i] : null,
    code: d.weather_code ? d.weather_code[i] : null,
  }));
}

/** "storm" | "rain" | "clear" | "mixed" for one forecast day. */
function weatherRisk(day) {
  if ((day.code != null && day.code >= 95) || (day.precip != null && day.precip >= 40) || (day.wind != null && day.wind >= 55)) return "storm";
  if (day.precip != null && day.precip >= 10) return "rain";
  if ((day.precip == null || day.precip < 2) && (day.code == null || day.code <= 3)) return "clear";
  return "mixed";
}

/** A short line for the stay's days, or empty when there is no forecast for those dates yet (the forecast reaches 16 days). */
function weatherNote(days, checkin, checkout) {
  const stay = (days || []).filter((d) => d.date >= checkin && d.date <= (checkout || checkin));
  if (stay.length === 0) return "";
  const risks = stay.map(weatherRisk);
  if (risks.includes("storm")) return "⛈ Storm or very heavy rain forecast for these dates, check before booking";
  if (risks.includes("rain")) return "\u{1F327} Rain forecast for part of this stay";
  if (risks.every((r) => r === "clear")) return "☀ Clear skies forecast, a cheap price AND good weather";
  return "";
}

// --- watches ("Track this hotel" buttons) ---

/** Short stable code for a hotel group key, used in t.me deep links (letters and digits only). */
function shortCode(str) {
  let h = 5381;
  for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) >>> 0;
  return h.toString(36);
}

/** True when a new price is a further drop on the watched stay since the watch (or last alert) base price. */
function watchTriggered(watch, price, checkin) {
  return watch.checkin === checkin && typeof price === "number" && price >= 300 && price <= watch.basePrice * 0.97;
}

// --- value score, calendar, lead curve, film gaps, digest ---

/** Higher = more hotel per rupee. Rating (default 3.5), amenities and star tier against price in thousands. */
function valueScore(g) {
  const price = g.cheapestPrice;
  if (!price) return 0;
  const tier = g.manualStarTier ?? g.starRating ?? g.aiEstimatedStarTier ?? 3;
  const quality = Math.max(0.5, (g.rating ?? 3.5) - 2) + Math.min((g.amenities || []).length, 4) * 0.15 + (tier - 3) * 0.2;
  return Math.round((quality / (price / 1000)) * 100) / 100;
}

/**
 * Cheapest-weekend calendar: for each destination and each upcoming
 * check-in date, the median current price across that destination's hotels,
 * and an index vs that destination's own overall median (1.0 = normal,
 * under 0.9 = cheap, over 1.1 = expensive). Only dates with 3+ hotels.
 */
function weekendIndex(groups, todayIso) {
  const byDest = {};
  for (const g of groups) {
    for (const d of g.dates || []) {
      if (d.checkin < todayIso || d.isLikelyBadScrape || d.verified === false) continue;
      ((byDest[g.destination] = byDest[g.destination] || {})[d.checkin] = (byDest[g.destination] || {})[d.checkin] || []).push(d.current);
    }
  }
  const out = {};
  for (const [dest, dates] of Object.entries(byDest)) {
    const meds = {};
    for (const [date, prices] of Object.entries(dates)) if (prices.length >= 3) meds[date] = medianOf(prices);
    const all = medianOf(Object.values(meds));
    if (all == null) continue;
    out[dest] = Object.keys(meds).sort().slice(0, 8).map((date) => ({ date, median: Math.round(meds[date]), index: Math.round((meds[date] / all) * 100) / 100 }));
  }
  return out;
}

/**
 * How prices behave as check-in approaches, from the ledger: for each stay,
 * every point's price relative to that stay's own median, grouped by lead
 * bucket. ratio under 1 in the 0-3 bucket means prices usually fall at the
 * last minute. Needs real volume to say anything.
 */
function leadCurve(histRecords) {
  const buckets = { "0-3": [], "4-7": [], "8-14": [], "15+": [] };
  for (const r of histRecords) {
    const pts = (r.prices || []).filter((p) => p.price >= 300 && p.lead != null && p.lead >= 0);
    if (pts.length < 6) continue;
    const med = medianOf(pts.map((p) => p.price));
    for (const p of pts) {
      const b = p.lead <= 3 ? "0-3" : p.lead <= 7 ? "4-7" : p.lead <= 14 ? "8-14" : "15+";
      buckets[b].push(p.price / med);
    }
  }
  const out = {};
  for (const [b, ratios] of Object.entries(buckets)) out[b] = { n: ratios.length, ratio: ratios.length ? Math.round(medianOf(ratios) * 100) / 100 : null };
  return out;
}

function bookAdvice(curve, minSamples = 30) {
  const near = curve["0-3"], far = curve["8-14"];
  if (!near || !far || near.n < minSamples || far.n < minSamples) return { advice: "not_enough_data", text: "Not enough history yet, needs a few more weeks of scans." };
  const diff = Math.round((far.ratio - near.ratio) * 100);
  if (diff >= 6) return { advice: "wait", text: `Usually about ${diff}% cheaper in the last 3 days. Waiting tends to pay off here.` };
  if (diff <= -6) return { advice: "book", text: `Usually about ${-diff}% dearer in the last 3 days. Book early here.` };
  return { advice: "either", text: "Price barely changes as the date gets close. Book when you like it." };
}

/** Hotels worth filming that nobody has covered yet: good rating or newly built, with 0 or 1 videos found. */
function filmGapList(groups, limit = 12) {
  return groups
    .filter((g) => g.youtubeCheckedAt && (g.youtubeVideoCount ?? 0) <= 1 && ((g.rating != null && g.rating >= 4.0) || g.isNewlyBuilt))
    .map((g) => ({ g, score: (g.isNewlyBuilt ? 3 : 0) + (g.rating || 0) + Math.min((g.reviewCount || 0) / 500, 1) }))
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((x) => x.g);
}

/** The 8am post: top stays for the coming weekend, by value, with real prices. */
function buildDigest(groups, weekendCheckin, limit = 5) {
  const rows = [];
  for (const g of groups) {
    const d = (g.dates || []).find((x) => x.checkin === weekendCheckin && !x.isLikelyBadScrape && x.verified !== false && x.current >= 800);
    if (!d) continue;
    if (g.rating != null && g.reviewCount >= 10 && g.rating < 3.8) continue;
    rows.push({ g, d, v: valueScore({ ...g, cheapestPrice: d.current }) });
  }
  rows.sort((a, b) => b.v - a.v);
  const top = rows.slice(0, limit);
  if (top.length === 0) return null;
  const lines = [`☀ This weekend (${weekendCheckin}): best value stays`, ""];
  top.forEach((r, i) => {
    lines.push(`${i + 1}. ${r.g.hotelName} (${r.g.destination}) ${formatINR(r.d.current)}${r.g.rating != null ? `, rated ${r.g.rating}` : ""}`);
  });
  return lines.join("\n");
}

// ---------------------------------------------------------------------------
// v1.40: helper computer (a second PC that scans its own share of destinations)
// ---------------------------------------------------------------------------

const HELPER_OVERLAP_HOURS = 72; // every upload re-sends the last 3 days, so a main PC that was off for a weekend loses nothing

/** File-safe device name: letters, digits, dash, underscore. */
function safeDeviceName(name) {
  const s = String(name || "").toLowerCase().replace(/[^a-z0-9_-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 32);
  return s || "helper";
}

/**
 * What a helper uploads: every hist: record changed in the window, carrying
 * ONLY the price points inside it (the receiving side merges point-by-point
 * by timestamp, so partial histories are fine and the file stays small),
 * plus the deal events from the same window.
 */
function buildHelperPayload(allEntries, deviceName, nowMs, overlapHours = HELPER_OVERLAP_HOURS) {
  const sinceIso = new Date(nowMs - overlapHours * 3600000).toISOString();
  const records = {};
  for (const [key, rec] of Object.entries(allEntries)) {
    if (!key.startsWith("hist:") || !rec || !Array.isArray(rec.prices) || !rec.updatedAt || rec.updatedAt < sinceIso) continue;
    records[key] = { ...rec, prices: rec.prices.filter((p) => p.at && p.at >= sinceIso) };
  }
  const events = ((allEntries.dealEvents) || []).filter((e) => e.at >= sinceIso);
  return { device: safeDeviceName(deviceName), uploadedAt: new Date(nowMs).toISOString(), since: sinceIso, records, events };
}

/** Rebuilds the listing object an alert needs from a stored deal event. */
function listingFromEvent(e) {
  return {
    source: e.source, hotelName: e.hotelName, destination: e.destination, checkin: e.checkin, checkout: e.checkout,
    discountedPrice: e.price, originalPrice: e.refPrice ?? null, discountPct: e.dropPct ?? null,
    starRating: e.starRating ?? null, isNewlyBuilt: !!e.isNewlyBuilt, rating: e.rating ?? null, reviewCount: e.reviewCount ?? null, url: e.url || null,
  };
}

/**
 * Splits imported events into ones to announce now (fresh, not seen, hotel not
 * removed) and ones to record silently (old, already seen, or removed hotels).
 * freshHours keeps a first connection from blasting out days of old news.
 */
function planEventImport(events, knownIds, blockedKeys, nowMs, freshHours = 6) {
  const known = new Set(knownIds);
  const announce = [], silent = [];
  for (const e of events || []) {
    if (!e || !e.id || known.has(e.id)) continue;
    const blocked = blockedKeys.has(`${e.source}:::${e.hotelName}:::${e.destination}`);
    if (!blocked && nowMs - new Date(e.at).getTime() <= freshHours * 3600000) announce.push(e);
    else silent.push(e);
  }
  return { announce, silent };
}

/** The slice of the main computer's state a helper needs to behave the same way. No credentials. */
function buildSharedState(settings, blockedHotels, goldHotels) {
  return {
    writtenAt: new Date().toISOString(),
    destinations: (settings.destinations || []).map((d) => ({ name: d.name, searchTerm: d.searchTerm, mmtCode: d.mmtCode || null, goibiboCode: d.goibiboCode || null })),
    nights: settings.nights, checkinWeekday: settings.checkinWeekday, lookaheadDays: settings.lookaheadDays,
    includeNext7Days: settings.includeNext7Days, minStarRating: settings.minStarRating, adults: settings.adults, rooms: settings.rooms,
    mmtDateFormat: settings.mmtDateFormat || null, holidayText: settings.holidayText ?? null,
    discountPctThreshold: settings.discountPctThreshold, priceDropPctThreshold: settings.priceDropPctThreshold,
    lastMinuteDays: settings.lastMinuteDays, lastMinuteDropPct: settings.lastMinuteDropPct,
    blockedHotels: blockedHotels || [], goldHotels: goldHotels || {},
  };
}

/** Applies shared state onto a helper's own settings, keeping its own per-destination scan times. Returns the new settings. */
function applySharedState(settings, shared) {
  const out = { ...settings };
  for (const k of ["nights", "checkinWeekday", "lookaheadDays", "includeNext7Days", "minStarRating", "adults", "rooms", "mmtDateFormat", "holidayText", "discountPctThreshold", "priceDropPctThreshold", "lastMinuteDays", "lastMinuteDropPct"]) {
    if (shared[k] !== undefined) out[k] = shared[k];
  }
  const mine = new Map((settings.destinations || []).map((d) => [d.name.toLowerCase(), d]));
  out.destinations = (shared.destinations || []).map((d) => {
    const own = mine.get(d.name.toLowerCase());
    return { ...d, mmtCode: d.mmtCode || (own && own.mmtCode) || null, goibiboCode: d.goibiboCode || (own && own.goibiboCode) || null, lastScannedAt: own ? own.lastScannedAt : undefined };
  });
  return out;
}

/** Destinations a computer should scan: its own list if it has one, otherwise all. */
function filterScanDestinations(destinations, scanList) {
  if (!scanList || scanList.length === 0) return destinations;
  const want = new Set(scanList.map((n) => String(n).trim().toLowerCase()).filter(Boolean));
  return destinations.filter((d) => want.has(d.name.toLowerCase()));
}

/** Display URL for a Google Places photo resource name. Billed per image shown, so callers load one at a time. */
function googlePhotoUrl(photoName, apiKey, maxWidthPx = 640) {
  if (!photoName || !apiKey || !/^places\/[A-Za-z0-9_-]+\/photos\/[A-Za-z0-9_-]+$/.test(photoName)) return null;
  return `https://places.googleapis.com/v1/${photoName}/media?maxWidthPx=${maxWidthPx}&key=${encodeURIComponent(apiKey)}`;
}
