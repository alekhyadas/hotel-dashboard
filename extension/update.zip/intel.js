/**
 * Deal intelligence: the price ledger, last-minute drop detection, smart
 * scan ordering, the deal-event model and the subscriber/plan engine
 * (the pieces a paid alert service would be built on).
 *
 * Everything in the first half is PURE (no chrome.*), so it's unit-tested
 * in tests/test_intel.js the same way evaluateTargetAlert() is. The small
 * storage helpers at the bottom are the only chrome.storage users.
 *
 * Loaded after shared.js (needs toISODate/formatINR) by background.js
 * (importScripts) and the dashboard page (<script>).
 */

// ---------------------------------------------------------------------------
// Price ledger
// ---------------------------------------------------------------------------

// Every scan of a (hotel, dates) record appends one point. This used to be
// capped at 30, which threw away history after a few weeks. 365 keeps a
// year of twice-daily checks, and each point is ~40 bytes (unlimitedStorage
// is on), so it's cheap. `lead` = calendar days between the scan and the
// check-in date: it's what makes "this is a last-minute price" answerable
// from history alone, long after the fact.
const LEDGER_MAX_POINTS = 365;

/** Whole calendar days from isoA to isoB (YYYY-MM-DD), DST-proof. */
function daysBetweenISO(isoA, isoB) {
  const [ya, ma, da] = isoA.split("-").map(Number);
  const [yb, mb, db] = isoB.split("-").map(Number);
  return Math.round((Date.UTC(yb, mb - 1, db) - Date.UTC(ya, ma - 1, da)) / 86400000);
}

/** Days from the (local) calendar day of `atIso` until `checkin`. 0 = same day. */
function leadDays(checkin, atIso) {
  return daysBetweenISO(toISODate(new Date(atIso)), checkin);
}

/**
 * dv: 1 marks a point whose check-in date was VERIFIED (read from the page's
 * own URL). Before v1.43 MakeMyTrip was being asked for dates in a format it
 * ignores, so most older points are tonight's price filed under another date;
 * they carry no dv and are kept only as history, never used for comparisons.
 */
function appendLedgerPoint(prices, price, atIso, checkin) {
  const out = (prices || []).slice(-(LEDGER_MAX_POINTS - 1));
  out.push({ price, at: atIso, lead: leadDays(checkin, atIso), dv: 1 });
  return out;
}

/** Only the points whose date was verified. Everything that compares prices uses these. */
function verifiedPoints(prices) {
  return (prices || []).filter((p) => p && p.dv === 1);
}

/**
 * Union of two price histories (by timestamp), oldest first. Used when a
 * backup is restored over data that has newer scans: neither side's points
 * are lost.
 */
function mergePriceHistories(a, b) {
  const byAt = new Map();
  for (const p of [...(a || []), ...(b || [])]) {
    if (p && typeof p.price === "number" && p.at) byAt.set(p.at, p);
  }
  return [...byAt.values()].sort((x, y) => new Date(x.at) - new Date(y.at)).slice(-LEDGER_MAX_POINTS);
}

/** Merge a restored hist: record into an existing local one without losing newer scans. */
function mergeHistRecords(local, restored) {
  if (!local) return restored;
  if (!restored) return local;
  const newer = (local.updatedAt || "") >= (restored.updatedAt || "") ? local : restored;
  const older = newer === local ? restored : local;
  const prices = mergePriceHistories(local.prices, restored.prices);
  const real = prices.filter((p) => p.price >= 300).map((p) => p.price);
  const lowest = real.length ? Math.min(...real) : newer.lowest;
  const lowestPoint = prices.find((p) => p.price === lowest);
  return { ...older, ...newer, prices, lowest, lowestAt: lowestPoint ? lowestPoint.at : newer.lowestAt };
}

/** Backup-size control: drop interior points of a run of identical prices, keeping the first and last. */
function compactPriceHistory(prices) {
  if (!prices || prices.length < 3) return prices || [];
  const out = [];
  for (let i = 0; i < prices.length; i++) {
    const prev = prices[i - 1], next = prices[i + 1];
    const interiorOfRun = prev && next && prev.price === prices[i].price && next.price === prices[i].price;
    if (!interiorOfRun) out.push(prices[i]);
  }
  return out;
}

// ---------------------------------------------------------------------------
// Last-minute drop detection
// ---------------------------------------------------------------------------

const LAST_MINUTE_DEFAULTS = {
  lastMinuteDays: 3,       // lead 0 (tonight) .. N days ahead counts as last-minute
  lastMinuteDropPct: 10,   // drop vs the reference price needed to fire
};

/**
 * Is `newPrice` a meaningful DROP, for a stay that starts within a few days?
 *
 * The reference is what this same stay cost on an EARLIER calendar day (the
 * case of "tracked it on the 20th, it's cheaper now it's nearly the day"),
 * or earlier today (a flash drop, e.g. just after midnight). Prices from
 * the same scan batch are never compared to themselves.
 *
 * Returns null when it isn't a last-minute drop, else
 * {leadDays, refPrice, refAt, dropPct, saving, refKind, weekHigh}.
 */
function detectLastMinuteDrop(prices, newPrice, checkin, nowIso, opts = {}) {
  const days = opts.lastMinuteDays ?? LAST_MINUTE_DEFAULTS.lastMinuteDays;
  const minPct = opts.lastMinuteDropPct ?? LAST_MINUTE_DEFAULTS.lastMinuteDropPct;
  if (typeof newPrice !== "number" || newPrice < 300) return null;
  const lead = leadDays(checkin, nowIso);
  if (lead < 0 || lead > days) return null;

  const today = toISODate(new Date(nowIso));
  const real = (prices || []).filter((p) => typeof p.price === "number" && p.price >= 300 && p.at);
  const earlierDay = real.filter((p) => toISODate(new Date(p.at)) < today);
  const earlierToday = real.filter((p) => toISODate(new Date(p.at)) === today);

  const candidates = [];
  if (earlierDay.length) {
    const p = earlierDay[earlierDay.length - 1];
    candidates.push({ ref: p.price, at: p.at, kind: "earlier_day" });
  }
  if (earlierToday.length) {
    const p = earlierToday[earlierToday.length - 1];
    candidates.push({ ref: p.price, at: p.at, kind: "same_day" });
  }
  let best = null;
  for (const c of candidates) {
    if (c.ref <= newPrice) continue;
    const pct = ((c.ref - newPrice) / c.ref) * 100;
    if (!best || pct > best.pct) best = { ...c, pct };
  }
  if (!best || best.pct < minPct) return null;

  const weekAgo = new Date(nowIso).getTime() - 7 * 86400000;
  const weekPrices = real.filter((p) => new Date(p.at).getTime() >= weekAgo).map((p) => p.price);
  return {
    leadDays: lead,
    refPrice: best.ref,
    refAt: best.at,
    refKind: best.kind,
    dropPct: Math.round(best.pct),
    saving: best.ref - newPrice,
    weekHigh: weekPrices.length ? Math.max(...weekPrices) : best.ref,
  };
}

/**
 * Fire-once-per-day (and again only if it falls a further 5%) decision for
 * last-minute alerts, so a stay that stays cheap all day doesn't ping on
 * every scan. `state` is the record's stored {price, day} or undefined.
 */
function shouldFireLastMinute(detection, newPrice, nowIso, state) {
  if (!detection) return { fire: false, newState: state };
  const day = toISODate(new Date(nowIso));
  const fire = !state || state.day !== day || newPrice <= state.price * 0.95;
  return { fire, newState: fire ? { price: newPrice, day } : state };
}

function leadLabel(lead) {
  if (lead <= 0) return "TONIGHT";
  if (lead === 1) return "tomorrow";
  return `in ${lead} days`;
}

// ---------------------------------------------------------------------------
// Deal events (the single record every alert channel + the feed is built from)
// ---------------------------------------------------------------------------

const DEAL_EVENT_TYPES = {
  record_low:  { label: "Lowest price ever", emoji: "\u{1F3C6}", rank: 7 },
  good_deal:   { label: "Well below its usual price", emoji: "\u{1F4B0}", rank: 3 },
  market_deal: { label: "Cheaper than similar hotels", emoji: "\u{1F4B8}", rank: 3 },
  error_fare:  { label: "Possible error fare", emoji: "🚨", rank: 6 },
  last_minute: { label: "Last-minute", emoji: "\u{1F525}", rank: 5 },
  rare:        { label: "Rare deal",   emoji: "\u{1F48E}", rank: 4 },
  drop:        { label: "Price drop",  emoji: "\u{1F4C9}", rank: 3 },
  discount:    { label: "Big discount",emoji: "\u{1F3F7}️", rank: 2 },
  new:         { label: "Newly built", emoji: "\u{1F195}", rank: 1 },
};

const MAX_DEAL_EVENTS = 500;

function makeDealEvent(type, listing, reasons, extra = {}, nowIso = new Date().toISOString()) {
  const price = listing.discountedPrice;
  return {
    id: [type, listing.source, listing.hotelName, listing.destination, listing.checkin, price, nowIso.slice(0, 13)].join("|"),
    at: nowIso,
    type,
    hotelName: listing.hotelName,
    destination: listing.destination,
    source: listing.source,
    starRating: listing.starRating ?? null,
    checkin: listing.checkin,
    checkout: listing.checkout,
    price,
    refPrice: extra.refPrice ?? listing.originalPrice ?? null,
    dropPct: extra.dropPct ?? listing.discountPct ?? null,
    leadDays: extra.leadDays ?? leadDays(listing.checkin, nowIso),
    isNewlyBuilt: !!listing.isNewlyBuilt,
    rating: listing.rating ?? null,
    reviewCount: listing.reviewCount ?? null,
    fairPrice: extra.fairPrice ?? null,
    holiday: extra.holiday ?? null,
    gold: !!extra.gold,
    url: listing.url || null,
    reasons: reasons || [],
  };
}

/** Newest first, de-duplicated by id, capped. Returns a new array. */
function addDealEvent(events, event) {
  const rest = (events || []).filter((e) => e.id !== event.id);
  return [event, ...rest].slice(0, MAX_DEAL_EVENTS);
}

/** The saving as a whole percent: the event's own figure, else worked out from the reference price. */
function eventSavingPct(e) {
  if (typeof e.dropPct === "number" && e.dropPct > 0) return Math.round(e.dropPct);
  if (e.refPrice && e.refPrice > e.price) return Math.round(((e.refPrice - e.price) / e.refPrice) * 100);
  return 0;
}

/**
 * v2.0.2: the first line of every alert says the whole story at a glance: what kind of deal, where,
 * how many stars, how big. "\u{1F525} LAST-MINUTE IN 2 DAYS · DARJEELING · 4★ · 51% OFF". The details follow.
 */
function alertHeadline(event) {
  const t = DEAL_EVENT_TYPES[event.type] || DEAL_EVENT_TYPES.drop;
  const label = event.type === "last_minute" ? `LAST-MINUTE ${leadLabel(event.leadDays).toUpperCase()}` : t.label.toUpperCase();
  const parts = [`${t.emoji} ${label}`];
  if (event.destination) parts.push(String(event.destination).toUpperCase());
  if (event.starRating) parts.push(`${event.starNote || ""}${event.starRating}★`);
  const pct = eventSavingPct(event);
  if (pct >= 5) parts.push(`${pct}% OFF`);
  return parts.join(" · ");
}

function stayDatesText(checkin, checkout) {
  const wd = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"], mo = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const f = (iso) => { const d = new Date(`${iso}T00:00:00`); return Number.isNaN(d.getTime()) ? String(iso) : `${wd[d.getDay()]} ${d.getDate()} ${mo[d.getMonth()]}`; };
  return `${f(checkin)} to ${f(checkout)}`;
}

/** The reasons without the repeats: the last-minute line already says the price dropped, the holiday goes on the dates line. */
function tidyReasons(event) {
  const rs = (event.reasons || []).map((r) => String(r)).filter(Boolean);
  const hasLastMinute = rs.some((r) => /Check-in /.test(r) && /->/.test(r));
  const out = [];
  for (const r of rs) {
    if (hasLastMinute && /^price dropped \d+% since last check/.test(r)) continue;
    if (/^Note: .* dates, higher prices are normal$/.test(r)) continue;
    if (!out.includes(r)) out.push(r);
  }
  return out.slice(0, 5);
}

function formatDealMessage(event, opts = {}) {
  const lines = [];
  const headline = alertHeadline(event);
  lines.push(opts.delayed ? `${headline} (delayed alert, Pro members get these instantly)` : headline);
  lines.push(`\u{1F3E8} ${event.hotelName}${event.rating != null ? `   ⭐ ${event.rating}${event.reviewCount ? ` (${event.reviewCount} reviews)` : ""}` : ""}`);
  const pct = eventSavingPct(event);
  lines.push(event.refPrice && event.refPrice > event.price
    ? `\u{1F4B0} ${formatINR(event.price)}  (was ${formatINR(event.refPrice)}${pct ? `, -${pct}%` : ""}, saves ${formatINR(event.refPrice - event.price)})`
    : `\u{1F4B0} ${formatINR(event.price)}${pct ? `  (-${pct}%)` : ""}`);
  const lead = typeof event.leadDays === "number" && event.type !== "last_minute" ? ` · ${leadLabel(event.leadDays)}` : "";
  lines.push(`\u{1F4C5} ${stayDatesText(event.checkin, event.checkout)}${lead}${event.holiday ? ` · ${event.holiday} dates` : ""}`);
  for (const r of tidyReasons(event)) lines.push(`✅ ${r}`);
  if (event.url) lines.push(event.url);
  return lines.join("\n");
}

function formatTeaserMessage(event, upgradeUrl) {
  const t = DEAL_EVENT_TYPES[event.type] || DEAL_EVENT_TYPES.drop;
  return [
    `\u{1F512} A ${t.label.toLowerCase()} just dropped in ${event.destination}${event.dropPct ? ` (-${event.dropPct}%)` : ""}.`,
    `Pro members saw it instantly with the hotel, dates and link.`,
    upgradeUrl ? `Upgrade: ${upgradeUrl}` : `Send /plan to see how to upgrade.`,
  ].join("\n");
}

// ---------------------------------------------------------------------------
// Plans + subscribers (the paid-alerts engine)
// ---------------------------------------------------------------------------

const ALL_EVENT_TYPES = Object.keys(DEAL_EVENT_TYPES);

// price = monthly INR, editable in the dashboard (settings.planPrices).
const PLANS = {
  free: { label: "Free", price: 0,   delayMinutes: 720, dailyCap: 2,  types: ["drop", "rare", "new", "record_low"], teasers: 1 },
  pro:  { label: "Pro",  price: 199, delayMinutes: 0,   dailyCap: 20, types: ["drop", "rare", "new", "discount", "last_minute", "error_fare", "record_low", "good_deal", "market_deal"], teasers: 0 },
  vip:  { label: "VIP",  price: 499, delayMinutes: 0,   dailyCap: 60, types: ALL_EVENT_TYPES, teasers: 0 },
};

function effectivePlanKey(sub, nowMs) {
  const key = PLANS[sub.plan] ? sub.plan : "free";
  if (key !== "free" && sub.expiresAt && new Date(sub.expiresAt).getTime() < nowMs) return "free";
  return key;
}

/**
 * What should happen to `event` for `sub` right now?
 * -> {action: "send"|"teaser"|"skip", sendAfterMs, reason, planKey, newSent}
 * Pure: the caller persists newSent onto the subscriber.
 */
function planDecision(sub, event, nowMs, opts = {}) {
  // plansEnabled === false (the default while the product is free): every
  // subscriber gets the VIP experience, nothing is delayed or gated.
  // Paying tiers are a switch away, not a rebuild.
  const planKey = opts.plansEnabled === false ? "vip" : effectivePlanKey(sub, nowMs);
  const plan = PLANS[planKey];
  const day = toISODate(new Date(nowMs));
  const sent = sub.sent && sub.sent.day === day ? { ...sub.sent } : { day, count: 0, teasers: 0 };
  const skip = (reason) => ({ action: "skip", reason, planKey, newSent: sent });

  if (!sub.active || !sub.telegramChatId) return skip("inactive");
  const dests = (sub.destinations || []).map((d) => d.toLowerCase());
  if (dests.length && !dests.includes(String(event.destination).toLowerCase())) return skip("destination_filter");
  if (sub.maxPrice && event.price > sub.maxPrice) return skip("over_budget");
  if (sub.minDropPct && event.dropPct != null && event.dropPct < sub.minDropPct && event.type !== "new") return skip("below_min_drop");

  if (!plan.types.includes(event.type)) {
    if (sent.teasers < (plan.teasers || 0)) {
      return { action: "teaser", reason: "plan_gate", planKey, newSent: { ...sent, teasers: sent.teasers + 1 } };
    }
    return skip("plan_gate");
  }
  if (sent.count >= plan.dailyCap) return skip("daily_cap");
  return {
    action: "send",
    sendAfterMs: nowMs + plan.delayMinutes * 60000,
    delayed: plan.delayMinutes > 0,
    reason: "ok",
    planKey,
    newSent: { ...sent, count: sent.count + 1 },
  };
}

/** Subscriber-count/revenue summary for the Business tab. Counts before revenue. */
function summarizeSubscribers(subs, nowMs, planPrices = {}) {
  const out = { total: subs.length, active: 0, free: 0, pro: 0, vip: 0, expiringSoon: 0, mrr: 0 };
  for (const s of subs) {
    if (!s.active) continue;
    out.active++;
    const key = effectivePlanKey(s, nowMs);
    out[key]++;
    if (key !== "free") {
      out.mrr += planPrices[key] ?? PLANS[key].price;
      if (s.expiresAt) {
        const left = new Date(s.expiresAt).getTime() - nowMs;
        if (left >= 0 && left < 7 * 86400000) out.expiringSoon++;
      }
    }
  }
  return out;
}

// ---------------------------------------------------------------------------
// Smart scan ordering
// ---------------------------------------------------------------------------

function stepKey(step) {
  return `${step.site}|${step.destinationName}|${step.checkin}`;
}

/**
 * v2.0.2: how often to scan. "normal" is the old cadence; "more" (the default) scans
 * the full set every 6 hours and re-checks the nearest weekends every few hours;
 * "max" every 3 hours. Faster rescans only touch stays that are stale by that
 * profile (the nearest dates first), so far-away dates stay once a day, which keeps
 * the page loads MakeMyTrip sees, and so how often it blocks, reasonable.
 */
const SCAN_PROFILES = {
  normal: { scanEveryMin: 12 * 60, sweepEveryMin: 90, rescan: [3, 12, 24, 24] },
  more:   { scanEveryMin: 6 * 60,  sweepEveryMin: 60, rescan: [2, 6, 12, 24] },
  max:    { scanEveryMin: 3 * 60,  sweepEveryMin: 45, rescan: [2, 4, 8, 24] },
};
function scanProfile(name) { return SCAN_PROFILES[name] || SCAN_PROFILES.normal; }

/** How long a step's data counts as fresh: the nearer the stay, the faster prices move. rescan = [<=3 days, <=14, <=30, beyond]. */
function minRescanHours(lead, profileName) {
  const r = scanProfile(profileName).rescan;
  if (lead <= 3) return r[0];
  if (lead <= 14) return r[1];
  if (lead <= 30) return r[2];
  return r[3];
}

/**
 * Higher = scan sooner. Urgency (how close the stay is) dominates, then
 * destinations that have been moving recently, favorites' destinations,
 * and how long since this exact step was last checked.
 * ctx = {nowMs, freshness: {stepKey: ms}, volatility: {dest: 0..1},
 *        hotDestinations: Set, favoriteDestinations: Set}
 */
function scoreScanStep(step, ctx) {
  const lead = daysBetweenISO(toISODate(new Date(ctx.nowMs)), step.checkin);
  let s;
  if (lead <= 0) s = 100;
  else if (lead <= 3) s = 85 - lead * 5;
  else if (lead <= 7) s = 55;
  else if (lead <= 14) s = 35;
  else s = Math.max(5, 25 - lead / 4);

  s += (ctx.volatility[step.destinationName] || 0) * 25;
  if (ctx.hotDestinations && ctx.hotDestinations.has(step.destinationName)) s += 15;
  if (ctx.favoriteDestinations && ctx.favoriteDestinations.has(step.destinationName)) s += 10;

  const last = ctx.freshness[stepKey(step)];
  s += last ? Math.min((ctx.nowMs - last) / 3600000, 72) / 72 * 30 : 35;
  return s;
}

/**
 * Sorts by score and (when skipFresh) drops steps checked more recently
 * than minRescanHours(lead). Stable for equal scores. Pure.
 */
function prioritizeSteps(steps, ctx, opts = {}) {
  const today = toISODate(new Date(ctx.nowMs));
  let list = steps.map((step, i) => ({ step, i, score: scoreScanStep(step, ctx) }));
  if (opts.skipFresh) {
    list = list.filter(({ step }) => {
      const last = ctx.freshness[stepKey(step)];
      if (!last) return true;
      const lead = daysBetweenISO(today, step.checkin);
      return (ctx.nowMs - last) / 3600000 >= minRescanHours(lead, opts.profile);
    });
  }
  list.sort((a, b) => b.score - a.score || a.i - b.i);
  let out = list.map((x) => x.step);
  if (opts.maxSteps) out = out.slice(0, opts.maxSteps);
  return out;
}

/** 0..1 per destination from how many drop-type events it produced in the last `days`. */
function destinationVolatility(events, nowMs, days = 14) {
  const cutoff = nowMs - days * 86400000;
  const counts = {};
  for (const e of events || []) {
    if (new Date(e.at).getTime() >= cutoff) counts[e.destination] = (counts[e.destination] || 0) + 1;
  }
  const out = {};
  for (const [d, n] of Object.entries(counts)) out[d] = Math.min(1, n / 5);
  return out;
}

/** Window for tonight (lead 0): last-minute scans start here, the weekly windows never include it. */
function todayWindow(nights, today = new Date()) {
  const start = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  const checkout = new Date(start);
  checkout.setDate(checkout.getDate() + nights);
  return { checkin: toISODate(start), checkout: toISODate(checkout) };
}

// ---------------------------------------------------------------------------
// Storage helpers (the only chrome.storage users in this file)
// ---------------------------------------------------------------------------

async function loadDealEvents() {
  const { dealEvents = [] } = await chrome.storage.local.get("dealEvents");
  return dealEvents;
}

/** Records the event in the feed. Not serialized: callers run it via notifyDealEvent's lock. */
async function recordDealEvent(event) {
  const events = await loadDealEvents();
  await chrome.storage.local.set({ dealEvents: addDealEvent(events, event) });
}

/** Last N public-safe events for the published deals.json feed. */
function publicFeed(events, limit = 100) {
  return (events || []).slice(0, limit).map((e) => ({
    id: e.id, at: e.at, type: e.type, hotelName: e.hotelName, destination: e.destination,
    source: e.source, starRating: e.starRating, checkin: e.checkin, checkout: e.checkout,
    price: e.price, refPrice: e.refPrice, dropPct: e.dropPct, leadDays: e.leadDays,
    isNewlyBuilt: e.isNewlyBuilt, url: e.url,
  }));
}

// ---------------------------------------------------------------------------
// Subscriber bot commands (pure: returns what to say and what to change)
// ---------------------------------------------------------------------------

/**
 * Interprets one Telegram message from a subscriber. `sub` is their stored
 * record or null (first contact). Returns {reply, patch} where patch is
 * merged into the subscriber (created if new). Free text gets the help
 * text rather than being ignored, so nobody is left wondering if it works.
 */
function subscriberCommandReply(text, sub, opts = {}, nowMs = Date.now()) {
  const raw = String(text || "").trim();
  const [cmdRaw, ...rest] = raw.split(/\s+/);
  const cmd = cmdRaw.toLowerCase().replace(/@\w+$/, "");
  const arg = rest.join(" ").trim();
  const prices = opts.planPrices || {};
  const help = [
    "Commands:",
    "/best Digha next friday - the best stays for a place and weekend (plain words work too)",
    "/plan - your plan and how to upgrade",
    "/destinations Digha, Puri - only these places (or /destinations all)",
    "/budget 5000 - only stays up to this price (or /budget off)",
    "/stop - pause alerts, /start to resume",
  ].join("\n");

  if (cmd === "/start" && opts.plansEnabled === false) {
    return {
      patch: { active: true },
      reply: [
        "\u{1F44B} You're in. I send hotel price drops for weekend getaways from Kolkata, free for everyone right now.",
        "You get every alert as it happens, including last-minute deals.",
        "",
        help,
      ].join("\n"),
    };
  }
  if (cmd === "/start") {
    return {
      patch: { active: true },
      reply: [
        "\u{1F44B} You're in. I send hotel price drops for weekend getaways from Kolkata.",
        `Free plan: up to ${PLANS.free.dailyCap} alerts a day, delayed by ${PLANS.free.delayMinutes / 60}h.`,
        `Pro (Rs ${prices.pro ?? PLANS.pro.price}/mo): instant alerts, last-minute deals, ${PLANS.pro.dailyCap} a day.`,
        "",
        help,
      ].join("\n"),
    };
  }
  if (cmd === "/stop") return { patch: { active: false }, reply: "Alerts paused. Send /start any time to resume." };
  if (cmd === "/plan" && opts.plansEnabled === false) {
    return { patch: {}, reply: "Everything is free for everyone right now: instant alerts, all deal types, last-minute included." };
  }
  if (cmd === "/plan") {
    const key = sub ? effectivePlanKey(sub, nowMs) : "free";
    const p = PLANS[key];
    const lines = [
      `Your plan: ${p.label}${sub && sub.expiresAt && key !== "free" ? ` (until ${String(sub.expiresAt).slice(0, 10)})` : ""}`,
      `Alerts: ${p.dailyCap}/day, ${p.delayMinutes ? `delayed ${p.delayMinutes / 60}h` : "instant"}`,
      `Includes: ${p.types.map((t) => DEAL_EVENT_TYPES[t].label).join(", ")}`,
    ];
    if (key === "free") {
      lines.push(`Pro: Rs ${prices.pro ?? PLANS.pro.price}/mo, VIP: Rs ${prices.vip ?? PLANS.vip.price}/mo`);
      lines.push(opts.upgradeUrl ? `Upgrade: ${opts.upgradeUrl}` : "Reply to the person who sent you this bot to upgrade.");
    }
    return { patch: {}, reply: lines.join("\n") };
  }
  if (cmd === "/destinations") {
    if (!arg || /^(all|any|everywhere)$/i.test(arg)) return { patch: { destinations: [] }, reply: "Watching all destinations." };
    const list = arg.split(/[,;]+/).map((x) => x.trim()).filter(Boolean).slice(0, 10);
    return { patch: { destinations: list }, reply: `Watching: ${list.join(", ")}` };
  }
  if (cmd === "/budget") {
    if (!arg || /^(off|none|any)$/i.test(arg)) return { patch: { maxPrice: null }, reply: "No budget limit." };
    const n = Number(arg.replace(/[^\d]/g, ""));
    if (!n || n < 500) return { patch: {}, reply: "Send a number like /budget 5000" };
    return { patch: { maxPrice: n }, reply: `Only stays up to Rs ${n}.` };
  }
  return { patch: {}, reply: help };
}

// ---------------------------------------------------------------------------
// Channel quality gate: only GREAT deals go to the public channel
// ---------------------------------------------------------------------------

const CHANNEL_DEFAULTS = {
  greatDealMinDropPct: 25, // drop/discount must be at least this to count as great
  greatLastMinutePct: 15,  // last-minute needs a bit more than the generic 10%
  channelMaxPerDay: 8,     // quality over volume: a noisy channel gets muted
  minPrice: 800,           // below this it's a basic room / mis-scrape, not a deal
};

/**
 * Is this event worth posting to the public channel? Rare deals always
 * (they already passed a strict statistical test), last-minute drops of
 * 15%+, ordinary drops/discounts of 25%+. Newly-built-only events never
 * (that's a vlogging signal, not a deal). Hotels with a poor guest rating
 * are held back no matter how cheap: a deal on a bad hotel is not a deal.
 */
function isGreatDeal(event, opts = {}) {
  const o = { ...CHANNEL_DEFAULTS, ...opts };
  if (!event || typeof event.price !== "number" || event.price < o.minPrice) return false;
  if (event.rating != null && event.reviewCount != null && event.reviewCount >= 10 && event.rating < 3.5) return false;
  if (event.type === "rare" || event.type === "error_fare" || event.type === "record_low") return true;
  if (event.type === "last_minute") return (event.dropPct || 0) >= o.greatLastMinutePct;
  if (event.type === "drop" || event.type === "discount" || event.type === "good_deal" || event.type === "market_deal") return (event.dropPct || 0) >= o.greatDealMinDropPct;
  return false;
}

/**
 * Daily cap + de-duplication for channel posts. state = {day, count, keys}
 * (keys = hotel|checkin posted today, so the same stay isn't posted twice
 * for two different reasons). Returns {post, newState, reason}.
 */
function channelPostDecision(event, state, nowMs, opts = {}) {
  const o = { ...CHANNEL_DEFAULTS, ...opts };
  const day = toISODate(new Date(nowMs));
  const cur = state && state.day === day ? state : { day, count: 0, keys: [] };
  const key = `${event.source}|${event.hotelName}|${event.destination}|${event.checkin}`;
  if (cur.keys.includes(key)) return { post: false, newState: cur, reason: "duplicate" };
  // (the key above is per hotel and check-in; one hotel is also posted at most once a day, whatever the dates)
  if (cur.keys.includes(`${event.source}|${event.hotelName}|${event.destination}`)) return { post: false, newState: cur, reason: "duplicate" };
  if (cur.count >= o.channelMaxPerDay) return { post: false, newState: cur, reason: "daily_cap" };
  return { post: true, newState: { day, count: cur.count + 1, keys: [...cur.keys, key, `${event.source}|${event.hotelName}|${event.destination}`].slice(-100) }, reason: "ok" };
}

function formatChannelPost(event) {
  const base = formatDealMessage(event);
  return `${base}\n\n\u{1F514} Free deal alerts for Kolkata weekend getaways. Tap the channel name to follow.`;
}

// ---------------------------------------------------------------------------
// Junk scoring: which tracked hotels are not worth anyone's attention
// ---------------------------------------------------------------------------

const JUNK_SUGGEST_THRESHOLD = 50;

/**
 * 0..100 "probably not worth tracking" with the reasons, so the swipe queue
 * can put the obvious rejects first and a person can clear them in
 * seconds. group = a loadTrackedHotelGroups() entry. Newly built
 * properties are exempt from the "no reviews" penalties (they have none yet).
 */
function junkScore(group) {
  const reasons = [];
  let score = 0;
  const add = (pts, why) => { score += pts; reasons.push(why); };
  const rating = group.rating, reviews = group.reviewCount;
  const tier = group.manualStarTier ?? group.starRating ?? group.aiEstimatedStarTier ?? null;

  if (rating != null && reviews != null && reviews >= 15 && rating < 3.5) add(55, `Low guest rating: ${rating} from ${reviews} reviews`);
  else if (rating != null && reviews != null && reviews >= 100 && rating < 3.9) add(25, `Mediocre rating: ${rating} from ${reviews} reviews`);
  if (!group.isNewlyBuilt) {
    if (rating == null && (reviews == null || reviews === 0)) add(25, "No guest rating at all");
    else if (reviews != null && reviews < 5) add(12, `Only ${reviews} review(s), not enough to trust`);
  }
  if (tier != null && tier < 3) add(30, `Only ${tier} star`);
  if (/\b(hostel|dorm|dormitory|bunk|lodge|dharamshala|guest\s?house)\b/i.test(group.hotelName || "")) add(30, "Looks like a hostel / basic lodge");
  if (typeof group.cheapestPrice === "number" && group.cheapestPrice < 800) add(25, `Very cheap (${formatINR(group.cheapestPrice)}), probably a basic room`);
  if (group.hasFlaggedDates) add(15, "Some prices look mis-scraped");
  return { score: Math.min(100, score), reasons, suggestRemove: score >= JUNK_SUGGEST_THRESHOLD };
}

// ---------------------------------------------------------------------------
// Google rating lookup (Places API "New" Text Search, your own API key)
// ---------------------------------------------------------------------------

/**
 * Stricter than the YouTube matcher: a hotel whose whole name is generic
 * words ("The Resort") can never be confirmed from a single shared word,
 * so it needs the full normalised name to match.
 */
function googleNameMatch(hotelName, destination, placeName) {
  const norm = (s) => String(s || "").toLowerCase().replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
  const destWords = new Set(significantWords(destination));
  const sig = significantWords(hotelName).filter((w) => !destWords.has(w));
  const place = norm(placeName);
  if (sig.length === 0) return norm(hotelName) === place;
  // every distinctive word must appear (not just one): "Sea Pearl Resort" must not match "Sea View Resort"
  return sig.every((w) => place.includes(w));
}

function pickGooglePlace(places, hotelName, destination) {
  for (const p of places || []) {
    const name = p.displayName && p.displayName.text;
    if (name && typeof p.rating === "number" && googleNameMatch(hotelName, destination, name)) {
      return {
        rating: p.rating, reviews: p.userRatingCount ?? null, url: p.googleMapsUri || null, matchedName: name,
        // photo resource names (not URLs: a URL needs the API key, built at display time) and up to 3 review snippets
        photos: (p.photos || []).map((ph) => ph && ph.name).filter(Boolean).slice(0, 4),
        reviewList: (p.reviews || []).slice(0, 3).map((r) => ({
          rating: r.rating ?? null,
          text: String((r.text && r.text.text) || (r.originalText && r.originalText.text) || "").replace(/\s+/g, " ").trim().slice(0, 260),
          author: (r.authorAttribution && r.authorAttribution.displayName) || "",
          when: r.relativePublishTimeDescription || "",
        })).filter((r) => r.text),
      };
    }
  }
  return null;
}

/**
 * One Text Search call (billed by Google at the tier of the most expensive
 * field requested, rating is one, see the README for the cost note).
 * Returns {rating, reviews, url, matchedName} or null when nothing
 * genuinely matched; throws on HTTP errors so callers can stop on a bad key.
 */
async function fetchGoogleRating(hotelName, destination, apiKey, extras = false) {
  const resp = await fetch("https://places.googleapis.com/v1/places:searchText", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Goog-Api-Key": apiKey,
      // photos + reviews put the call in a pricier Google tier, so only when asked for
      "X-Goog-FieldMask": "places.displayName,places.rating,places.userRatingCount,places.googleMapsUri" + (extras ? ",places.photos,places.reviews" : ""),
    },
    body: JSON.stringify({ textQuery: `${hotelName}, ${destination}, India`, maxResultCount: 3 }),
  });
  if (!resp.ok) {
    const body = await resp.text().catch(() => "");
    throw new Error(`Google Places ${resp.status}: ${body.slice(0, 160)}`);
  }
  const data = await resp.json();
  return pickGooglePlace(data.places, hotelName, destination);
}

// ---------------------------------------------------------------------------
// Confirm before alerting
// ---------------------------------------------------------------------------

/**
 * Decide what to do with a deal after re-checking its detail page.
 * lowestNow = the lowest plausible price found on the re-check (null if the
 * page could not be read). Within 5% of (or below) the alerted price means
 * it holds. Clearly higher means the first reading was wrong (a coupon
 * banner, a stale card) and the alert is dropped. Unreadable means we
 * cannot tell: send it, flagged, rather than silently lose a real deal.
 */
function confirmDecision(alertedPrice, lowestNow) {
  if (typeof lowestNow !== "number" || lowestNow < 300) return "unverified";
  return lowestNow <= alertedPrice * 1.05 ? "confirmed" : "cancel";
}

/** Which events are worth the extra page load of a re-check. */
function needsConfirmation(event) {
  return event.type === "last_minute" || event.type === "rare" || isGreatDeal(event);
}

// ---------------------------------------------------------------------------
// v1.39: fair price, holidays, desperate hotels, error fares, missing hotels,
// weather, digest, watches, calendar, value, lead curve, film gaps
// ---------------------------------------------------------------------------

function medianOf(values) {
  const v = values.filter((x) => typeof x === "number").sort((a, b) => a - b);
  if (v.length === 0) return null;
  const mid = Math.floor(v.length / 2);
  return v.length % 2 ? v[mid] : (v[mid - 1] + v[mid]) / 2;
}

/**
 * "Fair price" of one stay: the median of everything it has cost so far
 * (needs minPoints observations, default 6, so one or two scans never
 * define "normal"). Sticker discounts are judged against this, not against
 * the site's own crossed-out price.
 */
function fairPriceFor(prices, minPoints = 6) {
  const real = (prices || []).filter((p) => typeof p.price === "number" && p.price >= 300).map((p) => p.price);
  return robustUsual(real, minPoints);
}

/**
 * v2.0.2: the USUAL price of a stay from its readings, with absurd lows (an error
 * fare, a glitch: half the typical price or less) left out before the median is
 * taken. So one or two insane readings, say Rs 500 on a Rs 5,000 stay, never become
 * "normal" and never hide a later 70%-off price. n counts every reading, core only
 * the ones used. (If MOST readings were insane the usual price would be insane too;
 * error fares are fixed within hours, so that is not a case worth contorting for.)
 */
function robustUsual(readings, minPoints = 6) {
  const real = (readings || []).filter((n) => typeof n === "number" && n >= 300);
  if (real.length < minPoints) return null;
  const m0 = medianOf(real);
  const keep = real.filter((n) => n >= m0 * 0.5);
  const use = keep.length >= Math.max(3, Math.ceil(real.length * 0.5)) ? keep : real;
  return { fair: Math.round(medianOf(use)), n: real.length, core: use.length, outliers: real.length - use.length };
}

/** A price at or under 40% of the usual one is more likely a mistake (by the hotel or the scrape) than a deal. */
function isErrorFare(price, fairInfo, ratio = 0.4, minPoints = 8) {
  return !!(fairInfo && fairInfo.n >= minPoints && typeof price === "number" && price >= 300 && price <= fairInfo.fair * ratio);
}

/**
 * Three price drops in a row (one reading per calendar day, each drop at
 * least 2%): the hotel is probably not filling up.
 */
function isDesperate(prices) {
  const byDay = new Map();
  for (const p of prices || []) {
    if (typeof p.price === "number" && p.price >= 300 && p.at) byDay.set(toISODate(new Date(p.at)), p.price);
  }
  const days = [...byDay.entries()].sort((a, b) => a[0].localeCompare(b[0])).map((e) => e[1]);
  if (days.length < 4) return false;
  const last = days.slice(-4);
  for (let i = 1; i < last.length; i++) if (last[i] > last[i - 1] * 0.98) return false;
  return true;
}

// Editable in the Business tab. Dates are my best knowledge, not an official
// calendar: check Durga Puja and Diwali against the real almanac for the year.
const DEFAULT_HOLIDAY_TEXT = [
  "2026-10-16..2026-10-21 Durga Puja",
  "2026-11-07..2026-11-09 Diwali and Kali Puja",
  "2026-12-24..2027-01-02 Christmas and New Year",
  "2027-01-23..2027-01-26 Republic Day long weekend",
  "2027-08-13..2027-08-15 Independence Day weekend",
].join("\n");

function parseHolidayText(text) {
  const out = [];
  for (const line of String(text || "").split(/\r?\n/)) {
    const m = /^\s*(\d{4}-\d{2}-\d{2})\s*\.\.\s*(\d{4}-\d{2}-\d{2})\s+(.+?)\s*$/.exec(line);
    if (m && m[1] <= m[2]) out.push({ from: m[1], to: m[2], name: m[3] });
  }
  return out;
}

/** The holiday a stay overlaps, or null. */
function holidayFor(checkin, checkout, windows) {
  for (const w of windows || []) {
    if (checkin <= w.to && (checkout || checkin) >= w.from) return w.name;
  }
  return null;
}

/** One plain sentence on why this price is good, built only from real numbers. */
function buildWhyLine(info) {
  const parts = [];
  if (info.fair && info.price < info.fair) {
    parts.push(`${Math.round(((info.fair - info.price) / info.fair) * 100)}% under its usual ${formatINR(info.fair)}`);
  }
  if (info.lowestInDays && info.lowestInDays >= 7) parts.push(`lowest in ${info.lowestInDays} days of tracking`);
  if (info.rating != null) parts.push(`rated ${info.rating}${info.reviewCount ? ` by ${info.reviewCount} guests` : ""}`);
  if (info.holiday && info.fair && info.price < info.fair) parts.push(`cheap even for ${info.holiday}`);
  return parts.length ? parts.join(", ") : "";
}

/** Days of tracking if this price is the lowest the ledger has ever recorded (needs 5+ points), else null. */
function lowestInDays(prices, price, nowMs) {
  const real = (prices || []).filter((p) => typeof p.price === "number" && p.price >= 300 && p.at);
  if (real.length < 5) return null;
  if (real.some((p) => p.price <= price)) return null;
  return Math.max(1, Math.round((nowMs - new Date(real[0].at).getTime()) / 86400000));
}

/**
 * "Lowest ever" for one stay (one hotel, one pair of dates), v1.44.6. The new
 * price must be clearly under EVERY verified earlier price, not just a tick
 * lower, and there must be enough history for "ever" to mean something:
 * at least minPoints readings over at least minDays different days (the very
 * first scans are always "the lowest so far"). When the stay has a usual price
 * it must also be well under that, so a hotel that merely wobbles around its
 * normal price never counts. Needs no stored flag: once this price is in the
 * history it is the new low, so the same price can't fire twice and only a
 * further clear drop can.
 * -> {fire, prevLow, prevLowAt, belowPrevPct, belowFairPct}
 */
// ---------------------------------------------------------------------------
// v2.0.0: the alert gate. Before this, every listing could alert on every scan:
// a sticker discount that stayed on the site fired again each scan, a price that
// flipped between two values fired a "drop" each time it flipped down, every
// hotel/date pair alerted on its own, far-away and midweek dates counted like a
// Friday next week, and the owner's chat had no limit at all. Now an event must
// pass alertGate(), only urgent ones ping at once (alertClass), one ping per hotel
// per day, and the rest are batched into a digest.
// ---------------------------------------------------------------------------

const ALERT_DEFAULTS = {
  minPrice: 1000,          // below this it is a basic room or a farmstay, not a resort stay
  minSaving: 400,          // Rs saved versus the reference price; less is not worth a message
  minRating: 3.8,          // with 10+ reviews
  horizonDays: 42,         // a weekend further away than this is not worth a ping yet
  cooldownHours: 24,       // the same stay is not alerted again within this ...
  stickerCooldownDays: 7,  // ... (a sticker discount: this long) unless it falls a further reAlertBelowPct
  reAlertBelowPct: 10,
  dropBelowFairPct: 8,     // a "drop" must also be this far under the stay's usual price, or it is just a spike recovering
  discountBelowFairPct: 10, // a sticker discount counts only if the price is this far under usual
  pingMaxPerDay: 6,        // urgent pings to the owner per day
  digestEveryHours: 3,
  digestItems: 6,
};

const ALERT_DORM_RE = /\b(hostel|hostels|dorm|dorms|dormitory|bunk|backpackers?|dharamshala|farm\s?stays?|home\s?stays?|guest\s?houses?|lodge|lodges)\b/i;
const NOW_TYPES = new Set(["error_fare", "record_low", "last_minute", "rare"]);

/** "now" = worth an immediate message; "digest" = batched. */
function alertClass(event) {
  if (!event) return "digest";
  if (NOW_TYPES.has(event.type) || event.gold) return "now"; // gold = a hotel you have stayed at or filmed
  // A really big saving on a well-rated hotel is worth a message of its own.
  if (["drop", "good_deal", "market_deal"].includes(event.type) && (event.dropPct || 0) >= 40 && (event.rating || 0) >= 4.0) return "now";
  return "digest";
}
function stayKeyOfEvent(e) { return [e.source, e.hotelName, e.destination, e.checkin, e.checkout].join("|"); }
function hotelKeyOfEvent(e) { return `${e.source}:::${e.hotelName}:::${e.destination}`; }

/**
 * Is this event worth anyone's attention? ctx = {nowMs, cooldown: {price, at}|null, isGold, opts}.
 * -> {ok: true} or {ok: false, reason}. Pure.
 */
function alertGate(event, ctx = {}) {
  const o = { ...ALERT_DEFAULTS, ...definedOnly(ctx.opts || {}) };
  const nowMs = ctx.nowMs ?? Date.now();
  const no = (reason) => ({ ok: false, reason });
  if (!event || typeof event.price !== "number") return no("no_price");
  const gold = !!ctx.isGold;

  // Under the floor is a basic room, unless the stay is normally a real resort price
  // (usual Rs 2,500+): then Rs 600 is an error fare worth knowing about, not a cheap room.
  if (event.price < o.minPrice && !(event.fairPrice && event.fairPrice >= 2500)) return no("cheap_room");
  if (ALERT_DORM_RE.test(event.hotelName || "")) return no("hostel");
  if (!gold && event.rating != null && event.reviewCount != null && event.reviewCount >= 10 && event.rating < o.minRating) return no("poor_rating");

  // Relevance: a stay within a week (any day), or a weekend (starts Fri/Sat) inside the horizon.
  const lead = typeof event.leadDays === "number" ? event.leadDays : Math.round((new Date(`${event.checkin}T00:00:00`).getTime() - nowMs) / 86400000);
  if (lead < -1) return no("past");
  const wd = new Date(`${event.checkin}T00:00:00`).getDay();
  const weekend = wd === 5 || wd === 6;
  if (!(lead <= 7 || (weekend && lead <= o.horizonDays))) return no("not_relevant");

  if (event.refPrice && event.type !== "new" && event.refPrice - event.price < (gold ? o.minSaving / 2 : o.minSaving)) return no("small_saving");

  if (event.type === "discount") {
    if (!(event.fairPrice && event.price <= event.fairPrice * (1 - o.discountBelowFairPct / 100))) return no("sticker_only");
  }
  if (event.type === "drop" && !gold && event.fairPrice && event.price > event.fairPrice * (1 - o.dropBelowFairPct / 100)) return no("drop_not_below_usual");

  const cd = ctx.cooldown;
  if (cd && typeof cd.price === "number" && cd.at) {
    const hours = event.type === "discount" ? o.stickerCooldownDays * 24 : o.cooldownHours;
    // Held back only if it is about the SAME price we already told you about. A clearly higher
    // price (25%+) is a different deal: the earlier insane price went away and this one is new
    // (an error fare at Rs 500 must not silence a real 70% deal at Rs 1,500 an hour later).
    // Any of the recent price levels counts (cd.recent), not only the latest one.
    const levels = Array.isArray(cd.recent) && cd.recent.length ? cd.recent : [cd];
    for (const lv of levels) {
      const similar = event.price > lv.price * (1 - o.reAlertBelowPct / 100) && event.price <= lv.price * 1.25;
      if (similar && nowMs - new Date(lv.at).getTime() < hours * 3600000) return no("cooldown");
    }
  }
  return { ok: true };
}

/** Daily budget of urgent pings and one ping per hotel per day. state = {day, count, hotels:{}}. */
function ownerPingDecision(state, event, nowMs, opts = {}) {
  const max = opts.max ?? ALERT_DEFAULTS.pingMaxPerDay;
  const day = toISODate(new Date(nowMs));
  const cur = state && state.day === day ? { day, count: state.count || 0, hotels: { ...(state.hotels || {}) } } : { day, count: 0, hotels: {} };
  const hk = hotelKeyOfEvent(event);
  // One ping per hotel per day, unless it has since fallen a further 10% (then it is news again).
  const last = cur.hotels[hk];
  // (or a clearly different price level, 25%+ higher: the earlier one was a glitch that went away)
  if (last && !(typeof last === "number" && (event.price <= last * 0.9 || event.price >= last * 1.25))) return { send: false, reason: "hotel_today", newState: cur };
  if (cur.count >= max) return { send: false, reason: "daily_cap", newState: cur };
  return { send: true, reason: "ok", newState: { day, count: cur.count + 1, hotels: { ...cur.hotels, [hk]: event.price } } };
}

/** How interesting a batched deal is: size of the saving, rating, how soon the weekend is, type. */
function digestScore(event) {
  const pct = typeof event.dropPct === "number" ? event.dropPct : 10;
  const rating = event.rating != null ? Math.min(1.1, event.rating / 4) : 0.9;
  const lead = typeof event.leadDays === "number" ? event.leadDays : 30;
  const soon = lead <= 14 ? 1.2 : lead <= 28 ? 1.05 : 0.95;
  const w = { market_deal: 1, good_deal: 1, drop: 0.9, discount: 0.7, new: 0.45 }[event.type] ?? 0.8;
  return Math.round(pct * rating * soon * w * 10) / 10;
}

/** Adds an item to the digest queue: one entry per hotel, the better stay wins, the other dates are remembered. Newest-first cap 60. */
function mergeDigestQueue(queue, item, nowMs) {
  const hk = hotelKeyOfEvent(item.event);
  const list = [...(queue || [])];
  const i = list.findIndex((q) => q.hotelKey === hk);
  const mine = { hotelKey: hk, event: item.event, reasons: item.reasons || [], listing: item.listing, at: new Date(nowMs).toISOString(), score: digestScore(item.event), otherDates: [] };
  if (i === -1) { list.push(mine); return list.slice(-60); }
  const old = list[i];
  const keepNew = mine.score > old.score;
  const winner = keepNew ? mine : old;
  const loser = keepNew ? old : mine;
  winner.otherDates = [...new Set([...(old.otherDates || []), ...(mine.otherDates || []), loser.event.checkin].filter((d) => d && d !== winner.event.checkin))].slice(0, 6);
  list[i] = winner;
  return list.slice(-60);
}

/**
 * The batched message: the best few deals, one line each, not one message per
 * hotel per date. wanted(item) filters per recipient (a subscriber's places and budget).
 */
function buildDigestText(queue, nowMs, opts = {}) {
  const o = { items: ALERT_DEFAULTS.digestItems, ...definedOnly(opts) };
  const fresh = (queue || []).filter((q) => nowMs - new Date(q.at).getTime() < 12 * 3600000);
  const list = (typeof opts.wanted === "function" ? fresh.filter(opts.wanted) : fresh).sort((a, b) => b.score - a.score);
  if (!list.length) return null;
  const shown = list.slice(0, o.items);
  const dateText = (e) => (typeof niceStayDates === "function" ? niceStayDates(e.checkin, e.checkout) : `${e.checkin} to ${e.checkout}`);
  const L = [`\u{1F4EC} Deal digest: ${list.length} new deal${list.length === 1 ? "" : "s"}, best first`, ""];
  shown.forEach((q, i) => {
    const e = q.event;
    const t = (DEAL_EVENT_TYPES[e.type] || {}).emoji || "";
    L.push(`${i + 1}. ${t} ${e.hotelName} (${e.destination})  ${formatINR(e.price)}`);
    L.push(`   ${dateText(e)}${(q.otherDates || []).length ? `, also cheap ${q.otherDates.slice(0, 3).join(", ")}` : ""}`);
    const why = (q.reasons || []).find((r) => /%|under|cheaper|below|record/i.test(r)) || (q.reasons || [])[0];
    if (why) L.push(`   ${String(why).replace(/\s+/g, " ").slice(0, 150)}`);
    if (e.url) L.push(`   ${e.url}`);
  });
  if (list.length > shown.length) L.push("", `+${list.length - shown.length} more are in the Deal Feed.`);
  return L.join("\n");
}

/**
 * "Are these deals actually good?" Re-runs the gate's rules over alerts already
 * recorded (what can be judged from the event alone: price, rating, dates,
 * saving, sticker-only) and counts how many would still be sent. Also how many
 * hotels they were spread over, which is the real number of pings that matter.
 */
function auditAlerts(events, nowMs, opts = {}) {
  const sinceMs = opts.sinceHours ? nowMs - opts.sinceHours * 3600000 : 0;
  const rows = (events || []).filter((e) => e && new Date(e.at).getTime() >= sinceMs);
  const reasons = {};
  let passed = 0;
  const passedHotels = new Set();
  for (const e of rows) {
    const g = alertGate(e, { nowMs: new Date(e.at).getTime(), opts: opts.gate });
    if (g.ok) { passed++; passedHotels.add(hotelKeyOfEvent(e)); }
    else reasons[g.reason] = (reasons[g.reason] || 0) + 1;
  }
  const hotels = new Set(rows.map(hotelKeyOfEvent));
  return { total: rows.length, passed, hotels: hotels.size, passedHotels: passedHotels.size, rejected: rows.length - passed, reasons };
}

const ALERT_REASON_TEXT = {
  cheap_room: "a basic room under Rs 1,000", hostel: "a hostel, farmstay, homestay or guest house", poor_rating: "a badly reviewed hotel", past: "a date in the past",
  not_relevant: "a far-away or midweek date", small_saving: "a saving under Rs 400", sticker_only: "only a sticker discount, not under its usual price",
  drop_not_below_usual: "a price recovering from a spike, not below usual", cooldown: "the same stay again within a day", no_price: "no price",
};

/** Compares dotted version strings: 1 if a is newer, -1 if older, 0 if equal ("2.0.0" > "1.44.9"). */
function cmpVersion(a, b) {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d > 0 ? 1 : -1;
  }
  return 0;
}

/** Strips anything that looks like a bot token, GitHub token or API key from text that is about to be copied or shown. */
function redactSecrets(text) {
  return String(text == null ? "" : text)
    .replace(/bot\d{5,}:[A-Za-z0-9_-]{20,}/g, "bot<token>")
    .replace(/\b\d{6,}:[A-Za-z0-9_-]{30,}\b/g, "<bot token>")
    .replace(/\b(ghp|gho|ghs|ghu)_[A-Za-z0-9]{20,}\b/g, "<github token>")
    .replace(/\bgithub_pat_[A-Za-z0-9_]{20,}\b/g, "<github token>")
    .replace(/\bAIza[0-9A-Za-z_-]{20,}\b/g, "<api key>")
    .replace(/\bHDT1\.[A-Za-z0-9_-]{40,}/g, "<setup code>");
}

/** Options with undefined/null/NaN left out, so a missing setting falls back to the default instead of overriding it. */
function definedOnly(opts) {
  const out = {};
  for (const [k, v] of Object.entries(opts || {})) if (v !== undefined && v !== null && v !== "" && !Number.isNaN(v)) out[k] = Number(v);
  return out;
}

function detectRecordLow(verifiedPrior, price, opts = {}) {
  const o = { minPoints: 5, minDays: 3, minBelowPrevPct: 5, minBelowFairPct: 10, ...definedOnly(opts) };
  const none = { fire: false };
  if (typeof price !== "number" || price < 300) return none;
  const real = (verifiedPrior || []).filter((p) => p && typeof p.price === "number" && p.price >= 300 && p.at);
  if (real.length < o.minPoints) return none;
  const days = new Set(real.map((p) => toISODate(new Date(p.at))));
  if (days.size < o.minDays) return none;
  // The previous best is the lowest CREDIBLE reading: an earlier absurd low (an error fare,
  // half the usual price or less) is not the record to beat, or one glitch would hide every
  // genuinely great price after it.
  const fairInfo = fairPriceFor(real);
  const floor = fairInfo ? fairInfo.fair * 0.5 : 0;
  const credible = real.filter((p) => p.price >= floor);
  const pool = credible.length ? credible : real;
  const prev = pool.reduce((a, b) => (b.price < a.price ? b : a));
  const insane = real.filter((p) => p.price < floor).sort((a, b) => a.price - b.price)[0] || null;
  const belowPrevPct = ((prev.price - price) / prev.price) * 100;
  if (belowPrevPct < o.minBelowPrevPct) return none;
  const belowFairPct = fairInfo ? ((fairInfo.fair - price) / fairInfo.fair) * 100 : null;
  if (belowFairPct !== null && belowFairPct < o.minBelowFairPct) return none;
  return { fire: true, prevLow: prev.price, prevLowAt: prev.at, belowPrevPct: Math.round(belowPrevPct), belowFairPct: belowFairPct === null ? null : Math.round(belowFairPct), fair: fairInfo ? fairInfo.fair : null, ignoredLow: insane ? insane.price : null };
}

/**
 * "A really good deal" (v1.44.6): the price is at least minBelowPct under what
 * this stay usually costs (its median, needs 6+ verified readings), whatever
 * the hotel did since the last scan. Fires once per dip and re-arms when the
 * price climbs back to within rearmBelowPct of usual (same fire-once pattern as
 * price targets), so a steadily cheap stay is one alert, not one per scan.
 * -> {fire, newState, belowPct}
 */
function evaluateGoodDeal(price, fairInfo, wasAlerted, opts = {}) {
  const o = { minBelowPct: 25, rearmBelowPct: 10, ...definedOnly(opts) };
  const was = !!wasAlerted;
  if (!fairInfo || typeof price !== "number" || price < 300) return { fire: false, newState: was };
  const belowPct = ((fairInfo.fair - price) / fairInfo.fair) * 100;
  if (belowPct >= o.minBelowPct) return { fire: !was, newState: true, belowPct: Math.round(belowPct) };
  if (belowPct < o.rearmBelowPct) return { fire: false, newState: false };
  return { fire: false, newState: was };
}

/** A cheap price on a badly reviewed hotel is not a deal worth interrupting anyone for. */
function isPoorlyRated(rating, reviewCount) {
  return rating != null && reviewCount != null && reviewCount >= 10 && rating < 3.5;
}

/**
 * Missing-hotel stages, computed from how long ago any of its dates was seen
 * in a listing while its destination WAS being scanned (so a place we simply
 * stopped scanning never loses its hotels). Active -> paused at 7 days
 * (hidden, comes back by itself the moment a scan lists it again) ->
 * stopped at 37 days (a permanent removal until you restore it).
 */
function missingStage(lastSeenMs, nowMs, destScannedRecently, opts = {}) {
  const pausedAfter = opts.pausedAfterDays ?? 7;
  const stoppedAfter = opts.stoppedAfterDays ?? 37;
  if (!destScannedRecently || !lastSeenMs) return "active";
  const days = (nowMs - lastSeenMs) / 86400000;
  if (days >= stoppedAfter) return "stopped";
  if (days >= pausedAfter) return "paused";
  return "active";
}

// --- weather (Open-Meteo, free, no key) ---

const DESTINATION_COORDS = {
  digha: [21.6275, 87.5093], mandarmani: [21.6667, 87.7], darjeeling: [27.041, 88.2663], sundarbans: [22.16, 88.8],
  puri: [19.8135, 85.8312], kolkata: [22.5726, 88.3639], gangtok: [27.3389, 88.6065], purulia: [23.332, 86.3649],
  shantiniketan: [23.6833, 87.6833], "west bengal": [22.9868, 87.855],
};

function openMeteoUrl(lat, lon) {
  return `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&daily=precipitation_sum,wind_speed_10m_max,weather_code&timezone=Asia%2FKolkata&forecast_days=16`;
}

function parseOpenMeteo(json) {
  const d = json && json.daily;
  if (!d || !Array.isArray(d.time)) return [];
  return d.time.map((date, i) => ({
    date,
    precip: d.precipitation_sum ? d.precipitation_sum[i] : null,
    wind: d.wind_speed_10m_max ? d.wind_speed_10m_max[i] : null,
    code: d.weather_code ? d.weather_code[i] : null,
  }));
}

/** "storm" | "rain" | "clear" | "mixed" for one forecast day. */
function weatherRisk(day) {
  if ((day.code != null && day.code >= 95) || (day.precip != null && day.precip >= 40) || (day.wind != null && day.wind >= 55)) return "storm";
  if (day.precip != null && day.precip >= 10) return "rain";
  if ((day.precip == null || day.precip < 2) && (day.code == null || day.code <= 3)) return "clear";
  return "mixed";
}

/** A short line for the stay's days, or empty when there is no forecast for those dates yet (the forecast reaches 16 days). */
function weatherNote(days, checkin, checkout) {
  const stay = (days || []).filter((d) => d.date >= checkin && d.date <= (checkout || checkin));
  if (stay.length === 0) return "";
  const risks = stay.map(weatherRisk);
  if (risks.includes("storm")) return "⛈ Storm or very heavy rain forecast for these dates, check before booking";
  if (risks.includes("rain")) return "\u{1F327} Rain forecast for part of this stay";
  if (risks.every((r) => r === "clear")) return "☀ Clear skies forecast, a cheap price AND good weather";
  return "";
}

// --- watches ("Track this hotel" buttons) ---

/** Short stable code for a hotel group key, used in t.me deep links (letters and digits only). */
function shortCode(str) {
  let h = 5381;
  for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) >>> 0;
  return h.toString(36);
}

/** True when a new price is a further drop on the watched stay since the watch (or last alert) base price. */
function watchTriggered(watch, price, checkin) {
  return watch.checkin === checkin && typeof price === "number" && price >= 300 && price <= watch.basePrice * 0.97;
}

// --- value score, calendar, lead curve, film gaps, digest ---

/** Higher = more hotel per rupee. Rating (default 3.5), amenities and star tier against price in thousands. */
function valueScore(g) {
  const price = g.cheapestPrice;
  if (!price) return 0;
  const tier = g.manualStarTier ?? g.starRating ?? g.aiEstimatedStarTier ?? 3;
  const quality = Math.max(0.5, (g.rating ?? 3.5) - 2) + Math.min((g.amenities || []).length, 4) * 0.15 + (tier - 3) * 0.2;
  return Math.round((quality / (price / 1000)) * 100) / 100;
}

/**
 * Cheapest-weekend calendar: for each destination and each upcoming
 * check-in date, the median current price across that destination's hotels,
 * and an index vs that destination's own overall median (1.0 = normal,
 * under 0.9 = cheap, over 1.1 = expensive). Only dates with 3+ hotels.
 */
function weekendIndex(groups, todayIso) {
  const byDest = {};
  for (const g of groups) {
    for (const d of g.dates || []) {
      if (d.checkin < todayIso || d.isLikelyBadScrape || d.verified === false) continue;
      ((byDest[g.destination] = byDest[g.destination] || {})[d.checkin] = (byDest[g.destination] || {})[d.checkin] || []).push(d.current);
    }
  }
  const out = {};
  for (const [dest, dates] of Object.entries(byDest)) {
    const meds = {};
    for (const [date, prices] of Object.entries(dates)) if (prices.length >= 3) meds[date] = medianOf(prices);
    const all = medianOf(Object.values(meds));
    if (all == null) continue;
    out[dest] = Object.keys(meds).sort().slice(0, 8).map((date) => ({ date, median: Math.round(meds[date]), index: Math.round((meds[date] / all) * 100) / 100 }));
  }
  return out;
}

/**
 * How prices behave as check-in approaches, from the ledger: for each stay,
 * every point's price relative to that stay's own median, grouped by lead
 * bucket. ratio under 1 in the 0-3 bucket means prices usually fall at the
 * last minute. Needs real volume to say anything.
 */
function leadCurve(histRecords) {
  const buckets = { "0-3": [], "4-7": [], "8-14": [], "15+": [] };
  for (const r of histRecords) {
    const pts = (r.prices || []).filter((p) => p.price >= 300 && p.lead != null && p.lead >= 0);
    if (pts.length < 6) continue;
    const med = medianOf(pts.map((p) => p.price));
    for (const p of pts) {
      const b = p.lead <= 3 ? "0-3" : p.lead <= 7 ? "4-7" : p.lead <= 14 ? "8-14" : "15+";
      buckets[b].push(p.price / med);
    }
  }
  const out = {};
  for (const [b, ratios] of Object.entries(buckets)) out[b] = { n: ratios.length, ratio: ratios.length ? Math.round(medianOf(ratios) * 100) / 100 : null };
  return out;
}

function bookAdvice(curve, minSamples = 30) {
  const near = curve["0-3"], far = curve["8-14"];
  if (!near || !far || near.n < minSamples || far.n < minSamples) return { advice: "not_enough_data", text: "Not enough history yet, needs a few more weeks of scans." };
  const diff = Math.round((far.ratio - near.ratio) * 100);
  if (diff >= 6) return { advice: "wait", text: `Usually about ${diff}% cheaper in the last 3 days. Waiting tends to pay off here.` };
  if (diff <= -6) return { advice: "book", text: `Usually about ${-diff}% dearer in the last 3 days. Book early here.` };
  return { advice: "either", text: "Price barely changes as the date gets close. Book when you like it." };
}

/** Hotels worth filming that nobody has covered yet: good rating or newly built, with 0 or 1 videos found. */
function filmGapList(groups, limit = 12) {
  return groups
    .filter((g) => g.youtubeCheckedAt && (g.youtubeVideoCount ?? 0) <= 1 && ((g.rating != null && g.rating >= 4.0) || g.isNewlyBuilt))
    .map((g) => ({ g, score: (g.isNewlyBuilt ? 3 : 0) + (g.rating || 0) + Math.min((g.reviewCount || 0) / 500, 1) }))
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((x) => x.g);
}

/** The 8am post: top stays for the coming weekend, by value, with real prices. */
function buildDigest(groups, weekendCheckin, limit = 5) {
  const rows = [];
  for (const g of groups) {
    const d = (g.dates || []).find((x) => x.checkin === weekendCheckin && !x.isLikelyBadScrape && x.verified !== false && x.current >= 800);
    if (!d) continue;
    if (g.rating != null && g.reviewCount >= 10 && g.rating < 3.8) continue;
    rows.push({ g, d, v: valueScore({ ...g, cheapestPrice: d.current }) });
  }
  rows.sort((a, b) => b.v - a.v);
  const top = rows.slice(0, limit);
  if (top.length === 0) return null;
  const lines = [`☀ This weekend (${weekendCheckin}): best value stays`, ""];
  top.forEach((r, i) => {
    lines.push(`${i + 1}. ${r.g.hotelName} (${r.g.destination}) ${formatINR(r.d.current)}${r.g.rating != null ? `, rated ${r.g.rating}` : ""}`);
  });
  return lines.join("\n");
}

// ---------------------------------------------------------------------------
// v1.40: helper computer (a second PC that scans its own share of destinations)
// ---------------------------------------------------------------------------

const HELPER_OVERLAP_HOURS = 72; // every upload re-sends the last 3 days, so a main PC that was off for a weekend loses nothing

/** File-safe device name: letters, digits, dash, underscore. */
function safeDeviceName(name) {
  const s = String(name || "").toLowerCase().replace(/[^a-z0-9_-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 32);
  return s || "helper";
}

/**
 * What a helper uploads: every hist: record changed in the window, carrying
 * ONLY the price points inside it (the receiving side merges point-by-point
 * by timestamp, so partial histories are fine and the file stays small),
 * plus the deal events from the same window.
 */
function buildHelperPayload(allEntries, deviceName, nowMs, overlapHours = HELPER_OVERLAP_HOURS) {
  const sinceIso = new Date(nowMs - overlapHours * 3600000).toISOString();
  const records = {};
  for (const [key, rec] of Object.entries(allEntries)) {
    if (!(key.startsWith("hist:") || key.startsWith("sky:")) || !rec || !Array.isArray(rec.prices) || !rec.updatedAt || rec.updatedAt < sinceIso) continue;
    records[key] = { ...rec, prices: rec.prices.filter((p) => p.at && p.at >= sinceIso) };
  }
  const events = ((allEntries.dealEvents) || []).filter((e) => e.at >= sinceIso);
  return { device: safeDeviceName(deviceName), uploadedAt: new Date(nowMs).toISOString(), since: sinceIso, records, events };
}

/** Rebuilds the listing object an alert needs from a stored deal event. */
function listingFromEvent(e) {
  return {
    source: e.source, hotelName: e.hotelName, destination: e.destination, checkin: e.checkin, checkout: e.checkout,
    discountedPrice: e.price, originalPrice: e.refPrice ?? null, discountPct: e.dropPct ?? null,
    starRating: e.starRating ?? null, isNewlyBuilt: !!e.isNewlyBuilt, rating: e.rating ?? null, reviewCount: e.reviewCount ?? null, url: e.url || null,
  };
}

/**
 * Splits imported events into ones to announce now (fresh, not seen, hotel not
 * removed) and ones to record silently (old, already seen, or removed hotels).
 * freshHours keeps a first connection from blasting out days of old news.
 */
function planEventImport(events, knownIds, blockedKeys, nowMs, freshHours = 6) {
  const known = new Set(knownIds);
  const announce = [], silent = [];
  for (const e of events || []) {
    if (!e || !e.id || known.has(e.id)) continue;
    const blocked = blockedKeys.has(`${e.source}:::${e.hotelName}:::${e.destination}`);
    if (!blocked && nowMs - new Date(e.at).getTime() <= freshHours * 3600000) announce.push(e);
    else silent.push(e);
  }
  return { announce, silent };
}

/** The slice of the main computer's state a helper needs to behave the same way. No credentials. */
function buildSharedState(settings, blockedHotels, goldHotels) {
  return {
    writtenAt: new Date().toISOString(),
    destinations: (settings.destinations || []).map((d) => ({ name: d.name, searchTerm: d.searchTerm, mmtCode: d.mmtCode || null, goibiboCode: d.goibiboCode || null })),
    nights: settings.nights, checkinWeekday: settings.checkinWeekday, lookaheadDays: settings.lookaheadDays,
    includeNext7Days: settings.includeNext7Days, minStarRating: settings.minStarRating, adults: settings.adults, rooms: settings.rooms,
    mmtDateFormat: settings.mmtDateFormat || null, holidayText: settings.holidayText ?? null,
    discountPctThreshold: settings.discountPctThreshold, priceDropPctThreshold: settings.priceDropPctThreshold,
    lastMinuteDays: settings.lastMinuteDays, lastMinuteDropPct: settings.lastMinuteDropPct,
    alertRecordLow: settings.alertRecordLow, recordLowMinBelowPct: settings.recordLowMinBelowPct,
    alertGoodDeals: settings.alertGoodDeals, goodDealBelowPct: settings.goodDealBelowPct,
    blockedHotels: blockedHotels || [], goldHotels: goldHotels || {},
  };
}

/** Applies shared state onto a helper's own settings, keeping its own per-destination scan times. Returns the new settings. */
function applySharedState(settings, shared) {
  const out = { ...settings };
  for (const k of ["nights", "checkinWeekday", "lookaheadDays", "includeNext7Days", "minStarRating", "adults", "rooms", "mmtDateFormat", "holidayText", "discountPctThreshold", "priceDropPctThreshold", "lastMinuteDays", "lastMinuteDropPct", "alertRecordLow", "recordLowMinBelowPct", "alertGoodDeals", "goodDealBelowPct"]) {
    if (shared[k] !== undefined) out[k] = shared[k];
  }
  const mine = new Map((settings.destinations || []).map((d) => [d.name.toLowerCase(), d]));
  out.destinations = (shared.destinations || []).map((d) => {
    const own = mine.get(d.name.toLowerCase());
    return { ...d, mmtCode: d.mmtCode || (own && own.mmtCode) || null, goibiboCode: d.goibiboCode || (own && own.goibiboCode) || null, lastScannedAt: own ? own.lastScannedAt : undefined };
  });
  return out;
}

const normPlace = (s) => String(s || "").toLowerCase().replace(/[^a-z]/g, "");

function placeEditDistance(a, b) {
  const m = a.length, n = b.length;
  if (!m) return n;
  if (!n) return m;
  let prev = Array.from({ length: n + 1 }, (_, j) => j);
  for (let i = 1; i <= m; i++) {
    const cur = [i];
    for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    prev = cur;
  }
  return prev[n];
}

/**
 * Reads a scan list ("Digha, Mandarmani") against the places you actually track
 * ("Mandarmoni"). Exact names match; a small spelling slip (Mandarmani for
 * Mandarmoni) is read as the closest place instead of silently matching nothing,
 * which is how Mandarmoni ended up scanned by no computer at all.
 * -> {matched: [names], fixed: [{entry, name}], unmatched: [entries]}
 */
function matchScanList(destNames, scanList) {
  const names = destNames || [];
  const matched = [], fixed = [], unmatched = [];
  for (const raw of scanList || []) {
    const entry = String(raw).trim();
    if (!entry) continue;
    const n = normPlace(entry);
    let hit = names.find((d) => normPlace(d) === n);
    let wasFixed = false;
    if (!hit && n.length >= 4) {
      const tol = n.length >= 8 ? 2 : n.length >= 5 ? 1 : 0;
      if (tol) {
        const best = names.map((d) => ({ d, dist: placeEditDistance(normPlace(d), n) })).filter((x) => x.dist <= tol).sort((a, b) => a.dist - b.dist)[0];
        if (best) { hit = best.d; wasFixed = true; }
      }
    }
    if (hit) { if (!matched.includes(hit)) matched.push(hit); if (wasFixed) fixed.push({ entry, name: hit }); }
    else unmatched.push(entry);
  }
  return { matched, fixed, unmatched };
}

/** The list rewritten with the real place names (what to save), plus what was corrected or not understood. */
function canonicalizeScanList(destNames, scanList) {
  const r = matchScanList(destNames, scanList);
  return { list: [...r.matched, ...r.unmatched], fixed: r.fixed, unmatched: r.unmatched };
}

// ---------------------------------------------------------------------------
// v2.0.16: Skyscanner cross-check. Skyscanner lists the same hotels with the cheapest price over many booking
// sites ("Cheapest from"). It is read for the places and nights in skyscannerWatch and compared with what
// MakeMyTrip shows for the same hotel and night.
// ---------------------------------------------------------------------------

const SKY_WORDS = new Set(["hotel", "hotels", "resort", "resorts", "inn", "beach", "spa", "the", "and", "guest", "house", "lodge", "residency", "cottage", "cottages", "villa", "stay", "stays", "mandarmani", "mandarmoni", "by", "on", "near", "in", "at", "a", "of", "with", "pool", "sea", "view", "beachfront"]);

/** The words that identify a hotel: lower case, no "!! Beach 1 Minute !!" tails or brackets, no filler words. */
function hotelNameTokens(name) {
  const cleaned = String(name || "").toLowerCase().replace(/!!.*$/, " ").replace(/\(.*?\)/g, " ").replace(/[^a-z0-9]+/g, " ").trim();
  return cleaned.split(" ").filter((w) => w && !SKY_WORDS.has(w));
}

/** 0..1: how likely two names are the same hotel (word overlap; identical word sets are 1). */
function hotelNameSimilarity(a, b) {
  const ta = hotelNameTokens(a), tb = hotelNameTokens(b);
  if (!ta.length || !tb.length) return 0;
  const sa = new Set(ta), sb = new Set(tb);
  let both = 0;
  for (const w of sa) if (sb.has(w)) both++;
  return both / (sa.size + sb.size - both);
}

/** Storage key of one hotel on one night as seen on Skyscanner. */
function skyKey(destination, hotelName, checkin, checkout) {
  const id = hotelNameTokens(hotelName).join("-") || String(hotelName).toLowerCase().replace(/[^a-z0-9]+/g, "-");
  return `sky:${destination}:${id}:${checkin}:${checkout}`;
}

/** The Skyscanner search page for a place and night, cheapest first. */
function skyscannerUrl(entityId, checkin, checkout, adults = 2) {
  return `https://www.skyscanner.co.in/hotels/search?entity_id=${encodeURIComponent(entityId)}&checkin=${checkin}&checkout=${checkout}&adults=${adults}&rooms=1&sort=sort_type_price_asc`;
}

/** Adds this reading to the stored record of that hotel and night (history is kept, newest last). */
function buildSkyRecord(existing, listing, destination, checkin, checkout, nowIso) {
  const leadDays = Math.max(0, Math.round((new Date(`${checkin}T00:00:00`).getTime() - new Date(nowIso).getTime()) / 86400000));
  const point = { at: nowIso, price: listing.price, cheapest: listing.cheapest, provider: listing.provider || null, dv: 1, lead: leadDays };
  const prices = [...((existing && existing.prices) || []), point].slice(-120);
  const cheapestEver = Math.min(...prices.map((p) => p.cheapest || p.price));
  return {
    ...(existing || {}),
    source: "skyscanner", hotelName: listing.hotelName, destination, checkin, checkout,
    rating: listing.rating ?? null, reviewCount: listing.reviewCount ?? null, url: listing.url || (existing && existing.url) || null,
    freeCancel: !!listing.freeCancel, breakfast: !!listing.breakfast, km: listing.km ?? null, bookingOptions: listing.bookingOptions || 0,
    prices, lowest: cheapestEver, lowestAt: (prices.find((p) => (p.cheapest || p.price) === cheapestEver) || point).at, updatedAt: nowIso,
  };
}

/**
 * Skyscanner vs MakeMyTrip for the same night. skyRecords / mmtRecords are stored sky: and hist: records.
 * -> rows sorted by the gap: { hotelName, destination, checkin, checkout, skyCheapest, skyBestSite, mmtPrice, mmtName, mmtUrl,
 *    gapPct (positive = Skyscanner is cheaper), matched, ... } Only stays that have not started yet.
 */
function crossCheckSky(skyRecords, mmtRecords, nowMs, opts = {}) {
  const minSim = opts.minSimilarity ?? 0.6;
  const today = new Date(nowMs).toISOString().slice(0, 10);
  const byStay = new Map();
  for (const m of mmtRecords || []) {
    if (!m || !m.checkin || m.checkin < today) continue;
    const pts = (m.prices || []).filter((p) => p.dv === 1 && p.price >= 300);
    if (!pts.length) continue;
    const k = `${m.destination}|${m.checkin}|${m.checkout}`;
    if (!byStay.has(k)) byStay.set(k, []);
    byStay.get(k).push({ rec: m, price: pts[pts.length - 1].price, at: pts[pts.length - 1].at });
  }
  const rows = [];
  for (const s of skyRecords || []) {
    if (!s || !s.checkin || s.checkin < today || !s.prices || !s.prices.length) continue;
    const last = s.prices[s.prices.length - 1];
    const skyCheapest = last.cheapest || last.price;
    let best = null, bestSim = 0;
    for (const c of byStay.get(`${s.destination}|${s.checkin}|${s.checkout}`) || []) {
      const sim = hotelNameSimilarity(s.hotelName, c.rec.hotelName);
      if (sim > bestSim) { bestSim = sim; best = c; }
    }
    const matched = !!best && bestSim >= minSim;
    rows.push({
      hotelName: s.hotelName, destination: s.destination, checkin: s.checkin, checkout: s.checkout,
      skyCheapest, skyPrice: last.price, skyBestSite: last.provider || null, skyUrl: s.url || null, skyAt: last.at,
      rating: s.rating, reviewCount: s.reviewCount, freeCancel: !!s.freeCancel, bookingOptions: s.bookingOptions || 0,
      matched, similarity: Math.round(bestSim * 100) / 100,
      mmtPrice: matched ? best.price : null, mmtName: matched ? best.rec.hotelName : null, mmtUrl: matched ? best.rec.url || null : null, mmtAt: matched ? best.at : null,
      gapPct: matched ? Math.round(((best.price - skyCheapest) / best.price) * 100) : null,
    });
  }
  return rows.sort((a, b) => (b.gapPct ?? -999) - (a.gapPct ?? -999));
}

/** The big gaps worth opening and checking: matched, Skyscanner at least minGapPct cheaper, a plausible price. */
function skyVerifyCandidates(rows, minGapPct, verified, nowMs, max = 3) {
  return (rows || [])
    .filter((r) => r.matched && r.gapPct >= minGapPct && r.skyCheapest >= 500 && r.mmtUrl)
    .filter((r) => { const v = verified && verified[`${r.destination}|${r.hotelName}|${r.checkin}`]; return !v || nowMs - new Date(v.at).getTime() > 12 * 3600000; })
    .slice(0, max);
}

/** What the opened MakeMyTrip hotel page says, in words: is the gap real? (roomLowest = lowest room price on that page) */
function skyVerdict(row, roomLowest) {
  if (roomLowest == null) return { verdict: "unknown", text: "Could not read MakeMyTrip's hotel page, so the gap is unconfirmed." };
  if (roomLowest <= row.skyCheapest * 1.1) return { verdict: "mmt_matches", text: `MakeMyTrip's own hotel page has a room for about ${roomLowest} (its list showed ${row.mmtPrice}), so the real gap is small.` };
  return { verdict: "gap_holds", text: `MakeMyTrip's hotel page lowest room is ${roomLowest}; Skyscanner's cheapest is ${row.skyCheapest}. Check the cheaper site's room type, taxes and cancellation before booking.` };
}

/** The Skyscanner watch that applies to this place (its Skyscanner code included), or null. */
function skyscannerWatchFor(settings, placeName) {
  const sw = { ...SKYSCANNER_WATCH_DEFAULTS, ...((settings && settings.skyscannerWatch) || {}) };
  if (!sw.enabled || !Array.isArray(sw.destinations)) return null;
  const hit = matchScanList([placeName], sw.destinations).matched.length > 0;
  const idName = matchScanList([placeName], Object.keys(sw.entityIds || {})).matched.length ? Object.keys(sw.entityIds).find((n) => matchScanList([placeName], [n]).matched.length) : null;
  return hit && idName ? { ...sw, entityId: sw.entityIds[idName] } : null;
}

/** Is this hotel one of the brands in settings.brandWatch? (names match on letters only, so "SONAR BANGLA RESORT" and "Hotel Sonar Bangla Mandarmani" both match "Sonar Bangla".) */
function isBrandHotel(settings, hotelName) {
  const bw = { ...BRAND_WATCH_DEFAULTS, ...((settings && settings.brandWatch) || {}) };
  if (!bw.enabled || !Array.isArray(bw.names)) return false;
  const flat = String(hotelName || "").toLowerCase().replace(/[^a-z0-9]/g, "");
  return bw.names.some((n) => { const k = String(n || "").toLowerCase().replace(/[^a-z0-9]/g, ""); return k.length >= 4 && flat.includes(k); });
}

/** The trip watch that applies to this place (matched like a scan list, so Mandarmani finds Mandarmoni), or null. */
function tripWatchFor(settings, placeName) {
  const tw = { ...TRIP_WATCH_DEFAULTS, ...((settings && settings.tripWatch) || {}) };
  if (!tw.enabled || !Array.isArray(tw.destinations) || !tw.destinations.length) return null;
  return matchScanList([placeName], tw.destinations).matched.length ? tw : null;
}

/** Every night in the watch from today to tw.until on the chosen weekdays, as {checkin, checkout}. */
function tripWatchWindows(tw, now = new Date()) {
  const out = [];
  const nights = tw.nights || 1;
  const end = new Date(`${tw.until}T00:00:00`);
  if (Number.isNaN(end.getTime())) return out;
  for (let d = new Date(now.getFullYear(), now.getMonth(), now.getDate()); d <= end && out.length < 200; d = new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1)) {
    if (!(tw.weekdays || []).includes(d.getDay())) continue;
    const co = new Date(d.getFullYear(), d.getMonth(), d.getDate() + nights);
    out.push({ checkin: toISODate(d), checkout: toISODate(co) });
  }
  return out;
}

/** The dates to scan for one place: its trip-watch nights if it has a watch, otherwise the usual windows. */
function windowsForPlace(settings, placeName, generalWindows, now = new Date()) {
  const tw = tripWatchFor(settings, placeName);
  return tw ? tripWatchWindows(tw, now) : generalWindows;
}

/** Destinations a computer should scan: its own list if it has one, otherwise all. */
function filterScanDestinations(destinations, scanList) {
  if (!scanList || scanList.length === 0) return destinations;
  const r = matchScanList(destinations.map((d) => d.name), scanList);
  const want = new Set(r.matched.map((n) => n.toLowerCase()));
  return destinations.filter((d) => want.has(d.name.toLowerCase()));
}

/** Display URL for a Google Places photo resource name. Billed per image shown, so callers load one at a time. */
function googlePhotoUrl(photoName, apiKey, maxWidthPx = 640) {
  if (!photoName || !apiKey || !/^places\/[A-Za-z0-9_-]+\/photos\/[A-Za-z0-9_-]+$/.test(photoName)) return null;
  return `https://places.googleapis.com/v1/${photoName}/media?maxWidthPx=${maxWidthPx}&key=${encodeURIComponent(apiKey)}`;
}
