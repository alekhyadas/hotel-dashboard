/**
 * Clicking the extension icon opens this popup, which asks the background to
 * check for a newer version on disk and reload if there is one (it never
 * reloads mid-scan). The popup closes by itself when the extension reloads;
 * reopening it shows the new version.
 */
installErrorCapture("popup");

async function checkForUpdateOnOpen() {
  try {
    const r = await chrome.runtime.sendMessage({ type: "CHECK_FOR_UPDATE" });
    const line = document.getElementById("version-line");
    if (!r || !line) return;
    if (r.status === "reloading") line.textContent = `Updating to v${r.diskVersion}... reopen in a moment`;
    else if (r.status === "deferred") line.textContent += " • update ready, applies when the scan finishes";
  } catch (e) {
    // background not reachable (it is restarting), nothing to do
  }
}

async function render() {
  document.getElementById("version-line").textContent = `v${chrome.runtime.getManifest().version}`;
  const settings = await getSettings();
  renderPopToday(settings);
  renderDestinations(settings);
  renderSettingsForm(settings);
  renderSetupBanner(settings);
  renderDestTargets(settings);
  renderWhatsappForm(settings);
  await renderRecent();
  await renderLastScanSummary();
  const stillRunning = await renderProgress();
  if (stillRunning) startProgressPolling();
  const favStillRunning = await renderFavoriteRefreshProgress();
  if (favStillRunning) startFavoriteRefreshPolling();
}

/**
 * v1.44.0: the popup leads with the answer (this weekend's best stays, one
 * film pick, and the single worst problem if the data can't be trusted),
 * from the same buildToday() the dashboard's Today tab uses, so the two never
 * disagree. Everything else in the popup is folded away below it.
 */
async function renderPopToday(settings) {
  const el = (id) => document.getElementById(id);
  try {
    if (typeof buildToday !== "function") return;
    const [groups, blocked, state] = await Promise.all([
      loadTrackedHotelGroups(),
      getBlockedGroupKeys(),
      chrome.storage.local.get(["lastFullScanAt", "siteCooldown", "scanProgress", "channelPostState", "dealEvents", "helperStatus", "extPublishStatus", "extLatest", "errorLog"]),
    ]);
    state.runningVersion = chrome.runtime.getManifest().version;
    const t = buildToday({ groups, blocked, settings, state, nowMs: Date.now() });
    const w = t.book[0];
    const day = (iso) => new Date(iso + "T00:00:00").toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short" });
    if (w) el("pop-today-title").textContent = `This weekend, ${day(w.checkin)}`;
    el("pop-verdict").textContent = w ? w.verdict : "";
    const label = { deal: "Price drop", class: "Cheap for its class", value: "Good value" };
    el("pop-picks").innerHTML = (w ? w.picks.slice(0, 3) : []).map((p) => `
      <a class="pop-pick" ${p.url ? `href="${escapeHtml(p.url)}" target="_blank" rel="noopener noreferrer"` : ""}>
        <div class="pop-pick-top"><b>${escapeHtml(p.hotelName)}</b><span class="pop-price">${formatINR(p.price)}</span></div>
        <div class="pop-pick-meta"><span class="pop-badge pop-${p.kind}">${label[p.kind]}</span> ${escapeHtml(p.destination)}${p.why[0] ? ` • ${escapeHtml(p.why[0])}` : ""}</div>
      </a>`).join("");
    const f = t.film.picks[0];
    el("pop-film").innerHTML = f ? `\u{1F3AC} To film: <b>${escapeHtml(f.hotelName)}</b> (${escapeHtml(f.destination)}), from ${formatINR(f.price)}` : "";
    const worst = t.health.find((h) => h.level !== "info");
    el("pop-problem").classList.toggle("hidden", !worst);
    if (worst) el("pop-problem").innerHTML = `<b>${escapeHtml(worst.text)}</b><div>${escapeHtml(worst.fix)}</div>`;
    el("pop-status").textContent = worst
      ? `${t.summary.hotels} hotels tracked • needs attention`
      : `${t.summary.hotels} hotels tracked • last full scan ${t.summary.lastFullScan}`;
    const learned = (settings.destinations || []).some((d) => d.mmtCode || d.goibiboCode);
    if (!learned) el("fold-destinations").open = true;
  } catch (e) {
    console.log("[popup] today view failed:", e);
  }
}

function renderSetupBanner(settings) {
  const anyLearned = settings.destinations.some((d) => d.mmtCode || d.goibiboCode);
  const banner = document.getElementById("setup-banner");
  const text = document.getElementById("setup-banner-text");
  if (!anyLearned) {
    banner.classList.remove("hidden");
    text.textContent =
      "No destinations learned yet. Search for any of the places below normally on MakeMyTrip or Goibibo once to get started.";
    banner.onclick = null;
    banner.style.cursor = "";
  } else if (!settings.telegramBotToken) {
    banner.classList.remove("hidden");
    text.textContent = "Add a Telegram bot token and chat ID to receive deal alerts. Tap here to open Settings.";
    // The Settings fold sits far below a long Destinations list: open it and scroll to it.
    banner.style.cursor = "pointer";
    banner.onclick = () => {
      const dest = document.getElementById("fold-destinations");
      if (dest) dest.open = false;
      const fold = document.getElementById("fold-settings");
      if (fold) { fold.open = true; fold.scrollIntoView({ block: "start" }); }
    };
  } else {
    banner.classList.add("hidden");
    banner.onclick = null;
    banner.style.cursor = "";
  }
}

/**
 * v1.36.0: was a 4-column table (Place / MakeMyTrip / Goibibo / remove)
 * crammed into the popup's 380px width. The Place column packed the
 * destination name AND the "❤️ refresh favs" button into one cell with
 * no wrap control, so a longer name (Digha, Mandarmoni, ...) wrapped the
 * button onto its own line while a short one (Puri) didn't, giving every
 * row a different, inconsistent shape (the reported "ugly" screenshot).
 * Worse, the Open/Scan/Search buttons inside the MakeMyTrip/Goibibo
 * cells were never given the outlined "secondary" button treatment the
 * rest of the popup uses (.secondary-btn/.dest-action-btn) -- they fell
 * through to the base `button` rule (solid black, meant for a page's one
 * primary action), so a narrow table cell ended up with 2-3 full-size
 * black CTA buttons stacked in it.
 *
 * Rebuilt as one card per destination (name + remove on a header row,
 * then one row per site) instead of a table, so nothing has to share a
 * cell with anything else and every row has the same shape regardless
 * of name length. Every action button now gets the same small outlined
 * style as the rest of the popup's secondary actions (see .site-btn in
 * popup.css).
 */
function renderDestinations(settings) {
  const list = document.getElementById("destinations-list");
  list.innerHTML = "";
  for (const dest of settings.destinations) {
    const card = document.createElement("div");
    card.className = "dest-card";

    const header = document.createElement("div");
    header.className = "dest-card-header";
    const nameSpan = document.createElement("span");
    nameSpan.className = "dest-name";
    nameSpan.textContent = dest.name;
    header.appendChild(nameSpan);

    const headerActions = document.createElement("div");
    headerActions.className = "dest-header-actions";
    // Refresh just this destination's favorites, rather than every
    // favorite everywhere (the existing "Quick refresh favorites"
    // button in the Scan now section). Destination-scoped, not
    // site-scoped, since a favorite could be MMT or Goibibo either way.
    const favBtn = document.createElement("button");
    favBtn.textContent = "❤️ refresh favs";
    favBtn.className = "dest-action-btn";
    favBtn.title = `Quick-refresh only ${dest.name}'s favorited hotels`;
    favBtn.addEventListener("click", () => runDestinationFavoriteRefresh(dest.name, favBtn));
    headerActions.appendChild(favBtn);

    const removeBtn = document.createElement("button");
    removeBtn.textContent = "\u00d7";
    removeBtn.className = "remove-dest-btn";
    removeBtn.title = `Remove ${dest.name}`;
    removeBtn.addEventListener("click", async () => {
      const current = await getSettings();
      current.destinations = current.destinations.filter((d) => d.name !== dest.name);
      await saveSettings(current);
      renderDestinations(current);
      renderDestTargets(current);
    });
    headerActions.appendChild(removeBtn);
    header.appendChild(headerActions);
    card.appendChild(header);

    card.appendChild(siteRow(dest, "mmtCode", "makemytrip", "MakeMyTrip", "https://www.makemytrip.com/hotels/", settings));
    card.appendChild(siteRow(dest, "goibiboCode", "goibibo", "Goibibo", "https://www.goibibo.com/hotels/", settings));

    list.appendChild(card);
  }
}

function siteRow(dest, field, site, siteLabel, searchUrl, settings) {
  const row = document.createElement("div");
  row.className = "dest-site-row";

  const label = document.createElement("span");
  label.className = "site-label";
  label.textContent = siteLabel;
  row.appendChild(label);

  const actions = document.createElement("div");
  actions.className = "site-actions";

  if (dest[field]) {
    const status = document.createElement("span");
    status.className = "status-ok";
    status.textContent = "\u2713 learned";
    row.appendChild(status);

    const openBtn = document.createElement("button");
    openBtn.textContent = "Open";
    openBtn.className = "site-btn";
    openBtn.title = "Open the real listing page, to check it actually shows hotels";
    openBtn.addEventListener("click", () => {
      const weekends = upcomingWeekends(settings.nights, settings.checkinWeekday, settings.lookaheadDays);
      const { checkin, checkout } = weekends[0];
      const url =
        site === "makemytrip"
          ? buildMmtUrl(dest[field], checkin, checkout, settings.adults)
          : buildGoibiboUrl(dest[field], checkin, checkout, settings.adults, settings.rooms);
      chrome.tabs.create({ url });
    });
    // Scan just this one destination on this one site ("scan that
    // destination again"), rather than the full sweep the "Scan
    // MakeMyTrip"/"Scan Goibibo" buttons in the Scan now section kick
    // off. Reuses the exact same RUN_SCAN_NOW message, just with
    // destinationName set, so it goes through the same alarm-chained
    // step machine and watchdog as every other scan.
    const scanBtn = document.createElement("button");
    scanBtn.textContent = "Scan";
    scanBtn.className = "site-btn";
    scanBtn.title = `Scan only ${dest.name} on ${site === "makemytrip" ? "MakeMyTrip" : "Goibibo"} again`;
    scanBtn.addEventListener("click", () => runDestinationScan(site, dest.name, scanBtn));
    actions.appendChild(openBtn);
    actions.appendChild(scanBtn);
  } else {
    const status = document.createElement("span");
    status.className = "status-pending";
    status.textContent = "not yet";
    row.appendChild(status);

    const btn = document.createElement("button");
    btn.textContent = "Search";
    btn.className = "site-btn";
    btn.title = `Search "${dest.searchTerm}" on this site`;
    btn.addEventListener("click", () => chrome.tabs.create({ url: searchUrl }));
    actions.appendChild(btn);
  }

  row.appendChild(actions);
  return row;
}

/**
 * Per-destination default price-target alerts (PROJECT_BRIEF open item
 * 4). A hotel-specific target, set from the dashboard's target button on
 * a favorite, always overrides this, see evaluateTargetAlert in
 * shared.js for the actual fire-once/re-arm logic either way uses.
 */
function renderDestTargets(settings) {
  const body = document.getElementById("dest-targets-body");
  body.innerHTML = "";
  const targets = settings.destinationTargets || [];
  if (targets.length === 0) {
    body.innerHTML = '<tr><td colspan="3" class="hint">No destination defaults set.</td></tr>';
  }
  for (const t of targets) {
    const tr = document.createElement("tr");
    const nameTd = document.createElement("td");
    nameTd.textContent = t.destination;
    const priceTd = document.createElement("td");
    priceTd.textContent = formatINR(t.targetPrice);
    const removeTd = document.createElement("td");
    const removeBtn = document.createElement("button");
    removeBtn.textContent = "×";
    removeBtn.className = "remove-dest-btn";
    removeBtn.title = `Remove target for ${t.destination}`;
    removeBtn.addEventListener("click", async () => {
      const current = await getSettings();
      current.destinationTargets = (current.destinationTargets || []).filter((x) => x.destination !== t.destination);
      await saveSettings(current);
      renderDestTargets(current);
    });
    removeTd.appendChild(removeBtn);
    tr.appendChild(nameTd);
    tr.appendChild(priceTd);
    tr.appendChild(removeTd);
    body.appendChild(tr);
  }

  const select = document.getElementById("new-target-dest");
  select.innerHTML = "";
  for (const d of settings.destinations) {
    const opt = document.createElement("option");
    opt.value = d.name;
    opt.textContent = d.name;
    select.appendChild(opt);
  }
}

document.getElementById("add-dest-target").addEventListener("click", async () => {
  const destSelect = document.getElementById("new-target-dest");
  const priceInput = document.getElementById("new-target-price");
  const status = document.getElementById("dest-target-status");
  const destination = destSelect.value;
  const price = parseInt(priceInput.value, 10);

  if (!destination) {
    status.textContent = "Add a destination first (above).";
    return;
  }
  if (!Number.isFinite(price) || price < 300) {
    status.textContent = "Enter a plausible rupee amount (300 or more).";
    return;
  }

  const settings = await getSettings();
  settings.destinationTargets = settings.destinationTargets || [];
  const existing = settings.destinationTargets.find((t) => t.destination === destination);
  if (existing) {
    existing.targetPrice = price;
  } else {
    settings.destinationTargets.push({ destination, targetPrice: price });
  }
  await saveSettings(settings);
  priceInput.value = "";
  status.textContent = `Set: alert when any tracked ${destination} hotel hits ${formatINR(price)} or below (unless that specific hotel has its own target).`;
  renderDestTargets(settings);
});

function renderWhatsappForm(settings) {
  document.getElementById("whatsapp-enabled").checked = !!settings.whatsappEnabled;
  document.getElementById("whatsapp-phone-id").value = settings.whatsappPhoneNumberId || "";
  document.getElementById("whatsapp-token").value = settings.whatsappAccessToken || "";
  document.getElementById("whatsapp-recipient").value = settings.whatsappRecipientNumber || "";
}

document.getElementById("save-whatsapp").addEventListener("click", async () => {
  const settings = await getSettings();
  settings.whatsappEnabled = document.getElementById("whatsapp-enabled").checked;
  settings.whatsappPhoneNumberId = document.getElementById("whatsapp-phone-id").value.trim();
  settings.whatsappAccessToken = document.getElementById("whatsapp-token").value.trim();
  settings.whatsappRecipientNumber = document.getElementById("whatsapp-recipient").value.trim();
  await saveSettings(settings);
  const status = document.getElementById("whatsapp-status");
  status.textContent = "Saved.";
  setTimeout(() => (status.textContent = ""), 2000);
});

function renderSettingsForm(settings) {
  document.getElementById("telegram-token").value = settings.telegramBotToken || "";
  document.getElementById("telegram-chat").value = settings.telegramChatId || "";
  document.getElementById("min-star").value = String(settings.minStarRating);
  document.getElementById("discount-threshold").value = settings.discountPctThreshold;
  document.getElementById("price-drop-threshold").value = settings.priceDropPctThreshold;
  document.getElementById("per-page-seconds").value = settings.perPageSeconds;
  document.getElementById("scan-concurrency").value = String(settings.scanConcurrency || 1);
  document.getElementById("room-detail-top-n").value = settings.checkRoomDetailsForTopN;
  document.getElementById("ai-provider").value = settings.aiProvider || "none";
  document.getElementById("ai-api-key").value = settings.aiApiKey || "";
  document.getElementById("youtube-api-key").value = settings.youtubeApiKey || "";
  document.getElementById("github-token").value = settings.githubToken || "";
  document.getElementById("github-repo").value = settings.githubRepo || "";
  document.getElementById("serpapi-keys").value = (settings.serpApiKeys || []).join("\n");
  document.getElementById("include-next7").checked = !!settings.includeNext7Days;
}

// Split from what used to be one renderRecent() function: counting real
// storage.local.get(null) dumps the ENTIRE local storage (every hist:
// record ever saved, all settings, everything) just to count keys with a
// "hist:" prefix. The old combined function ran this on every single
// progress-poll tick during an active scan (every 2 seconds, for
// however many minutes the scan runs), so the cost of just checking
// "did the list of recent listings change" grew with however many
// months of tracked data had piled up, and kept paying that cost
// continuously for the whole length of every scan. Counting is now its
// own function, called once when the popup opens and once when a scan
// or refresh actually finishes, not on every poll tick.
async function renderTrackedCount() {
  const all = await chrome.storage.local.get(null);
  const trackedCount = Object.keys(all).filter((k) => k.startsWith("hist:")).length;
  const countEl = document.getElementById("tracked-count");
  if (countEl) {
    countEl.textContent = trackedCount
      ? `${trackedCount} hotel/date record(s) saved`
      : "Nothing saved yet";
  }
}

// The cheap half: only reads recentScans (never the whole storage dump),
// safe to call on every poll tick so the list still updates live as a
// scan finds hotels, which is the whole reason it was being called that
// often in the first place.
async function renderRecentList() {
  const { recentScans = [] } = await chrome.storage.local.get("recentScans");
  const container = document.getElementById("recent-list");

  container.innerHTML = "";
  if (recentScans.length === 0) {
    container.innerHTML = '<p class="hint">No scans yet.</p>';
    return;
  }
  for (const item of recentScans.slice(0, 15)) {
    const div = document.createElement("div");
    div.className = "recent-item";
    const priceStr = formatINR(item.discountedPrice);
    const scannedStr = item.scannedAt
      ? new Date(item.scannedAt).toLocaleString("en-IN", {
          day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit",
        })
      : null;
    div.innerHTML = `
      <div class="name">${escapeHtml(item.hotelName)}${item.isNewlyBuilt ? ' <span class="badge-new-inline">NEW</span>' : ""}</div>
      <div class="meta">${escapeHtml(item.destination)} \u2022 ${escapeHtml(item.source)} \u2022 ${item.checkin}
        \u2022 ${priceStr}${item.discountPct ? ` (${item.discountPct}% off)` : ""}</div>
      ${scannedStr ? `<div class="meta scanned-at">Scanned ${scannedStr} IST</div>` : ""}
    `;
    container.appendChild(div);
  }
}

// Convenience wrapper for the discrete moments both halves genuinely
// need refreshing: initial popup load, and right after a scan/refresh
// actually finishes (a new hist: record may have just been created).
// Poll-tick call sites use renderRecentList() alone, see its comment.
async function renderRecent() {
  await Promise.all([renderTrackedCount(), renderRecentList()]);
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str ?? "";
  return div.innerHTML;
}

document.getElementById("telegram-test").addEventListener("click", async () => {
  const status = document.getElementById("telegram-test-status");
  const btn = document.getElementById("telegram-test");
  btn.disabled = true;
  status.textContent = "Sending...";
  const r = await sendTelegramTestMessage(document.getElementById("telegram-token").value, document.getElementById("telegram-chat").value);
  status.textContent = r.message;
  btn.disabled = false;
});

document.getElementById("save-settings").addEventListener("click", async () => {
  const settings = await getSettings();
  settings.telegramBotToken = document.getElementById("telegram-token").value.trim();
  settings.telegramChatId = document.getElementById("telegram-chat").value.trim();
  settings.minStarRating = parseInt(document.getElementById("min-star").value, 10);
  settings.discountPctThreshold = parseInt(document.getElementById("discount-threshold").value, 10);
  settings.priceDropPctThreshold = parseInt(document.getElementById("price-drop-threshold").value, 10);
  const perPage = parseInt(document.getElementById("per-page-seconds").value, 10);
  settings.perPageSeconds = Number.isFinite(perPage) ? Math.min(180, Math.max(15, perPage)) : 40;
  const concurrency = parseInt(document.getElementById("scan-concurrency").value, 10);
  settings.scanConcurrency = Number.isFinite(concurrency) ? Math.min(3, Math.max(1, concurrency)) : 1;
  const roomN = parseInt(document.getElementById("room-detail-top-n").value, 10);
  settings.checkRoomDetailsForTopN = Number.isFinite(roomN) ? Math.min(10, Math.max(0, roomN)) : 0;
  settings.aiProvider = document.getElementById("ai-provider").value;
  settings.aiApiKey = document.getElementById("ai-api-key").value.trim();
  settings.youtubeApiKey = document.getElementById("youtube-api-key").value.trim();
  settings.githubToken = document.getElementById("github-token").value.trim();
  settings.githubRepo = document.getElementById("github-repo").value.trim();
  const rawKeys = document.getElementById("serpapi-keys").value.split("\n").map((k) => k.trim()).filter(Boolean);
  settings.serpApiKeys = [...new Set(rawKeys)];
  settings.includeNext7Days = document.getElementById("include-next7").checked;
  await saveSettings(settings);
  const status = document.getElementById("save-status");
  status.textContent = "Saved.";
  setTimeout(() => (status.textContent = ""), 2000);
  renderSetupBanner(settings);
});

document.getElementById("add-destination").addEventListener("click", async () => {
  const nameInput = document.getElementById("new-dest-name");
  const searchInput = document.getElementById("new-dest-search");
  const status = document.getElementById("add-destination-status");
  const name = nameInput.value.trim();
  if (!name) {
    status.textContent = "Enter a place name first.";
    return;
  }
  const searchTerm = searchInput.value.trim() || name;
  const settings = await getSettings();
  if (settings.destinations.some((d) => d.name.toLowerCase() === name.toLowerCase())) {
    status.textContent = `${name} is already in the list.`;
    return;
  }
  settings.destinations.push({ name, searchTerm, mmtCode: null, goibiboCode: null });
  await saveSettings(settings);
  nameInput.value = "";
  searchInput.value = "";
  status.textContent = `Added ${name}. Search it on each site to learn its code.`;
  renderDestinations(settings);
  renderSetupBanner(settings);
  renderDestTargets(settings);
});

/**
 * Turns a startScan() result (now forwarded honestly by RUN_SCAN_NOW,
 * see background.js) into a message for the person, when it wasn't a
 * genuine start. Used to fix a real report: clicking a destination's
 * "Scan" button while a DIFFERENT scan was already running just reset
 * the button with no explanation, and the destination that actually kept
 * scanning wasn't the one clicked. The click was silently absorbed by
 * startScan()'s own "already running, skip" guard, which used to return
 * nothing for the popup to go on. Now it names the destination that's
 * actually running, so the person isn't left thinking their click did
 * something it didn't.
 */
function describeScanSkip(result, requestedLabel) {
  if (!result || result.started !== false) return null;
  if (result.reason === "queued" && result.scanProgress) {
    // v1.32.0: a destination-scoped request made while busy is now
    // queued and starts on its own once the current scan finishes, no
    // need to click again.
    const sp = result.scanProgress;
    const runningWhat = sp.destinationName ? `A scan of ${sp.destinationName}` : "A scan";
    return `${runningWhat} is already running (${sp.completed}/${sp.total} done). ${requestedLabel} is queued and will start automatically once that finishes.`;
  }
  if (result.reason === "already_running" && result.scanProgress) {
    const sp = result.scanProgress;
    const runningWhat = sp.destinationName ? `A scan of ${sp.destinationName}` : "A scan";
    return `${runningWhat} is already running (${sp.completed}/${sp.total} done), so ${requestedLabel} wasn't started. Try again once that one finishes.`;
  }
  return result.message || `${requestedLabel} wasn't started.`;
}

function wireScanButton(buttonId, site) {
  document.getElementById(buttonId).addEventListener("click", async () => {
    const { scanProgress } = await chrome.storage.local.get("scanProgress");
    const notice = document.getElementById("scan-click-notice");
    if (scanProgress && scanProgress.running) {
      // This used to write into progress-label, which the polling loop
      // below overwrites every 2 seconds, so the message vanished almost
      // immediately and clicking looked like it did nothing. A separate
      // element the poller never touches fixes that.
      notice.textContent = `A scan is already running (${scanProgress.completed}/${scanProgress.total} done), it'll pick up the rest next time rather than starting a second one on top of it.`;
      document.getElementById("progress-box").classList.remove("hidden");
      startProgressPolling();
      return;
    }
    notice.textContent = "";
    const staleOnly = document.getElementById("stale-only-toggle").checked;
    chrome.runtime.sendMessage({ type: "RUN_SCAN_NOW", sites: [site], staleOnly }, (result) => {
      renderRecent();
      // The pre-click check above is racy (state can change between that
      // read and the message actually reaching the background), so this
      // is the source of truth: startScan()'s own real result.
      const skipMsg = describeScanSkip(result, `this ${site === "makemytrip" ? "MakeMyTrip" : "Goibibo"} scan`);
      if (skipMsg) notice.textContent = skipMsg;
    });
    startProgressPolling();
  });
}

wireScanButton("scan-mmt", "makemytrip");
wireScanButton("scan-goibibo", "goibibo");

/**
 * Destination-scoped version of wireScanButton()'s click handler, for
 * the per-destination "Scan" button in the destinations table. Same
 * already-running guard and progress polling as the full-sweep buttons,
 * just with destinationName passed through so background.js's
 * startScan() only builds steps for that one place.
 */
async function runDestinationScan(site, destinationName, btn) {
  const { scanProgress } = await chrome.storage.local.get("scanProgress");
  const notice = document.getElementById("scan-click-notice");
  if (scanProgress && scanProgress.running) {
    notice.textContent = `A scan is already running (${scanProgress.completed}/${scanProgress.total} done), it'll pick up the rest next time rather than starting a second one on top of it.`;
    document.getElementById("progress-box").classList.remove("hidden");
    startProgressPolling();
    return;
  }
  notice.textContent = "";
  const original = btn.textContent;
  btn.textContent = "Scanning...";
  btn.disabled = true;
  // Safety net: if the response never arrives (e.g. the service worker
  // was recycled between this click and it replying, see the v1.30.0
  // "No SW" fix), don't leave the button stuck showing "Scanning..."
  // forever with no way to tell it actually didn't do anything.
  const safety = setTimeout(() => {
    btn.textContent = original;
    btn.disabled = false;
    notice.textContent = `Didn't hear back in time for ${destinationName}, the button's been reset. Check the progress box above for what's actually running before trying again.`;
  }, 20000);
  chrome.runtime.sendMessage({ type: "RUN_SCAN_NOW", sites: [site], destinationName }, (result) => {
    clearTimeout(safety);
    renderRecent();
    btn.textContent = original;
    btn.disabled = false;
    const skipMsg = describeScanSkip(result, destinationName);
    if (skipMsg) notice.textContent = skipMsg;
  });
  startProgressPolling();
}

/**
 * Destination-scoped version of the "Quick refresh favorites" handler,
 * for the per-destination "❤️ refresh favs" button. Same
 * message type as the full sweep, just with destinationName so
 * startFavoriteRefresh() only touches that one destination's favorites.
 */
function runDestinationFavoriteRefresh(destinationName, btn) {
  const status = document.getElementById("quick-refresh-status");
  status.textContent = "";
  const original = btn.textContent;
  btn.textContent = "Refreshing...";
  btn.disabled = true;
  // Same safety net as runDestinationScan() above: don't leave the
  // button stuck forever if the response never arrives.
  const safety = setTimeout(() => {
    btn.textContent = original;
    btn.disabled = false;
    status.textContent = `Didn't hear back in time for ${destinationName}, the button's been reset.`;
  }, 20000);
  chrome.runtime.sendMessage({ type: "QUICK_REFRESH_FAVORITES", destinationName }, (result) => {
    clearTimeout(safety);
    if (result) status.textContent = result.message;
    renderRecent();
    btn.textContent = original;
    btn.disabled = false;
  });
  startFavoriteRefreshPolling();
}

document.getElementById("stop-scan").addEventListener("click", () => {
  const btn = document.getElementById("stop-scan");
  const notice = document.getElementById("scan-click-notice");
  btn.textContent = "Stopping...";
  btn.disabled = true;
  notice.textContent = "Stopping can take a minute or two, it can't interrupt a page that's already mid-load, only skip the next one.";
  chrome.runtime.sendMessage({ type: "STOP_SCAN" }, () => {
    // Re-enable once the scan has genuinely stopped (checked by the
    // existing progress polling), not on a fixed timer, a scan that's
    // still finishing its current page shouldn't look like the button
    // did nothing just because a few seconds passed. Capped at 5 minutes
    // as a safety net in case something unexpected happens.
    let checks = 0;
    const checkStopped = setInterval(async () => {
      checks++;
      const { scanProgress } = await chrome.storage.local.get("scanProgress");
      if (!scanProgress || !scanProgress.running || checks > 150) {
        btn.textContent = "Stop scan";
        btn.disabled = false;
        notice.textContent = "";
        clearInterval(checkStopped);
      }
    }, 2000);
  });
});

document.getElementById("quick-refresh").addEventListener("click", () => {
  const status = document.getElementById("quick-refresh-status");
  status.textContent = "";
  chrome.runtime.sendMessage({ type: "QUICK_REFRESH_FAVORITES" }, (result) => {
    if (result) status.textContent = result.message;
    renderRecent();
  });
  startFavoriteRefreshPolling();
});

document.getElementById("stop-favorite-refresh").addEventListener("click", () => {
  const btn = document.getElementById("stop-favorite-refresh");
  btn.textContent = "Stopping...";
  btn.disabled = true;
  chrome.runtime.sendMessage({ type: "STOP_FAVORITE_REFRESH" }, () => {
    setTimeout(() => {
      btn.textContent = "Stop";
      btn.disabled = false;
    }, 3000);
  });
});

async function renderFavoriteRefreshProgress() {
  const { favoriteRefreshProgress } = await chrome.storage.local.get("favoriteRefreshProgress");
  const box = document.getElementById("favorite-refresh-box");
  const stopBtn = document.getElementById("stop-favorite-refresh");

  if (!favoriteRefreshProgress || (!favoriteRefreshProgress.running && !favoriteRefreshProgress.finishedAt)) {
    box.classList.add("hidden");
    stopBtn.classList.add("hidden");
    return false;
  }
  box.classList.remove("hidden");
  stopBtn.classList.toggle("hidden", !favoriteRefreshProgress.running);

  const pct = favoriteRefreshProgress.total
    ? Math.round((favoriteRefreshProgress.completed / favoriteRefreshProgress.total) * 100)
    : 0;
  document.getElementById("favorite-refresh-bar-fill").style.width = `${pct}%`;

  const label = document.getElementById("favorite-refresh-label");
  if (favoriteRefreshProgress.running) {
    const elapsed = formatElapsed(favoriteRefreshProgress.startedAt);
    let eta = "";
    if (favoriteRefreshProgress.completed > 0) {
      const elapsedMs = Date.now() - new Date(favoriteRefreshProgress.startedAt).getTime();
      const perStepMs = elapsedMs / favoriteRefreshProgress.completed;
      const remaining = favoriteRefreshProgress.total - favoriteRefreshProgress.completed;
      eta = ` \u2022 ~${formatDuration(perStepMs * remaining)} left`;
    }
    label.textContent = `${favoriteRefreshProgress.completed}/${favoriteRefreshProgress.total} \u2022 running ${elapsed}${eta} \u2022 ${favoriteRefreshProgress.currentLabel}`;
  } else {
    label.textContent = `${favoriteRefreshProgress.currentLabel} \u2022 ${favoriteRefreshProgress.completed}/${favoriteRefreshProgress.total} checked, ${favoriteRefreshProgress.updated} updated`;
  }

  return favoriteRefreshProgress.running;
}

let favoriteRefreshPollTimer = null;
function startFavoriteRefreshPolling() {
  if (favoriteRefreshPollTimer) return;
  favoriteRefreshPollTimer = setInterval(async () => {
    const stillRunning = await renderFavoriteRefreshProgress();
    if (!stillRunning) {
      clearInterval(favoriteRefreshPollTimer);
      favoriteRefreshPollTimer = null;
      renderRecent();
    }
  }, 1500);
}

function formatElapsed(startedAt) {
  const seconds = Math.round((Date.now() - new Date(startedAt).getTime()) / 1000);
  return formatDuration(seconds * 1000);
}

function formatDuration(ms) {
  const totalSeconds = Math.round(ms / 1000);
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

async function renderProgress() {
  const { scanProgress } = await chrome.storage.local.get("scanProgress");
  const box = document.getElementById("progress-box");
  const stopBtn = document.getElementById("stop-scan");

  if (!scanProgress || (!scanProgress.running && !scanProgress.finishedAt)) {
    box.classList.add("hidden");
    stopBtn.classList.add("hidden");
    return false;
  }
  box.classList.remove("hidden");
  stopBtn.classList.toggle("hidden", !scanProgress.running);

  const pct = scanProgress.total ? Math.round((scanProgress.completed / scanProgress.total) * 100) : 0;
  document.getElementById("progress-bar-fill").style.width = `${pct}%`;

  const label = document.getElementById("progress-label");
  const etaEl = document.getElementById("progress-eta");
  if (scanProgress.running) {
    label.textContent = `${scanProgress.completed}/${scanProgress.total} done (${pct}%), running ${formatElapsed(scanProgress.startedAt)} \u2022 now: ${scanProgress.currentLabel}`;

    if (scanProgress.completed > 0) {
      const elapsedMs = Date.now() - new Date(scanProgress.startedAt).getTime();
      const perStepMs = elapsedMs / scanProgress.completed;
      const remaining = scanProgress.total - scanProgress.completed;
      etaEl.textContent = `~${formatDuration(perStepMs * remaining)} remaining at the current pace`;
    } else {
      etaEl.textContent = "Working out the pace, estimate appears after the first step...";
    }
  } else {
    const status = scanProgress.currentLabel === "Stopped" ? "Stopped" : "Finished";
    label.textContent = `${status} ${scanProgress.completed}/${scanProgress.total} \u2022 took ${formatElapsed(scanProgress.startedAt)}`;
    etaEl.textContent = "";
  }

  const logEl = document.getElementById("progress-log");
  logEl.innerHTML = (scanProgress.log || [])
    .slice(0, 6)
    .map((entry) => {
      const time = new Date(entry.at).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
      const warn = entry.mismatched
        ? ` <span class="warn-inline">site served different dates</span>`
        : "";
      const hiddenNote = entry.hidden ? " (window was hidden, page may be incomplete)" : "";
      return `<div>${time} \u2014 ${escapeHtml(entry.label)}: found ${entry.found}${warn}${hiddenNote}</div>`;
    })
    .join("");

  return scanProgress.running;
}

async function renderLastScanSummary() {
  const { scanHistory = [] } = await chrome.storage.local.get("scanHistory");
  const el = document.getElementById("last-scan-summary");
  if (scanHistory.length === 0) {
    el.textContent = "";
    return;
  }
  const latest = scanHistory[0];
  const finishedTime = new Date(latest.finishedAt).toLocaleString("en-IN", {
    day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit",
  });
  let line = `Last scan (${latest.sites.join(", ")}): ${latest.stopped ? "stopped" : "finished"} ${finishedTime}, took ${formatDuration(latest.durationMs)} (${latest.completed}/${latest.total} steps, ${latest.scanned} hotel${latest.scanned === 1 ? "" : "s"} found)`;

  const previous = scanHistory.find((s, i) => i > 0 && s.sites.join(",") === latest.sites.join(","));
  if (previous) {
    const diffMs = latest.durationMs - previous.durationMs;
    const pct = Math.round((Math.abs(diffMs) / previous.durationMs) * 100);
    if (Math.abs(diffMs) > 5000) {
      line += diffMs < 0 ? ` \u2014 ${pct}% faster than before` : ` \u2014 ${pct}% slower than before`;
    } else {
      line += " \u2014 about the same as before";
    }
  }
  el.textContent = line;
}

let progressPollTimer = null;
function startProgressPolling() {
  if (progressPollTimer) return;
  progressPollTimer = setInterval(async () => {
    const stillRunning = await renderProgress();
    // refresh the listings panel as results come in, not just at the end,
    // otherwise it reads "No scans yet" while the log is clearly finding
    // hotels, which looks broken. The list-only half: see
    // renderTrackedCount()'s comment for why the full storage count isn't
    // recomputed on every one of these ticks too.
    renderRecentList();
    if (!stillRunning) {
      clearInterval(progressPollTimer);
      progressPollTimer = null;
      renderLastScanSummary();
      renderTrackedCount();
    }
  }, 2000);
}

document.getElementById("swipe-hotels").addEventListener("click", () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html#swipe") });
});

document.getElementById("open-dashboard").addEventListener("click", () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("dashboard.html") });
});

checkForUpdateOnOpen();
render();
