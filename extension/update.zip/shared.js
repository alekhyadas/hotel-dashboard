/**
 * Shared defaults and small helpers used by background.js, content.js and
 * popup.js. Everything user-editable actually lives in chrome.storage.local
 * under the "settings" key (see getSettings/saveSettings below); DEFAULTS
 * is just what a fresh install starts with.
 */

const DEFAULT_DESTINATIONS = [
  { name: "Digha", searchTerm: "Digha", mmtCode: null, goibiboCode: null },
  { name: "Mandarmoni", searchTerm: "Mandarmoni", mmtCode: null, goibiboCode: null },
  { name: "Darjeeling", searchTerm: "Darjeeling", mmtCode: null, goibiboCode: null },
  { name: "Sundarbans", searchTerm: "Sundarban", mmtCode: null, goibiboCode: null },
  { name: "Puri", searchTerm: "Puri", mmtCode: null, goibiboCode: null },
  { name: "Kolkata", searchTerm: "Kolkata", mmtCode: null, goibiboCode: null },
  { name: "West Bengal", searchTerm: "West Bengal", mmtCode: null, goibiboCode: null },
  { name: "Gangtok", searchTerm: "Gangtok", mmtCode: null, goibiboCode: null },
  { name: "Purulia", searchTerm: "Purulia", mmtCode: null, goibiboCode: null },
];

const DEFAULTS = {
  destinations: DEFAULT_DESTINATIONS,
  nights: 2,
  checkinWeekday: 5, // JS getDay(): Sunday=0 ... Friday=5
  lookaheadDays: 60,
  includeNext7Days: true,
  minStarRating: 3,
  discountPctThreshold: 35,
  priceDropPctThreshold: 15,
  adults: 2,
  rooms: 1,
  sites: ["makemytrip"], // goibibo is opt-in, see popup
  telegramBotToken: "",
  telegramChatId: "",
  minDelaySeconds: 20,
  maxDelaySeconds: 45,
  // how long each listing page gets to load and scroll before moving on.
  // Higher means more hotels captured per date, but a slower overall scan.
  perPageSeconds: 40,
  // how many windows to run at once. 1 = exactly the original behaviour,
  // one window at a time with human-like pauses. Anything higher trades
  // some of that camouflage for speed, deliberately opt-in, see the popup.
  scanConcurrency: 1,
  // null until the first scan works out which date format MakeMyTrip
  // actually honours, see calibrateMmtDateFormat() in background.js
  mmtDateFormat: null,
  // opt-in: for this many of the cheapest listings per destination/date,
  // also visit the hotel's own detail page to confirm the actual lowest
  // room price rather than trusting the listing card's headline figure.
  // 0 = off. Each one is a full extra page load, so keep this small.
  checkRoomDetailsForTopN: 0,
  // "none", "gemini", or "grok". Summarizes the tracked hotels using
  // whichever provider, with your own API key, see the dashboard.
  aiProvider: "none",
  aiApiKey: "",
  // YouTube Data API v3 has a genuine free daily quota. Used to check
  // whether a hotel shows up in popular travel videos, a much better
  // proxy for "worth filming" than price or review count alone.
  youtubeApiKey: "",
  // For publishing a read-only snapshot to GitHub Pages, so the dashboard
  // is viewable from any browser, not just this extension. See the
  // dashboard's "Publish live dashboard" button.
  githubToken: "",
  githubRepo: "", // format: yourusername/your-repo-name
  // For the optional cross-check against Google Hotels (via SerpApi),
  // which aggregates Booking.com/Agoda/etc. rates in one response.
  // An array so multiple keys can be entered and rotated through
  // automatically as each one's free monthly allowance runs out,
  // rather than requiring a manual swap in Settings every time.
  serpApiKeys: [],
  serpApiKeyIndex: 0, // which key in serpApiKeys to try next
  // Per-destination price-target alerts (a hotel-specific target set on a
  // favorite always wins over this, see favoriteHotels' own targetPrice
  // field and evaluateTargetAlert() below). Array of {destination, targetPrice}.
  destinationTargets: [],
  // WhatsApp Cloud API, for price-target alerts only (the existing
  // discount/price-drop/newly-built alerts stay Telegram-only). See
  // sendWhatsAppAlert() in background.js for an important caveat about
  // the 24-hour free-form-message window.
  whatsappEnabled: false,
  whatsappPhoneNumberId: "",
  whatsappAccessToken: "",
  whatsappRecipientNumber: "",
  // Travelpayouts (multi-OTA aggregation beyond SerpApi), see
  // PROJECT_BRIEF.md open item 6. Scaffolded, not called anywhere yet:
  // sign up at travelpayouts.com, get your API token and marker (partner
  // ID), paste them here, then the Tools tab's "Check Travelpayouts
  // rates" button lights up. Until both are filled in, that button stays
  // disabled and explains why rather than failing silently.
  travelpayoutsApiToken: "",
  travelpayoutsMarker: "",
  // Smart scanning (v1.37.0): order steps by urgency/volatility/staleness
  // and let automatic runs skip recently-checked ones.
  smartScan: true,
  // Also scan stays that start tonight (the weekly windows begin tomorrow).
  scanTonight: true,
  // A cheap frequent pass over only the next few days' stays, every ~90
  // minutes, for the most promising destinations (see runLastMinuteSweep).
  lastMinuteSweepEnabled: true,
  lastMinuteMaxSteps: 6,
  // Last-minute = stay starts within this many days (0 = tonight)...
  lastMinuteDays: 3,
  // ...and the price fell at least this much vs an earlier day/earlier today.
  lastMinuteDropPct: 10,
  // Paid-alerts layer. Subscribers live in storage ("subscribers"), managed
  // from the dashboard's Business tab. subscriberBotEnabled lets anyone
  // who messages the Telegram bot with /start join as a Free subscriber.
  subscriberBotEnabled: false,
  planPrices: { pro: 199, vip: 499 }, // INR / month, display + MRR only
  upgradeUrl: "",                      // payment link shown to free users
  // While the product is free (the default) every subscriber gets every
  // alert instantly. Turn this on later to apply the Free/Pro/VIP gating.
  plansEnabled: false,
  // Public Telegram channel for GREAT deals only, e.g. "@kolkata_stay_deals"
  // or a numeric -100... id. The bot must be an admin of the channel.
  channelChatId: "",
  greatDealMinDropPct: 25,
  channelMaxPerDay: 8,
  // Google Places API key (optional) for Google Maps ratings on swipe cards.
  googlePlacesApiKey: "",
  googleDailyCap: 30,
  // Also fetch Google photos and review snippets with each lookup (a higher Google price tier per call).
  googleFetchExtras: true,
  // Where Swipe-card Google data comes from: "browser" (free: reads the Google
  // Maps page in your own Chrome) or "api" (Places API key, billed by Google).
  googleSource: "browser",
  googleBrowserDailyCap: 60,
  // Re-check a great deal's detail page a few minutes later before telling
  // anyone, so a misread price never becomes a fake alert.
  confirmBeforeAlert: true,
  confirmDelayMinutes: 10,
  // v1.39
  passiveCollect: true,   // ingest prices from MakeMyTrip pages you open yourself
  digestEnabled: true,    // one post a day with the weekend's best-value stays
  digestHour: 8,
  // v1.40: helper computer. "main" does everything. "helper" only scans its
  // share of destinations and sends results through GitHub, no alerts, no
  // publishing, no backups (so it can never overwrite the main PC's).
  deviceRole: "main",
  deviceName: "",
  scanDestinations: [],   // destination names THIS computer scans, empty = all
  helpersEnabled: false,  // main: look for helper uploads and share state with them
  mmtClearAllOnBlock: true, // on a MakeMyTrip block, clear its cookies and site data too, not just the cache
  publishExtensionUpdates: true, // main: keep extension/update.zip in the GitHub repo current for other computers
  alertRecordLow: true,   // tell me when a stay hits its lowest price ever (must-know)
  recordLowMinBelowPct: 5, // ...and the new price must be this % under its previous best
  alertGoodDeals: true,   // tell me about stays well below their usual price, on every destination
  goodDealBelowPct: 25,   // "really good" = at least this % under the usual price
  scanIntensity: "more",  // how often to scan: normal (every 12h) / more (every 6h, nearest weekends re-checked every few hours) / max (every 3h)
  alertHorizonDays: 42,   // weekends further away than this do not alert (a stay within a week always can)
  alertPingMax: 6,        // urgent pings to the owner per day; everything else goes in the digest
  digestEveryHours: 3,    // the deal digest goes out at most this often, 8am to 10pm
  digestItems: 6,         // deals shown in one digest message
  botAsks: true,          // the bot answers questions like "best deals Mandarmani next friday" (the owner; subscribers too when sign-ups are on)
  alertMarketDeals: true, // tell me about stays far cheaper than comparable hotels on the same dates (no target needed)
  marketDealBelowPct: 25, // "far cheaper" = at least this % under the median of similar hotels
  marketDealMinPeers: 5,  // comparable same-star hotels needed on those dates
  marketDealDailyMax: 6,  // at most this many market-deal alerts a day, best first
  holidayText: null,      // null = built-in list (DEFAULT_HOLIDAY_TEXT in intel.js), editable in the Business tab
};

// Rough, well-known typical travel times from Kolkata for these
// destinations, not a live check against any transit API, just general
// knowledge of these established routes. Shown as an approximate range
// since actual time varies with traffic, train class, and route chosen.
const KOLKATA_TRANSIT_ESTIMATES = {
  digha: "~3.5-4h by train or car",
  mandarmoni: "~4-4.5h by car",
  darjeeling: "~10-12h by road, or fly to Bagdogra + ~3h road",
  sundarbans: "~3-4h by road + boat",
  puri: "~7-8h by train",
  kolkata: "In the city",
  shantiniketan: "~3h by train or car",
  gangtok: "~12-14h by road, or fly to Bagdogra + ~4-5h road",
  purulia: "~5-6h by train or car",
};

function transitEstimate(destination) {
  return KOLKATA_TRANSIT_ESTIMATES[(destination || "").toLowerCase().trim()] || null;
}

/**
 * Amenity/couple-friendly badges (PROJECT_BRIEF open item 3). Detected by
 * scanning a hotel detail page's own visible text for these phrases,
 * rather than parsing specific CSS classes or DOM structure, the same
 * defensive reasoning as the SerpApi field-name fallback: a keyword match
 * against rendered text survives a markup change that would break a
 * selector. UNVERIFIED against a real MakeMyTrip/Goibibo detail page,
 * this environment has no network access to check the actual wording
 * these sites use, only well-known general phrasing. Test against a real
 * page before trusting the results, and adjust the patterns here if a
 * known amenity isn't getting picked up.
 *
 * Deliberately only visited alongside the existing opt-in detail-page
 * check (see checkRoomDetailsForTopN), not a new scan step of its own,
 * since detecting this requires the same page load that's already
 * opt-in and already costs real scan time.
 */
/**
 * Text that marks a nearby number as a promo/discount/cashback figure
 * rather than an actual price ("Flat ₹330 Off", "₹150 Cashback", "Save
 * extra ₹100"). Shared by content.js (listing pages) and
 * detail-content.js (detail pages) so this can't quietly diverge between
 * the two the way it once did — detail-content.js had no such filter at
 * all until v1.24.1, and content.js's own copy was unanchored (matched
 * "off" inside "coffee", "office", "toffee", "cutoff") until this word-
 * boundaried version replaced both.
 */
const PROMO_RE = /\boff\b|\bdiscount\b|\bcashback\b|\bsave\b|\bextra\b|\bcoupon\b|\bflat\s*₹/i;

/**
 * Same class of bug as PROMO_RE above, found while adding a test for it:
 * the unanchored `/tax|fee/` this replaces matched "fee" as a substring
 * of "coffee" and "toffee" (an amenity like "complimentary coffee" sitting
 * near a real price was enough to wrongly exclude it), and would've
 * matched "tax" inside an unrelated word starting with it too. Boundaried,
 * but still matches the actual "Taxes & Fees" wording this exists for.
 */
const TAX_RE = /\btax(es)?\b|\bfee(s)?\b/i;

const AMENITY_PATTERNS = [
  { label: "Unmarried Couples Allowed", re: /unmarried coupl(e|es)|couple[- ]friendly|couples allowed/i },
  { label: "Private Balcony", re: /private balcony/i },
  { label: "Swimming Pool", re: /swimming pool/i },
  { label: "Spa", re: /\bspa\b/i },
  { label: "Beachfront", re: /beach\s?front|beach access|on the beach/i },
  { label: "Free Wifi", re: /free wi[- ]?fi/i },
  { label: "Free Parking", re: /free parking/i },
  { label: "Pet Friendly", re: /pet[- ]friendly/i },
  { label: "Room Service", re: /room service/i },
];

/** Pure so it's unit-testable without a DOM, see detail-content.js for the caller. */
function findAmenitiesInText(text) {
  const found = [];
  for (const { label, re } of AMENITY_PATTERNS) {
    if (re.test(text || "")) found.push(label);
  }
  return found;
}

/**
 * Flags a date entry whose price looks like a bad scrape rather than a
 * real discount: far below every OTHER tracked date for the SAME hotel,
 * with nothing else this hotel has ever shown coming anywhere close.
 * A genuine weekend price swing at one property doesn't usually run past
 * a 4x gap; a lone date sitting under a quarter of what every other date
 * on the same hotel shows is much more likely a promo/cashback/tax figure
 * that slipped past the scraper (see detail-content.js's isPromo fix,
 * added because it had no such filter and a page's own "Flat ₹330 Off"
 * banner could out-compete the real room price for Math.min()).
 *
 * Needs at least one other date on the same hotel to compare against, a
 * hotel tracked on a single date has nothing to be an outlier relative
 * to and is left unflagged rather than guessed at. Pure and returns new
 * objects (doesn't mutate the input) so it's unit-testable without
 * chrome.storage, same reasoning as evaluateTargetAlert below.
 */
function flagOutlierDates(dates, ratio = 0.25) {
  return dates.map((d) => {
    const others = dates.filter((o) => o !== d && typeof o.current === "number");
    if (others.length === 0 || typeof d.current !== "number") {
      return { ...d, isLikelyBadScrape: false };
    }
    const maxOther = Math.max(...others.map((o) => o.current));
    return { ...d, isLikelyBadScrape: d.current < maxOther * ratio };
  });
}

/**
 * Percentile rank of `value` within `dataset`: the fraction of dataset
 * entries strictly greater than value. 1.0 means value is lower than
 * every other price in the dataset (as rare as a reading can get); 0
 * means nothing in the dataset is higher. This is the actual test for
 * "rare", which "all-time low"/"lowest ever" isn't: that badge is
 * trivially true the very first time a hotel is scraped (there's
 * nothing else to compare against yet), a percentile only means
 * something once there's a real distribution of prices behind it.
 */
function percentileRank(value, dataset) {
  if (!dataset || dataset.length === 0 || typeof value !== "number") return null;
  const higher = dataset.filter((v) => v > value).length;
  return higher / dataset.length;
}

/**
 * True only if a price has actually HELD at (or near) a given threshold
 * for at least two consecutive scans, not landed there once. A single-
 * scan crash to a suspiciously low number has already turned out twice
 * to be a promo/tax banner misread as the room price (see PROMO_RE/
 * TAX_RE and detail-content.js's isPromo history) rather than a genuine
 * deal, so requiring persistence before calling something "rare" is
 * cheap insurance against a new badge repeating an old bug's failure
 * mode. Allows a small (2%) tolerance between the two scans, a real
 * re-scrape of the same live price rarely comes back byte-identical.
 */
function isPersistentLow(priceHistory, thresholdPrice) {
  if (!priceHistory || priceHistory.length < 2 || typeof thresholdPrice !== "number") return false;
  const sorted = [...priceHistory].sort((a, b) => new Date(a.at) - new Date(b.at));
  const lastTwo = sorted.slice(-2);
  return lastTwo.every((p) => typeof p.price === "number" && p.price <= thresholdPrice * 1.02);
}

/**
 * Self-history rarity: is this hotel's current cheapest price in the
 * bottom slice of every price this SAME hotel has ever shown, across
 * every date it's tracked on. Pools price history across all of a
 * hotel's dates (rather than just its cheapest date's own history)
 * since this is a weekend-only tracker, every tracked date is broadly
 * comparable, and pooling reaches a usable sample size far sooner than
 * waiting on one single date's own scan history. Requires both a real
 * percentile (not just "lower than the couple of scrapes done so far")
 * and persistence across the last two scans of the actual winning date,
 * see isPersistentLow above for why a single-scan dip doesn't count.
 */
function computeSelfRarity(group, opts = {}) {
  const minDataPoints = opts.minDataPoints ?? 8;
  const percentileThreshold = opts.percentile ?? 0.85; // bottom 15% of history

  const pooled = (group.dates || [])
    .flatMap((d) => d.priceHistory || [])
    .filter((p) => typeof p.price === "number");

  if (pooled.length < minDataPoints) {
    return { isRareLow: false, reason: "not enough price history yet to tell", dataPoints: pooled.length, percentile: null };
  }

  const cheapest = group.cheapest;
  if (!cheapest || typeof cheapest.current !== "number") {
    return { isRareLow: false, reason: "no current price", dataPoints: pooled.length, percentile: null };
  }

  const rank = percentileRank(cheapest.current, pooled.map((p) => p.price));
  if (rank === null || rank < percentileThreshold) {
    return { isRareLow: false, reason: "not in the rare percentile of this hotel's own history", dataPoints: pooled.length, percentile: rank };
  }

  const persistent = isPersistentLow(cheapest.priceHistory, cheapest.current);
  return {
    isRareLow: persistent,
    reason: persistent
      ? `beats ${Math.round(rank * 100)}% of this hotel's own price history, held for 2+ scans`
      : "a rare-looking price showed up, waiting for the next scan to confirm it holds",
    dataPoints: pooled.length,
    percentile: rank,
  };
}

/**
 * Peer-comparison rarity: is this hotel's cheapest price meaningfully
 * below what OTHER tracked hotels of the same star tier, in the same
 * destination, are showing right now. Catches a hotel that has always
 * been cheap (so it would never trip computeSelfRarity above, its own
 * history has nothing higher to stand out against) as long as it's
 * genuinely cheap relative to its actual peers, not just relative to
 * itself. Star tier resolution mirrors dashboard.js's starTierValue():
 * manual correction first, then real scraped stars, then the AI
 * estimate, in that order.
 */
function computePeerRarity(group, allGroups, opts = {}) {
  const minPeers = opts.minPeers ?? 3;
  const ratio = opts.ratio ?? 0.75; // at least 25% below the peer median

  const tier = group.manualStarTier || group.starRating || group.aiEstimatedStarTier || null;
  if (!tier) {
    return { isPeerRareLow: false, reason: "no star tier to compare against", peerCount: 0, peerMedian: null };
  }

  const peers = (allGroups || []).filter((o) => {
    if (o === group || o.groupKey === group.groupKey) return false;
    if (o.destination !== group.destination) return false;
    const peerTier = o.manualStarTier || o.starRating || o.aiEstimatedStarTier || null;
    return peerTier === tier;
  });

  const peerPrices = peers.map((p) => p.cheapestPrice).filter((v) => typeof v === "number").sort((a, b) => a - b);
  if (peerPrices.length < minPeers) {
    return { isPeerRareLow: false, reason: "not enough same-tier peers tracked in this destination yet", peerCount: peerPrices.length, peerMedian: null };
  }
  const mid = Math.floor(peerPrices.length / 2);
  const median = peerPrices.length % 2 !== 0 ? peerPrices[mid] : (peerPrices[mid - 1] + peerPrices[mid]) / 2;

  const isPeerRareLow = typeof group.cheapestPrice === "number" && group.cheapestPrice <= median * ratio;
  return {
    isPeerRareLow,
    reason: isPeerRareLow
      ? `${Math.round((1 - group.cheapestPrice / median) * 100)}% below the ${tier}★ ${group.destination} median (${peers.length} peers)`
      : "not meaningfully below same-tier peers",
    peerCount: peers.length,
    peerMedian: median,
  };
}

/**
 * Combines both rarity checks into one badge decision. A deal is
 * flagged "rare" if EITHER its own history or its peer comparison says
 * so, since the two answer genuinely different questions (has THIS
 * hotel gotten unusually cheap for itself, vs is it cheap relative to
 * what else is available right now) and either on its own is worth
 * surfacing rather than requiring both to agree.
 */
function computeRarityBadge(group, allGroups, opts = {}) {
  const self = computeSelfRarity(group, opts);
  const peer = computePeerRarity(group, allGroups, opts);
  const reasons = [];
  if (self.isRareLow) reasons.push(self.reason);
  if (peer.isPeerRareLow) reasons.push(peer.reason);
  return { isRareDeal: self.isRareLow || peer.isPeerRareLow, self, peer, reasons };
}

/**
 * Pure decision logic for price-target alerts, kept separate from
 * chrome.storage so it can be unit-tested directly. Given the current
 * price, the user's target (null/undefined = no target set), and whether
 * an alert was already sent for the current below-target streak, says
 * whether to alert now and what the "already alerted" flag should become.
 * This is what makes the alert fire once per dip below target rather than
 * every single scan while the price stays low, and re-arm once the price
 * rises back above target so a future dip can alert again.
 */
function evaluateTargetAlert(currentPrice, targetPrice, alreadyAlerted) {
  if (targetPrice === null || targetPrice === undefined) {
    return { shouldAlert: false, newAlertedState: !!alreadyAlerted };
  }
  const isBelow = currentPrice <= targetPrice;
  if (isBelow && !alreadyAlerted) return { shouldAlert: true, newAlertedState: true };
  if (!isBelow && alreadyAlerted) return { shouldAlert: false, newAlertedState: false };
  return { shouldAlert: false, newAlertedState: !!alreadyAlerted };
}

/**
 * PROJECT_BRIEF.md Open Item #14: the "Rare deal" badge (v1.28.0,
 * computeRarityBadge() above) was a dashboard-only signal, never wired
 * into an alert channel. Same fire-once/re-arm shape as
 * evaluateTargetAlert() above, just applied to a boolean flag
 * (isRareDeal) instead of a price-vs-target comparison: alert once when
 * a hotel's rarity badge first turns on, stay quiet while it remains on
 * (so an 8-day-old rare price isn't re-announced every single scan),
 * and re-arm once it turns off so a future rare dip can alert again.
 */
function evaluateRareDealAlert(isRareDeal, alreadyAlerted) {
  if (isRareDeal && !alreadyAlerted) return { shouldAlert: true, newAlertedState: true };
  if (!isRareDeal && alreadyAlerted) return { shouldAlert: false, newAlertedState: false };
  return { shouldAlert: false, newAlertedState: !!alreadyAlerted };
}

async function getSettings() {
  const stored = await chrome.storage.local.get("settings");
  let settings = stored.settings ? { ...DEFAULTS, ...stored.settings } : { ...DEFAULTS, destinations: [...DEFAULT_DESTINATIONS] };
  let changed = !stored.settings;

  // Migrate: if new default destinations were added in an update (like
  // Kolkata/West Bengal), add them for existing installs too, without
  // touching destinations you've already set up and learned codes for.
  const existingNames = new Set(settings.destinations.map((d) => d.name.toLowerCase()));
  for (const d of DEFAULT_DESTINATIONS) {
    if (!existingNames.has(d.name.toLowerCase())) {
      settings.destinations.push({ ...d });
      changed = true;
    }
  }

  // Migrate: an old install may have a single serpApiKey string from
  // before multiple keys were supported, fold it into the new array
  // rather than losing it.
  if (settings.serpApiKey && (!settings.serpApiKeys || settings.serpApiKeys.length === 0)) {
    settings.serpApiKeys = [settings.serpApiKey];
    delete settings.serpApiKey;
    changed = true;
  }

  if (changed) await chrome.storage.local.set({ settings });
  return settings;
}

async function saveSettings(settings) {
  await chrome.storage.local.set({ settings });
}

/** Upcoming weekends as {checkin, checkout} ISO date strings. */
function upcomingWeekends(nights, checkinWeekday, lookaheadDays, today = new Date()) {
  const start = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  const daysUntil = (checkinWeekday - start.getDay() + 7) % 7;
  let checkin = new Date(start);
  checkin.setDate(checkin.getDate() + daysUntil);

  const weekends = [];
  while ((checkin - start) / 86400000 <= lookaheadDays) {
    const checkout = new Date(checkin);
    checkout.setDate(checkout.getDate() + nights);
    weekends.push({ checkin: toISODate(checkin), checkout: toISODate(checkout) });
    checkin = new Date(checkin);
    checkin.setDate(checkin.getDate() + 7);
  }
  return weekends;
}

/** Every day in the next 7 days as a check-in candidate, starting
 * tomorrow, not today, checking in same-day isn't useful for planning
 * ahead and just wastes a scan step. */
function next7DaysWindow(nights, today = new Date()) {
  const start = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  const results = [];
  for (let i = 1; i <= 7; i++) {
    const checkin = new Date(start);
    checkin.setDate(checkin.getDate() + i);
    const checkout = new Date(checkin);
    checkout.setDate(checkout.getDate() + nights);
    results.push({ checkin: toISODate(checkin), checkout: toISODate(checkout) });
  }
  return results;
}

/** Combines two {checkin, checkout} lists, dropping duplicate check-in dates. */
function dedupeByCheckin(...lists) {
  const seen = new Set();
  const out = [];
  for (const list of lists) {
    for (const w of list) {
      if (!seen.has(w.checkin)) {
        seen.add(w.checkin);
        out.push(w);
      }
    }
  }
  return out;
}

function toISODate(d) {
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

/** DDMMYYYY, the format MakeMyTrip URLs use. */
function toMmtDate(isoDate) {
  const [y, m, d] = isoDate.split("-");
  return `${d}${m}${y}`;
}

function formatINR(amount) {
  if (amount === null || amount === undefined) return "N/A";
  const n = Math.abs(Math.round(amount));
  const s = String(n);
  let grouped;
  if (s.length <= 3) {
    grouped = s;
  } else {
    const last3 = s.slice(-3);
    let rest = s.slice(0, -3);
    const parts = [];
    while (rest.length > 2) {
      parts.unshift(rest.slice(-2));
      rest = rest.slice(0, -2);
    }
    if (rest) parts.unshift(rest);
    grouped = parts.join(",") + "," + last3;
  }
  return (amount < 0 ? "-" : "") + "\u20b9" + grouped;
}

/**
 * MakeMyTrip turned out to ignore the dates we passed and fall back to its
 * own defaults (today + tomorrow), which would have meant silently
 * tracking the wrong dates forever. The exact format it expects isn't
 * documented, so rather than guessing, the extension tries these in turn
 * and keeps whichever one the site actually honours, see
 * calibrateMmtDateFormat() in background.js.
 */
// MakeMyTrip's own format is month-day-year ("10212026" = 21 Oct 2026), checked
// live in Oct 2026: asked for "24102026" (day-month-year) it silently ignores
// the dates and shows tonight's price instead. This used to be listed first,
// so every scan priced "tonight" and filed it under the date it had asked for.
const MMT_DATE_FORMATS = ["MMDDYYYY", "DDMMYYYY", "YYYY-MM-DD", "DD-MM-YYYY", "MM/DD/YYYY"];

/** One date from a MakeMyTrip URL parameter, as ISO, or null if it isn't a real date. */
function parseMmtUrlDate(raw) {
  if (!raw) return null;
  let y, m, d, mt;
  if ((mt = /^(\d{4})-(\d{2})-(\d{2})$/.exec(raw))) { y = +mt[1]; m = +mt[2]; d = +mt[3]; }
  else if ((mt = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(raw))) { m = +mt[1]; d = +mt[2]; y = +mt[3]; }
  else if ((mt = /^(\d{2})-(\d{2})-(\d{4})$/.exec(raw))) { d = +mt[1]; m = +mt[2]; y = +mt[3]; }
  else if ((mt = /^(\d{2})(\d{2})(\d{4})$/.exec(raw))) {
    const a = +mt[1], b = +mt[2];
    y = +mt[3];
    if (a <= 12) { m = a; d = b; } else { d = a; m = b; } // month-day-year first: that is what MakeMyTrip writes
  } else return null;
  const dt = new Date(Date.UTC(y, m - 1, d));
  if (dt.getUTCFullYear() !== y || dt.getUTCMonth() !== m - 1 || dt.getUTCDate() !== d) return null;
  return `${y}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
}

/**
 * The dates MakeMyTrip is ACTUALLY showing, from the listing page's own URL
 * (it rewrites the address to the dates it used, so when it ignores ours the
 * URL changes to its defaults). This is the only reliable source: the dates
 * are not in the page text any more. {checkin, checkout} ISO or null.
 */
function mmtDatesFromUrl(search) {
  const p = new URLSearchParams(search);
  const checkin = parseMmtUrlDate(p.get("checkin"));
  const checkout = parseMmtUrlDate(p.get("checkout"));
  return checkin && checkout ? { checkin, checkout } : null;
}

function formatDateAs(isoDate, fmt) {
  const [y, m, d] = isoDate.split("-");
  switch (fmt) {
    case "DDMMYYYY": return `${d}${m}${y}`;
    case "MMDDYYYY": return `${m}${d}${y}`;
    case "YYYY-MM-DD": return `${y}-${m}-${d}`;
    case "DD-MM-YYYY": return `${d}-${m}-${y}`;
    case "MM/DD/YYYY": return `${m}/${d}/${y}`;
    default: return `${d}${m}${y}`;
  }
}

function buildMmtUrl(code, checkinIso, checkoutIso, adults, dateFormat) {
  const fmt = dateFormat || MMT_DATE_FORMATS[0];
  const params = new URLSearchParams({
    checkin: formatDateAs(checkinIso, fmt),
    checkout: formatDateAs(checkoutIso, fmt),
    city: code,
    country: "IN",
    roomStayQualifier: `${adults}e0e`,
    locusId: code,
    locusType: "city",
    _uCurrency: "INR",
    region: "in",
  });
  return `https://www.makemytrip.com/hotels/hotel-listing/?${params.toString()}`;
}

function buildGoibiboUrl(code, checkinIso, checkoutIso, adults, rooms) {
  const params = new URLSearchParams({
    checkin: checkinIso,
    checkout: checkoutIso,
    adult: String(adults),
    room: String(rooms),
  });
  return `https://www.goibibo.com/hotels/hotels-in-${code}-ct/?${params.toString()}`;
}

/**
 * Some MakeMyTrip links have their raw href written with the domain
 * repeated as a path segment ("/www.makemytrip.com/hotels/..."). content.js
 * fixed this for new scrapes, but hotels tracked before that fix still
 * have the broken URL sitting in storage, this cleans those up wherever
 * a stored URL gets read, not just at scrape time.
 */
/**
 * Picks the hotel photo out of a listing card's images: the biggest https
 * image that is not an icon, logo, badge or star. candidates = [{src, w, h}]
 * (rendered size). Returns a URL or null. Pure, so it is unit tested.
 */
function pickBestImage(candidates) {
  let best = null;
  for (const c of candidates || []) {
    const src = String(c.src || "");
    if (!/^https:\/\//i.test(src)) continue;
    if (/\.svg(\?|$)/i.test(src) || /sprite|logo|icon|badge|star|rating|flag|avatar|placeholder/i.test(src)) continue;
    const area = (c.w || 0) * (c.h || 0);
    if (area < 80 * 60) continue; // thumbnails and icons
    if (!best || area > best.area) best = { src, area };
  }
  return best ? best.src : null;
}

function sanitizeUrl(url) {
  if (!url) return url;
  try {
    const u = new URL(url);
    const hostEscaped = u.hostname.replace(/\./g, "\\.");
    const dupRe = new RegExp(`^/${hostEscaped}(/.*)$`, "i");
    const m = dupRe.exec(u.pathname);
    if (m) u.pathname = m[1];
    return u.toString();
  } catch (e) {
    return url;
  }
}

/**
 * Loads every tracked hotel/date record and groups them by hotel, one
 * entry per hotel with all its dates nested inside, sorted cheapest
 * first. Shared by the popup/dashboard (manual publish) and background.js
 * (automatic publish after every scan), so both stay in sync.
 */
async function loadTrackedHotelGroups() {
  const all = await chrome.storage.local.get(null);
  const { favoriteHotels = [] } = await chrome.storage.local.get("favoriteHotels");
  const favoriteMap = new Map(favoriteHotels.map((f) => [`${f.source}:::${f.hotelName}:::${f.destination}`, f]));
  const settings = await getSettings();
  const destTargetMap = new Map((settings.destinationTargets || []).map((t) => [t.destination, t.targetPrice]));
  const rows = [];
  for (const [key, value] of Object.entries(all)) {
    if (!key.startsWith("hist:") || !value || !Array.isArray(value.prices) || value.prices.length === 0) continue;
    // A price below this floor can only be leftover corruption from
    // before detail-content.js had a plausibility check, it can never
    // come from a legitimate scrape going forward (both content.js and
    // detail-content.js now enforce this floor at the source). If the
    // most recent recorded price is corrupted, fall back to the latest
    // plausible one instead of displaying garbage as "the price".
    const plausiblePriceEntries = value.prices.filter((p) => p.price >= 300);
    // Points with a verified date (dv: 1) are the only ones that can be trusted
    // to belong to this check-in date. Older points were often tonight's price
    // filed under another date (see MMT_DATE_FORMATS), they stay as history
    // but are not used while any verified point exists.
    const verifiedEntries = plausiblePriceEntries.filter((p) => p.dv === 1);
    const hasVerified = verifiedEntries.length > 0;
    const basis = hasVerified ? verifiedEntries : plausiblePriceEntries;
    const currentSource = basis.length > 0 ? basis : value.prices;
    const current = currentSource[currentSource.length - 1].price;

    // Math.min only ever ratchets a value down, it can never self-correct
    // upward, so one corrupted reading below the floor stays stuck as
    // "lowest ever" permanently unless actively recovered here.
    let lowest = hasVerified ? Math.min(...verifiedEntries.map((p) => p.price)) : value.lowest;
    if (lowest < 300) {
      lowest = plausiblePriceEntries.length > 0 ? Math.min(...plausiblePriceEntries.map((p) => p.price)) : current;
    }

    rows.push({
      key,
      hotelName: value.hotelName,
      destination: value.destination,
      source: value.source,
      starRating: value.starRating,
      rating: value.rating ?? null,
      reviewCount: value.reviewCount ?? null,
      checkin: value.checkin,
      checkout: value.checkout,
      url: sanitizeUrl(value.url),
      isNewlyBuilt: !!value.isNewlyBuilt,
      imageUrl: value.imageUrl ?? null,
      current,
      priceHistory: basis.length > 0 ? basis : value.prices,
      verified: hasVerified,
      originalPrice: value.originalPrice ?? null,
      lowest,
      lowestAt: value.lowestAt,
      updatedAt: value.updatedAt,
      roomDetailLowest: value.roomDetailLowest >= 300 ? value.roomDetailLowest : null,
      youtubeViews: value.youtubeViews ?? null,
      youtubeVideoCount: value.youtubeVideoCount ?? null,
      youtubeVideoTitle: value.youtubeVideoTitle ?? null,
      youtubeVideoUrl: value.youtubeVideoUrl ?? null,
      youtubeTopShort: value.youtubeTopShort ?? null,
      youtubeTopLong: value.youtubeTopLong ?? null,
      youtubeShorts: value.youtubeShorts ?? null,
      youtubeLongForm: value.youtubeLongForm ?? null,
      youtubeCheckedAt: value.youtubeCheckedAt ?? null,
      aiEstimatedStarTier: value.aiEstimatedStarTier ?? null,
      aiEstimatedStarConfidence: value.aiEstimatedStarConfidence ?? null,
      manualStarTier: value.manualStarTier ?? null,
      amenities: value.amenities ?? [],
      aiReviewSummary: value.aiReviewSummary ?? null,
    });
  }

  const groups = new Map();
  for (const r of rows) {
    const groupKey = `${r.source}:::${r.hotelName}:::${r.destination}`;
    if (!groups.has(groupKey)) {
      groups.set(groupKey, {
        groupKey,
        hotelName: r.hotelName,
        destination: r.destination,
        source: r.source,
        starRating: r.starRating,
        rating: r.rating,
        reviewCount: r.reviewCount,
        isNewlyBuilt: r.isNewlyBuilt,
        imageUrl: null,
        youtubeViews: null,
        youtubeVideoCount: null,
        youtubeVideoTitle: null,
        youtubeVideoUrl: null,
        youtubeTopShort: null,
        youtubeTopLong: null,
        youtubeShorts: null,
        youtubeLongForm: null,
        youtubeCheckedAt: null,
        aiEstimatedStarTier: null,
        aiEstimatedStarConfidence: null,
        manualStarTier: null,
        aiReviewSummary: null,
        dates: [],
      });
    }
    const g = groups.get(groupKey);
    g.dates.push(r);
    if (r.isNewlyBuilt) g.isNewlyBuilt = true;
    if (!g.imageUrl && r.imageUrl) g.imageUrl = r.imageUrl;
    if (g.rating === null && r.rating !== null) { g.rating = r.rating; g.reviewCount = r.reviewCount; }
    if (g.aiEstimatedStarTier === null && r.aiEstimatedStarTier !== null) {
      g.aiEstimatedStarTier = r.aiEstimatedStarTier;
      g.aiEstimatedStarConfidence = r.aiEstimatedStarConfidence;
    }
    if (g.manualStarTier === null && r.manualStarTier !== null) {
      g.manualStarTier = r.manualStarTier;
    }
    if (g.aiReviewSummary === null && r.aiReviewSummary !== null) {
      g.aiReviewSummary = r.aiReviewSummary;
    }
    // Whichever date record was checked most recently wins, this is a
    // property-level signal duplicated across every date, so "most
    // recent" is the meaningful one, not "highest views".
    if (r.youtubeCheckedAt && (!g.youtubeCheckedAt || r.youtubeCheckedAt > g.youtubeCheckedAt)) {
      g.youtubeViews = r.youtubeViews;
      g.youtubeVideoCount = r.youtubeVideoCount;
      g.youtubeVideoTitle = r.youtubeVideoTitle;
      g.youtubeVideoUrl = r.youtubeVideoUrl;
      g.youtubeTopShort = r.youtubeTopShort;
      g.youtubeTopLong = r.youtubeTopLong;
      g.youtubeShorts = r.youtubeShorts;
      g.youtubeLongForm = r.youtubeLongForm;
      g.youtubeCheckedAt = r.youtubeCheckedAt;
    }
  }

  for (const g of groups.values()) {
    g.dates.sort((a, b) => a.current - b.current);
    // Flag any date whose price looks like a mis-scraped promo/tax figure
    // rather than a real price, see flagOutlierDates() above. Replaces
    // g.dates with new objects carrying isLikelyBadScrape, order unchanged.
    g.dates = flagOutlierDates(g.dates);

    // A date that's already passed can never be rescanned, the scan
    // only ever generates future date-windows, so a stale, wrong price
    // recorded for a date that's now behind us would otherwise stay
    // stuck as "the price" forever, uncorrectable by any future scan.
    // Full history stays in g.dates for the expanded view, this only
    // affects what counts as the headline "cheapest" figure.
    const today = toISODate(new Date());
    const bookableDates = g.dates.filter((d) => d.checkin >= today);
    let relevantDates = bookableDates.length > 0 ? bookableDates : g.dates;

    // Prefer dates that don't look like a bad scrape for the headline
    // cheapest/lowest figures, otherwise an implausibly small mis-scraped
    // number would still win as "the cheapest" purely by being the
    // smallest one, exactly what happened before this fix. Only falls
    // back to including flagged dates when literally every date for this
    // hotel is flagged, better to show a suspect number than none at all.
    // Prefer dates whose prices were verified; fall back to the legacy ones
    // only for a hotel that has none yet (it is flagged so screens can say so).
    g.unverified = !g.dates.some((d) => d.verified);
    const verifiedRows = relevantDates.filter((d) => d.verified);
    if (verifiedRows.length > 0) relevantDates = verifiedRows;

    const trustedDates = relevantDates.filter((d) => !d.isLikelyBadScrape);
    if (trustedDates.length > 0) relevantDates = trustedDates;

    g.cheapest = relevantDates[0];
    g.cheapestPrice = g.cheapest.current;
    g.everAtLowest = relevantDates.some((d) => d.current <= d.lowest);
    g.lowestEver = Math.min(...relevantDates.map((d) => d.lowest));
    g.hasFlaggedDates = g.dates.some((d) => d.isLikelyBadScrape);

    const favEntry = favoriteMap.get(g.groupKey);
    g.isFavorite = !!favEntry;
    g.targetPrice = favEntry && favEntry.targetPrice != null ? favEntry.targetPrice : null;
    const destTarget = destTargetMap.has(g.destination) ? destTargetMap.get(g.destination) : null;
    g.effectiveTargetPrice = g.targetPrice ?? destTarget;
    g.targetPriceSource = g.targetPrice != null ? "hotel" : destTarget != null ? "destination" : null;

    // Property-level, not per-date, a hotel's amenities don't change by
    // check-in date. Union across whichever dates happened to get a
    // detail-page visit (see checkRoomDetailsForTopN), rather than only
    // the cheapest date, so an amenity found via a different date's visit
    // still shows up.
    g.amenities = [...new Set(g.dates.flatMap((d) => d.amenities || []))];
  }

  // Rarity needs every group's cheapest/cheapestPrice/star tier already
  // settled (for peer comparison), so this is a second pass over the
  // now-fully-built list, not folded into the loop above.
  const groupList = Array.from(groups.values());
  for (const g of groupList) {
    g.rarity = computeRarityBadge(g, groupList);
  }
  return groupList;
}

/**
 * One row per (hotel, tracked date) -- not one row per hotel -- so the
 * export actually reflects everything the extension has recorded, not
 * just each hotel's current headline price. The only export that
 * existed before this was the activity log (dashboard.js's
 * activityLogToCsv(), diagnostics only); there was no way to get the
 * actual tracked hotel/price data itself out of Chrome storage for
 * personal analysis or a record outside the extension.
 */
function trackedHotelsToCsv(groups) {
  const escapeCsv = (val) => {
    const s = val === null || val === undefined ? "" : typeof val === "object" ? JSON.stringify(val) : String(val);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const header = [
    "Hotel", "Destination", "Source", "Star tier", "Rating", "Review count",
    "Check-in", "Check-out", "Price (INR)", "Lowest ever (INR)", "Original price (INR)",
    "Discount %", "Newly built", "Favorite", "Rare deal", "Looks like a bad scrape",
    "Amenities", "YouTube views", "Last checked", "Booking URL",
  ].join(",") + "\n";

  const rows = [];
  for (const g of groups) {
    const starTier = g.manualStarTier || g.starRating || g.aiEstimatedStarTier || "";
    for (const d of g.dates) {
      const discountPct = d.originalPrice && d.originalPrice > d.current
        ? Math.round(((d.originalPrice - d.current) / d.originalPrice) * 100)
        : "";
      rows.push([
        g.hotelName, g.destination, g.source, starTier, g.rating ?? "", g.reviewCount ?? "",
        d.checkin, d.checkout, d.current, d.lowest, d.originalPrice ?? "",
        discountPct, g.isNewlyBuilt ? "Yes" : "No", g.isFavorite ? "Yes" : "No",
        g.rarity && g.rarity.isRareDeal ? "Yes" : "No", d.isLikelyBadScrape ? "Yes" : "No",
        (g.amenities || []).join("; "), g.youtubeViews ?? "", d.updatedAt, d.url,
      ].map(escapeCsv).join(","));
    }
  }
  return header + rows.join("\n");
}

/**
 * search.list costs 100 quota units, videos.list costs ~1, against a free
 * daily quota of 10,000 -- roughly 100 hotel checks/day for free. Used
 * by both the dashboard's manual "Check YouTube popularity" button
 * (dashboard.js) and, since v1.34.0, background.js's automatic daily
 * check (PROJECT_BRIEF.md Open Item #10, "automatic periodic re-checks,
 * not built" -- now built). Moved here from dashboard.js so both
 * callers share the exact same matching/scoring logic rather than
 * risking two copies drifting apart, the same lesson this project keeps
 * relearning on other parallel paths (see PROJECT_BRIEF.md's
 * "conventions" section).
 */
/** Parses an ISO 8601 duration ("PT1M30S") into seconds. */
function parseISO8601Duration(iso) {
  const m = /^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/.exec(iso || "");
  if (!m) return 0;
  const h = parseInt(m[1] || "0", 10);
  const min = parseInt(m[2] || "0", 10);
  const s = parseInt(m[3] || "0", 10);
  return h * 3600 + min * 60 + s;
}

// YouTube Shorts can run up to 3 minutes as of the 2024 length increase,
// not just 60 seconds, using the older 60s cutoff would misclassify a
// lot of real Shorts as long-form.
const SHORT_MAX_SECONDS = 180;

// Words too generic to count as "this video is specifically about this
// hotel", every property near a beach has "resort" and "sea view" in its
// name, matching on those alone is how a single generic "Mandarmani
// trip" vlog was ending up falsely attributed to several different,
// unrelated hotels in the same destination.
const GENERIC_HOTEL_WORDS = new Set([
  "hotel", "resort", "beach", "spa", "the", "near", "new", "inn", "stay",
  "homestay", "cottage", "cabin", "guest", "house", "view", "sea", "lodge",
  "camp", "retreat", "villa", "paradise", "park", "garden", "and", "of",
]);

// Plain "s" plurals of a generic word are just as generic ("resorts",
// "villas", "cottages"), a hotel literally named "... Resorts" was
// slipping through as "distinctive" against a video titled "Top 10
// resorts in Digha" purely because the set only had the singular form.
// Not a full stemmer, just the common case.
function isGenericHotelWord(w) {
  return GENERIC_HOTEL_WORDS.has(w) || (w.endsWith("s") && GENERIC_HOTEL_WORDS.has(w.slice(0, -1)));
}

function significantWords(name) {
  return (name || "")
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((w) => w.length >= 3 && !isGenericHotelWord(w));
}

/**
 * A video only counts as genuinely about this hotel if its title
 * contains at least one word that's distinctive to the hotel specifically,
 * not just generic hospitality vocabulary or the destination's own name,
 * which is often embedded right in the hotel's name (a hotel named
 * "... Near New Digha Beach" would otherwise match any video merely
 * about Digha generally, the exact same failure mode with extra steps).
 * If a hotel's name has nothing left over after stripping both, don't
 * filter at all, there's nothing distinctive to check against.
 */
function isGenuineVideoMatch(hotelName, destination, videoTitle) {
  const destinationWords = new Set(significantWords(destination));
  const sigWords = significantWords(hotelName).filter((w) => !destinationWords.has(w));
  if (sigWords.length === 0) return true;
  const titleLower = (videoTitle || "").toLowerCase();
  return sigWords.some((w) => titleLower.includes(w));
}

async function checkYoutubeForHotel(hotelName, destination, apiKey) {
  const query = encodeURIComponent(`${hotelName} ${destination} hotel`);
  // maxResults doesn't cost extra quota, search.list is a flat 100 units
  // regardless of how many results come back, 8 gives enough spread to
  // find both a Short and a long-form video where they exist.
  const searchResp = await fetch(
    `https://www.googleapis.com/youtube/v3/search?part=snippet&q=${query}&type=video&maxResults=8&order=viewCount&key=${encodeURIComponent(apiKey)}`
  );
  const searchData = await searchResp.json();
  if (!searchResp.ok) throw new Error(searchData.error?.message || `YouTube search failed (${searchResp.status})`);

  const videoIds = (searchData.items || []).map((it) => it.id?.videoId).filter(Boolean);
  if (videoIds.length === 0) return emptyYoutubeResult();

  const statsResp = await fetch(
    `https://www.googleapis.com/youtube/v3/videos?part=statistics,snippet,contentDetails&id=${videoIds.join(",")}&key=${encodeURIComponent(apiKey)}`
  );
  const statsData = await statsResp.json();
  if (!statsResp.ok) throw new Error(statsData.error?.message || `YouTube video lookup failed (${statsResp.status})`);

  const videos = (statsData.items || []).map((item) => ({
    videoId: item.id,
    title: item.snippet?.title,
    channelId: item.snippet?.channelId,
    channelTitle: item.snippet?.channelTitle,
    publishedAt: item.snippet?.publishedAt,
    views: parseInt(item.statistics?.viewCount || "0", 10),
    durationSeconds: parseISO8601Duration(item.contentDetails?.duration),
  }));

  if (videos.length === 0) return emptyYoutubeResult();

  const shorts = videos.filter((v) => v.durationSeconds > 0 && v.durationSeconds <= SHORT_MAX_SECONDS);
  const longForm = videos.filter((v) => v.durationSeconds > SHORT_MAX_SECONDS);

  // Only videos that actually name-check this specific hotel are
  // eligible to be picked, a loosely-relevant destination-wide vlog
  // showing up as "the video" for several unrelated hotels was actively
  // misleading, not just untidy. No genuine match means no video for
  // that category, not a fallback to the closest thing found.
  const genuineShorts = shorts.filter((v) => isGenuineVideoMatch(hotelName, destination, v.title));
  const genuineLongForm = longForm.filter((v) => isGenuineVideoMatch(hotelName, destination, v.title));

  genuineShorts.sort((a, b) => b.views - a.views);
  genuineLongForm.sort((a, b) => b.views - a.views);
  if (genuineShorts.length === 0 && genuineLongForm.length === 0) return emptyYoutubeResult();
  // Total views counts every genuinely-matched video, both formats.
  const totalViews = [...genuineShorts, ...genuineLongForm].reduce((sum, v) => sum + v.views, 0);

  // v1.27.0: this used to fetch just the top short's and top long-form
  // video's channel, plus that one channel's OTHER recent uploads (an
  // "is this creator generally good" signal). Report: "why creator of
  // one? are you tracking just one creator" — the display was only
  // showing a single video per format, which reads exactly like that
  // even though multiple creators could genuinely cover the same hotel.
  // Now every genuinely-matched video is kept (up to what the 8-result
  // search actually returned, this doesn't search further), so channel
  // info is fetched for every distinct channel involved, not just one
  // or two, and the per-video-of-this-hotel average replaces the old
  // per-channel-other-uploads average, since "does this creator usually
  // do well" was never actually the question this page is for.
  const channelIds = [...new Set([...genuineShorts, ...genuineLongForm].map((v) => v.channelId).filter(Boolean))];
  const channelInfo = {};
  if (channelIds.length) {
    try {
      const chResp = await fetch(
        `https://www.googleapis.com/youtube/v3/channels?part=statistics&id=${channelIds.join(",")}&key=${encodeURIComponent(apiKey)}`
      );
      const chData = await chResp.json();
      if (chResp.ok) {
        for (const ch of chData.items || []) {
          channelInfo[ch.id] = {
            subscriberCount: ch.statistics?.hiddenSubscriberCount ? null : parseInt(ch.statistics?.subscriberCount || "0", 10),
          };
        }
      }
    } catch (e) {
      console.log("[youtube] channel lookup failed:", e);
    }
  }

  const toVideoRecord = (v) => ({
    title: v.title,
    url: `https://www.youtube.com/watch?v=${v.videoId}`,
    views: v.views,
    publishedAt: v.publishedAt,
    channelTitle: v.channelTitle,
    channelSubs: channelInfo[v.channelId]?.subscriberCount ?? null,
  });

  const shortsRecords = genuineShorts.map(toVideoRecord);
  const longFormRecords = genuineLongForm.map(toVideoRecord);
  const topShort = shortsRecords[0] || null;
  const topLong = longFormRecords[0] || null;
  // Whichever of the two has more views drives the simple badge shown
  // in the main table, the full breakdown lives in the Video coverage
  // section for anyone who wants the detail.
  const primary = topLong && (!topShort || topLong.views >= topShort.views) ? topLong : topShort;

  return {
    totalViews,
    videoCount: shortsRecords.length + longFormRecords.length,
    topShort,
    topLong,
    shorts: shortsRecords,
    longForm: longFormRecords,
    topTitle: primary ? primary.title : null,
    topUrl: primary ? primary.url : null,
  };
}

function emptyYoutubeResult() {
  return {
    totalViews: null,
    videoCount: 0,
    topShort: null,
    topLong: null,
    shorts: [],
    longForm: [],
    topTitle: null,
    topUrl: null,
  };
}

async function getBlockedGroupKeys() {
  const { blockedHotels = [] } = await chrome.storage.local.get("blockedHotels");
  return new Set(blockedHotels.map((b) => `${b.source}:::${b.hotelName}:::${b.destination}`));
}

/** GitHub Contents API: read a file's sha (required to update it), then write. */
async function githubGetSha(repo, path, token) {
  const resp = await fetch(`https://api.github.com/repos/${repo}/contents/${path}`, {
    headers: { Authorization: `Bearer ${token}`, Accept: "application/vnd.github+json" },
  });
  if (resp.status === 404) return null;
  const data = await resp.json();
  if (!resp.ok) throw new Error(data.message || `GitHub read failed (${resp.status})`);
  return data.sha;
}

function toBase64Utf8(str) {
  return btoa(unescape(encodeURIComponent(str)));
}

function fromBase64Utf8(base64) {
  // atob() alone mangles anything outside plain ASCII, hotel names and
  // video titles here can include Bengali script and the rupee symbol,
  // so this decodes as actual bytes first, then as UTF-8 text.
  const binary = atob(base64.replace(/\n/g, ""));
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new TextDecoder("utf-8").decode(bytes);
}

/** Directory listing, [] when it does not exist. */
async function githubListDir(repo, path, token) {
  const resp = await fetch(`https://api.github.com/repos/${repo}/contents/${path}`, {
    headers: { Authorization: `Bearer ${token}`, Accept: "application/vnd.github+json" },
  });
  if (resp.status === 404) return [];
  const data = await resp.json();
  if (!resp.ok) throw new Error(data.message || `GitHub list failed (${resp.status})`);
  return Array.isArray(data) ? data.map((f) => ({ name: f.name, path: f.path, sha: f.sha, type: f.type })) : [];
}

/** Raw file contents; works for files over 1 MB, which the normal contents response leaves empty. */
async function githubGetFileRaw(repo, path, token) {
  const resp = await fetch(`https://api.github.com/repos/${repo}/contents/${path}`, {
    headers: { Authorization: `Bearer ${token}`, Accept: "application/vnd.github.raw+json" },
  });
  if (resp.status === 404) return null;
  if (!resp.ok) throw new Error(`GitHub read failed (${resp.status})`);
  return await resp.text();
}

async function githubGetFile(repo, path, token) {
  const resp = await fetch(`https://api.github.com/repos/${repo}/contents/${path}`, {
    headers: { Authorization: `Bearer ${token}`, Accept: "application/vnd.github+json" },
  });
  if (resp.status === 404) return null;
  const data = await resp.json();
  if (!resp.ok) throw new Error(data.message || `GitHub read failed (${resp.status})`);
  return fromBase64Utf8(data.content);
}

// Everything actually worth carrying to another PC: every tracked
// hotel/date's history, favorites, hidden hotels, settings, and scan
// history. Deliberately excludes anything ephemeral or derived that a
// fresh install regenerates on its own anyway: live scan/refresh
// progress, the diagnostics snapshot, and the activity log, none of
// which the person would actually mourn losing, and skipping them keeps
// the backup file meaningfully smaller.
// dealEvents (the drop feed) is included. "subscribers" is deliberately NOT:
// the backup goes to the same GitHub repo that serves the public Pages
// site, and subscriber chat IDs are personal data. They're covered by the
// dashboard's "Download full backup" file instead (buildFullBackup below).
const BACKUP_SINGLE_KEYS = ["settings", "favoriteHotels", "blockedHotels", "scanHistory", "lastScan", "dealEvents", "stepFreshness", "hotelMeta", "reviewedHotels", "swipeLog", "goldHotels", "missingIgnore"];

// backupToGithub() pushes "settings" whole into a file committed to the
// person's own GitHub repo -- this is every credential-shaped field it
// can contain. Without scrubbing these, the backup was silently failing
// every single time: GitHub's own push-protection secret scanning
// correctly recognizes a real token/API key and blocks the commit
// outright ("Repository rule violations found -- Secret detected in
// content"). Restoring a backup won't bring these back, they need to be
// re-entered by hand on the new machine, which is the right trade-off:
// credentials shouldn't sit in a git repo's history regardless of
// whether GitHub's scanner happens to catch them.
const CREDENTIAL_SETTING_KEYS = ["githubToken", "telegramBotToken", "whatsappAccessToken", "aiApiKey", "youtubeApiKey", "serpApiKey", "serpApiKeys", "googlePlacesApiKey"];

function scrubCredentials(settings) {
  const scrubbed = { ...settings };
  for (const key of CREDENTIAL_SETTING_KEYS) delete scrubbed[key];
  return scrubbed;
}

/** Thins runs of identical prices (see compactPriceHistory in intel.js) so a year of history stays a reasonable backup size. */
function compactHistForBackup(record) {
  if (!record || !Array.isArray(record.prices) || typeof compactPriceHistory !== "function") return record;
  return { ...record, prices: compactPriceHistory(record.prices) };
}

/**
 * Everything worth keeping as ONE downloadable file (dashboard button):
 * the same data as the GitHub backup plus subscribers/alert queue, with
 * credentials scrubbed. Survives losing the GitHub repo or the Chrome profile.
 */
async function buildFullBackup() {
  const all = await chrome.storage.local.get(null);
  const data = {};
  for (const [key, value] of Object.entries(all)) {
    if (key.startsWith("hist:")) data[key] = compactHistForBackup(value);
  }
  for (const key of [...BACKUP_SINGLE_KEYS, "subscribers", "watches", "rareDealAlertState", "recentScans"]) {
    if (all[key] !== undefined) data[key] = all[key];
  }
  if (data.settings) data.settings = scrubCredentials(data.settings);
  return { backedUpAt: new Date().toISOString(), format: "hotel-tracker-backup/2", keyCount: Object.keys(data).length, data };
}

/**
 * Applies a parsed backup ({data}) to local storage. hist: records are
 * MERGED with whatever is already here (every price point from both
 * sides kept), so restoring an older backup can never erase newer scans.
 * Credentials already present locally are kept (a backup never contains them).
 */
async function applyBackupData(parsedData, currentSettings) {
  const data = { ...parsedData };
  if (data.settings) {
    const restoredSettings = { ...data.settings };
    for (const key of CREDENTIAL_SETTING_KEYS) {
      if (restoredSettings[key] === undefined && currentSettings && currentSettings[key] !== undefined) {
        restoredSettings[key] = currentSettings[key];
      }
    }
    data.settings = restoredSettings;
  }
  const histKeys = Object.keys(data).filter((k) => k.startsWith("hist:"));
  if (histKeys.length && typeof mergeHistRecords === "function") {
    const local = await chrome.storage.local.get(histKeys);
    for (const k of histKeys) {
      if (local[k]) data[k] = mergeHistRecords(local[k], data[k]);
    }
  }
  await chrome.storage.local.set(data);
  return Object.keys(data).length;
}

async function backupToGithub(settings) {
  if (settings.deviceRole === "helper") {
    throw new Error("This computer is a helper. Back up from the main computer, a helper must never overwrite its backup.");
  }
  if (!settings.githubToken || !settings.githubRepo) {
    throw new Error("Add a GitHub token and repo in Settings first.");
  }
  const all = await chrome.storage.local.get(null);
  const data = {};
  for (const [key, value] of Object.entries(all)) {
    if (key.startsWith("hist:")) data[key] = compactHistForBackup(value);
  }
  for (const key of BACKUP_SINGLE_KEYS) {
    if (all[key] !== undefined) data[key] = all[key];
  }
  if (data.settings) {
    data.settings = scrubCredentials(data.settings);
  }

  const payload = JSON.stringify({ backedUpAt: new Date().toISOString(), keyCount: Object.keys(data).length, data });
  await githubPutFile(settings.githubRepo, "extension-backup.json", payload, "Backup hotel tracker data", settings.githubToken);
  return { backedUp: true, keyCount: Object.keys(data).length };
}

async function restoreFromGithub(settings) {
  if (!settings.githubToken || !settings.githubRepo) {
    throw new Error("Add a GitHub token and repo in Settings first.");
  }
  const content = await githubGetFile(settings.githubRepo, "extension-backup.json", settings.githubToken);
  if (!content) {
    throw new Error("No backup found in that repo yet, back up from the original PC first.");
  }
  const parsed = JSON.parse(content);
  if (!parsed.data || typeof parsed.data !== "object") {
    throw new Error("That backup file doesn't look like one this extension made.");
  }

  // Credentials are never in a backup (see scrubCredentials), so the
  // caller's current ones are carried over, and hist: records are merged
  // rather than overwritten, both handled in applyBackupData().
  const restoredCount = await applyBackupData(parsed.data, settings);
  return { restored: true, keyCount: restoredCount, backedUpAt: parsed.backedUpAt };
}

async function githubPutFile(repo, path, content, message, token) {
  return githubPutBase64(repo, path, toBase64Utf8(content), message, token);
}

/** Same as githubPutFile but takes the content already base64-encoded, so binary files (a zip) survive. */
async function githubPutBase64(repo, path, base64, message, token) {
  const sha = await githubGetSha(repo, path, token);
  const body = { message, content: base64, branch: "main" };
  if (sha) body.sha = sha;
  const resp = await fetch(`https://api.github.com/repos/${repo}/contents/${path}`, {
    method: "PUT",
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: "application/vnd.github+json",
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });
  const data = await resp.json();
  if (!resp.ok) throw new Error(data.message || `GitHub write failed (${resp.status})`);
  return data;
}

// ---------------------------------------------------------------------------
// v1.44.2: publishing the extension itself, so another computer can update.
// Chrome cannot overwrite an unpacked extension's own files, so the main PC
// uploads extension/update.zip + extension/version.json to the GitHub repo and
// tools/update-extension.ps1 (an hourly Windows task on the other PC) copies
// the new files over its folder; the existing 30-second self-reload does the rest.
// ---------------------------------------------------------------------------

// Files that no page or manifest names, so they cannot be found by reading
// those. Everything else is discovered (collectExtensionFiles).
const EXTENSION_EXTRA_FILES = [
  "live-dashboard.html",
  "tools/update-extension.ps1",
  "tools/install-auto-update.ps1",
  "tools/install-auto-update.cmd",
];

/**
 * Every file the extension needs, found by reading manifest.json, the pages it
 * opens and background.js's importScripts, so a script added later can never be
 * left out of an update. readText(path) returns a file's text.
 */
async function collectExtensionFiles(readText) {
  const found = new Set();
  const queue = [];
  const add = (p) => {
    if (!p || /^([a-z]+:)?\/\//i.test(p) || p.startsWith("data:")) return;
    const clean = p.replace(/^\.?\//, "").split(/[?#]/)[0];
    if (clean && !found.has(clean)) { found.add(clean); queue.push(clean); }
  };
  add("manifest.json");
  add("dashboard.html"); // opened with chrome.runtime.getURL, not named in the manifest
  for (const p of EXTENSION_EXTRA_FILES) add(p);
  while (queue.length) {
    const p = queue.shift();
    if (p === "manifest.json") {
      const m = JSON.parse(await readText(p));
      add(m.background && m.background.service_worker);
      for (const cs of m.content_scripts || []) for (const f of [...(cs.js || []), ...(cs.css || [])]) add(f);
      add(m.action && m.action.default_popup);
      for (const v of Object.values(m.icons || {})) add(v);
      for (const v of Object.values((m.action && m.action.default_icon) || {})) add(v);
    } else if (/\.html$/i.test(p) && !EXTENSION_EXTRA_FILES.includes(p)) {
      const html = await readText(p);
      for (const m of html.matchAll(/<script[^>]*\ssrc=["']([^"']+)["']/gi)) add(m[1]);
      for (const m of html.matchAll(/<link[^>]*\shref=["']([^"']+\.css[^"']*)["']/gi)) add(m[1]);
      for (const m of html.matchAll(/<img[^>]*\ssrc=["']([^"']+)["']/gi)) add(m[1]);
    } else if (p === "background.js") {
      const js = await readText(p);
      for (const m of js.matchAll(/importScripts\(([^)]*)\)/g)) for (const s of m[1].matchAll(/["']([^"']+)["']/g)) add(s[1]);
    }
  }
  // Pages that are not in the extra list but were found: already handled above.
  return [...found].sort();
}

let CRC32_TABLE = null;
function crc32(bytes) {
  if (!CRC32_TABLE) {
    CRC32_TABLE = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      CRC32_TABLE[n] = c >>> 0;
    }
  }
  let crc = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) crc = CRC32_TABLE[(crc ^ bytes[i]) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

/** Raw deflate through the browser's own compressor (null where it does not exist). */
async function deflateRawBytes(bytes) {
  const stream = new Blob([bytes]).stream().pipeThrough(new CompressionStream("deflate-raw"));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

/**
 * A standard .zip from [{name, data: Uint8Array}]. With a compress function
 * (deflateRawBytes) entries are deflated, without one they are stored. Forward
 * slashes, UTF-8 names, no zip64 (the extension is a few MB).
 */
async function buildZip(entries, { compress = null, now = new Date() } = {}) {
  const enc = new TextEncoder();
  const dosTime = ((now.getHours() & 31) << 11) | ((now.getMinutes() & 63) << 5) | ((now.getSeconds() >> 1) & 31);
  const dosDate = (((now.getFullYear() - 1980) & 127) << 9) | (((now.getMonth() + 1) & 15) << 5) | (now.getDate() & 31);
  const parts = [];
  const central = [];
  let offset = 0;
  for (const e of entries) {
    const name = enc.encode(e.name);
    const crc = crc32(e.data);
    let body = e.data, method = 0;
    if (compress && e.data.length > 64) {
      const packed = await compress(e.data);
      if (packed.length < e.data.length) { body = packed; method = 8; }
    }
    const local = new DataView(new ArrayBuffer(30));
    local.setUint32(0, 0x04034b50, true);
    local.setUint16(4, 20, true);
    local.setUint16(6, 0x0800, true);
    local.setUint16(8, method, true);
    local.setUint16(10, dosTime, true);
    local.setUint16(12, dosDate, true);
    local.setUint32(14, crc, true);
    local.setUint32(18, body.length, true);
    local.setUint32(22, e.data.length, true);
    local.setUint16(26, name.length, true);
    local.setUint16(28, 0, true);
    parts.push(new Uint8Array(local.buffer), name, body);
    const cen = new DataView(new ArrayBuffer(46));
    cen.setUint32(0, 0x02014b50, true);
    cen.setUint16(4, 20, true);
    cen.setUint16(6, 20, true);
    cen.setUint16(8, 0x0800, true);
    cen.setUint16(10, method, true);
    cen.setUint16(12, dosTime, true);
    cen.setUint16(14, dosDate, true);
    cen.setUint32(16, crc, true);
    cen.setUint32(20, body.length, true);
    cen.setUint32(24, e.data.length, true);
    cen.setUint16(28, name.length, true);
    cen.setUint32(42, offset, true);
    central.push(new Uint8Array(cen.buffer), name);
    offset += 30 + name.length + body.length;
  }
  const cdSize = central.reduce((n, p) => n + p.length, 0);
  const end = new DataView(new ArrayBuffer(22));
  end.setUint32(0, 0x06054b50, true);
  end.setUint16(8, entries.length, true);
  end.setUint16(10, entries.length, true);
  end.setUint32(12, cdSize, true);
  end.setUint32(16, offset, true);
  const all = [...parts, ...central, new Uint8Array(end.buffer)];
  const out = new Uint8Array(all.reduce((n, p) => n + p.length, 0));
  let at = 0;
  for (const p of all) { out.set(p, at); at += p.length; }
  return out;
}

function bytesToBase64(bytes) {
  let bin = "";
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(bin);
}

// ---------------------------------------------------------------------------
// v1.44.5: setup code. There is no server to sign in to, so this is the
// equivalent: a block of text, encrypted with a passphrase you choose, that
// carries the GitHub token + repo (and, if you ask, your other keys) to a new
// computer. Paste it there with the passphrase and the computer is connected;
// keep a copy somewhere safe and it is also a backup of your logins (the GitHub
// data backup deliberately never contains credentials, see scrubCredentials).
// AES-256-GCM, key from the passphrase with PBKDF2-SHA256 (250,000 rounds).
// ---------------------------------------------------------------------------

/**
 * v2.0.0: errors the extension throws in the background (or in its own pages)
 * are kept in a small log, so "the Errors button is red" has text you can read
 * and copy (Tools > Copy diagnostics) instead of a trip to chrome://extensions.
 * The same error repeating within a minute is counted, not repeated. Never
 * throws: an error handler that fails must not make things worse.
 */
async function recordError(where, err) {
  try {
    const message = String((err && err.message) || err || "unknown error").slice(0, 300);
    const stack = String((err && err.stack) || "").split("\n").slice(0, 4).join(" | ").slice(0, 400);
    const { errorLog = [] } = await chrome.storage.local.get("errorLog");
    const now = Date.now();
    const last = errorLog[errorLog.length - 1];
    if (last && last.where === where && last.message === message && now - new Date(last.at).getTime() < 60000) {
      last.count = (last.count || 1) + 1;
    } else {
      errorLog.push({ at: new Date(now).toISOString(), where, message, stack, count: 1 });
    }
    await chrome.storage.local.set({ errorLog: errorLog.slice(-40) });
  } catch (e) { /* ignore */ }
}

function installErrorCapture(where, target = typeof self !== "undefined" ? self : null) {
  if (!target || typeof target.addEventListener !== "function" || target.__errorCaptureInstalled) return;
  target.__errorCaptureInstalled = true;
  target.addEventListener("error", (ev) => { recordError(where, ev.error || ev.message); });
  target.addEventListener("unhandledrejection", (ev) => { recordError(where, ev.reason); });
}

/**
 * v1.44.7: "Send a test message" next to the Telegram fields. Tries the bot
 * token and chat ID exactly as typed (saved or not) and says in plain words
 * what is wrong. -> {ok, message}
 */
async function sendTelegramTestMessage(token, chatId, fetchFn = fetch) {
  token = String(token || "").trim();
  chatId = String(chatId || "").trim();
  if (!token || !chatId) return { ok: false, message: "Fill in both the bot token and the chat ID first." };
  if (!/^\d{5,}:[A-Za-z0-9_-]{20,}$/.test(token)) return { ok: false, message: "That does not look like a bot token. It should look like 123456789:AAH... (numbers, a colon, then letters). Copy it again from BotFather." };
  if (!/^-?\d{5,}$/.test(chatId)) return { ok: false, message: "The chat ID should be only numbers, like 123456789. Get it from @userinfobot, not the bot's username." };
  let resp;
  try {
    resp = await fetchFn(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text: "✅ Test message from Weekend Resort Deal Tracker. Deal alerts will arrive here." }),
    });
  } catch (e) {
    return { ok: false, message: "Could not reach Telegram. Check this computer's internet and try again." };
  }
  if (resp.ok) return { ok: true, message: "Sent. Check Telegram, then press Save settings below." };
  let detail = "";
  try { detail = ((await resp.json()) || {}).description || ""; } catch (e) { /* no body */ }
  if (resp.status === 401 || resp.status === 404) return { ok: false, message: "Telegram says the bot token is wrong. Copy it again from BotFather (the whole thing, no spaces)." };
  if (resp.status === 403) return { ok: false, message: "The bot can't message you yet. Open your bot in Telegram, press Start, send it \"hi\", then try again." };
  if (resp.status === 400) return { ok: false, message: /chat not found/i.test(detail) ? "Telegram can't find that chat ID. Check the number from @userinfobot, and make sure you pressed Start in your own bot's chat." : `Telegram refused it: ${detail || "bad request"}` };
  return { ok: false, message: `Telegram answered ${resp.status}${detail ? `: ${detail}` : ""}. Try again in a minute.` };
}

const SETUP_CODE_PREFIX = "HDT1.";
const SETUP_PBKDF2_ROUNDS = 250000;
// Beyond the credentials, what "everything" restores on a computer you are rebuilding.
const SETUP_FULL_EXTRA_KEYS = ["telegramChatId", "channelChatId"];

function bytesToBase64Url(bytes) {
  return bytesToBase64(bytes).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function base64UrlToBytes(text) {
  const b64 = String(text).replace(/-/g, "+").replace(/_/g, "/");
  const bin = atob(b64 + "=".repeat((4 - (b64.length % 4)) % 4));
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

async function deriveSetupKey(passphrase, salt, rounds) {
  const base = await crypto.subtle.importKey("raw", new TextEncoder().encode(String(passphrase)), "PBKDF2", false, ["deriveKey"]);
  return crypto.subtle.deriveKey({ name: "PBKDF2", salt, iterations: rounds, hash: "SHA-256" }, base, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
}

/**
 * What goes into the code. mode "helper": just what a helper computer needs
 * (GitHub token + repo, role, name, its destinations). mode "full": that plus
 * every API key and chat ID, for rebuilding a computer or keeping a backup.
 */
function buildSetupBundle(settings, { mode = "helper", deviceName = "", scanDestinations = [] } = {}) {
  if (!settings || !settings.githubToken || !settings.githubRepo) throw new Error("Add your GitHub token and repo in the popup Settings first.");
  const bundle = { kind: "setup", v: 1, mode, createdAt: new Date().toISOString(), githubToken: settings.githubToken, githubRepo: settings.githubRepo };
  if (mode === "helper") {
    const name = String(deviceName || "").toLowerCase().replace(/[^a-z0-9_-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 32);
    if (!name) throw new Error("Give the new computer a name, for example helper-2.");
    bundle.deviceRole = "helper";
    bundle.deviceName = name;
    bundle.scanDestinations = (scanDestinations || []).map((x) => String(x).trim()).filter(Boolean);
  } else {
    bundle.credentials = {};
    for (const k of [...CREDENTIAL_SETTING_KEYS, ...SETUP_FULL_EXTRA_KEYS]) {
      const v = settings[k];
      if (v !== undefined && v !== null && v !== "" && !(Array.isArray(v) && !v.length)) bundle.credentials[k] = v;
    }
  }
  return bundle;
}

async function encryptSetupBundle(bundle, passphrase) {
  if (!passphrase || String(passphrase).length < 8) throw new Error("Choose a passphrase of at least 8 characters.");
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await deriveSetupKey(passphrase, salt, SETUP_PBKDF2_ROUNDS);
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, new TextEncoder().encode(JSON.stringify(bundle))));
  const body = JSON.stringify({ v: 1, r: SETUP_PBKDF2_ROUNDS, s: bytesToBase64Url(salt), i: bytesToBase64Url(iv), c: bytesToBase64Url(ct) });
  return SETUP_CODE_PREFIX + bytesToBase64Url(new TextEncoder().encode(body));
}

async function decryptSetupBundle(code, passphrase) {
  const text = String(code || "").replace(/\s+/g, "");
  if (!text.startsWith(SETUP_CODE_PREFIX)) throw new Error("That does not look like a setup code (it should start with HDT1.).");
  let env;
  try { env = JSON.parse(new TextDecoder().decode(base64UrlToBytes(text.slice(SETUP_CODE_PREFIX.length)))); } catch (e) { throw new Error("The setup code is damaged or cut short. Copy it again in full."); }
  if (!env || env.v !== 1 || !env.s || !env.i || !env.c) throw new Error("The setup code is damaged or from a newer version.");
  const rounds = Number(env.r);
  if (!(rounds >= 10000 && rounds <= 2000000)) throw new Error("The setup code is damaged.");
  let plain;
  try {
    const key = await deriveSetupKey(passphrase || "", base64UrlToBytes(env.s), rounds);
    plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv: base64UrlToBytes(env.i) }, key, base64UrlToBytes(env.c));
  } catch (e) { throw new Error("Wrong passphrase, or the code was changed."); }
  const bundle = JSON.parse(new TextDecoder().decode(plain));
  if (!bundle || bundle.kind !== "setup" || bundle.v !== 1) throw new Error("That is not a setup code from this extension.");
  return bundle;
}

/** The settings after connecting with a bundle. Only the listed fields can change, nothing else is touched. */
function applySetupBundle(settings, bundle) {
  const next = { ...settings };
  if (!bundle || bundle.kind !== "setup") throw new Error("Not a setup bundle.");
  if (typeof bundle.githubToken === "string" && bundle.githubToken) next.githubToken = bundle.githubToken;
  if (typeof bundle.githubRepo === "string" && /^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(bundle.githubRepo)) next.githubRepo = bundle.githubRepo;
  if (bundle.deviceRole === "helper") {
    next.deviceRole = "helper";
    next.deviceName = String(bundle.deviceName || "").toLowerCase().replace(/[^a-z0-9_-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 32) || "helper";
    next.scanDestinations = Array.isArray(bundle.scanDestinations) ? bundle.scanDestinations.map(String).filter(Boolean) : [];
    next.helpersEnabled = false;
  }
  if (bundle.credentials && typeof bundle.credentials === "object") {
    for (const k of [...CREDENTIAL_SETTING_KEYS, ...SETUP_FULL_EXTRA_KEYS]) {
      const v = bundle.credentials[k];
      if (typeof v === "string" ? v !== "" : Array.isArray(v) && v.length) next[k] = v;
    }
  }
  return next;
}

/**
 * Publishes the current tracked hotels to GitHub Pages. Called
 * automatically after every scan finishes (from background.js) and
 * on-demand from the dashboard's Publish button, same function either
 * way so the two never drift apart. Silently does nothing if GitHub
 * isn't configured, this is opt-in.
 */
async function publishSnapshotToGithub(settings) {
  if (!settings.githubToken || !settings.githubRepo) return { skipped: true };
  if (settings.deviceRole === "helper") return { skipped: true, reason: "helper" }; // a helper only has part of the data

  const groups = await loadTrackedHotelGroups();
  const blockedSet = await getBlockedGroupKeys();
  const publishable = groups
    .filter((g) => !blockedSet.has(g.groupKey))
    .map((g) => ({
      groupKey: g.groupKey,
      hotelName: g.hotelName,
      destination: g.destination,
      source: g.source,
      starRating: g.starRating,
      rating: g.rating,
      reviewCount: g.reviewCount,
      isNewlyBuilt: g.isNewlyBuilt,
      isFavorite: g.isFavorite,
      youtubeViews: g.youtubeViews,
      youtubeVideoCount: g.youtubeVideoCount,
      aiEstimatedStarTier: g.aiEstimatedStarTier,
      manualStarTier: g.manualStarTier,
      aiReviewSummary: g.aiReviewSummary,
      amenities: g.amenities,
      youtubeVideoUrl: g.youtubeVideoUrl,
      youtubeTopShort: g.youtubeTopShort,
      youtubeTopLong: g.youtubeTopLong,
      youtubeShorts: g.youtubeShorts,
      youtubeLongForm: g.youtubeLongForm,
      roomDetailLowest: g.dates.reduce((best, d) => (d.roomDetailLowest !== null && (best === null || d.roomDetailLowest < best) ? d.roomDetailLowest : best), null),
      cheapestPrice: g.cheapestPrice,
      cheapestCheckin: g.cheapest.checkin,
      cheapestCheckout: g.cheapest.checkout,
      cheapestUrl: g.cheapest.url,
      lowestEver: g.lowestEver,
      everAtLowest: g.everAtLowest,
      hasFlaggedDates: g.hasFlaggedDates,
      isRareDeal: g.rarity ? g.rarity.isRareDeal : false,
      rarityReasons: g.rarity ? g.rarity.reasons : [],
      dates: g.dates.map((d) => ({
        checkin: d.checkin,
        checkout: d.checkout,
        price: d.current,
        lowest: d.lowest,
        updatedAt: d.updatedAt,
        url: d.url,
        priceHistory: d.priceHistory,
        originalPrice: d.originalPrice,
        isLikelyBadScrape: d.isLikelyBadScrape,
        roomDetailLowest: d.roomDetailLowest,
        // v1.44.0: was missing, so the public page could not tell a
        // date-checked price from an old one (see MMT_DATE_FORMATS).
        verified: !!d.verified,
      })),
    }));

  // v1.44.0: the Today picks (what to book this weekend and next, what to
  // film, cheapest per place), computed here by the same buildToday() the
  // extension's Today tab uses and published ready-made, the same way
  // isRareDeal is, so the public page never runs a second copy of the logic.
  // Scan health and channel details stay private.
  let today = null;
  if (typeof buildToday === "function") {
    const t = buildToday({ groups, blocked: blockedSet, settings, state: {}, nowMs: Date.now() });
    today = { generatedAt: t.generatedAt, weekends: t.weekends, book: t.book, film: t.film, cheapest: t.cheapest };
  }

  const dataJson = JSON.stringify({ generatedAt: new Date().toISOString(), groups: publishable, today }, null, 2);
  await githubPutFile(settings.githubRepo, "data.json", dataJson, "Update hotel dashboard data", settings.githubToken);

  // This used to only push index.html the first time, on the assumption
  // it was static. It isn't, this file keeps improving, and skipping
  // re-uploads meant every improvement after the first publish silently
  // never reached the live site, it stayed frozen on whatever version
  // existed at first publish. Always pushing the current packaged
  // version fixes that, and also self-heals a live site that broke
  // because its old page didn't understand a newer data.json shape.
  // The public deal feed: the latest drops, newest first, no private data.
  // This is also the seed of a paid API/widget surface (same JSON, keyed
  // by destination/plan) if that's ever wanted.
  if (typeof publicFeed === "function") {
    const { dealEvents = [] } = await chrome.storage.local.get("dealEvents");
    const blockedForFeed = blockedSet;
    const feed = publicFeed(dealEvents.filter((e) => !blockedForFeed.has(`${e.source}:::${e.hotelName}:::${e.destination}`)), 100);
    await githubPutFile(settings.githubRepo, "deals.json", JSON.stringify({ generatedAt: new Date().toISOString(), events: feed }, null, 2), "Update deal feed", settings.githubToken);
  }

  const indexHtml = await fetch(chrome.runtime.getURL("live-dashboard.html")).then((r) => r.text());
  await githubPutFile(settings.githubRepo, "index.html", indexHtml, "Update live dashboard page", settings.githubToken);

  const [owner, repoName] = settings.githubRepo.split("/");
  return { published: true, url: `https://${owner}.github.io/${repoName}/` };
}

/**
 * Applies a manual star tier correction across every date record for a
 * hotel, this takes priority over both the scraped rating and any AI
 * estimate wherever it's displayed. Pass null to clear it.
 */
async function setManualStarTier(group, tier) {
  for (const d of group.dates) {
    const { [d.key]: existing } = await chrome.storage.local.get(d.key);
    if (existing) {
      await chrome.storage.local.set({ [d.key]: { ...existing, manualStarTier: tier } });
    }
  }
}

/**
 * Minimal, dependency-free MD5, needed for Travelpayouts' request
 * signature (PROJECT_BRIEF open item 6, multi-OTA aggregation). No
 * external library is loadable in a Chrome extension without bundling it
 * in, so this is written by hand and checked against the standard
 * published MD5 test vectors in test_md5.js, something that, unlike a
 * site's live response shape, doesn't need network access to verify: MD5
 * is a fixed, fully-specified algorithm, not something Travelpayouts
 * could change on their end.
 *
 * NOT yet wired up to an actual Travelpayouts call, see the "Multi-OTA
 * (Travelpayouts)" note in the dashboard's Tools tab for exactly why:
 * their Hotel Search API is a two-step signed-and-polled flow keyed by
 * Travelpayouts' own city/hotel IDs (not hotel names), and this
 * environment couldn't get a confirmed exact endpoint URL and full
 * parameter list from their docs (one page is blocked by robots.txt, the
 * others only partially confirm it). Shipping a guessed URL/parameter
 * set for a signed API risks silent, hard-to-diagnose failures, worse
 * than shipping nothing. This function and the settings fields
 * (travelpayoutsApiToken/travelpayoutsMarker) are the confirmed, useful
 * groundwork for whoever picks this up next with the real docs open.
 */
function md5(input) {
  function rotateLeft(x, c) { return (x << c) | (x >>> (32 - c)); }
  function toUint32(x) { return x >>> 0; }
  function addUint32(...xs) { return toUint32(xs.reduce((a, b) => toUint32(a) + toUint32(b), 0)); }

  const s = [
    7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22,
    5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20,
    4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23,
    6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21,
  ];
  const K = new Array(64);
  for (let i = 0; i < 64; i++) K[i] = toUint32(Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296));

  const bytes = [];
  const utf8 = unescape(encodeURIComponent(input));
  for (let i = 0; i < utf8.length; i++) bytes.push(utf8.charCodeAt(i) & 0xff);

  const originalLenBits = bytes.length * 8;
  bytes.push(0x80);
  while (bytes.length % 64 !== 56) bytes.push(0);
  for (let i = 0; i < 8; i++) bytes.push((originalLenBits / Math.pow(2, 8 * i)) & 0xff);

  let a0 = 0x67452301, b0 = 0xefcdab89, c0 = 0x98badcfe, d0 = 0x10325476;

  for (let chunkStart = 0; chunkStart < bytes.length; chunkStart += 64) {
    const M = new Array(16);
    for (let i = 0; i < 16; i++) {
      M[i] =
        bytes[chunkStart + i * 4] |
        (bytes[chunkStart + i * 4 + 1] << 8) |
        (bytes[chunkStart + i * 4 + 2] << 16) |
        (bytes[chunkStart + i * 4 + 3] << 24);
      M[i] = toUint32(M[i]);
    }

    let A = a0, B = b0, C = c0, D = d0;

    for (let i = 0; i < 64; i++) {
      let F, g;
      if (i < 16) { F = (B & C) | (~B & D); g = i; }
      else if (i < 32) { F = (D & B) | (~D & C); g = (5 * i + 1) % 16; }
      else if (i < 48) { F = B ^ C ^ D; g = (3 * i + 5) % 16; }
      else { F = C ^ (B | ~D); g = (7 * i) % 16; }

      F = addUint32(F, A, K[i], M[g]);
      A = D;
      D = C;
      C = B;
      B = addUint32(B, rotateLeft(F, s[i]));
    }

    a0 = addUint32(a0, A);
    b0 = addUint32(b0, B);
    c0 = addUint32(c0, C);
    d0 = addUint32(d0, D);
  }

  function toHexLE(n) {
    let hex = "";
    for (let i = 0; i < 4; i++) {
      hex += ((n >>> (i * 8)) & 0xff).toString(16).padStart(2, "0");
    }
    return hex;
  }

  return toHexLE(a0) + toHexLE(b0) + toHexLE(c0) + toHexLE(d0);
}

// Exposed for both service worker (importScripts) and popup (script tag) use.
if (typeof module !== "undefined") {
  module.exports = {
    DEFAULTS,
    DEFAULT_DESTINATIONS,
    getSettings,
    saveSettings,
    upcomingWeekends,
    next7DaysWindow,
    dedupeByCheckin,
    toISODate,
    toMmtDate,
    formatINR,
    buildMmtUrl,
    buildGoibiboUrl,
    MMT_DATE_FORMATS,
    formatDateAs,
    sanitizeUrl,
    PROMO_RE,
    TAX_RE,
    transitEstimate,
    AMENITY_PATTERNS,
    findAmenitiesInText,
    evaluateTargetAlert,
    evaluateRareDealAlert,
    flagOutlierDates,
    percentileRank,
    isPersistentLow,
    computeSelfRarity,
    computePeerRarity,
    computeRarityBadge,
    md5,
    backupToGithub,
    scrubCredentials,
    CREDENTIAL_SETTING_KEYS,
    trackedHotelsToCsv,
    parseISO8601Duration,
    SHORT_MAX_SECONDS,
    isGenuineVideoMatch,
    significantWords,
    checkYoutubeForHotel,
    emptyYoutubeResult,
  };
}
