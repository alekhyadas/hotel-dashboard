/**
 * v2.0.16: reads a Skyscanner hotel search page (sorted lowest price first) opened by the extension's
 * Skyscanner watch, and sends the hotels back as a SCRAPE_RESULT like content.js does for MakeMyTrip.
 *
 * Each hotel card is an <li> with one "Go to site" button. The card text reads, in order: name, distance,
 * rating and reviews, the struck-through price and "% off" (sometimes), the price "a night" (the best
 * single site), "+N booking options" and "Cheapest from X" (the lowest of all the sites Skyscanner compares).
 * Prices are per night for the dates in the page address and exclude taxes and fees.
 *
 * If Skyscanner shows its bot check instead of results, nothing is guessed: the page reports `botCheck`
 * and the background backs off. A puzzle is never solved here.
 */
(function () {
  const rupees = (s) => {
    const n = parseInt(String(s).replace(/,/g, ""), 10);
    return Number.isFinite(n) ? n : null;
  };

  function cards() {
    return [...document.querySelectorAll("li")].filter((l) => ((l.innerText || "").match(/Go to site/g) || []).length === 1);
  }

  function readCard(li) {
    const text = li.innerText || "";
    const lines = text.split("\n").map((s) => s.trim()).filter(Boolean);
    const name = lines[0] || null;
    const night = /₹\s?([\d,]+)\s*a night/.exec(text);
    if (!name || !night) return null;
    const cheapest = /Cheapest from\s*₹\s?([\d,]+)/.exec(text);
    const off = /(\d+)%\s*off/.exec(text);
    let original = null;
    if (off) {
      const before = text.slice(0, text.indexOf(night[0]));
      const all = [...before.matchAll(/₹\s?([\d,]+)/g)];
      if (all.length) original = rupees(all[all.length - 1][1]);
    }
    const km = /([\d.]+)\s*km from/.exec(text);
    const rating = /(\d(?:\.\d)?)\/5/.exec(text);
    const reviews = /(\d[\d,]*)\s+reviews?/.exec(text);
    const options = /\+(\d+)\s+booking options?/.exec(text);
    const providerImg = li.querySelector('img[alt^="on "]');
    const link = [...li.querySelectorAll("a[href]")].map((a) => a.href).find((h) => /\/hotels\/|hotel_deeplink/.test(h)) || null;
    const price = rupees(night[1]);
    const best = cheapest ? rupees(cheapest[1]) : price;
    return {
      source: "skyscanner",
      hotelName: name,
      price,
      cheapest: best != null && price != null ? Math.min(best, price) : price,
      originalPrice: original,
      discountPct: off ? parseInt(off[1], 10) : null,
      bookingOptions: options ? parseInt(options[1], 10) : 0,
      provider: providerImg ? providerImg.alt.replace(/^on\s+/i, "") : null,
      rating: rating ? parseFloat(rating[1]) : null,
      reviewCount: reviews ? rupees(reviews[1]) : null,
      km: km ? parseFloat(km[1]) : null,
      freeCancel: /Free cancellation/i.test(text),
      breakfast: /Breakfast included/i.test(text),
      url: link ? link.split("?")[0] : null,
    };
  }

  function botCheck() {
    const t = ((document.body && document.body.innerText) || "").slice(0, 600).toLowerCase();
    return /press (&|and) hold|verify (that )?you are (a )?human|are you a person or a robot|access denied|unusual traffic/.test(t);
  }

  function pageDates() {
    const p = new URLSearchParams(location.search);
    return { checkin: p.get("checkin"), checkout: p.get("checkout") };
  }

  async function waitFor(fn, ms, step) {
    const start = Date.now();
    while (Date.now() - start < ms) {
      if (fn()) return true;
      await new Promise((r) => setTimeout(r, step));
    }
    return fn();
  }

  async function scrollLoad(budgetMs) {
    const start = Date.now();
    let last = cards().length, stable = 0, rounds = 0;
    while (Date.now() - start < budgetMs && stable < 5) {
      window.scrollBy({ top: Math.round(window.innerHeight * 0.9), behavior: "instant" });
      rounds++;
      await new Promise((r) => setTimeout(r, 500 + Math.random() * 250));
      const n = cards().length;
      if (n > last) { last = n; stable = 0; } else stable++;
    }
    window.scrollTo(0, 0);
    return { rounds, cards: cards().length };
  }

  (async function main() {
    let listings = [];
    let debug = {};
    try {
      await new Promise((r) => setTimeout(r, 2500 + Math.random() * 1500)); // the bot check takes a few seconds to pass by itself
      const appeared = await waitFor(() => cards().length > 0 || botCheck(), 20000, 700);
      const dates = pageDates();
      let scroll = null;
      if (appeared && cards().length > 0) scroll = await scrollLoad(18000);
      const totalMatch = /(\d[\d,]*)\s+results/.exec(document.body ? document.body.innerText : "");
      for (const li of cards()) {
        const l = readCard(li);
        if (l) listings.push({ ...l, pageCheckin: dates.checkin, pageCheckout: dates.checkout });
      }
      debug = {
        url: location.href.split("?")[0], title: document.title, visibilityState: document.visibilityState,
        botCheck: botCheck(), cardsFound: cards().length, expectedCount: totalMatch ? rupees(totalMatch[1]) : null,
        scrollStats: scroll, displayedDates: dates,
        bodyTextSample: (document.body ? document.body.innerText : "").slice(0, 300),
      };
    } catch (e) {
      debug = { error: String(e && e.stack ? e.stack : e) };
    }
    try {
      if (chrome.runtime && chrome.runtime.id) chrome.runtime.sendMessage({ type: "SCRAPE_RESULT", listings, debug });
    } catch (e) { /* the extension reloaded meanwhile */ }
  })();
})();
