/**
 * Swipe tab: clear out hotels that aren't worth tracking, fast.
 *
 *   left  / Remove    -> stops tracking (blockedHotels: hidden everywhere, no
 *                        more history, alerts or feed entries; history already
 *                        collected is kept so a restore picks up where it left off)
 *   right / Favourite -> favoriteHotels (price-target + Quick Refresh apply)
 *   up    / Keep      -> reviewed, never asked about again, nothing else changes
 *   down  / Later     -> back of the queue, not shown for 3 days
 *   Z / Undo          -> reverses the last decision (also across sessions)
 *
 * Every card shows what's needed to decide: MakeMyTrip rating + volume,
 * Google Maps rating (when a Places API key is set), the price history
 * chart, a price-by-weekend bar chart, and the reasons the junk score
 * thinks it's a reject. Plain script loaded after dashboard.js/feed.js.
 */
(function () {
  const $ = (id) => document.getElementById(id);
  const LATER_MS = 3 * 86400000;

  let queue = [];
  let current = null;
  let busy = false;
  let refreshTimer = null;
  let removedOpen = false;

  const gkey = (o) => `${o.source}:::${o.hotelName}:::${o.destination}`;

  async function loadState() {
    const s = await chrome.storage.local.get(["blockedHotels", "favoriteHotels", "reviewedHotels", "swipeLater", "hotelMeta", "swipeLog"]);
    return {
      blocked: s.blockedHotels || [],
      favorites: s.favoriteHotels || [],
      reviewed: s.reviewedHotels || {},
      later: s.swipeLater || {},
      meta: s.hotelMeta || {},
      log: s.swipeLog || [],
    };
  }

  function scheduleRefresh() {
    clearTimeout(refreshTimer);
    refreshTimer = setTimeout(() => { if (typeof refresh === "function") refresh(); }, 2000);
  }

  // ---------------------------------------------------------------- queue

  async function buildQueue() {
    const st = await loadState();
    const blockedSet = new Set(st.blocked.map(gkey));
    const favSet = new Set(st.favorites.map(gkey));
    const dest = $("swipe-dest").value;
    const now = Date.now();
    let groups = (allGroups || []).filter((g) =>
      !blockedSet.has(g.groupKey) && !favSet.has(g.groupKey) && !st.reviewed[g.groupKey] &&
      !(st.later[g.groupKey] && now - new Date(st.later[g.groupKey]).getTime() < LATER_MS) &&
      (!dest || g.destination === dest));
    groups = groups.map((g) => ({ g, junk: junkScore(g) }));
    const order = $("swipe-order").value;
    if (order === "junk") groups.sort((a, b) => b.junk.score - a.junk.score);
    else if (order === "best") groups.sort((a, b) => (b.g.rarity && b.g.rarity.isRareDeal) - (a.g.rarity && a.g.rarity.isRareDeal) || a.junk.score - b.junk.score || a.g.cheapestPrice - b.g.cheapestPrice);
    else groups.sort(() => Math.random() - 0.5);
    queue = groups;

    const sel = $("swipe-dest");
    const dests = [...new Set((allGroups || []).map((g) => g.destination))].sort();
    if (sel.options.length !== dests.length + 1) {
      const cur = sel.value;
      sel.innerHTML = `<option value="">All destinations</option>` + dests.map((d) => `<option>${escapeHtml(d)}</option>`).join("");
      sel.value = dests.includes(cur) ? cur : "";
    }
    updateTop(st);
    showNext();
  }

  function updateTop(st) {
    $("swipe-left-count").textContent = String(queue.length);
    const junkN = queue.filter((q) => q.junk.suggestRemove).length;
    const bulk = $("swipe-bulk");
    bulk.textContent = `Remove all ${junkN} suggested junk`;
    bulk.disabled = junkN === 0;
    $("swipe-removed-toggle").textContent = `Removed (${st.blocked.length})`;
    $("swipe-undo").disabled = st.log.length === 0;
  }

  // ----------------------------------------------------------------- card

  function dateBars(g) {
    const dates = [...g.dates].filter((d) => d.checkin >= toISODate(new Date()) && !d.isLikelyBadScrape)
      .sort((a, b) => a.checkin.localeCompare(b.checkin)).slice(0, 10);
    if (dates.length < 2) return "";
    const max = Math.max(...dates.map((d) => d.current));
    const min = Math.min(...dates.map((d) => d.current));
    const W = 520, H = 90, bw = Math.min(40, (W - 10) / dates.length - 6);
    const bars = dates.map((d, i) => {
      const h = Math.max(6, (d.current / max) * (H - 24));
      const x = 5 + i * ((W - 10) / dates.length);
      const cheapest = d.current === min;
      return `<rect x="${x.toFixed(1)}" y="${(H - 14 - h).toFixed(1)}" width="${bw}" height="${h.toFixed(1)}" rx="3" class="${cheapest ? "bar-low" : "bar"}"><title>${escapeHtml(d.checkin)}: ${escapeHtml(formatINR(d.current))}</title></rect>
        <text x="${(x + bw / 2).toFixed(1)}" y="${H - 2}" text-anchor="middle" class="hist-axis">${escapeHtml(d.checkin.slice(5))}</text>`;
    }).join("");
    return `<div class="swipe-chart-label">Price by weekend (lowest highlighted)</div><svg viewBox="0 0 ${W} ${H}" class="hist-chart">${bars}</svg>`;
  }

  function ratingBlock(g, meta) {
    const mmt = g.rating != null
      ? `<div class="rating-box"><b>${g.rating.toFixed(1)}</b><span>MakeMyTrip${g.reviewCount != null ? `, ${g.reviewCount.toLocaleString("en-IN")} reviews` : ""}</span></div>`
      : `<div class="rating-box rating-none"><b>—</b><span>No MakeMyTrip rating</span></div>`;
    let google;
    if (meta && meta.googleRating != null) {
      const url = typeof sanitizeUrl === "function" ? sanitizeUrl(meta.googleUrl) : null;
      google = `<div class="rating-box"><b>${meta.googleRating.toFixed(1)}</b><span>Google Maps${meta.googleReviews != null ? `, ${meta.googleReviews.toLocaleString("en-IN")} reviews` : ""}${url ? ` • <a href="${escapeAttr(url)}" target="_blank" rel="noopener noreferrer">open</a>` : ""}</span></div>`;
    } else if (meta && meta.googleNotFound) {
      google = `<div class="rating-box rating-none"><b>—</b><span>Not found on Google Maps</span></div>`;
    } else {
      google = `<div class="rating-box rating-none" id="google-slot"><b>—</b><span id="google-slot-text">Google rating not loaded</span></div>`;
    }
    return `<div class="rating-row">${mmt}${google}</div>`;
  }

  /** The two photos side by side: MakeMyTrip's (from the listing scan) and Google Maps'. */
  function photoBlock(g, meta, settings) {
    const mmtUrl = g.imageUrl || (meta && meta.mmtImageUrl) || null;
    const mmt = mmtUrl && /^https:/.test(mmtUrl)
      ? `<figure class="photo"><img class="photo-img" src="${escapeAttr(mmtUrl)}" referrerpolicy="no-referrer" alt="MakeMyTrip photo of ${escapeAttr(g.hotelName)}"><figcaption>MakeMyTrip</figcaption></figure>`
      : `<figure class="photo photo-empty"><div>No MakeMyTrip photo yet.<br>It is picked up the next time this destination is scanned.</div><figcaption>MakeMyTrip</figcaption></figure>`;
    // Free reader: direct photo URLs. API: photo references that need the key to display.
    const direct = (meta && meta.googlePhotoUrls) || [];
    const apiPhotos = (meta && meta.googlePhotos) || [];
    const photos = direct.length ? direct : apiPhotos;
    const firstUrl = direct.length ? direct[0] : (apiPhotos[0] ? googlePhotoUrl(apiPhotos[0], settings.googlePlacesApiKey, 640) : null);
    let google;
    if (firstUrl) {
      google = `<figure class="photo"><img class="photo-img" src="${escapeAttr(firstUrl)}" referrerpolicy="no-referrer" alt="Google Maps photo of ${escapeAttr(g.hotelName)}"><figcaption>Google Maps${photos.length > 1 ? ` <button class="photo-more" data-more="1">more photos</button>` : ""}</figcaption></figure>`;
    } else {
      const viaApi = settings.googleSource === "api";
      let text = viaApi ? "Photos load with the Google lookup" : "Google Maps photos load automatically (a small window opens for about 15 seconds)";
      if (viaApi && !settings.googlePlacesApiKey) text = "Add a Google Places key in the Business tab to see Google photos";
      else if (meta && meta.googleNotFound) text = `Not found on Google Maps${meta.googleNote ? ` (${meta.googleNote})` : ""}`;
      else if (viaApi && settings.googleFetchExtras === false) text = "Google photos are switched off in the Business tab";
      else if (meta && meta.googleRating != null && meta.googleDetailsAt) text = "Google has no photos for this place";
      google = `<figure class="photo photo-empty"><div id="google-photo-text">${escapeHtml(text)}</div><figcaption>Google Maps</figcaption></figure>`;
    }
    return `<div class="photo-row">${mmt}${google}</div><div id="photo-strip" class="photo-strip"></div>`;
  }

  function reviewsBlock(meta) {
    const list = (meta && meta.googleReviewList) || [];
    const summary = (meta && meta.googleSummary) || "";
    if (!list.length && !summary) return "";
    const url = typeof sanitizeUrl === "function" ? sanitizeUrl(meta.googleUrl) : null;
    return (summary ? `<div class="swipe-chart-label">Google's summary of its reviews (AI)</div><blockquote class="g-review g-summary">${escapeHtml(summary)}</blockquote>` : "")
      + (list.length ? `<div class="swipe-chart-label">What Google reviewers say</div>` : "") + list.map((r) =>
      `<blockquote class="g-review"><div class="g-review-top">${"★".repeat(Math.max(0, Math.min(5, Math.round(r.rating || 0))))} <span>${escapeHtml(r.author || "A guest")}${r.when ? ` • ${escapeHtml(r.when)}` : ""}</span></div>${escapeHtml(r.text)}</blockquote>`).join("")
      + (url ? `<a class="g-review-link" href="${escapeAttr(url)}" target="_blank" rel="noopener noreferrer">Open all reviews and photos on Google Maps</a>` : "");
  }

  function attachPhotoHandlers(meta, settings) {
    document.querySelectorAll("#swipe-card .photo-img").forEach((img) => {
      img.addEventListener("error", () => {
        const fig = img.closest("figure");
        if (fig) { fig.classList.add("photo-empty"); fig.querySelector("img").replaceWith(Object.assign(document.createElement("div"), { textContent: "Photo could not be loaded" })); }
      }, { once: true });
    });
    const more = document.querySelector("#swipe-card .photo-more");
    if (more) {
      more.addEventListener("click", () => {
        const direct = (meta && meta.googlePhotoUrls) || [];
        const rest = direct.length ? direct.slice(1, 4) : ((meta && meta.googlePhotos) || []).slice(1, 4);
        $("photo-strip").innerHTML = rest.map((n) => { const u = direct.length ? n : googlePhotoUrl(n, settings.googlePlacesApiKey, 480); return u && /^https:/.test(u) ? `<img src="${escapeAttr(u)}" referrerpolicy="no-referrer" alt="">` : ""; }).join("");
        more.remove();
      });
    }
  }

  async function renderCard(entry) {
    const { g, junk } = entry;
    const st = await loadState();
    const meta = st.meta[g.groupKey];
    const settings = await getSettings();
    const c = g.cheapest;
    const tier = starTierValue(g);
    const transit = typeof transitEstimate === "function" ? transitEstimate(g.destination) : null;
    const chips = [];
    for (const r of junk.reasons) chips.push(`<span class="chip chip-bad">${escapeHtml(r)}</span>`);
    if (g.rarity && g.rarity.isRareDeal) chips.push(`<span class="chip chip-good">Rare deal</span>`);
    if (g.isNewlyBuilt) chips.push(`<span class="chip chip-good">Newly built</span>`);
    if (g.youtubeViews) chips.push(`<span class="chip chip-good">${formatViews(g.youtubeViews)} YouTube views</span>`);
    for (const a of (g.amenities || []).slice(0, 4)) chips.push(`<span class="chip">${escapeHtml(a)}</span>`);
    const fairInfo = fairPriceFor(c.priceHistory || []);
    if (fairInfo) chips.push(`<span class="chip ${g.cheapestPrice < fairInfo.fair ? "chip-good" : ""}">Usually ${formatINR(fairInfo.fair)} (median of ${fairInfo.n} checks)</span>`);
    const vs = valueScore(g);
    if (vs) chips.push(`<span class="chip">Value score ${vs}</span>`);

    const vals = (c.priceHistory || []).map((p) => p.price);
    const avg = vals.length ? Math.round(vals.reduce((a, b) => a + b, 0) / vals.length) : null;

    $("swipe-card").innerHTML = `
      <div class="stamp stamp-left">REMOVE</div><div class="stamp stamp-right">FAVOURITE</div>
      <div class="swipe-head">
        <div>
          <h2 class="swipe-name">${escapeHtml(g.hotelName)}</h2>
          <div class="swipe-sub">${escapeHtml(g.destination)}${tier ? ` • ${tier}★` : ""}${transit ? ` • ${escapeHtml(transit)}` : ""}</div>
        </div>
        <div class="swipe-junk ${junk.suggestRemove ? "junk-high" : junk.score > 0 ? "junk-mid" : "junk-low"}" title="How likely this is not worth tracking">
          ${junk.suggestRemove ? "Likely junk" : junk.score > 0 ? "Questionable" : "Looks fine"}
        </div>
      </div>
      ${photoBlock(g, meta, settings)}
      <div class="swipe-price-row">
        <div class="swipe-price">${formatINR(g.cheapestPrice)}</div>
        <div class="swipe-price-sub">${escapeHtml(c.checkin)} to ${escapeHtml(c.checkout)}<br>lowest ever ${formatINR(g.lowestEver)}${avg ? ` • average ${formatINR(avg)}` : ""}</div>
      </div>
      ${ratingBlock(g, meta)}
      ${reviewsBlock(meta)}
      <div class="chip-row">${chips.join("")}</div>
      <div class="swipe-chart-label">Price history for ${escapeHtml(c.checkin)}</div>
      ${HotelCharts.historyChart(c.priceHistory || [], c.checkin)}
      ${dateBars(g)}`;
    attachDrag();
    attachPhotoHandlers(meta, settings);
    maybeFetchGoogle(g, meta);
  }

  const lookupInFlight = new Set();

  /** The free path: ask the background to read the Google Maps page, once per card, only if you stay on it. */
  async function maybeFetchGoogleBrowser(g, meta) {
    const fresh = meta && (meta.googleDetailsAt || (meta.googleNotFound && Date.now() - new Date(meta.googleCheckedAt || 0).getTime() < 14 * 86400000));
    if (fresh || lookupInFlight.has(g.groupKey)) return;
    const slot = $("google-slot-text"), photoText = $("google-photo-text");
    if (slot) slot.textContent = "Reading Google Maps (a small window opens for about 15 seconds)...";
    // Only look up the card you actually stay on, not ones you swipe straight past.
    await new Promise((r) => setTimeout(r, 1500));
    if (!current || current.g.groupKey !== g.groupKey) return;
    lookupInFlight.add(g.groupKey);
    if (photoText) photoText.textContent = "Loading from Google Maps...";
    let res = null;
    try {
      res = await chrome.runtime.sendMessage({ type: "GOOGLE_PAGE_LOOKUP", groupKey: g.groupKey, hotelName: g.hotelName, destination: g.destination });
    } catch (e) { /* background restarting */ }
    lookupInFlight.delete(g.groupKey);
    if (res && res.capped) {
      if (slot) slot.textContent = "Daily Google Maps lookup limit reached";
      if (photoText) photoText.textContent = "Daily Google Maps lookup limit reached";
      return;
    }
    if (res && current && current.g.groupKey === g.groupKey) renderCard(current);
  }

  async function maybeFetchGoogle(g, meta) {
    const settings = await getSettings();
    if (settings.googleSource !== "api") return maybeFetchGoogleBrowser(g, meta);
    const wantExtras = settings.googleFetchExtras !== false;
    // Cached ratings from before photos/reviews existed are looked up once more to add them.
    const needsExtras = wantExtras && meta && meta.googleRating != null && !meta.googleDetailsAt;
    if (meta && (meta.googleRating != null || meta.googleNotFound) && !needsExtras) return;
    const slot = $("google-slot-text");
    const photoText = $("google-photo-text");
    if (!settings.googlePlacesApiKey) {
      if (slot) slot.textContent = "Add a Google Places key in the Business tab for Google ratings";
      return;
    }
    const usageStore = await chrome.storage.local.get("googleUsage");
    const today = toISODate(new Date());
    const usage = usageStore.googleUsage && usageStore.googleUsage.day === today ? usageStore.googleUsage : { day: today, count: 0 };
    if (usage.count >= (settings.googleDailyCap || 40)) {
      if (slot) slot.textContent = "Daily Google lookup limit reached";
      return;
    }
    if (slot) slot.textContent = "Looking up on Google...";
    try {
      if (photoText) photoText.textContent = "Loading Google photos...";
      const hit = await fetchGoogleRating(g.hotelName, g.destination, settings.googlePlacesApiKey, wantExtras);
      await chrome.storage.local.set({ googleUsage: { day: today, count: usage.count + 1 } });
      const { hotelMeta = {} } = await chrome.storage.local.get("hotelMeta");
      hotelMeta[g.groupKey] = hit
        ? { googleRating: hit.rating, googleReviews: hit.reviews, googleUrl: hit.url, googlePhotos: hit.photos || [], googleReviewList: hit.reviewList || [], googleCheckedAt: new Date().toISOString(), googleDetailsAt: wantExtras ? new Date().toISOString() : undefined }
        : { googleNotFound: true, googleCheckedAt: new Date().toISOString() };
      await chrome.storage.local.set({ hotelMeta });
      if (current && current.g.groupKey === g.groupKey) renderCard(current);
    } catch (e) {
      if (slot) slot.textContent = String(e.message || e).slice(0, 90);
      if (photoText) photoText.textContent = "Google photos unavailable (see the message under Google rating)";
    }
  }

  function showNext() {
    current = queue[0] || null;
    const empty = !current;
    $("swipe-card").classList.toggle("hidden", empty);
    $("swipe-empty").classList.toggle("hidden", !empty);
    document.querySelectorAll(".swipe-buttons button").forEach((b) => { if (b.id !== "swipe-undo") b.disabled = empty; });
    if (current) {
      $("swipe-card").style.transition = "none";
      $("swipe-card").style.transform = "";
      $("swipe-card").style.opacity = "1";
      renderCard(current);
    }
  }

  // ------------------------------------------------------------- actions

  async function applyAction(g, action, batch) {
    const st = await loadState();
    const entry = { groupKey: g.groupKey, hotelName: g.hotelName, action, at: new Date().toISOString(), changed: false };
    if (batch) entry.batch = batch;
    if (action === "remove") {
      if (!st.blocked.some((b) => gkey(b) === g.groupKey)) {
        st.blocked.push({ source: g.source, hotelName: g.hotelName, destination: g.destination, blockedAt: entry.at, via: "swipe" });
        await chrome.storage.local.set({ blockedHotels: st.blocked });
        entry.changed = true;
      }
    } else if (action === "favorite") {
      if (!st.favorites.some((f) => gkey(f) === g.groupKey)) {
        st.favorites.push({ source: g.source, hotelName: g.hotelName, destination: g.destination, favoritedAt: entry.at });
        await chrome.storage.local.set({ favoriteHotels: st.favorites });
        entry.changed = true;
      }
    } else if (action === "gold") {
      // Gold = you stayed or filmed here. Also a favourite, and drops of even 5% get a louder alert.
      const { goldHotels = {} } = await chrome.storage.local.get("goldHotels");
      goldHotels[g.groupKey] = entry.at;
      await chrome.storage.local.set({ goldHotels });
      entry.goldChanged = true;
      if (!st.favorites.some((f) => gkey(f) === g.groupKey)) {
        st.favorites.push({ source: g.source, hotelName: g.hotelName, destination: g.destination, favoritedAt: entry.at });
        await chrome.storage.local.set({ favoriteHotels: st.favorites });
        entry.changed = true;
      }
    } else if (action === "keep") {
      st.reviewed[g.groupKey] = entry.at;
      await chrome.storage.local.set({ reviewedHotels: st.reviewed });
      entry.changed = true;
    } else if (action === "later") {
      st.later[g.groupKey] = entry.at;
      await chrome.storage.local.set({ swipeLater: st.later });
      entry.changed = true;
    }
    st.log.push(entry);
    await chrome.storage.local.set({ swipeLog: st.log.slice(-300) });
  }

  async function reverseEntry(entry) {
    if (entry.action === "gold") {
      const { goldHotels = {} } = await chrome.storage.local.get("goldHotels");
      delete goldHotels[entry.groupKey];
      await chrome.storage.local.set({ goldHotels });
    }
    if (!entry.changed) return;
    const st = await loadState();
    if (entry.action === "remove") await chrome.storage.local.set({ blockedHotels: st.blocked.filter((b) => gkey(b) !== entry.groupKey) });
    else if (entry.action === "favorite" || entry.action === "gold") await chrome.storage.local.set({ favoriteHotels: st.favorites.filter((f) => gkey(f) !== entry.groupKey) });
    else if (entry.action === "keep") { delete st.reviewed[entry.groupKey]; await chrome.storage.local.set({ reviewedHotels: st.reviewed }); }
    else if (entry.action === "later") { delete st.later[entry.groupKey]; await chrome.storage.local.set({ swipeLater: st.later }); }
  }

  async function decide(action) {
    if (!current || busy) return;
    busy = true;
    const card = $("swipe-card");
    const dir = action === "remove" ? -1 : action === "favorite" || action === "gold" ? 1 : 0;
    card.style.transition = "transform 0.22s ease, opacity 0.22s ease";
    card.style.transform = dir ? `translate(${dir * 520}px, 20px) rotate(${dir * 14}deg)` : action === "keep" ? "translateY(-420px)" : "translateY(420px)";
    card.style.opacity = "0";
    const done = current;
    await applyAction(done.g, action);
    await new Promise((r) => setTimeout(r, 200));
    queue = queue.filter((q) => q !== done);
    updateTop(await loadState());
    showNext();
    if (removedOpen) renderRemoved();
    scheduleRefresh();
    busy = false;
  }

  async function undo() {
    if (busy) return;
    const st = await loadState();
    const last = st.log[st.log.length - 1];
    if (!last) return;
    busy = true;
    const group = last.batch ? st.log.filter((e) => e.batch === last.batch) : [last];
    for (const e of group) await reverseEntry(e);
    await chrome.storage.local.set({ swipeLog: st.log.slice(0, st.log.length - group.length) });
    showToast(group.length > 1 ? `Undid ${group.length} removals` : `Undid: ${last.action} ${last.hotelName}`);
    busy = false;
    await buildQueue();
    if (removedOpen) renderRemoved();
    scheduleRefresh();
  }

  async function bulkRemoveJunk() {
    const junk = queue.filter((q) => q.junk.suggestRemove);
    if (junk.length === 0) return;
    const preview = junk.slice(0, 8).map((q) => `• ${q.g.hotelName} (${q.junk.reasons[0]})`).join("\n");
    if (!confirm(`Remove ${junk.length} hotels the junk score flags?\n\n${preview}${junk.length > 8 ? `\n...and ${junk.length - 8} more` : ""}\n\nYou can undo this in one click, or restore any of them later from the Removed list.`)) return;
    busy = true;
    const batch = `b${Date.now()}`;
    for (const q of junk) await applyAction(q.g, "remove", batch);
    busy = false;
    showToast(`Removed ${junk.length} hotels (Undo reverses all of them)`);
    await buildQueue();
    if (removedOpen) renderRemoved();
    scheduleRefresh();
  }

  // ------------------------------------------------------------- removed

  async function renderRemoved() {
    const st = await loadState();
    const byKey = new Map((allGroups || []).map((g) => [g.groupKey, g]));
    const list = [...st.blocked].sort((a, b) => String(b.blockedAt || "").localeCompare(String(a.blockedAt || "")));
    const row = (b) => {
      const g = byKey.get(gkey(b));
      const why = b.via && b.via.startsWith("missing")
        ? `missing from listings since ${String(b.lastSeen || b.blockedAt || "").slice(0, 10)}`
        : (g ? junkScore(g).reasons[0] : "");
      return `<div class="removed-row"><div><b>${escapeHtml(b.hotelName)}</b><div class="hint">${escapeHtml(b.destination)}${why ? ` • ${escapeHtml(why)}` : ""}</div></div><button class="secondary-btn" data-restore="${escapeAttr(gkey(b))}">Restore</button></div>`;
    };
    const groups = [
      ["Removed by you", list.filter((b) => !b.via || !b.via.startsWith("missing"))],
      ["Paused: missing from listings for a week or more (comes back by itself if it is listed again)", list.filter((b) => b.via === "missing-paused")],
      ["Stopped: missing for over 5 weeks (restore by hand if it returns)", list.filter((b) => b.via === "missing-stopped")],
    ];
    $("swipe-removed-list").innerHTML = list.length
      ? groups.filter(([, rows]) => rows.length).map(([title, rows]) => `<div class="removed-group">${escapeHtml(title)} (${rows.length})</div>${rows.map(row).join("")}`).join("")
      : `<p class="hint">Nothing removed.</p>`;
  }

  $("swipe-removed-list").addEventListener("click", async (ev) => {
    const b = ev.target.closest("[data-restore]");
    if (!b) return;
    const st = await loadState();
    const entry = st.blocked.find((x) => gkey(x) === b.dataset.restore);
    if (entry && entry.via && entry.via.startsWith("missing")) {
      // Restored by hand: do not auto-pause it again for 90 days.
      const { missingIgnore = {} } = await chrome.storage.local.get("missingIgnore");
      missingIgnore[b.dataset.restore] = new Date().toISOString();
      await chrome.storage.local.set({ missingIgnore });
    }
    await chrome.storage.local.set({ blockedHotels: st.blocked.filter((x) => gkey(x) !== b.dataset.restore) });
    showToast("Restored, tracking resumes on the next scan");
    await renderRemoved();
    await buildQueue();
    scheduleRefresh();
  });

  // ------------------------------------------------------------ gestures

  function attachDrag() {
    const card = $("swipe-card");
    let startX = null, startY = 0, dx = 0;
    const left = card.querySelector(".stamp-left"), right = card.querySelector(".stamp-right");
    card.onpointerdown = (e) => {
      if (e.target.closest("a, button")) return;
      startX = e.clientX; startY = e.clientY; dx = 0;
      card.setPointerCapture(e.pointerId);
      card.style.transition = "none";
    };
    card.onpointermove = (e) => {
      if (startX === null) return;
      dx = e.clientX - startX;
      const dy = (e.clientY - startY) * 0.3;
      card.style.transform = `translate(${dx}px, ${dy}px) rotate(${dx / 24}deg)`;
      left.style.opacity = dx < 0 ? Math.min(1, -dx / 120) : 0;
      right.style.opacity = dx > 0 ? Math.min(1, dx / 120) : 0;
    };
    card.onpointerup = () => {
      if (startX === null) return;
      startX = null;
      if (dx < -110) decide("remove");
      else if (dx > 110) decide("favorite");
      else {
        card.style.transition = "transform 0.18s ease";
        card.style.transform = "";
        left.style.opacity = 0; right.style.opacity = 0;
      }
    };
  }

  // -------------------------------------------------------------- wiring

  $("swipe-remove").addEventListener("click", () => decide("remove"));
  $("swipe-fav").addEventListener("click", () => decide("favorite"));
  $("swipe-keep").addEventListener("click", () => decide("keep"));
  $("swipe-gold").addEventListener("click", () => decide("gold"));
  $("swipe-later").addEventListener("click", () => decide("later"));
  $("swipe-undo").addEventListener("click", undo);
  $("swipe-bulk").addEventListener("click", bulkRemoveJunk);
  $("swipe-order").addEventListener("change", buildQueue);
  $("swipe-dest").addEventListener("change", buildQueue);
  $("swipe-removed-toggle").addEventListener("click", () => {
    removedOpen = !removedOpen;
    $("swipe-removed").classList.toggle("hidden", !removedOpen);
    if (removedOpen) renderRemoved();
  });

  document.addEventListener("keydown", (e) => {
    if ($("swipe-panel").classList.contains("hidden")) return;
    if (/^(INPUT|SELECT|TEXTAREA)$/.test(document.activeElement && document.activeElement.tagName)) return;
    if (e.key === "ArrowLeft") { e.preventDefault(); decide("remove"); }
    else if (e.key === "ArrowRight") { e.preventDefault(); decide("favorite"); }
    else if (e.key === "ArrowUp") { e.preventDefault(); decide("keep"); }
    else if (e.key === "ArrowDown") { e.preventDefault(); decide("later"); }
    else if (e.key === "g" || e.key === "G") decide("gold");
    else if (e.key === "z" || e.key === "Z") undo();
  });

  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      if (btn.dataset.tab !== "swipe") return;
      if (!allGroups || allGroups.length === 0) await refresh();
      buildQueue();
    });
  });
})();
