/**
 * Deep links and a remembered tab for the dashboard. dashboard.html#swipe
 * opens the Swipe tab directly (the popup's "Swipe hotels" button uses it),
 * and picking a tab updates the address so a refresh stays where you were.
 * Loaded last so every tab's own click handler already exists.
 */
(function () {
  const buttons = document.querySelectorAll(".tab-btn");
  buttons.forEach((btn) => {
    btn.addEventListener("click", () => {
      for (const other of buttons) {
        if (other === btn) other.setAttribute("aria-current", "page");
        else other.removeAttribute("aria-current");
      }
      const more = document.getElementById("nav-more");
      if (more) more.open = false;
      document.querySelector("header")?.scrollIntoView({ block: "start" });
      try { history.replaceState(null, "", "#" + btn.dataset.tab); } catch (e) { /* not important */ }
    });
  });
  document.querySelector('.tab-btn.active')?.setAttribute("aria-current", "page");
  document.addEventListener("click", (e) => {
    const more = document.getElementById("nav-more");
    if (more?.open && !more.contains(e.target)) more.open = false;
    const section = e.target.closest("[data-trip-section]");
    if (section) {
      if (more) more.open = false;
      document.dispatchEvent(new CustomEvent("trip:section", { detail: { section: section.dataset.tripSection } }));
    }
  });
  document.addEventListener("keydown", (e) => {
    const more = document.getElementById("nav-more");
    if (e.key === "Escape" && more?.open) { more.open = false; more.querySelector("summary")?.focus(); }
  });
  // Notice after the date-bug clean-up, shown for three weeks.
  chrome.storage.local.get("datesFixMigratedAt").then(({ datesFixMigratedAt }) => {
    if (datesFixMigratedAt && Date.now() - new Date(datesFixMigratedAt).getTime() < 21 * 86400000) {
      const el = document.getElementById("dates-fix-banner");
      if (el) el.classList.remove("hidden");
    }
  }).catch(() => {});

  const wanted = location.hash.replace("#", "");
  if (wanted) {
    const btn = document.querySelector('.tab-btn[data-tab="' + wanted.replace(/[^a-z]/g, "") + '"]');
    if (btn) btn.click();
  }
})();
