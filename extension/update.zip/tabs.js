/**
 * Deep links and a remembered tab for the dashboard. dashboard.html#swipe
 * opens the Swipe tab directly (the popup's "Swipe hotels" button uses it),
 * and picking a tab updates the address so a refresh stays where you were.
 * Loaded last so every tab's own click handler already exists.
 */
(function () {
  const fullView = () => document.documentElement.dataset.dashboardView === "full";
  function setView(mode, save = false) {
    const full = mode === "full";
    document.documentElement.dataset.dashboardView = full ? "full" : "simple";
    const toggle = document.getElementById("dashboard-view-toggle");
    if (toggle) {
      toggle.textContent = full ? "Use simpler view" : "Show full dashboard";
      toggle.setAttribute("aria-pressed", String(full));
    }
    const more = document.getElementById("nav-more");
    if (more) more.open = full;
    const channel = document.getElementById("home-channel-details");
    if (channel) channel.open = full;
    document.dispatchEvent(new CustomEvent("dashboard:view", { detail: { mode: full ? "full" : "simple" } }));
    if (save) chrome.storage.local.set({ dashboardViewMode: full ? "full" : "simple" }).catch(() => {});
  }
  document.getElementById("dashboard-view-toggle")?.addEventListener("click", () => setView(fullView() ? "simple" : "full", true));
  document.addEventListener("dashboard:full", () => setView("full", true));
  chrome.storage.local.get("dashboardViewMode").then(({ dashboardViewMode }) => setView(dashboardViewMode)).catch(() => {});
  const buttons = document.querySelectorAll(".tab-btn");
  buttons.forEach((btn) => {
    btn.addEventListener("click", () => {
      for (const other of buttons) {
        if (other === btn) other.setAttribute("aria-current", "page");
        else other.removeAttribute("aria-current");
      }
      const more = document.getElementById("nav-more");
      if (more && !fullView()) more.open = false;
      document.querySelector("header")?.scrollIntoView({ block: "start" });
      try { history.replaceState(null, "", "#" + btn.dataset.tab); } catch (e) { /* not important */ }
    });
  });
  document.querySelector('.tab-btn.active')?.setAttribute("aria-current", "page");
  document.addEventListener("click", (e) => {
    const more = document.getElementById("nav-more");
    if (!fullView() && more?.open && !more.contains(e.target)) more.open = false;
    const section = e.target.closest("[data-trip-section]");
    if (section) {
      if (more && !fullView()) more.open = false;
      document.dispatchEvent(new CustomEvent("trip:section", { detail: { section: section.dataset.tripSection } }));
    }
  });
  document.addEventListener("keydown", (e) => {
    const more = document.getElementById("nav-more");
    if (!fullView() && e.key === "Escape" && more?.open) { more.open = false; more.querySelector("summary")?.focus(); }
  });
  // Notice after the date-bug clean-up, shown for three weeks.
  chrome.storage.local.get("datesFixMigratedAt").then(({ datesFixMigratedAt }) => {
    if (datesFixMigratedAt && Date.now() - new Date(datesFixMigratedAt).getTime() < 21 * 86400000) {
      const el = document.getElementById("dates-fix-banner");
      if (el) el.classList.remove("hidden");
    }
  }).catch(() => {});

  const wanted = location.hash.replace("#", "");
  if (wanted) {
    const btn = document.querySelector('.tab-btn[data-tab="' + wanted.replace(/[^a-z]/g, "") + '"]');
    if (btn) btn.click();
  }
})();
