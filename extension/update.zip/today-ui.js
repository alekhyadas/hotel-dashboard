/**
 * Today tab (v1.44.0): draws buildToday() (today.js) on the dashboard. This is
 * now the tab the dashboard opens on. Loaded after dashboard.js (uses its
 * allGroups, refresh(), getBlockedSet(), escapeHtml/escapeAttr) and before
 * tabs.js.
 */
(function () {
  const $ = (id) => document.getElementById(id);
  let weekIdx = 0;
  let last = null;

  const fmtDay = (iso) => new Date(iso + "T00:00:00").toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short" });
  const stars = (t) => (t ? `${t}★` : "");

  function healthHtml(t) {
    const problems = t.health;
    const serious = problems.some((h) => h.level !== "info");
    const ok = serious ? "" : `<div class="td-health td-ok"><div><b>Data looks healthy.</b> Last complete scan ${escapeHtml(t.summary.lastFullScan)}, ${t.summary.hotels} hotels tracked.</div></div>`;
    return ok + problems.map((h) => `
      <div class="td-health td-${h.level}">
        <div><b>${escapeHtml(h.text)}</b><div class="td-fix">${escapeHtml(h.fix)}</div></div>
        ${/complete scan/.test(h.text) ? `<button class="td-btn" data-act="scan">Scan now</button>` : ""}
      </div>`).join("");
  }

  function pickCard(p) {
    const badge = p.kind === "deal"
      ? `<span class="td-badge td-deal" title="Below this stay's own usual price">Price drop</span>`
      : p.kind === "class"
        ? `<span class="td-badge td-class" title="Well below similar hotels on the same dates; may simply always be cheaper">Cheap for its class</span>`
        : `<span class="td-badge td-value">Good value</span>`;
    const meta = [escapeHtml(p.destination), stars(p.tier), p.isFavorite ? "♥ favourite" : ""].filter(Boolean).join(" • ");
    return `
      <article class="td-card">
        <div class="td-card-top">
          <div><h3>${escapeHtml(p.hotelName)}</h3><div class="td-meta">${meta}</div></div>
          <div class="td-price">${formatINR(p.price)}${p.fair && p.price < p.fair ? `<s>${formatINR(p.fair)}</s>` : ""}</div>
        </div>
        <div class="td-badges">${badge}<span class="td-conf td-conf-${p.confidence.level}" title="How many date-checked prices this rests on">${escapeHtml(p.confidence.label)}</span></div>
        <ul class="td-why">${p.why.slice(0, 4).map((w) => `<li>${escapeHtml(w)}</li>`).join("")}</ul>
        ${p.url ? `<a class="td-book" href="${escapeAttr(p.url)}" target="_blank" rel="noopener noreferrer">Book on MakeMyTrip</a>` : ""}
      </article>`;
  }

  function bookHtml(t) {
    const w = t.book[weekIdx];
    if (!w) return `<p class="hint">No weekend in range.</p>`;
    const tabs = t.book.map((b, i) => `<button class="td-week ${i === weekIdx ? "active" : ""}" data-week="${i}">${i === 0 ? "This weekend" : "Next weekend"} <span>${escapeHtml(fmtDay(b.checkin))}</span></button>`).join("");
    return `
      <div class="td-weeks">${tabs}</div>
      <p class="td-verdict">${escapeHtml(w.verdict)}</p>
      <div class="td-grid">${w.picks.map(pickCard).join("") || ""}</div>`;
  }

  function filmHtml(t) {
    const f = t.film;
    if (f.picks.length === 0) return `<p class="hint">Nothing newly built or well rated and uncovered yet. This fills in as more hotels are scanned and checked on YouTube.</p>`;
    return f.picks.map((p) => `
      <div class="td-row">
        <div><b>${escapeHtml(p.hotelName)}</b><div class="td-meta">${escapeHtml(p.destination)} • ${escapeHtml(p.why.join(", "))}</div></div>
        <div class="td-row-right"><b>${formatINR(p.price)}</b><div class="td-meta">${escapeHtml(fmtDay(p.checkin))}</div>${p.url ? `<a href="${escapeAttr(p.url)}" target="_blank" rel="noopener noreferrer">open</a>` : ""}</div>
      </div>`).join("")
      + (f.unchecked ? `<p class="hint">${f.unchecked} of these have not been checked on YouTube yet. <button class="td-link" data-act="videos">Check YouTube now</button></p>` : "");
  }

  function cheapestHtml(t) {
    if (t.cheapest.length === 0) return `<p class="hint">No checked prices for this weekend yet.</p>`;
    return `<table class="td-table"><thead><tr><th>Place</th><th>Cheapest decent stay</th><th class="num">Price</th><th class="num">Typical</th></tr></thead><tbody>${
      t.cheapest.map((c) => `<tr><td><b>${escapeHtml(c.destination)}</b><div class="td-meta">${c.count} hotel${c.count === 1 ? "" : "s"}</div></td><td>${c.cheapest.url ? `<a href="${escapeAttr(c.cheapest.url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(c.cheapest.hotelName)}</a>` : escapeHtml(c.cheapest.hotelName)}${c.cheapest.rating != null ? ` <span class="td-meta">${c.cheapest.rating}</span>` : ""}</td><td class="num"><b>${formatINR(c.cheapest.price)}</b></td><td class="num td-meta">${formatINR(c.typical)}</td></tr>`).join("")
    }</tbody></table>`;
  }

  function channelHtml(t) {
    const c = t.channel;
    const head = c.configured ? `Posted today: <b>${c.postedToday}</b>` : `Public channel not set up. <button class="td-link" data-act="business">Set it up</button>`;
    const list = c.recent.length
      ? c.recent.map((e) => `<div class="td-row"><div><b>${escapeHtml(e.hotelName)}</b><div class="td-meta">${escapeHtml(e.destination)} • ${escapeHtml(e.type.replace("_", " "))} • ${escapeHtml(e.checkin || "")}</div></div><div class="td-row-right"><b>${formatINR(e.price)}</b></div></div>`).join("")
      : `<p class="hint">No deals detected yet since prices started being date-checked.</p>`;
    return `<p>${head}</p>${list}<button class="td-link" data-act="feed">Open the full Deal Feed</button>`;
  }

  async function renderToday() {
    const root = $("today-root");
    if (!root) return;
    if (typeof allGroups === "undefined" || allGroups.length === 0) await refresh();
    const blocked = await getBlockedSet();
    const settings = await getSettings();
    const state = await chrome.storage.local.get(["scanHistory", "lastFullScanAt", "siteCooldown", "scanProgress", "dealEvents", "channelPostState", "helperStatus", "extPublishStatus", "extLatest", "errorLog", "stepCounts"]);
    state.runningVersion = chrome.runtime.getManifest().version;
    last = buildToday({ groups: allGroups, blocked, settings, state, nowMs: Date.now() });
    draw();
  }

  function draw() {
    const t = last;
    if (!t) return;
    $("today-health").innerHTML = healthHtml(t);
    $("today-book").innerHTML = bookHtml(t);
    $("today-film").innerHTML = filmHtml(t);
    $("today-cheapest-title").textContent = t.weekends[0] ? `Cheapest per place, ${fmtDay(t.weekends[0].checkin)}` : "Cheapest per place";
    $("today-cheapest").innerHTML = cheapestHtml(t);
    $("today-channel").innerHTML = channelHtml(t);
  }

  function goTab(name) {
    const btn = document.querySelector(`.tab-btn[data-tab="${name}"]`);
    if (btn) btn.click();
  }

  document.addEventListener("click", (e) => {
    const week = e.target.closest("[data-week]");
    if (week) { weekIdx = Number(week.dataset.week) || 0; draw(); return; }
    const act = e.target.closest("[data-act]");
    if (!act || !act.closest("#today-root")) return;
    const a = act.dataset.act;
    if (a === "scan") {
      act.disabled = true;
      act.textContent = "Starting...";
      chrome.runtime.sendMessage({ type: "RUN_SCAN_NOW", sites: ["makemytrip"] }, (res) => {
        act.textContent = res && res.started === false ? "Already running" : "Scan started";
      });
    } else if (a === "videos" || a === "feed" || a === "business") {
      goTab(a);
    }
  });

  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", () => { if (btn.dataset.tab === "today") renderToday(); });
  });
  // Keep it current while the dashboard sits open (scans land in the background).
  setInterval(() => {
    const active = document.querySelector('.tab-btn.active');
    if (active && active.dataset.tab === "today" && !document.hidden) refresh().then(renderToday).catch(() => {});
  }, 5 * 60 * 1000);
  renderToday();
})();
