/* Everyday dashboard: a few picks, a saved shortlist, one next step.
 * Price judgments and existing storage still come from today.js/shared.js. */
(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const esc = (v) => escapeHtml(String(v ?? "")), attr = (v) => escapeAttr(String(v ?? ""));
  const fmtDay = (iso) => iso ? new Date(iso + "T00:00:00").toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short" }) : "Date not checked";
  let weekIdx = 0, destination = "", last = null, rendering = false, saving = false, refreshTimer = null, wasRunning = false, currentProgress = null;
  const fullView = () => document.documentElement.dataset.dashboardView === "full";
  const allDetails = (label) => `<button class="home-text-button" data-act="full">${esc(label)}</button>`;

  function cover(p) {
    const photo = TripTools.safeUrl(p.imageUrl);
    const scene = /darjeeling|gangtok|purulia/i.test(p.destination) ? "hills" : /digha|mandarm|puri/i.test(p.destination) ? "sea" : "green";
    return `<div class="stay-cover stay-cover-${scene}"><div class="stay-cover-place"><span>Weekend escape</span><b>${esc(p.destination)}</b></div>${photo ? `<img src="${attr(photo)}" alt="${attr(p.hotelName)}" loading="lazy" referrerpolicy="no-referrer" />` : ""}</div>`;
  }
  function card(p, saved = false) {
    const g = allGroups.find((g) => g.groupKey === p.groupKey), isSaved = !!g?.isFavorite;
    const total = TripTools.payable(p.quote, p), price = total.known ? total.total : p.price;
    const priceLabel = total.known ? "total for this stay" : "room rate · total not checked";
    const badge = p.kind === "deal" ? "Price dropped" : p.kind === "class" ? "Good for its class" : saved ? "Your shortlist" : "Worth a look";
    const date = `${fmtDay(p.checkin)}${p.checkout ? " → " + fmtDay(p.checkout) : ""}`;
    const rating = p.rating != null ? `${p.rating}${p.reviewCount ? " · " + p.reviewCount.toLocaleString("en-IN") + " reviews" : " · few reviews"}` : "Guest rating not checked";
    const stale = p.updatedAt && TripTools.freshness(p).status !== "fresh";
    const bookingUrl = TripTools.safeUrl(p.url);
    const provider = p.source === "goibibo" ? "Goibibo" : p.source === "makemytrip" ? "MakeMyTrip" : "booking site";
    const confidence = p.confidence;
    const evidence = confidence || p.fair ? `<div class="stay-evidence">${confidence ? `<span class="td-conf td-conf-${attr(confidence.level)}" title="Evidence behind this recommendation">${esc(confidence.label)}</span>` : ""}${p.fair ? `<span class="stay-typical">Typical tracked rate ${p.price < p.fair ? `<s>${formatINR(p.fair)}</s>` : formatINR(p.fair)}</span>` : ""}</div>` : "";
    return `<article class="stay-card${stale ? " stay-stale" : ""}">
      <div class="stay-photo">${cover(p)}<span class="stay-label">${stale ? "Needs a fresh check" : badge}</span><button class="stay-save" data-home-save="${attr(p.groupKey)}" aria-pressed="${isSaved}" aria-label="${isSaved ? "Remove " : "Save "}${attr(p.hotelName)}${isSaved ? " from saved hotels" : ""}">${isSaved ? "♥" : "♡"}</button></div>
      <div class="stay-body"><p class="stay-place">${esc(p.destination)}${p.tier ? " · " + p.tier + " star" : ""}</p><h3>${esc(p.hotelName)}</h3><p class="stay-rating">${esc(rating)}</p><p class="stay-date">${esc(date)}</p>
      ${evidence}<p class="stay-reason">${esc((p.why || []).slice(0, 4).join(". ") || (stale ? "Check the latest price before making plans." : "Saved so you can come back to it."))}</p>
      <div class="stay-footer"><div><strong>${formatINR(price)}</strong><span>${priceLabel}</span></div><button class="stay-open" data-home-open="${attr(p.groupKey)}" data-checkin="${attr(p.checkin)}" data-checkout="${attr(p.checkout)}">See stay <span aria-hidden="true">↗</span></button></div>
      ${bookingUrl ? `<a class="stay-book-link" href="${attr(bookingUrl)}" target="_blank" rel="noopener noreferrer">Open on ${provider} ↗</a>` : ""}${saved && g?.targetPrice ? `<p class="hint">Your price alert: ${formatINR(g.targetPrice)} or less</p>` : ""}</div></article>`;
  }
  function empty(title, text, action = "scan", label = "Check prices") {
    return `<div class="home-empty"><span aria-hidden="true">↗</span><h3>${esc(title)}</h3><p>${esc(text)}</p><button class="stay-open" data-act="${action}">${esc(label)}</button></div>`;
  }
  function healthHtml(t, progress) {
    const issues = t.health || [], attention = issues.some((h) => h.level !== "info");
    const running = !!progress?.running;
    const status = running ? `Checking prices · ${progress.completed || 0} of ${progress.total || 0} searches` : attention ? "Some searches need attention" : `Last full check: ${t.summary.lastFullScan}`;
    return `<div class="home-status-strip"><span class="home-status-text${attention && !running ? " home-status-warn" : ""}"><i aria-hidden="true"></i>${esc(status)} · ${t.summary.hotels} hotels tracked</span><details class="home-checks"${fullView() ? " open" : ""}><summary>Checks &amp; setup${issues.length ? ` <span>${issues.length}</span>` : ""}</summary><div class="home-check-list">${issues.length ? issues.map((h) => `<div class="td-health td-${h.level}"><div><b>${esc(h.text)}</b><div class="td-fix">${esc(h.fix)}</div>${/complete scan/.test(h.text) ? '<button class="home-text-button" data-act="scan">Scan now</button>' : ""}</div></div>`).join("") : '<p class="hint">No tracking problems reported. Booking availability still needs checking.</p>'}</div></details></div>`;
  }
  function bookHtml(t) {
    const w = t.book[weekIdx];
    if (!w) return empty("No dates to show yet", "Run a price check to start finding stays.");
    const tabs = t.book.map((b, i) => `<button class="td-week${i === weekIdx ? " active" : ""}" data-week="${i}" aria-pressed="${i === weekIdx}">${i === 0 ? "This weekend" : "Next weekend"}<span>${esc(fmtDay(b.checkin))}</span></button>`).join("");
    const picks = fullView() ? w.picks : w.picks.slice(0, 3);
    return `<div class="td-weeks">${tabs}</div><p class="home-verdict">${esc(w.verdict)}</p>${picks.length ? `<div class="stay-grid">${picks.map((p) => card(p)).join("")}</div>${picks.length < w.picks.length ? allDetails(`Show all ${w.picks.length} picks and details`) : ""}<button class="home-text-button" data-act="hotels">Browse all tracked hotels <span aria-hidden="true">→</span></button>` : empty(destination ? `No fresh picks for ${destination} yet` : "Your next stay starts with a price check", "We’ll show a few good options here once these dates have been checked.")}`;
  }
  function filmHtml(t) {
    const picks = fullView() ? t.film.picks : t.film.picks.slice(0, 3);
    if (!picks.length) return '<p class="home-small-empty">New or less-covered hotels will appear here as you discover them.</p>';
    return picks.map((p) => `<button class="home-small-stay" data-home-open="${attr(p.groupKey)}" data-checkin="${attr(p.checkin)}" data-checkout="${attr(p.checkout)}"><span><b>${esc(p.hotelName)}</b><small>${esc(p.destination)} · ${esc((p.why || []).join(", ") || "Worth researching")}</small></span><span>${formatINR(p.price)}<small>${esc(fmtDay(p.checkin))}</small><span aria-hidden="true">↗</span></span></button>`).join("")
      + (picks.length < t.film.picks.length ? allDetails(`Show all ${t.film.picks.length} filming picks`) : "")
      + (t.film.unchecked ? `<p class="hint">${t.film.unchecked} have not been checked on YouTube yet. <button class="home-text-button" data-act="videos">Check YouTube now</button></p>` : "");
  }
  function cheapestHtml(t) {
    if (!t.cheapest.length) return '<p class="home-small-empty">Check a few destinations to compare their starting prices.</p>';
    if (fullView()) return `<table class="td-table"><thead><tr><th>Place</th><th>Cheapest decent stay</th><th class="num">Tracked rate</th><th class="num">Typical</th></tr></thead><tbody>${t.cheapest.map((c) => {
      const url = TripTools.safeUrl(c.cheapest.url);
      return `<tr><td><b>${esc(c.destination)}</b><div class="td-meta">${c.count} hotel${c.count === 1 ? "" : "s"}</div></td><td>${url ? `<a href="${attr(url)}" target="_blank" rel="noopener noreferrer">${esc(c.cheapest.hotelName)}</a>` : esc(c.cheapest.hotelName)}${c.cheapest.rating != null ? `<span class="td-meta"> · ${esc(c.cheapest.rating)}/5</span>` : ""}</td><td class="num"><b>${formatINR(c.cheapest.price)}</b></td><td class="num td-meta">${formatINR(c.typical)}</td></tr>`;
    }).join("")}</tbody></table>`;
    return t.cheapest.slice(0, 4).map((c) => `<button class="home-place-row" data-home-destination="${attr(c.destination)}"><span><b>${esc(c.destination)}</b><small>${esc(c.cheapest.hotelName)}${c.cheapest.rating != null ? ` · ${esc(c.cheapest.rating)}/5` : ""}</small><small>${c.count} hotels · typical ${formatINR(c.typical)}</small></span><span><small>room rate from</small><b>${formatINR(c.cheapest.price)}</b></span></button>`).join("")
      + (t.cheapest.length > 4 ? allDetails(`Compare all ${t.cheapest.length} destinations`) : "");
  }
  function channelHtml(t) {
    const c = t.channel;
    const recent = fullView() ? c.recent : c.recent.slice(0, 3);
    return `<p class="hint">${c.configured ? `${c.postedToday} posted today.` : 'Public channel not set up. <button class="home-text-button" data-act="business">Set it up</button>'}</p>${recent.map((e) => `<div class="td-row"><span>${esc(e.hotelName)}<small class="td-meta"> · ${esc(e.destination)} · ${esc(String(e.type || "").replace(/_/g, " "))} · ${esc(e.checkin || "")}</small></span><b>${formatINR(e.price)}</b></div>`).join("")}${recent.length < c.recent.length ? allDetails(`Show all ${c.recent.length} recent alerts`) : ""}<button class="home-text-button" data-act="feed">View recent alerts →</button>`;
  }
  async function renderToday() {
    if (!$('today-root') || rendering) return;
    rendering = true;
    try {
      if (typeof allGroups === "undefined" || allGroups.length === 0) await refresh();
      const [blocked, settings, state] = await Promise.all([getBlockedSet(), getSettings(), chrome.storage.local.get(["scanHistory", "lastFullScanAt", "siteCooldown", "scanProgress", "dealEvents", "channelPostState", "helperStatus", "extPublishStatus", "extLatest", "errorLog", "stepCounts", "helperLive"])]);
      state.runningVersion = chrome.runtime.getManifest().version;
      const places = [...new Set(allGroups.filter((g) => !blocked.has(g.groupKey)).map((g) => g.destination))].sort();
      const select = $("home-destination");
      if (select) { select.innerHTML = '<option value="">Anywhere tracked</option>' + places.map((p) => `<option value="${attr(p)}">${esc(p)}</option>`).join(""); select.value = destination; }
      last = buildToday({ groups: destination ? allGroups.filter((g) => g.destination === destination) : allGroups, blocked, settings, state, nowMs: Date.now() });
      wasRunning = !!state.scanProgress?.running;
      draw(state.scanProgress);
      await renderSaved();
    } catch (_) { $("today-book").innerHTML = empty("Couldn’t load your stays", "Your saved data is still here. Try loading the dashboard again.", "reload", "Try again"); }
    finally { rendering = false; }
  }
  function draw(progress = currentProgress) {
    if (!last) return;
    currentProgress = progress;
    $("today-health").innerHTML = healthHtml(last, progress);
    $("today-book").innerHTML = bookHtml(last);
    $("today-film").innerHTML = filmHtml(last);
    $("today-cheapest-title").textContent = last.weekends[0] ? `Cheapest per place, ${fmtDay(last.weekends[0].checkin)}` : "Cheapest per place";
    $("today-cheapest").innerHTML = cheapestHtml(last);
    $("today-channel").innerHTML = channelHtml(last);
    document.querySelectorAll('#today-root [data-act="scan"]').forEach((button) => { button.disabled = !!progress?.running; button.textContent = progress?.running ? "Checking prices…" : "Check prices"; });
  }
  async function renderSaved() {
    if (!$("saved-hotels")) return;
    const blocked = await getBlockedSet(), groups = allGroups.filter((g) => g.isFavorite && !blocked.has(g.groupKey));
    if ($("saved-count")) $("saved-count").textContent = String(groups.length);
    const checkButton = document.querySelector("[data-saved-refresh]");
    if (checkButton) checkButton.disabled = groups.length === 0;
    $("saved-hotels").innerHTML = groups.length ? groups.map((g) => {
      const future = g.dates.filter((d) => d.checkin >= toISODate(new Date()) && d.verified && !d.isLikelyBadScrape);
      const fresh = future.filter((d) => TripTools.freshness(d).status === "fresh");
      const d = [...(fresh.length ? fresh : future.length ? future : g.dates)].sort((a, b) => a.current - b.current)[0];
      return d ? card({ groupKey: g.groupKey, hotelName: g.hotelName, destination: g.destination, source: g.source, price: d.current, quote: d.quote, checkin: d.checkin, checkout: d.checkout, updatedAt: d.updatedAt, imageUrl: g.imageUrl, rating: g.rating, reviewCount: g.reviewCount, tier: g.manualStarTier ?? g.starRating, why: [] }, true) : "";
    }).join("") : empty("Your shortlist starts here", "Tap the heart on a stay you like. You can compare it or check its price again whenever you’re ready.", "today", "Find a stay");
  }
  function goTab(name) { document.querySelector(`.tab-btn[data-tab="${name}"]`)?.click(); }
  function openStay(button) {
    const g = allGroups.find((g) => g.groupKey === button.dataset.homeOpen);
    const d = g?.dates.find((d) => d.checkin === button.dataset.checkin && (!button.dataset.checkout || d.checkout === button.dataset.checkout));
    if (d?.key) document.dispatchEvent(new CustomEvent("trip:open", { detail: { id: d.key } }));
    else { goTab("hotels"); const search = $("search-hotel-name"); if (search && g) { search.value = g.hotelName; search.dispatchEvent(new Event("input", { bubbles: true })); } }
  }
  async function startScan(button) {
    button.disabled = true; button.textContent = "Starting…";
    try {
      const r = await chrome.runtime.sendMessage({ type: "RUN_SCAN_NOW", sites: ["makemytrip"], ...(destination ? { destinationName: destination } : {}) });
      button.textContent = r?.started ? "Checking prices…" : r?.queued ? "Check queued" : "Check prices";
      if (!r?.started) { button.disabled = false; showToast(r?.message || (r?.reason === "already_running" ? "A price check is already running." : "Open More → Settings & diagnostics to review tracking.")); }
      await updateProgress();
    } catch (_) { button.disabled = false; button.textContent = "Check prices"; showToast("Couldn’t start the check. Try again in a moment.", "error"); }
  }
  async function updateProgress() {
    const { scanProgress } = await chrome.storage.local.get("scanProgress");
    currentProgress = scanProgress;
    if (last) {
      const open = document.querySelector(".home-checks")?.open;
      $("today-health").innerHTML = healthHtml(last, scanProgress);
      if (open) document.querySelector(".home-checks").open = true;
      document.querySelectorAll('#today-root [data-act="scan"]').forEach((button) => { button.disabled = !!scanProgress?.running; button.textContent = scanProgress?.running ? "Checking prices…" : "Check prices"; });
    }
    if (wasRunning && !scanProgress?.running) { await refresh(); await renderToday(); }
    wasRunning = !!scanProgress?.running;
  }
  document.addEventListener("error", (e) => { if (e.target.matches?.(".stay-cover img")) e.target.hidden = true; }, true);
  document.addEventListener("change", (e) => { if (e.target.id === "home-destination") { destination = e.target.value; renderToday(); } });
  document.addEventListener("click", async (e) => {
    const b = e.target.closest("button");
    if (!b || !b.closest("#today-root, #saved-root")) return;
    if (b.dataset.week !== undefined) { weekIdx = Number(b.dataset.week) || 0; draw(); return; }
    if (b.dataset.homeOpen) { openStay(b); return; }
    if (b.dataset.homeDestination) { destination = b.dataset.homeDestination; renderToday(); return; }
    if (b.dataset.homeSave && !saving) {
      const g = allGroups.find((g) => g.groupKey === b.dataset.homeSave);
      if (!g) return; saving = true; b.disabled = true;
      try { await toggleFavorite(g); await renderToday(); }
      catch (_) { showToast("Couldn’t update saved hotels. Try again.", "error"); }
      finally { saving = false; if (b.isConnected) b.disabled = false; }
      return;
    }
    if (b.hasAttribute("data-saved-refresh")) {
      b.disabled = true; $("saved-status").textContent = "Starting a check of your saved hotels…";
      try { const r = await chrome.runtime.sendMessage({ type: "QUICK_REFRESH_FAVORITES" }); $("saved-status").textContent = r?.message || "Saved hotel price check requested."; }
      catch (_) { $("saved-status").textContent = "Couldn’t start the check. Try again shortly."; }
      finally { b.disabled = false; }
      return;
    }
    const action = b.dataset.act;
    if (action === "scan") startScan(b);
    else if (action === "full") document.dispatchEvent(new CustomEvent("dashboard:full"));
    else if (action === "reload") { await refresh(); renderToday(); }
    else if (["today", "hotels", "videos", "feed", "business", "plan"].includes(action)) goTab(action);
  });
  document.addEventListener("dashboard:view", () => draw());
  document.querySelectorAll(".tab-btn").forEach((b) => b.addEventListener("click", () => {
    if (b.dataset.tab === "today") renderToday();
    if (b.dataset.tab === "saved") refresh().then(renderSaved).catch(() => {});
  }));
  if (chrome.storage.onChanged) chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.scanProgress) updateProgress().catch(() => {});
    if (changes.favoriteHotels) { clearTimeout(refreshTimer); refreshTimer = setTimeout(() => refresh().then(renderToday).catch(() => {}), 120); }
  });
  setInterval(() => { if (!document.hidden && document.querySelector('.tab-btn.active')?.dataset.tab === "today") refresh().then(renderToday).catch(() => {}); }, 5 * 60 * 1000);
  renderToday();
})();
