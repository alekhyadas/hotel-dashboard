/**
 * Today: the answer-first view (v1.44.0).
 *
 * Every screen before this made you dig: a settings form in the popup, seven
 * dashboard tabs, tables to sort. This module answers the four questions the
 * extension exists for, in one place, from data that is already collected:
 *
 *   1. What should I book this weekend (and next)?   bookPicks()
 *   2. What is worth filming?                        filmPicks()
 *   3. Where is cheapest this weekend?               cheapestByDestination()
 *   4. Can I trust what I'm seeing right now?        healthChecks()
 *
 * Only date-verified prices are used (see MMT_DATE_FORMATS / dv: 1). Junk
 * (hostels, unrated, low-rated, sub-Rs 800 rooms) is filtered with the same
 * junkScore() the Swipe tab uses. Every pick carries plain-language reasons
 * built only from real numbers, and a confidence label saying how many
 * checked prices it rests on.
 *
 * PURE: no chrome.* calls, so it is unit-tested in tests/test_today.js and
 * shared by the dashboard, the popup, background.js (morning digest) and,
 * through its own copy, live-dashboard.html. Loaded after shared.js and
 * intel.js (needs formatINR, toISODate, upcomingWeekends, fairPriceFor,
 * junkScore, valueScore, medianOf, JUNK_SUGGEST_THRESHOLD).
 */

const TODAY_DEFAULTS = {
  minPrice: 800,          // below this it is almost always a basic room, not a resort stay
  minRating: 3.8,         // with 10+ reviews; under this it is not worth recommending
  picksPerWeekend: 5,
  filmLimit: 5,
  dealBelowUsualPct: 10,  // "deal" label: at least this far under the stay's own usual price
  dealBelowPeersPct: 20,  // or this far under same-star hotels in the same place, same dates
  staleFullScanHours: 30,
};

function todayTier(g) {
  return g.manualStarTier ?? g.starRating ?? g.aiEstimatedStarTier ?? null;
}

function verifiedHistory(d) {
  return (d.priceHistory || []).filter((p) => p && p.dv === 1 && typeof p.price === "number" && p.price >= 300);
}

function confidenceFor(n) {
  if (n >= 6) return { n, level: "high", label: `${n} checked prices` };
  if (n >= 2) return { n, level: "some", label: `${n} checked prices` };
  return { n, level: "new", label: n === 1 ? "first checked price" : "no checked price" };
}

/** A stay a person could actually book: verified, not mis-scraped, not a basic room. */
function isUsableStay(d, minPrice) {
  return !!d && d.verified === true && !d.isLikelyBadScrape && typeof d.current === "number" && d.current >= minPrice;
}

const DORM_RE = /\b(hostel|hostels|dorm|dorms|dormitory|bunk|backpackers?|dharamshala)\b/i;

/**
 * A hotel a person looking for a resort weekend would accept: not a hostel or
 * dorm (junkScore only treats those as a mild negative, so a well-rated hostel
 * used to slip through), not poorly rated, not junk by the Swipe tab's score.
 * Used both for what gets recommended and for which hotels count as "similar"
 * when comparing prices.
 */
function isComparable(g, price, o) {
  if (DORM_RE.test(g.hotelName || "")) return false;
  if (g.rating != null && g.reviewCount != null && g.reviewCount >= 10 && g.rating < o.minRating) return false;
  const threshold = typeof JUNK_SUGGEST_THRESHOLD === "number" ? JUNK_SUGGEST_THRESHOLD : 50;
  return junkScore({ ...g, cheapestPrice: price }).score < threshold;
}

/** What may be recommended: comparable hotels, plus anything you favourited. */
function isRecommendable(g, price, o) {
  return !!g.isFavorite || isComparable(g, price, o);
}

/**
 * Median price of comparable same-star hotels in the same destination for the
 * same check-in (3+ needed). Junk is left out on purpose: a few hostels in the
 * mix would drag the median down and hide a genuinely cheap good hotel.
 */
function peerMedianFor(groups, g, checkin, o) {
  const tier = todayTier(g);
  if (!tier) return null;
  const prices = [];
  for (const other of groups) {
    if (other.groupKey === g.groupKey || other.destination !== g.destination || todayTier(other) !== tier) continue;
    const d = (other.dates || []).find((x) => x.checkin === checkin && isUsableStay(x, o.minPrice));
    if (d && isComparable(other, d.current, o)) prices.push(d.current);
  }
  return prices.length >= 3 ? { median: medianOf(prices), n: prices.length, tier } : null;
}

/** Everything known about one stay, as numbers plus plain-language reasons. */
function stayFacts(groups, g, d, nowMs, o) {
  const pts = verifiedHistory(d);
  const fairInfo = fairPriceFor(pts);
  const belowUsualPct = fairInfo && d.current < fairInfo.fair ? Math.round(((fairInfo.fair - d.current) / fairInfo.fair) * 100) : 0;
  const peer = peerMedianFor(groups, g, d.checkin, o);
  const belowPeersPct = peer && d.current < peer.median ? Math.round(((peer.median - d.current) / peer.median) * 100) : 0;
  const earlier = pts.slice(0, -1);
  const lowestDays = earlier.length >= 5 && earlier.every((p) => p.price > d.current)
    ? Math.max(1, Math.round((nowMs - new Date(earlier[0].at).getTime()) / 86400000))
    : null;

  const why = [];
  if (belowUsualPct >= 5) why.push(`${belowUsualPct}% under its usual ${formatINR(fairInfo.fair)}`);
  if (belowPeersPct >= 10) why.push(`${belowPeersPct}% cheaper than other ${peer.tier}★ ${g.destination} hotels those dates`);
  if (lowestDays && lowestDays >= 3) why.push(`lowest in ${lowestDays} days of tracking`);
  if (g.rating != null) why.push(`rated ${g.rating}${g.reviewCount ? ` by ${g.reviewCount} guests` : ""}`);
  if (g.isNewlyBuilt) why.push("newly built");
  const am = (g.amenities || []).slice(0, 2);
  if (am.length) why.push(am.join(", ").toLowerCase());

  // Two different things, labelled differently on purpose: a price DROP (under
  // this stay's own usual price) is a deal today; being cheaper than similar
  // hotels may just mean it is always cheaper, which is good value, not news.
  const kind = belowUsualPct >= o.dealBelowUsualPct ? "deal" : belowPeersPct >= o.dealBelowPeersPct ? "class" : "value";
  return { fair: fairInfo ? fairInfo.fair : null, belowUsualPct, belowPeersPct, peerMedian: peer ? Math.round(peer.median) : null, lowestDays, why, kind, confidence: confidenceFor(pts.length) };
}

function pickFrom(g, d, facts) {
  return {
    groupKey: g.groupKey, hotelName: g.hotelName, destination: g.destination, source: g.source,
    checkin: d.checkin, checkout: d.checkout, price: d.current, url: d.url || null,
    rating: g.rating ?? null, reviewCount: g.reviewCount ?? null, tier: todayTier(g),
    isNewlyBuilt: !!g.isNewlyBuilt, isFavorite: !!g.isFavorite, imageUrl: g.imageUrl || null,
    kind: facts.kind, // "deal" (price drop) | "class" (cheap for its class) | "value"
    belowUsualPct: facts.belowUsualPct, belowPeersPct: facts.belowPeersPct, fair: facts.fair,
    why: facts.why, confidence: facts.confidence,
  };
}

/**
 * Best stays for one check-in date. Real deals (under the stay's own usual
 * price, or clearly under same-star peers) rank first; when there are none,
 * the best value stays are shown and labelled as such, never dressed up as
 * deals.
 */
function bookPicks(groups, blocked, checkin, nowMs, opts = {}) {
  const o = { ...TODAY_DEFAULTS, ...opts };
  const usable = groups.filter((g) => !blocked.has(g.groupKey));
  let priced = 0;
  const rows = [];
  for (const g of usable) {
    const d = (g.dates || []).find((x) => x.checkin === checkin && isUsableStay(x, o.minPrice));
    if (!d) continue;
    priced++;
    if (!isRecommendable(g, d.current, o)) continue;
    const facts = stayFacts(usable, g, d, nowMs, o);
    const value = valueScore({ ...g, cheapestPrice: d.current });
    let score = value * (1 + facts.belowUsualPct / 40 + facts.belowPeersPct / 60 + (g.isFavorite ? 0.1 : 0));
    if (facts.confidence.level === "new") score *= 0.85;
    rows.push({ pick: pickFrom(g, d, facts), score, rank: facts.kind === "deal" ? 2 : facts.kind === "class" ? 1 : 0 });
  }
  rows.sort((a, b) => (b.rank - a.rank) || (b.score - a.score));
  const picks = rows.slice(0, o.picksPerWeekend).map((r) => r.pick);
  const deals = rows.filter((r) => r.rank === 2).length;
  const cheapForClass = rows.filter((r) => r.rank === 1).length;
  const classNote = cheapForClass > 0 ? ` ${cheapForClass} more priced well below similar hotels.` : "";
  let verdict;
  if (priced === 0) verdict = "No checked prices for these dates yet. Run a scan to fill this in.";
  else if (deals > 0) verdict = `${deals} price drop${deals === 1 ? "" : "s"} out of ${priced} hotels with checked prices.${classNote}`;
  else verdict = `No price drops for these dates (${priced} hotels checked).${classNote || " These are the best value."}`;
  return { checkin, picks, deals, cheapForClass, priced, verdict };
}

/** Newly built or well-rated places with little or no YouTube coverage, with a price to plan around. */
function filmPicks(groups, blocked, nowMs, opts = {}) {
  const o = { ...TODAY_DEFAULTS, ...opts };
  const todayIso = toISODate(new Date(nowMs));
  let unchecked = 0;
  const rows = [];
  for (const g of groups) {
    if (blocked.has(g.groupKey)) continue;
    const goodEnough = g.isNewlyBuilt || (g.rating != null && g.rating >= 4.0 && (g.reviewCount || 0) >= 20);
    if (!goodEnough) continue;
    const upcoming = (g.dates || []).filter((d) => d.checkin >= todayIso && isUsableStay(d, o.minPrice)).sort((a, b) => a.current - b.current);
    const d = upcoming[0];
    if (!d) continue;
    if (!isRecommendable(g, d.current, o)) continue;
    const checked = !!g.youtubeCheckedAt;
    const videos = g.youtubeVideoCount ?? 0;
    if (checked && videos > 1) continue;
    if (!checked) unchecked++;
    const why = [];
    if (g.isNewlyBuilt) why.push("newly built");
    if (g.rating != null) why.push(`rated ${g.rating}${g.reviewCount ? ` by ${g.reviewCount} guests` : ""}`);
    why.push(!checked ? "YouTube not checked yet" : videos === 0 ? "no YouTube videos found" : "only 1 YouTube video found");
    const score = (g.isNewlyBuilt ? 3 : 0) + (g.rating || 3.5) + Math.min((g.reviewCount || 0) / 500, 1) + (checked ? 1 : 0) - d.current / 10000;
    rows.push({ score, pick: { groupKey: g.groupKey, hotelName: g.hotelName, destination: g.destination, source: g.source,
      checkin: d.checkin, checkout: d.checkout, price: d.current, url: d.url || null, rating: g.rating ?? null,
      reviewCount: g.reviewCount ?? null, isNewlyBuilt: !!g.isNewlyBuilt, imageUrl: g.imageUrl || null,
      youtubeChecked: checked, videoCount: checked ? videos : null, why } });
  }
  rows.sort((a, b) => b.score - a.score);
  return { picks: rows.slice(0, o.filmLimit).map((r) => r.pick), unchecked };
}

/** One line per destination for a check-in date: cheapest decent stay, typical price, how many hotels. */
function cheapestByDestination(groups, blocked, checkin, opts = {}) {
  const o = { ...TODAY_DEFAULTS, ...opts };
  const byDest = new Map();
  for (const g of groups) {
    if (blocked.has(g.groupKey)) continue;
    const d = (g.dates || []).find((x) => x.checkin === checkin && isUsableStay(x, o.minPrice));
    if (!d || !isRecommendable(g, d.current, o)) continue;
    if (!byDest.has(g.destination)) byDest.set(g.destination, []);
    byDest.get(g.destination).push({ g, d });
  }
  const out = [];
  for (const [destination, list] of byDest) {
    list.sort((a, b) => a.d.current - b.d.current);
    const best = list[0];
    out.push({
      destination, count: list.length, typical: Math.round(medianOf(list.map((x) => x.d.current))),
      cheapest: { hotelName: best.g.hotelName, price: best.d.current, rating: best.g.rating ?? null, url: best.d.url || null, groupKey: best.g.groupKey },
    });
  }
  return out.sort((a, b) => a.cheapest.price - b.cheapest.price);
}

function hoursAgo(iso, nowMs) {
  const t = iso ? new Date(iso).getTime() : NaN;
  return Number.isFinite(t) ? (nowMs - t) / 3600000 : null;
}

function agoText(h) {
  if (h == null) return "never";
  if (h < 1) return "under an hour ago";
  if (h < 48) return `${Math.round(h)} hours ago`;
  return `${Math.round(h / 24)} days ago`;
}

/**
 * Plain-language problems that make the picks less trustworthy, each with
 * the one thing to do about it. Ordered worst first. An empty list means the
 * data can be trusted.
 */
function healthChecks(groups, settings, state, nowMs, opts = {}) {
  const o = { ...TODAY_DEFAULTS, ...opts };
  const s = state || {};
  const out = [];
  const dests = settings.destinations || [];
  const learned = dests.filter((d) => d.mmtCode || d.goibiboCode).length;
  if (learned === 0) {
    out.push({ level: "bad", text: "No destination is set up yet, so nothing is being scanned.", fix: "Open the popup, and for each place press Search and search it once on MakeMyTrip." });
  }

  const cool = (s.siteCooldown || {}).makemytrip;
  if (cool && cool > nowMs) {
    const until = new Date(cool).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" });
    out.push({ level: "bad", text: `MakeMyTrip blocked the scanner. Automatic scans pause until ${until}.`, fix: "Nothing to do; it resumes by itself. A manual Scan still works if you need one now." });
  }

  const fullH = hoursAgo(s.lastFullScanAt, nowMs);
  if (learned > 0 && (fullH == null || fullH > o.staleFullScanHours)) {
    out.push({ level: fullH == null || fullH > 72 ? "bad" : "warn", text: `The last complete scan finished ${agoText(fullH)}, so prices may be out of date.`, fix: "Press Scan MakeMyTrip in the popup and leave Chrome open until it finishes (about 2 hours)." });
  }

  const log = ((s.scanProgress && s.scanProgress.log) || []).filter((e) => e && typeof e.found === "number");
  if (log.length >= 8) {
    const hidden = log.filter((e) => e.hidden).length;
    if (hidden / log.length >= 0.3) {
      out.push({ level: "warn", text: `${hidden} of the last ${log.length} pages were scanned in a hidden window, so they only loaded part of the hotel list.`, fix: "In Chrome open chrome://flags, search \"occlusion\", set \"Calculate window occlusion on Windows\" to Disabled, relaunch." });
    }
    const withHotels = log.filter((e) => e.found > 0);
    if (withHotels.length >= 8) {
      const avg = withHotels.reduce((a, e) => a + e.found, 0) / withHotels.length;
      if (avg < 10) out.push({ level: "warn", text: `Pages are only loading about ${Math.round(avg)} hotels each (they list 50 to 120).`, fix: "Raise \"Seconds per page\" to 60 in the popup settings, and see the hidden-window fix above." });
    }
  }

  const todayIso = toISODate(new Date(nowMs));
  const withUpcoming = groups.filter((g) => (g.dates || []).some((d) => d.checkin >= todayIso));
  if (withUpcoming.length >= 10) {
    const verified = withUpcoming.filter((g) => g.dates.some((d) => d.checkin >= todayIso && d.verified)).length;
    const pct = Math.round((verified / withUpcoming.length) * 100);
    if (pct < 50) out.push({ level: "warn", text: `Only ${pct}% of hotels have a date-checked price yet. Older prices were often wrong and are ignored here.`, fix: "This fills in as scans run. Each full scan re-checks every hotel." });
  }

  if (!settings.telegramBotToken || !settings.telegramChatId) {
    out.push({ level: "warn", text: "Telegram is not set up, so deals can't reach your phone.", fix: "Popup > Settings: paste your bot token and chat ID, then Save." });
  }
  if (!settings.youtubeApiKey) {
    out.push({ level: "info", text: "No YouTube key, so film picks can't tell which places are already covered.", fix: "Popup > Settings: paste a free YouTube Data API key." });
  }
  const rank = { bad: 0, warn: 1, info: 2 };
  return out.sort((a, b) => rank[a.level] - rank[b.level]);
}

/** The whole Today view. state = {scanHistory, lastFullScanAt, siteCooldown, scanProgress, dealEvents, channelPostState}. */
function buildToday(input) {
  const { groups = [], settings = {}, state = {}, nowMs = Date.now(), opts = {} } = input || {};
  const blocked = input && input.blocked instanceof Set ? input.blocked : new Set((input && input.blocked) || []);
  const weekends = upcomingWeekends(settings.nights || 2, settings.checkinWeekday ?? 5, 14, new Date(nowMs)).slice(0, 2);
  const book = weekends.map((w) => ({ ...bookPicks(groups, blocked, w.checkin, nowMs, opts), checkout: w.checkout }));
  const film = filmPicks(groups, blocked, nowMs, opts);
  const cheapest = weekends[0] ? cheapestByDestination(groups, blocked, weekends[0].checkin, opts) : [];
  const health = healthChecks(groups, settings, state, nowMs, opts);
  const day = toISODate(new Date(nowMs));
  const cps = state.channelPostState;
  const channel = {
    configured: !!settings.channelChatId,
    postedToday: cps && cps.day === day ? cps.count || 0 : 0,
    recent: (state.dealEvents || []).slice(0, 5).map((e) => ({ type: e.type, hotelName: e.hotelName, destination: e.destination, price: e.price, checkin: e.checkin, at: e.at, url: e.url || null })),
  };
  const fullH = hoursAgo(state.lastFullScanAt, nowMs);
  const summary = {
    hotels: groups.filter((g) => !blocked.has(g.groupKey)).length,
    lastFullScan: agoText(fullH),
    trustworthy: !health.some((h) => h.level === "bad"),
  };
  return { generatedAt: new Date(nowMs).toISOString(), weekends, book, film, cheapest, health, channel, summary };
}

function fmtTodayDate(iso) {
  return new Date(iso + "T00:00:00").toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short" });
}

/**
 * The morning Telegram message, from the same picks the Today tab shows, so
 * your phone and your screen never disagree. Returns null when there is
 * nothing worth sending.
 */
function formatTodayDigest(today, opts = {}) {
  const w = today.book[0];
  if (!w || w.picks.length === 0) return null;
  const lines = [`☀ This weekend (${fmtTodayDate(w.checkin)}): ${w.deals > 0 ? `${w.deals} price drop${w.deals === 1 ? "" : "s"}` : "no price drops, best value below"}`, ""];
  w.picks.slice(0, opts.limit || 5).forEach((p, i) => {
    lines.push(`${i + 1}. ${p.kind === "deal" ? "\u{1F525} " : p.kind === "class" ? "\u{1F4B0} " : ""}${p.hotelName} (${p.destination}) ${formatINR(p.price)}`);
    if (p.why.length) lines.push(`   ${p.why.slice(0, 3).join(", ")}`);
    if (p.url && opts.links !== false) lines.push(`   ${p.url}`);
  });
  const f = today.film.picks[0];
  if (f && opts.film !== false) {
    lines.push("", `\u{1F3AC} To film: ${f.hotelName} (${f.destination}), from ${formatINR(f.price)}, ${f.why.join(", ")}`);
  }
  return lines.join("\n");
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { TODAY_DEFAULTS, bookPicks, filmPicks, cheapestByDestination, healthChecks, buildToday, formatTodayDigest, stayFacts };
}
