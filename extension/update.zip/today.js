/**
 * Today: the answer-first view (v1.44.0).
 *
 * Every screen before this made you dig: a settings form in the popup, seven
 * dashboard tabs, tables to sort. This module answers the four questions the
 * extension exists for, in one place, from data that is already collected:
 *
 *   1. What should I book this weekend (and next)?   bookPicks()
 *   2. What is worth filming?                        filmPicks()
 *   3. Where is cheapest this weekend?               cheapestByDestination()
 *   4. Can I trust what I'm seeing right now?        healthChecks()
 *
 * Only date-verified prices are used (see MMT_DATE_FORMATS / dv: 1). Junk
 * (hostels, unrated, low-rated, sub-Rs 800 rooms) is filtered with the same
 * junkScore() the Swipe tab uses. Every pick carries plain-language reasons
 * built only from real numbers, and a confidence label saying how many
 * checked prices it rests on.
 *
 * PURE: no chrome.* calls, so it is unit-tested in tests/test_today.js and
 * shared by the dashboard, the popup, background.js (morning digest) and,
 * through its own copy, live-dashboard.html. Loaded after shared.js and
 * intel.js (needs formatINR, toISODate, upcomingWeekends, fairPriceFor,
 * junkScore, valueScore, medianOf, JUNK_SUGGEST_THRESHOLD).
 */

const TODAY_DEFAULTS = {
  minPrice: 800,          // below this it is almost always a basic room, not a resort stay
  minRating: 3.8,         // with 10+ reviews; under this it is not worth recommending
  picksPerWeekend: 5,
  filmLimit: 5,
  dealBelowUsualPct: 10,  // "deal" label: at least this far under the stay's own usual price
  dealBelowPeersPct: 20,  // or this far under same-star hotels in the same place, same dates
  staleFullScanHours: 30,
};

function todayTier(g) {
  return g.manualStarTier ?? g.starRating ?? g.aiEstimatedStarTier ?? null;
}

function verifiedHistory(d) {
  return (d.priceHistory || []).filter((p) => p && p.dv === 1 && typeof p.price === "number" && p.price >= 300);
}

function confidenceFor(n) {
  if (n >= 6) return { n, level: "high", label: `${n} checked prices` };
  if (n >= 2) return { n, level: "some", label: `${n} checked prices` };
  return { n, level: "new", label: n === 1 ? "first checked price" : "no checked price" };
}

/** A stay a person could actually book: verified, not mis-scraped, not a basic room. */
function isUsableStay(d, minPrice) {
  return !!d && d.verified === true && !d.isLikelyBadScrape && typeof d.current === "number" && d.current >= minPrice;
}

const DORM_RE = /\b(hostel|hostels|dorm|dorms|dormitory|bunk|backpackers?|dharamshala)\b/i;

/**
 * A hotel a person looking for a resort weekend would accept: not a hostel or
 * dorm (junkScore only treats those as a mild negative, so a well-rated hostel
 * used to slip through), not poorly rated, not junk by the Swipe tab's score.
 * Used both for what gets recommended and for which hotels count as "similar"
 * when comparing prices.
 */
function isComparable(g, price, o) {
  if (DORM_RE.test(g.hotelName || "")) return false;
  if (g.rating != null && g.reviewCount != null && g.reviewCount >= 10 && g.rating < o.minRating) return false;
  const threshold = typeof JUNK_SUGGEST_THRESHOLD === "number" ? JUNK_SUGGEST_THRESHOLD : 50;
  return junkScore({ ...g, cheapestPrice: price }).score < threshold;
}

/** What may be recommended: comparable hotels, plus anything you favourited. */
function isRecommendable(g, price, o) {
  return !!g.isFavorite || isComparable(g, price, o);
}

/**
 * Median price of comparable same-star hotels in the same destination for the
 * same check-in (3+ needed). Junk is left out on purpose: a few hostels in the
 * mix would drag the median down and hide a genuinely cheap good hotel.
 */
function peerMedianFor(groups, g, checkin, o) {
  const tier = todayTier(g);
  if (!tier) return null;
  const prices = [];
  for (const other of groups) {
    if (other.groupKey === g.groupKey || other.destination !== g.destination || todayTier(other) !== tier) continue;
    const d = (other.dates || []).find((x) => x.checkin === checkin && isUsableStay(x, o.minPrice));
    if (d && isComparable(other, d.current, o)) prices.push(d.current);
  }
  return prices.length >= 3 ? { median: medianOf(prices), n: prices.length, tier } : null;
}

/** Everything known about one stay, as numbers plus plain-language reasons. */
function stayFacts(groups, g, d, nowMs, o) {
  const pts = verifiedHistory(d);
  const fairInfo = fairPriceFor(pts);
  const belowUsualPct = fairInfo && d.current < fairInfo.fair ? Math.round(((fairInfo.fair - d.current) / fairInfo.fair) * 100) : 0;
  const peer = peerMedianFor(groups, g, d.checkin, o);
  const belowPeersPct = peer && d.current < peer.median ? Math.round(((peer.median - d.current) / peer.median) * 100) : 0;
  const earlier = pts.slice(0, -1);
  const lowestDays = earlier.length >= 5 && earlier.every((p) => p.price > d.current)
    ? Math.max(1, Math.round((nowMs - new Date(earlier[0].at).getTime()) / 86400000))
    : null;

  const why = [];
  if (belowUsualPct >= 5) why.push(`${belowUsualPct}% under its usual ${formatINR(fairInfo.fair)}`);
  if (belowPeersPct >= 10) why.push(`${belowPeersPct}% cheaper than other ${peer.tier}★ ${g.destination} hotels those dates`);
  if (lowestDays && lowestDays >= 3) why.push(`lowest in ${lowestDays} days of tracking`);
  if (g.rating != null) why.push(`rated ${g.rating}${g.reviewCount ? ` by ${g.reviewCount} guests` : ""}`);
  if (g.isNewlyBuilt) why.push("newly built");
  const am = (g.amenities || []).slice(0, 2);
  if (am.length) why.push(am.join(", ").toLowerCase());

  // Two different things, labelled differently on purpose: a price DROP (under
  // this stay's own usual price) is a deal today; being cheaper than similar
  // hotels may just mean it is always cheaper, which is good value, not news.
  const kind = belowUsualPct >= o.dealBelowUsualPct ? "deal" : belowPeersPct >= o.dealBelowPeersPct ? "class" : "value";
  return { fair: fairInfo ? fairInfo.fair : null, belowUsualPct, belowPeersPct, peerMedian: peer ? Math.round(peer.median) : null, lowestDays, why, kind, confidence: confidenceFor(pts.length) };
}

function pickFrom(g, d, facts) {
  return {
    groupKey: g.groupKey, hotelName: g.hotelName, destination: g.destination, source: g.source,
    checkin: d.checkin, checkout: d.checkout, price: d.current, url: d.url || null,
    rating: g.rating ?? null, reviewCount: g.reviewCount ?? null, tier: todayTier(g),
    isNewlyBuilt: !!g.isNewlyBuilt, isFavorite: !!g.isFavorite, imageUrl: g.imageUrl || null,
    kind: facts.kind, // "deal" (price drop) | "class" (cheap for its class) | "value"
    belowUsualPct: facts.belowUsualPct, belowPeersPct: facts.belowPeersPct, fair: facts.fair,
    why: facts.why, confidence: facts.confidence,
  };
}

/**
 * Best stays for one check-in date. Real deals (under the stay's own usual
 * price, or clearly under same-star peers) rank first; when there are none,
 * the best value stays are shown and labelled as such, never dressed up as
 * deals.
 */
function bookPicks(groups, blocked, checkin, nowMs, opts = {}) {
  const o = { ...TODAY_DEFAULTS, ...opts };
  const usable = groups.filter((g) => !blocked.has(g.groupKey));
  let priced = 0;
  const rows = [];
  for (const g of usable) {
    const d = (g.dates || []).find((x) => x.checkin === checkin && isUsableStay(x, o.minPrice));
    if (!d) continue;
    priced++;
    if (!isRecommendable(g, d.current, o)) continue;
    const facts = stayFacts(usable, g, d, nowMs, o);
    const value = valueScore({ ...g, cheapestPrice: d.current });
    let score = value * (1 + facts.belowUsualPct / 40 + facts.belowPeersPct / 60 + (g.isFavorite ? 0.1 : 0));
    if (facts.confidence.level === "new") score *= 0.85;
    rows.push({ pick: pickFrom(g, d, facts), score, rank: facts.kind === "deal" ? 2 : facts.kind === "class" ? 1 : 0 });
  }
  rows.sort((a, b) => (b.rank - a.rank) || (b.score - a.score));
  const picks = rows.slice(0, o.picksPerWeekend).map((r) => r.pick);
  const deals = rows.filter((r) => r.rank === 2).length;
  const cheapForClass = rows.filter((r) => r.rank === 1).length;
  const classNote = cheapForClass > 0 ? ` ${cheapForClass} more priced well below similar hotels.` : "";
  let verdict;
  if (priced === 0) verdict = "No checked prices for these dates yet. Run a scan to fill this in.";
  else if (deals > 0) verdict = `${deals} price drop${deals === 1 ? "" : "s"} out of ${priced} hotels with checked prices.${classNote}`;
  else verdict = `No price drops for these dates (${priced} hotels checked).${classNote || " These are the best value."}`;
  return { checkin, picks, deals, cheapForClass, priced, verdict };
}

/** Newly built or well-rated places with little or no YouTube coverage, with a price to plan around. */
function filmPicks(groups, blocked, nowMs, opts = {}) {
  const o = { ...TODAY_DEFAULTS, ...opts };
  const todayIso = toISODate(new Date(nowMs));
  let unchecked = 0;
  const rows = [];
  for (const g of groups) {
    if (blocked.has(g.groupKey)) continue;
    const goodEnough = g.isNewlyBuilt || (g.rating != null && g.rating >= 4.0 && (g.reviewCount || 0) >= 20);
    if (!goodEnough) continue;
    const upcoming = (g.dates || []).filter((d) => d.checkin >= todayIso && isUsableStay(d, o.minPrice)).sort((a, b) => a.current - b.current);
    const d = upcoming[0];
    if (!d) continue;
    if (!isRecommendable(g, d.current, o)) continue;
    const checked = !!g.youtubeCheckedAt;
    const videos = g.youtubeVideoCount ?? 0;
    if (checked && videos > 1) continue;
    if (!checked) unchecked++;
    const why = [];
    if (g.isNewlyBuilt) why.push("newly built");
    if (g.rating != null) why.push(`rated ${g.rating}${g.reviewCount ? ` by ${g.reviewCount} guests` : ""}`);
    why.push(!checked ? "YouTube not checked yet" : videos === 0 ? "no YouTube videos found" : "only 1 YouTube video found");
    const score = (g.isNewlyBuilt ? 3 : 0) + (g.rating || 3.5) + Math.min((g.reviewCount || 0) / 500, 1) + (checked ? 1 : 0) - d.current / 10000;
    rows.push({ score, pick: { groupKey: g.groupKey, hotelName: g.hotelName, destination: g.destination, source: g.source,
      checkin: d.checkin, checkout: d.checkout, price: d.current, url: d.url || null, rating: g.rating ?? null,
      reviewCount: g.reviewCount ?? null, isNewlyBuilt: !!g.isNewlyBuilt, imageUrl: g.imageUrl || null,
      youtubeChecked: checked, videoCount: checked ? videos : null, why } });
  }
  rows.sort((a, b) => b.score - a.score);
  return { picks: rows.slice(0, o.filmLimit).map((r) => r.pick), unchecked };
}

/** One line per destination for a check-in date: cheapest decent stay, typical price, how many hotels. */
function cheapestByDestination(groups, blocked, checkin, opts = {}) {
  const o = { ...TODAY_DEFAULTS, ...opts };
  const byDest = new Map();
  for (const g of groups) {
    if (blocked.has(g.groupKey)) continue;
    const d = (g.dates || []).find((x) => x.checkin === checkin && isUsableStay(x, o.minPrice));
    if (!d || !isRecommendable(g, d.current, o)) continue;
    if (!byDest.has(g.destination)) byDest.set(g.destination, []);
    byDest.get(g.destination).push({ g, d });
  }
  const out = [];
  for (const [destination, list] of byDest) {
    list.sort((a, b) => a.d.current - b.d.current);
    const best = list[0];
    out.push({
      destination, count: list.length, typical: Math.round(medianOf(list.map((x) => x.d.current))),
      cheapest: { hotelName: best.g.hotelName, price: best.d.current, rating: best.g.rating ?? null, url: best.d.url || null, groupKey: best.g.groupKey },
    });
  }
  return out.sort((a, b) => a.cheapest.price - b.cheapest.price);
}

function hoursAgo(iso, nowMs) {
  const t = iso ? new Date(iso).getTime() : NaN;
  return Number.isFinite(t) ? (nowMs - t) / 3600000 : null;
}

function agoText(h) {
  if (h == null) return "never";
  if (h < 1) return "under an hour ago";
  if (h < 48) return `${Math.round(h)} hours ago`;
  return `${Math.round(h / 24)} days ago`;
}

/**
 * Plain-language problems that make the picks less trustworthy, each with
 * the one thing to do about it. Ordered worst first. An empty list means the
 * data can be trusted.
 */
function healthChecks(groups, settings, state, nowMs, opts = {}) {
  const o = { ...TODAY_DEFAULTS, ...opts };
  const s = state || {};
  const out = [];
  const dests = settings.destinations || [];
  const learned = dests.filter((d) => d.mmtCode || d.goibiboCode).length;
  if (learned === 0) {
    out.push({ level: "bad", text: "No destination is set up yet, so nothing is being scanned.", fix: "Open the popup, and for each place press Search and search it once on MakeMyTrip." });
  }

  const cool = (s.siteCooldown || {}).makemytrip;
  if (cool && cool > nowMs) {
    const until = new Date(cool).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" });
    out.push({ level: "bad", text: `MakeMyTrip blocked the scanner. Automatic scans pause until ${until}.`, fix: "Nothing to do; it resumes by itself. A manual Scan still works if you need one now." });
  }

  const fullH = hoursAgo(s.lastFullScanAt, nowMs);
  if (learned > 0 && (fullH == null || fullH > o.staleFullScanHours)) {
    out.push({ level: fullH == null || fullH > 72 ? "bad" : "warn", text: `The last complete scan finished ${agoText(fullH)}, so prices may be out of date.`, fix: "Press Scan MakeMyTrip in the popup and leave Chrome open until it finishes (about 2 hours)." });
  }

  const log = ((s.scanProgress && s.scanProgress.log) || []).filter((e) => e && typeof e.found === "number");
  if (log.length >= 8) {
    const hidden = log.filter((e) => e.hidden).length;
    if (hidden / log.length >= 0.3) {
      out.push({ level: "warn", text: `${hidden} of the last ${log.length} pages were scanned in a hidden window, so they only loaded part of the hotel list.`, fix: "In Chrome open chrome://flags, search \"occlusion\", set \"Calculate window occlusion on Windows\" to Disabled, relaunch." });
    }
    const withHotels = log.filter((e) => e.found > 0);
    if (withHotels.length >= 8) {
      const avg = withHotels.reduce((a, e) => a + e.found, 0) / withHotels.length;
      if (avg < 10) out.push({ level: "warn", text: `Pages are only loading about ${Math.round(avg)} hotels each (they list 50 to 120).`, fix: "Raise \"Seconds per page\" to 60 in the popup settings, and see the hidden-window fix above." });
    }
  }

  const todayIso = toISODate(new Date(nowMs));
  const withUpcoming = groups.filter((g) => (g.dates || []).some((d) => d.checkin >= todayIso));
  if (withUpcoming.length >= 10) {
    const verified = withUpcoming.filter((g) => g.dates.some((d) => d.checkin >= todayIso && d.verified)).length;
    const pct = Math.round((verified / withUpcoming.length) * 100);
    if (pct < 50) out.push({ level: "warn", text: `Only ${pct}% of hotels have a date-checked price yet. Older prices were often wrong and are ignored here.`, fix: "This fills in as scans run. Each full scan re-checks every hotel." });
  }

  // v2.0.0: setup checks, so "is it working?" has an answer on screen.
  const helper = settings.deviceRole === "helper";
  const hs = s.helperStatus || {};
  if (helper) {
    const pullH = hoursAgo(hs.lastPullAt, nowMs);
    if (!settings.githubToken || !settings.githubRepo) {
      out.push({ level: "bad", text: "This helper has no GitHub token or repo, so nothing it finds can reach the main computer.", fix: "Dashboard > Channel & computers > paste a setup code, or add them in the popup Settings." });
    } else if (!hs.lastPullAt) {
      out.push({ level: "warn", text: "This helper has not received the main computer's settings yet.", fix: "Dashboard > Channel & computers > Sync now." });
    } else if (pullH != null && pullH > 2) {
      out.push({ level: "warn", text: `This helper last heard from the main computer ${agoText(pullH)}.`, fix: "Keep Chrome open and internet on, then press Sync now." });
    } else if (!hs.lastUploadAt && learned > 0) {
      out.push({ level: "info", text: "This helper has not sent any prices to the main computer yet.", fix: "Run a scan (Scan on a destination in the popup); it sends results every 15 minutes." });
    }
  } else if (settings.helpersEnabled && !(hs.devices || []).length) {
    out.push({ level: "info", text: "No helper computer has sent prices yet.", fix: "On the helper: Channel & computers > Sync now, then run a scan." });
  }

  // Is this computer on the version the main computer published?
  const latest = s.extLatest;
  if (latest && latest.version && s.runningVersion && cmpVersion(latest.version, s.runningVersion) > 0) {
    const seenH = hoursAgo(latest.seenAt, nowMs);
    if (seenH != null && seenH > 2) {
      out.push({ level: "warn", text: `This computer runs version ${s.runningVersion} but ${latest.version} was published ${agoText(seenH)}.`, fix: "If the hourly update task is not installed here, double-click tools\\install-auto-update.cmd once. Or copy the new files from the main computer." });
    }
  }
  if (!helper && s.extPublishStatus && s.extPublishStatus.state === "error") {
    out.push({ level: "warn", text: `Updates for your other computers could not be published: ${String(s.extPublishStatus.error || "").slice(0, 140)}`, fix: "Check the GitHub token has access to the repo (popup > Settings), then press Publish update now." });
  }

  // Background errors from the last day (Chrome's own "No SW" restarts are harmless and left out).
  const errs = (s.errorLog || []).filter((e) => e && !/No SW/i.test(e.message || "") && nowMs - new Date(e.at).getTime() < 24 * 3600000);
  if (errs.length) {
    out.push({ level: errs.length >= 5 ? "bad" : "warn", text: `${errs.length} background error${errs.length === 1 ? "" : "s"} in the last 24 hours. Latest: ${String(errs[errs.length - 1].message).slice(0, 120)}`, fix: "Dashboard > Tools > Copy diagnostics, and send it to me." });
  }

  if (!settings.telegramBotToken || !settings.telegramChatId) {
    out.push({ level: "warn", text: "Telegram is not set up, so deals can't reach your phone.", fix: "Popup > Settings: paste your bot token and chat ID, press Send a test message, then Save." });
  }
  if (!settings.youtubeApiKey) {
    out.push({ level: "info", text: "No YouTube key, so film picks can't tell which places are already covered.", fix: "Popup > Settings: paste a free YouTube Data API key." });
  }
  const rank = { bad: 0, warn: 1, info: 2 };
  return out.sort((a, b) => rank[a.level] - rank[b.level]);
}

/** The whole Today view. state = {scanHistory, lastFullScanAt, siteCooldown, scanProgress, dealEvents, channelPostState}. */
function buildToday(input) {
  const { groups = [], settings = {}, state = {}, nowMs = Date.now(), opts = {} } = input || {};
  const blocked = input && input.blocked instanceof Set ? input.blocked : new Set((input && input.blocked) || []);
  const weekends = upcomingWeekends(settings.nights || 2, settings.checkinWeekday ?? 5, 14, new Date(nowMs)).slice(0, 2);
  const book = weekends.map((w) => ({ ...bookPicks(groups, blocked, w.checkin, nowMs, opts), checkout: w.checkout }));
  const film = filmPicks(groups, blocked, nowMs, opts);
  const cheapest = weekends[0] ? cheapestByDestination(groups, blocked, weekends[0].checkin, opts) : [];
  const health = healthChecks(groups, settings, state, nowMs, opts);
  const day = toISODate(new Date(nowMs));
  const cps = state.channelPostState;
  const channel = {
    configured: !!settings.channelChatId,
    postedToday: cps && cps.day === day ? cps.count || 0 : 0,
    recent: (state.dealEvents || []).slice(0, 5).map((e) => ({ type: e.type, hotelName: e.hotelName, destination: e.destination, price: e.price, checkin: e.checkin, at: e.at, url: e.url || null })),
  };
  const fullH = hoursAgo(state.lastFullScanAt, nowMs);
  const summary = {
    hotels: groups.filter((g) => !blocked.has(g.groupKey)).length,
    lastFullScan: agoText(fullH),
    trustworthy: !health.some((h) => h.level === "bad"),
  };
  return { generatedAt: new Date(nowMs).toISOString(), weekends, book, film, cheapest, health, channel, summary };
}

function fmtTodayDate(iso) {
  return new Date(iso + "T00:00:00").toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short" });
}

/**
 * The morning Telegram message, from the same picks the Today tab shows, so
 * your phone and your screen never disagree. Returns null when there is
 * nothing worth sending.
 */
function formatTodayDigest(today, opts = {}) {
  const w = today.book[0];
  if (!w || w.picks.length === 0) return null;
  const lines = [`☀ This weekend (${fmtTodayDate(w.checkin)}): ${w.deals > 0 ? `${w.deals} price drop${w.deals === 1 ? "" : "s"}` : "no price drops, best value below"}`, ""];
  w.picks.slice(0, opts.limit || 5).forEach((p, i) => {
    lines.push(`${i + 1}. ${p.kind === "deal" ? "\u{1F525} " : p.kind === "class" ? "\u{1F4B0} " : ""}${p.hotelName} (${p.destination}) ${formatINR(p.price)}`);
    if (p.why.length) lines.push(`   ${p.why.slice(0, 3).join(", ")}`);
    if (p.url && opts.links !== false) lines.push(`   ${p.url}`);
  });
  const f = today.film.picks[0];
  if (f && opts.film !== false) {
    lines.push("", `\u{1F3AC} To film: ${f.hotelName} (${f.destination}), from ${formatINR(f.price)}, ${f.why.join(", ")}`);
  }
  return lines.join("\n");
}

// ---------------------------------------------------------------------------
// v1.44.8: market deals. A stay that is cheap compared with comparable hotels
// on the SAME dates, found by the extension itself with no target price to
// set. Same dates is the whole point: a Durga Puja or a plain Friday, every
// hotel is priced for those dates, so comparing like with like is what makes
// weekends and holidays "intelligent" without a rulebook. Peak dates are
// detected from the data too (a place's prices that weekend sit well above its
// usual for that kind of stay), so the alert can say so.
// ---------------------------------------------------------------------------

const MARKET_DEFAULTS = {
  minPeers: 5,        // comparable same-star hotels needed on the same dates; fewer = not enough to call a market
  belowPct: 25,       // at least this far under their median
  maxAgeHours: 72,    // a price older than this is not "the market" any more
  rearmBelowPct: 10,  // the alert is armed again once the stay is back within this of the market
  peakRatio: 1.25,    // a check-in whose median is this far above the place's usual is a peak date
  unratedExtraPct: 10, // hotels with no star rating are compared among themselves, with a higher bar
  unratedMinReviews: 20, // ...and only hotels with a real guest rating (20+ reviews) are in that group
  unratedDealMinRating: 4.0, // ...and the deal itself must be well rated by 50+ guests
  unratedDealMinReviews: 50,
};

const WEEKDAY_NAMES = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

/** A stay that starts Friday or Saturday is a weekend stay; anything else is midweek. */
function dayKindOf(checkin) {
  const wd = new Date(`${checkin}T00:00:00`).getDay();
  return wd === 5 || wd === 6 ? "weekend" : "midweek";
}

function niceStayDates(checkin, checkout) {
  const f = (iso) => { const d = new Date(`${iso}T00:00:00`); return `${WEEKDAY_NAMES[d.getDay()]} ${d.getDate()} ${MONTH_NAMES[d.getMonth()]}`; };
  return `${f(checkin)} to ${f(checkout)}`;
}

/** One line saying what kind of stay this is, so a price is never judged without its dates. */
function stayContextLine(checkin, checkout, holiday, peak) {
  const kind = dayKindOf(checkin);
  const parts = [`${niceStayDates(checkin, checkout)}, ${kind === "weekend" ? "weekend" : "midweek"} stay`];
  if (holiday) parts.push(`${holiday} dates`);
  if (peak) parts.push(`peak dates: this place is about ${peak.pct}% dearer than its usual ${kind === "weekend" ? "weekends" : "midweek stays"}`);
  return parts.join(" · ");
}

function marketDeals(groups, blockedSet, nowMs, holidayWindows, opts = {}) {
  const o = { ...TODAY_DEFAULTS, ...MARKET_DEFAULTS, ...(typeof definedOnly === "function" ? definedOnly(opts) : opts) };
  const todayIso = toISODate(new Date(nowMs));
  const maxAgeMs = o.maxAgeHours * 3600000;

  // Every fresh, usable, comparable stay from today on.
  const pool = [];
  for (const g of groups || []) {
    if (blockedSet && blockedSet.has(g.groupKey)) continue;
    // A hotel with no star rating (MakeMyTrip often shows none) is compared with
    // the other unrated hotels that have a real guest rating, not skipped.
    const tier = todayTier(g) || (g.rating != null && g.reviewCount != null && g.reviewCount >= o.unratedMinReviews ? "unrated" : null);
    if (!tier) continue;
    for (const d of g.dates || []) {
      if (!d || d.checkin < todayIso || !isUsableStay(d, o.minPrice)) continue;
      const at = d.updatedAt ? new Date(d.updatedAt).getTime() : 0;
      if (nowMs - at > maxAgeMs) continue;
      if (!isComparable(g, d.current, o)) continue;
      pool.push({ g, d, tier });
    }
  }

  // Same place, same star band, same dates.
  const byMarket = new Map();
  const byCheckin = new Map();
  for (const e of pool) {
    const mk = `${e.g.destination}|${e.tier}|${e.d.checkin}|${e.d.checkout}`;
    if (!byMarket.has(mk)) byMarket.set(mk, []);
    byMarket.get(mk).push(e);
    const ck = `${e.g.destination}|${e.tier}|${e.d.checkin}`;
    if (!byCheckin.has(ck)) byCheckin.set(ck, []);
    byCheckin.get(ck).push(e.d.current);
  }
  // Each check-in's median per place and star band, for spotting peak dates.
  const medianByCheckin = new Map(); // "dest|tier" -> Map(checkin -> median)
  for (const [ck, prices] of byCheckin) {
    if (prices.length < 3) continue;
    const [dest, tier, checkin] = ck.split("|");
    const pk = `${dest}|${tier}`;
    if (!medianByCheckin.has(pk)) medianByCheckin.set(pk, new Map());
    medianByCheckin.get(pk).set(checkin, medianOf(prices));
  }

  const candidates = [];
  const evaluated = {};
  for (const e of pool) {
    const mk = `${e.g.destination}|${e.tier}|${e.d.checkin}|${e.d.checkout}`;
    const peers = byMarket.get(mk).filter((x) => x.g.groupKey !== e.g.groupKey).map((x) => x.d.current);
    if (peers.length < o.minPeers) continue;
    const median = medianOf(peers);
    const belowPct = ((median - e.d.current) / median) * 100;
    const stayKey = `${e.g.groupKey}|${e.d.checkin}|${e.d.checkout}`;
    evaluated[stayKey] = belowPct;
    const unrated = e.tier === "unrated";
    if (belowPct < (unrated ? o.belowPct + o.unratedExtraPct : o.belowPct)) continue;
    if (unrated && !((e.g.rating || 0) >= o.unratedDealMinRating && (e.g.reviewCount || 0) >= o.unratedDealMinReviews)) continue;

    const kind = dayKindOf(e.d.checkin);
    const medians = medianByCheckin.get(`${e.g.destination}|${e.tier}`) || new Map();
    const thisMedian = medians.get(e.d.checkin);
    const others = [...medians.entries()].filter(([c]) => c !== e.d.checkin && dayKindOf(c) === kind).map(([, m]) => m);
    let peak = null;
    if (thisMedian && others.length >= 3) {
      const baseline = medianOf(others);
      if (baseline && thisMedian / baseline >= o.peakRatio) peak = { pct: Math.round((thisMedian / baseline - 1) * 100), baseline: Math.round(baseline) };
    }
    const fairInfo = fairPriceFor(verifiedHistory(e.d));
    candidates.push({
      stayKey, groupKey: e.g.groupKey, hotelName: e.g.hotelName, destination: e.g.destination, source: e.g.source,
      checkin: e.d.checkin, checkout: e.d.checkout, price: e.d.current, url: e.d.url || null,
      rating: e.g.rating ?? null, reviewCount: e.g.reviewCount ?? null, tier: e.tier, starRating: e.g.starRating ?? null,
      isNewlyBuilt: !!e.g.isNewlyBuilt, originalPrice: e.d.originalPrice ?? null,
      belowPeersPct: Math.round(belowPct), peerMedian: Math.round(median), peerCount: peers.length,
      fair: fairInfo ? fairInfo.fair : null,
      belowUsualPct: fairInfo && e.d.current < fairInfo.fair ? Math.round(((fairInfo.fair - e.d.current) / fairInfo.fair) * 100) : 0,
      alwaysCheap: !!(fairInfo && e.d.current >= fairInfo.fair * 0.97),
      holiday: typeof holidayFor === "function" ? holidayFor(e.d.checkin, e.d.checkout, holidayWindows) : null,
      kind, peak,
    });
  }
  candidates.sort((a, b) => b.belowPeersPct - a.belowPeersPct || (b.rating || 0) - (a.rating || 0));
  return { candidates, evaluated };
}

/**
 * v2.0.1: what a hotel usually costs for the SAME kind of stay (weekend or midweek), from its own
 * verified readings across all its dates of that kind. A "rare deal" is judged against this, not against
 * all its dates pooled together (a cheap Wednesday is not rare next to its weekend prices).
 * -> {ref, n, kind} or null (needs 6+ readings).
 */
function rareDealReference(g) {
  const cheapest = g && g.cheapest;
  if (!cheapest || !cheapest.checkin) return null;
  const kind = dayKindOf(cheapest.checkin);
  const prices = [];
  for (const d of g.dates || []) {
    if (dayKindOf(d.checkin) !== kind || !d.verified) continue; // priceHistory of a verified date is its verified readings only
    for (const p of d.priceHistory || []) if (p && typeof p.price === "number" && p.price >= 300) prices.push(p.price);
  }
  if (prices.length < 6) return null;
  return { ref: Math.round(medianOf(prices)), n: prices.length, kind };
}

/**
 * v2.0.0: one block of text that says how this computer is doing: version, role,
 * what is connected (yes/no only, never the keys), alert switches, scan and
 * helper status, recent errors and activity, and the health checks. Meant to
 * be copied and sent, so anything shaped like a token is redacted at the end.
 */
function buildDiagnostics(input) {
  const { version, settings = {}, state = {}, hotels = null, nowMs = Date.now(), health = [] } = input || {};
  const yes = (v) => (v ? "yes" : "no");
  const iso = (t) => (t ? new Date(t).toISOString().replace("T", " ").slice(0, 16) : "never");
  const ago = (t) => (t ? agoText(hoursAgo(t, nowMs)) : "never");
  const L = [];
  L.push("Weekend Resort Deal Tracker diagnostics", `Made ${iso(nowMs)} UTC`, "");
  const latest = state.extLatest;
  L.push(`Version: ${version || "?"}${latest ? `   (main computer has published ${latest.version}, checked ${ago(latest.checkedAt)})` : ""}`);
  const helper = settings.deviceRole === "helper";
  L.push(`This computer: ${helper ? `HELPER "${settings.deviceName || "?"}"` : "MAIN"}   scans: ${(settings.scanDestinations || []).join(", ") || "everything"}`);
  L.push(`Hotels tracked: ${hotels == null ? "?" : hotels}`);
  L.push("");
  L.push("Connections (yes/no only)");
  L.push(`  GitHub token: ${yes(settings.githubToken)}   repo: ${settings.githubRepo || "not set"}`);
  L.push(`  Telegram bot token: ${yes(settings.telegramBotToken)}   chat ID: ${yes(settings.telegramChatId)}   public channel: ${settings.channelChatId || "not set"}`);
  L.push(`  AI key: ${yes(settings.aiApiKey)}   YouTube key: ${yes(settings.youtubeApiKey)}   subscriber sign-ups: ${yes(settings.subscriberBotEnabled)}`);
  L.push("");
  L.push("Alerts");
  L.push(`  price drop >= ${settings.priceDropPctThreshold}%   discount >= ${settings.discountPctThreshold}%   last-minute ${settings.lastMinuteDays} days, ${settings.lastMinuteDropPct}%`);
  L.push(`  lowest ever: ${yes(settings.alertRecordLow !== false)}   good deals: ${yes(settings.alertGoodDeals !== false)} (${settings.goodDealBelowPct ?? 25}%)   market deals: ${yes(settings.alertMarketDeals !== false)} (${settings.marketDealBelowPct ?? 25}%)`);
  const day = toISODate(new Date(nowMs));
  const cps = state.channelPostState;
  L.push(`  channel posts today: ${cps && cps.day === day ? cps.count || 0 : 0}   deal events kept: ${(state.dealEvents || []).length}`);
  L.push("");
  L.push("Scanning");
  const sp = state.scanProgress || {};
  L.push(`  running: ${yes(sp.running)}${sp.currentLabel ? `   ${String(sp.currentLabel).slice(0, 80)}` : ""}`);
  L.push(`  last full scan: ${ago(state.lastFullScanAt)}   MakeMyTrip pause until: ${(state.siteCooldown || {}).makemytrip > nowMs ? iso((state.siteCooldown || {}).makemytrip) : "none"}`);
  if (state.lastMmtClear) L.push(`  MakeMyTrip data last cleared: ${ago(state.lastMmtClear.at)}`);
  L.push("");
  L.push("Alert quality (are these deals actually good?)");
  const au = auditAlerts(state.dealEvents || [], nowMs, { sinceHours: 72 });
  const why = (r) => Object.entries(r || {}).sort((a, b) => b[1] - a[1]).map(([k, n]) => `${n} ${ALERT_REASON_TEXT[k] || k}`).join("; ");
  L.push(`  last 3 days in the feed: ${au.total} alerts on ${au.hotels} hotels; under today's rules ${au.passed} would be sent (${au.passedHotels} hotels)`);
  if (au.rejected) L.push(`  those that would not: ${why(au.reasons)}`);
  const sup = state.alertSuppressed;
  if (sup) L.push(`  held back since this version: ${Object.values(sup.total || {}).reduce((a, b) => a + b, 0)} (${why(sup.total) || "none"})`);
  const pings = state.ownerPingState && state.ownerPingState.day === day ? state.ownerPingState.count || 0 : 0;
  const dg = state.ownerDigestState;
  L.push(`  urgent messages today: ${pings} of ${settings.alertPingMax ?? 6}   waiting for the next digest: ${(state.ownerDigestQueue || []).length}   last digest: ${dg && dg.lastAt ? ago(dg.lastAt) : "never"}`);
  L.push("");
  L.push("Helpers and updates");
  const hs = state.helperStatus || {};
  if (helper) L.push(`  last pulled settings: ${ago(hs.lastPullAt)}   last upload: ${ago(hs.lastUploadAt)}${hs.lastUploadRecords != null ? ` (${hs.lastUploadRecords} records)` : ""}`);
  else L.push(`  helpers enabled: ${yes(settings.helpersEnabled)}   last sync: ${ago(hs.lastSyncAt)}   seen: ${(hs.devices || []).map((d) => `${d.device} (${ago(d.at)}, ${d.records} records)`).join(", ") || "none"}`);
  if (hs.error) L.push(`  helper problem: ${hs.error}`);
  const ps = state.extPublishStatus;
  if (!helper) L.push(`  publishing updates: ${yes(settings.publishExtensionUpdates !== false)}   ${ps ? `${ps.state}${ps.version ? ` ${ps.version}` : ""}${ps.error ? ` (${ps.error})` : ""}, checked ${ago(ps.checkedAt)}` : "never checked"}`);
  L.push("");
  const probs = (health || []).filter((h) => h.level !== "info");
  L.push(`Health checks (${probs.length} need attention)`);
  for (const h of probs) L.push(`  [${h.level}] ${h.text}`);
  if (!probs.length) L.push("  all clear");
  L.push("");
  const errs = (state.errorLog || []).slice(-10);
  L.push(`Recent errors (${(state.errorLog || []).length} kept, last 10 shown)`);
  for (const e of errs) L.push(`  ${iso(e.at)} [${e.where}]${e.count > 1 ? ` x${e.count}` : ""} ${e.message}${e.stack ? `   ${String(e.stack).slice(0, 200)}` : ""}`);
  if (!errs.length) L.push("  none");
  L.push("");
  const acts = (state.activityLog || []).slice(-20);
  L.push("Recent activity (last 20)");
  for (const a of acts) L.push(`  ${iso(a.at)} ${a.event}${a.details ? ` ${JSON.stringify(a.details).slice(0, 140)}` : ""}`);
  if (!acts.length) L.push("  none");
  return redactSecrets(L.join("\n"));
}

/** The lines of an owner alert for one market deal. */
function marketDealReasons(c) {
  const band = c.tier === "unrated" ? "hotels with no star rating" : `${c.tier}★ hotels`;
  const out = [`\u{1F4B8} ${c.belowPeersPct}% cheaper than similar ${band} in ${c.destination} on the same dates (they cost about ${formatINR(c.peerMedian)}, ${c.peerCount} compared)`];
  out.push(`\u{1F4C5} ${stayContextLine(c.checkin, c.checkout, c.holiday, c.peak)}`);
  if (c.peak) out.push("On peak dates everyone is dearer, so this is still a clear saving against the rest");
  if (c.belowUsualPct >= 10) out.push(`Also ${c.belowUsualPct}% under its own usual ${formatINR(c.fair)}`);
  else if (c.alwaysCheap) out.push("It usually prices about like this, so this is good value rather than a one-off drop");
  return out;
}

// ---------------------------------------------------------------------------
// v2.0.0: ask the bot. Plain words in, the best stays out:
//   "best deals mandarmani next friday or the one after, dont wanna go during diwali"
// parseTripRequest() works out the place(s), which weekend(s) and which
// holidays to avoid; answerTripRequest() looks the stays up in what has been
// scanned and writes the reply. Pure: no chrome.* calls (background.js sends it).
// ---------------------------------------------------------------------------

const ASK_MONTHS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
const ASK_NOT_PLACES = new Set(["the", "next", "this", "that", "weekend", "weekends", "friday", "saturday", "sunday", "fri", "sat", "sun", "tonight", "today", "tomorrow", "me", "us", "you", "it", "them", "december", "january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "diwali", "puja", "durga", "christmas", "holiday", "holidays", "any", "all", "some", "two", "three", "one", "now", "later", "there", "here", "week", "month", "budget", "family", "couple", "friends", "kolkata"]);

function editDistance(a, b) {
  const m = a.length, n = b.length;
  if (!m) return n;
  if (!n) return m;
  let prev = Array.from({ length: n + 1 }, (_, j) => j);
  for (let i = 1; i <= m; i++) {
    const cur = [i];
    for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    prev = cur;
  }
  return prev[n];
}

/** Which of the known places a message names, forgiving small spelling slips (mandarmoni = Mandarmani). */
function matchAskDestinations(text, names) {
  const norm = (s) => String(s).toLowerCase().replace(/[^a-z]/g, "");
  const words = String(text).toLowerCase().split(/[^a-z]+/).filter(Boolean);
  const hay = norm(text);
  const found = [];
  for (const name of names || []) {
    const n = norm(name);
    if (!n || found.includes(name)) continue;
    let ok = n.length >= 7 ? hay.includes(n) : words.includes(n);
    if (!ok) {
      const tol = n.length >= 8 ? 2 : n.length >= 5 ? 1 : 0;
      if (tol) ok = words.some((w) => w.length >= 4 && Math.abs(w.length - n.length) <= tol && editDistance(w, n) <= tol);
    }
    if (ok) found.push(name);
  }
  return found;
}

/** Dates written out in the message (2026-11-13, 13 Nov, Nov 13th) as ISO dates, in the future. */
function parseAskDates(t, nowMs) {
  const today = toISODate(new Date(nowMs));
  const year = new Date(nowMs).getFullYear();
  const out = [];
  const push = (y, m, d) => {
    if (m < 1 || m > 12 || d < 1 || d > 31) return;
    let iso = `${y}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
    if (iso < today && y === year) iso = `${y + 1}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
    if (!out.includes(iso)) out.push(iso);
  };
  for (const m of t.matchAll(/\b(\d{4})-(\d{2})-(\d{2})\b/g)) push(+m[1], +m[2], +m[3]);
  const mon = ASK_MONTHS.join("|");
  for (const m of t.matchAll(new RegExp(`\\b(\\d{1,2})(?:st|nd|rd|th)?\\s*(?:of\\s+)?(${mon})[a-z]*\\b`, "g"))) push(year, ASK_MONTHS.indexOf(m[2]) + 1, +m[1]);
  for (const m of t.matchAll(new RegExp(`\\b(${mon})[a-z]*\\s+(\\d{1,2})(?:st|nd|rd|th)?\\b`, "g"))) push(year, ASK_MONTHS.indexOf(m[1]) + 1, +m[2]);
  return out;
}

/** The holiday windows the message asks to avoid ("not during diwali", "avoid holidays"). */
function askedExclusions(t, windows) {
  const neg = "(?:no|skip|avoid|not|without|except|excluding|exclude|don'?t|dont|never|nothing)";
  const hit = [];
  for (const w of windows || []) {
    const tokens = String(w.name).toLowerCase().split(/[^a-z]+/).filter((x) => x.length >= 4 && !["weekend", "long", "and", "dates", "holiday"].includes(x));
    if (!tokens.length) continue;
    if (new RegExp(`\\b${neg}\\b(?:\\W+\\w+){0,5}?\\W+(?:${tokens.join("|")})\\b`).test(t)) hit.push(w.name);
  }
  const generic = new RegExp(`\\b${neg}\\b(?:\\W+\\w+){0,4}?\\W+(?:holiday|holidays|festival|festivals|puja|pujas|peak|crowds?|long weekends?)\\b`).test(t);
  return { names: hit, all: generic };
}

/**
 * ctx = {nowMs, destinations:[names], windows:[{from,to,name}], nights, checkinWeekday}
 * -> {isRequest, destinations, unknownPlace, weekends, skipped, mode, avoided}
 */
function parseTripRequest(text, ctx) {
  const t = String(text || "").toLowerCase().replace(/[’‘]/g, "'").replace(/[–—]/g, "-").trim();
  const nowMs = ctx.nowMs;
  const none = { isRequest: false, destinations: [], unknownPlace: null, weekends: [], skipped: [], mode: "none", avoided: [] };
  if (!t) return none;
  if (/^\/(start|stop|plan|budget|destinations|mywatches|unwatch|help)\b/.test(t)) return none;

  const destinations = matchAskDestinations(t, ctx.destinations);
  const explicitDates = parseAskDates(t, nowMs);
  const today = toISODate(new Date(nowMs));
  const nights = ctx.nights || 2, wd = ctx.checkinWeekday ?? 5;
  const W = upcomingWeekends(nights, wd, 80, new Date(nowMs));
  const weekendAfterToday = W.filter((w) => w.checkin > today);

  const cmd = /^\/(best|find|deals?|trip|where|search)\b/.test(t);
  const strong = /\b(best|cheapest|cheap|deals?|bargains?)\b/.test(t);
  const dealish = /\b(stay|stays|hotel|hotels|resort|resorts|price|prices|weekend|trip|plan|book|find|where|go|going|visit|recommend|suggest|show)\b/.test(t);
  // a bare month name ("in december"), but not "13 nov" / "nov 13", which are dates
  const tNoDates = t.replace(new RegExp(`\\b\\d{1,2}(?:st|nd|rd|th)?\\s*(?:of\\s+)?(?:${ASK_MONTHS.join("|")})[a-z]*\\b`, "g"), " ").replace(new RegExp(`\\b(?:${ASK_MONTHS.join("|")})[a-z]*\\s+\\d{1,2}(?:st|nd|rd|th)?\\b`, "g"), " ");
  const monthIdx = ASK_MONTHS.findIndex((m) => m === "may" ? /\bin may\b|\bmay\s+weekends?\b/.test(tNoDates) : new RegExp(`\\b${m}[a-z]*\\b`).test(tNoDates));
  const timeish = /\b(friday|fri|saturday|sat|sunday|sun|weekend|weekends|tonight|today|next|this|coming|upcoming)\b/.test(t) || explicitDates.length > 0 || monthIdx >= 0;
  let unknownPlace = null;
  if (!destinations.length) {
    const m = /\b(?:for|in|to|at|near|around)\s+([a-z]{3,}(?:\s+[a-z]{3,})?)/.exec(t);
    if (m) {
      const first = m[1].split(/\s+/)[0];
      if (!ASK_NOT_PLACES.has(first) && !ASK_MONTHS.some((x) => first.startsWith(x))) unknownPlace = m[1].split(/\s+/).filter((w) => !ASK_NOT_PLACES.has(w)).join(" ");
    }
  }
  const asksToAvoid = (() => { const e = askedExclusions(t, ctx.windows); return e.all || e.names.length > 0; })();
  const isRequest = cmd || strong || ((destinations.length > 0 || !!unknownPlace) && (dealish || timeish || asksToAvoid)) || (dealish && timeish);
  if (!isRequest) return none;

  // which weekend(s)
  let chosen = [];
  let mode = "any";
  const after = /\b(next\s+to\s+next|next\s+next|the\s+one\s+after|one\s+after|after\s+that|the\s+following|following\s+(?:weekend|friday)|(?:friday|weekend)\s+after|week\s+after|two\s+weeks|2\s+weeks)\b/.test(t);
  const hasNext = /\bnext\b/.test(t);
  const thisWk = /\b(?:this|coming)\s+(?:weekend|friday|fri|saturday|sat)\b|\btonight\b|\btoday\b/.test(t);
  if (explicitDates.length) {
    mode = "dates";
    for (const d of explicitDates) {
      const w = W.find((x) => d >= x.checkin && d <= x.checkout) || W.filter((x) => x.checkin <= d).pop();
      if (w && !chosen.some((c) => c.checkin === w.checkin)) chosen.push(w);
    }
  } else if (after) {
    mode = "after";
    const base = hasNext ? weekendAfterToday[0] : (W[0] && W[0].checkin >= today ? W[0] : weekendAfterToday[0]);
    const idx = W.findIndex((x) => base && x.checkin === base.checkin);
    chosen = idx >= 0 ? [W[idx], W[idx + 1]].filter(Boolean) : [];
  } else if (hasNext && !thisWk) {
    mode = "next";
    chosen = weekendAfterToday.slice(0, 1);
  } else if (thisWk) {
    mode = "this";
    chosen = W.slice(0, 1);
  } else if (monthIdx >= 0) {
    mode = "month";
    chosen = W.filter((w) => new Date(`${w.checkin}T00:00:00`).getMonth() === monthIdx).slice(0, 4);
  }
  if (!chosen.length) { mode = "any"; chosen = W.filter((w) => w.checkin >= today).slice(0, 4); }

  // holidays to avoid
  const ex = askedExclusions(t, ctx.windows);
  const skipped = [];
  const keep = [];
  const avoid = (w) => (ctx.windows || []).find((x) => (ex.all || ex.names.includes(x.name)) && w.checkin <= x.to && w.checkout >= x.from);
  for (const w of chosen) {
    const hit = avoid(w);
    if (hit) skipped.push({ ...w, holiday: hit.name }); else keep.push(w);
  }
  // Everything asked for was a holiday: offer the next clear weekends instead.
  if (!keep.length && skipped.length) {
    const lastAsked = skipped[skipped.length - 1].checkin;
    for (const w of W) {
      if (w.checkin <= lastAsked || avoid(w)) continue;
      keep.push(w);
      if (keep.length >= Math.max(1, Math.min(2, skipped.length))) break;
    }
  }
  return { isRequest: true, destinations, unknownPlace, weekends: keep.slice(0, 4), skipped, mode, avoided: ex.all ? ["holidays"] : ex.names };
}

function askHelpText(names) {
  return [
    "Ask me for the best stays in plain words, for example:",
    "• best deals Mandarmani next friday",
    "• Digha this weekend",
    "• cheapest weekend for Darjeeling in December",
    "• Mandarmani next friday or the one after, not Diwali",
    "• /best Puri 13 Nov",
    "",
    `Places I know: ${(names || []).join(", ") || "none yet"}.`,
    "I look at the prices already collected (they can be a few hours old), so check the price before you book.",
  ].join("\n");
}

/** The reply for a parsed request. groups = loadTrackedHotelGroups() output. ctx = {destinations, windows}. */
function answerTripRequest(groups, blocked, req, nowMs, ctx = {}) {
  const known = ctx.destinations || [];
  if (req.unknownPlace && !req.destinations.length) {
    return `I don't track "${req.unknownPlace}". Places I know: ${known.join(", ") || "none yet"}.\nTry: best deals ${known[0] || "Digha"} next friday`;
  }
  const build = (perWeekend) => {
    const L = [];
    const names = req.destinations.length ? req.destinations : null;
    const where = names ? names.join(" and ") : "all my places";
    const usable = (names ? groups.filter((g) => names.includes(g.destination)) : groups).filter((g) => !blocked.has(g.groupKey));
    L.push(`\u{1F50E} Best stays, ${where}`);
    for (const s of req.skipped) L.push(`Skipped ${niceStayDates(s.checkin, s.checkout)}: ${s.holiday}.`);
    if (req.skipped.length && !req.weekends.length) L.push("No other weekend in range is clear of those dates.");
    const summaries = [];
    for (const w of req.weekends) {
      const hol = typeof holidayFor === "function" ? holidayFor(w.checkin, w.checkout, ctx.windows || []) : null;
      L.push("", `\u{1F4C5} ${niceStayDates(w.checkin, w.checkout)}${hol ? ` · ${hol} dates` : ""}`);
      for (const dname of names || [null]) {
        const g2 = dname ? usable.filter((g) => g.destination === dname) : usable;
        const bp = bookPicks(g2, blocked, w.checkin, nowMs, { picksPerWeekend: names && names.length > 1 ? Math.min(2, perWeekend) : perWeekend });
        const cheap = cheapestByDestination(g2, blocked, w.checkin, {});
        let newest = 0;
        for (const g of g2) for (const d of g.dates || []) if (d.checkin === w.checkin && d.updatedAt) newest = Math.max(newest, new Date(d.updatedAt).getTime());
        if (dname && names.length > 1) L.push(`${dname}:`);
        if (!bp.picks.length) { L.push(dname ? `No checked prices for ${dname} on these dates yet.` : "No checked prices for these dates yet. Run a scan."); continue; }
        const label = { deal: "price drop", class: "cheap for its class", value: "good value" };
        bp.picks.forEach((p, i) => {
          L.push(`${i + 1}. ${p.hotelName}${p.tier ? ` (${p.tier}★)` : ""}  ${formatINR(p.price)}  [${label[p.kind]}]`);
          if (p.why.length) L.push(`   ${p.why.slice(0, 3).join(", ")}`);
          if (p.url) L.push(`   ${p.url}`);
        });
        const typical = cheap.length ? Math.round(medianOf(cheap.map((x) => x.typical))) : null;
        L.push(`Typical ${typical ? formatINR(typical) : "?"}, ${bp.priced} hotels priced${newest ? `, prices seen ${agoText(hoursAgo(new Date(newest).toISOString(), nowMs))}` : ""}.`);
        if (!names || names.length === 1) summaries.push({ w, typical });
      }
    }
    const priced = summaries.filter((s) => s.typical);
    if (priced.length > 1) {
      priced.sort((a, b) => a.typical - b.typical);
      const cheapest = priced[0], dearest = priced[priced.length - 1];
      const pct = Math.round(((dearest.typical - cheapest.typical) / dearest.typical) * 100);
      L.push("", pct >= 5 ? `\u{1F449} ${niceStayDates(cheapest.w.checkin, cheapest.w.checkout)} is the cheaper weekend: typical ${formatINR(cheapest.typical)} against ${formatINR(dearest.typical)} (${pct}% less).` : "\u{1F449} Both weekends are priced about the same.");
    }
    L.push("", "Prices change; check before you book.");
    return L.join("\n");
  };
  let text = build(3);
  if (text.length > 3800) text = build(2);
  if (text.length > 3800) text = build(1);
  return text.slice(0, 4000);
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { TODAY_DEFAULTS, MARKET_DEFAULTS, bookPicks, filmPicks, cheapestByDestination, healthChecks, buildToday, formatTodayDigest, stayFacts, marketDeals, marketDealReasons, stayContextLine, dayKindOf, buildDiagnostics, rareDealReference, parseTripRequest, answerTripRequest, askHelpText, matchAskDestinations };
}
