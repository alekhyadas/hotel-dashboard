@echo off
rem Double-click this on the OTHER computer, once. It asks for your GitHub repo
rem (username/repo-name) and then makes Windows check for extension updates every hour.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-auto-update.ps1" %*
echo.
pause
