<#
  One-time setup on a computer that runs a COPY of the extension folder:
  makes Windows run update-extension.ps1 every hour (and when you sign in), so
  this computer picks up every new version the main computer publishes.

  Easiest: double-click install-auto-update.cmd and type your GitHub repo when
  asked (the same "username/repo-name" as in the extension's Settings).

  Remove it again with:  install-auto-update.ps1 -Remove
#>
[CmdletBinding()]
param(
  [string]$Repo,
  [string]$Token,
  [string]$TaskName = "HotelDealExtensionAutoUpdate",
  [switch]$Remove,
  [switch]$DryRun
)

$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$updater = Join-Path $here "update-extension.ps1"
$configPath = Join-Path $here "update-config.json"

if ($Remove) {
  if ($DryRun) { Write-Output "Would remove the scheduled task $TaskName"; exit 0 }
  Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
  Write-Output "Removed the automatic update task ($TaskName)."
  exit 0
}

if (-not (Test-Path $updater)) { throw "update-extension.ps1 is not next to this script ($here)." }

if (-not $Repo -and (Test-Path $configPath)) {
  $existing = Get-Content -Raw -Path $configPath | ConvertFrom-Json
  if ($existing.repo) { $Repo = [string]$existing.repo; if (-not $Token -and $existing.token) { $Token = [string]$existing.token } }
}
if (-not $Repo) { $Repo = Read-Host "GitHub repo that holds the extension updates (username/repo-name)" }
$Repo = $Repo.Trim()
if ($Repo -notmatch '^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$') { throw "That does not look like username/repo-name: '$Repo'" }

# The simple per-user hourly task (schtasks.exe), used when Windows will not let
# a normal account register the fuller one. This is the documented /TR form:
# the whole command in quotes, the inner quotes escaped as \" .
function Get-SchtasksCommandLine {
  $tr = '\"powershell.exe\" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"' + $updater + '\"'
  return '/Create /SC HOURLY /MO 1 /TN "' + $TaskName + '" /TR "' + $tr + '" /F'
}

if ($DryRun) {
  Write-Output "Would save repo '$Repo' and create the hourly task $TaskName running $updater"
  Write-Output ("Fallback command: schtasks.exe " + (Get-SchtasksCommandLine))
  exit 0
}

@{ repo = $Repo; token = $Token } | ConvertTo-Json | Set-Content -Path $configPath -Encoding UTF8

$method = $null
try {
  # Run as the signed-in user only (no admin needed). The sign-in trigger must
  # name that user: without -User it means "anyone who signs in", which Windows
  # only allows for an administrator (that was the "Access is denied").
  $me = [Security.Principal.WindowsIdentity]::GetCurrent().Name
  $arg = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $updater + '"'
  $action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument $arg
  $everyHour = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(2) -RepetitionInterval (New-TimeSpan -Hours 1) -RepetitionDuration (New-TimeSpan -Days 3650)
  $atLogon = New-ScheduledTaskTrigger -AtLogOn -User $me
  $principal = New-ScheduledTaskPrincipal -UserId $me -LogonType Interactive -RunLevel Limited
  $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Minutes 10) -MultipleInstances IgnoreNew
  Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger @($everyHour, $atLogon) -Principal $principal -Settings $settings -Description "Updates the Weekend Resort Deal Tracker extension from GitHub every hour" -Force -ErrorAction Stop | Out-Null
  $method = "hourly and at sign-in"
} catch {
  Write-Output ("Windows would not create the full task (" + $_.Exception.Message.Trim() + "). Trying the simpler hourly task.")
  $p = Start-Process -FilePath "schtasks.exe" -ArgumentList (Get-SchtasksCommandLine) -Wait -PassThru -NoNewWindow
  if ($p.ExitCode -ne 0) { throw "Could not create the hourly task either (schtasks exit code $($p.ExitCode)). Right-click install-auto-update.cmd and choose Run as administrator, or ask me." }
  $method = "hourly"
}

Write-Output "Done. This computer will now check for extension updates every hour ($method)."
Write-Output "Checking once right now:"
& $updater
