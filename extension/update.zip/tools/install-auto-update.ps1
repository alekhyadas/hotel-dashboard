<#
  One-time setup on a computer that runs a COPY of the extension folder:
  makes Windows run update-extension.ps1 every hour (and when you sign in), so
  this computer picks up every new version the main computer publishes.

  Easiest: double-click install-auto-update.cmd and type your GitHub repo when
  asked (the same "username/repo-name" as in the extension's Settings).

  Remove it again with:  install-auto-update.ps1 -Remove
#>
[CmdletBinding()]
param(
  [string]$Repo,
  [string]$Token,
  [string]$TaskName = "HotelDealExtensionAutoUpdate",
  [switch]$Remove,
  [switch]$DryRun
)

$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$updater = Join-Path $here "update-extension.ps1"
$configPath = Join-Path $here "update-config.json"

if ($Remove) {
  if ($DryRun) { Write-Output "Would remove the scheduled task $TaskName"; exit 0 }
  Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false -ErrorAction SilentlyContinue
  Write-Output "Removed the automatic update task ($TaskName)."
  exit 0
}

if (-not (Test-Path $updater)) { throw "update-extension.ps1 is not next to this script ($here)." }

if (-not $Repo -and (Test-Path $configPath)) {
  $existing = Get-Content -Raw -Path $configPath | ConvertFrom-Json
  if ($existing.repo) { $Repo = [string]$existing.repo; if (-not $Token -and $existing.token) { $Token = [string]$existing.token } }
}
if (-not $Repo) { $Repo = Read-Host "GitHub repo that holds the extension updates (username/repo-name)" }
$Repo = $Repo.Trim()
if ($Repo -notmatch '^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$') { throw "That does not look like username/repo-name: '$Repo'" }

if ($DryRun) {
  Write-Output "Would save repo '$Repo' and create the hourly task $TaskName running $updater"
  exit 0
}

@{ repo = $Repo; token = $Token } | ConvertTo-Json | Set-Content -Path $configPath -Encoding UTF8

$arg = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $updater + '"'
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument $arg
$everyHour = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(2) -RepetitionInterval (New-TimeSpan -Hours 1) -RepetitionDuration (New-TimeSpan -Days 3650)
$atLogon = New-ScheduledTaskTrigger -AtLogOn
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Minutes 10) -MultipleInstances IgnoreNew
Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger @($everyHour, $atLogon) -Settings $settings -Description "Updates the Weekend Resort Deal Tracker extension from GitHub every hour" -Force | Out-Null

Write-Output "Done. This computer will now check for extension updates every hour."
Write-Output "Checking once right now:"
& $updater
