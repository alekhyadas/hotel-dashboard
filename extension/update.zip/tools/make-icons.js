/**
 * Discount hotel mark: an ivory hotel and gold percentage badge on deep green.
 * Code-native artwork, supersampled for crisp toolbar and favicon sizes.
 * Run: node tools/make-icons.js (PNGs, multi-size ICO, SVG, public favicon).
 */
const fs = require("fs");
const path = require("path");
const zlib = require("zlib");

const crcTable = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; }
  return t;
})();
const crc32 = (buf) => { let c = 0xffffffff; for (const b of buf) c = crcTable[(c ^ b) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
function chunk(type, data) {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
  const td = Buffer.concat([Buffer.from(type), data]);
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td));
  return Buffer.concat([len, td, crc]);
}
function png(size, rgba) {
  const raw = Buffer.alloc((size * 4 + 1) * size);
  for (let y = 0; y < size; y++) { raw[y * (size * 4 + 1)] = 0; rgba.copy(raw, y * (size * 4 + 1) + 1, y * size * 4, (y + 1) * size * 4); }
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(size, 0); ihdr.writeUInt32BE(size, 4); ihdr[8] = 8; ihdr[9] = 6;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk("IHDR", ihdr), chunk("IDAT", zlib.deflateSync(raw)), chunk("IEND", Buffer.alloc(0))]);
}

const rect = (x, y, x0, y0, x1, y1) => x >= x0 && x <= x1 && y >= y0 && y <= y1;
function roundedRect(x, y, r) {
  const cx = Math.min(Math.max(x, r), 1 - r), cy = Math.min(Math.max(y, r), 1 - r);
  return (x - cx) ** 2 + (y - cy) ** 2 <= r * r;
}
const mix = (a, b, t) => a.map((v, i) => Math.round(v + (b[i] - v) * t));
const circle = (x, y, cx, cy, r) => (x - cx) ** 2 + (y - cy) ** 2 <= r * r;
function line(x, y, ax, ay, bx, by, width) {
  const t = Math.min(1, Math.max(0, ((x - ax) * (bx - ax) + (y - ay) * (by - ay)) / ((bx - ax) ** 2 + (by - ay) ** 2)));
  return (x - ax - t * (bx - ax)) ** 2 + (y - ay - t * (by - ay)) ** 2 <= (width / 2) ** 2;
}

/** Colour at a point of the unit square, or null where transparent. */
function sample(x, y) {
  if (!roundedRect(x, y, 0.22)) return null;
  const bg = mix([37, 92, 72], [17, 48, 40], y);
  const ivory = [250, 248, 234], ink = [24, 63, 49], gold = [255, 197, 81];
  // Badge first, so it overlaps the hotel without merging into its windows.
  if (circle(x, y, .735, .695, .225)) {
    if (!circle(x, y, .735, .695, .199)) return bg;
    if (circle(x, y, .668, .629, .027) || circle(x, y, .802, .761, .027) || line(x, y, .674, .783, .796, .607, .031)) return ink;
    return gold;
  }
  // A generous silhouette and six windows, legible even at 16 px.
  for (const wx of [.27, .445]) for (const wy of [.32, .46, .60]) if (rect(x, y, wx, wy, wx + .09, wy + .073)) return ink;
  if (rect(x, y, .345, .71, .455, .82)) return ink;
  if (rect(x, y, .19, .265, .615, .815)) return ivory;
  if (rect(x, y, .175, .205, .63, .26)) return ivory;
  if (rect(x, y, .145, .815, .64, .85)) return ivory;
  return bg;
}

function render(size) {
  const ss = 8, out = Buffer.alloc(size * size * 4);
  for (let py = 0; py < size; py++) for (let px = 0; px < size; px++) {
    let r = 0, g = 0, b = 0, a = 0;
    for (let sy = 0; sy < ss; sy++) for (let sx = 0; sx < ss; sx++) {
      const c = sample((px + (sx + 0.5) / ss) / size, (py + (sy + 0.5) / ss) / size);
      if (c) { r += c[0]; g += c[1]; b += c[2]; a++; }
    }
    const i = (py * size + px) * 4;
    if (a) { out[i] = Math.round(r / a); out[i + 1] = Math.round(g / a); out[i + 2] = Math.round(b / a); out[i + 3] = Math.round((a / (ss * ss)) * 255); }
  }
  return out;
}

const dir = path.join(__dirname, "..", "icons");
fs.mkdirSync(dir, { recursive: true });
const rendered = new Map();
for (const size of [16, 32, 48, 128]) {
  const data = png(size, render(size)); rendered.set(size, data);
  fs.writeFileSync(path.join(dir, `icon${size}.png`), data);
  console.log("wrote", `icon${size}.png`);
}
// A real ICO directory containing lossless PNG frames at common favicon sizes.
const sizes = [16, 32, 48], header = Buffer.alloc(6 + sizes.length * 16);
header.writeUInt16LE(1, 2); header.writeUInt16LE(sizes.length, 4);
let offset = header.length;
sizes.forEach((size, i) => {
  const start = 6 + i * 16, data = rendered.get(size);
  header[start] = size; header[start + 1] = size;
  header.writeUInt16LE(1, start + 4); header.writeUInt16LE(32, start + 6);
  header.writeUInt32LE(data.length, start + 8); header.writeUInt32LE(offset, start + 12);
  offset += data.length;
});
fs.writeFileSync(path.join(dir, "favicon.ico"), Buffer.concat([header, ...sizes.map((s) => rendered.get(s))]));
const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" role="img" aria-label="Discount hotel"><defs><linearGradient id="g" x2="0" y2="1"><stop stop-color="#255c48"/><stop offset="1" stop-color="#113028"/></linearGradient></defs><rect width="128" height="128" rx="28" fill="url(#g)"/><path d="M22.4 26.2h58.2v7H22.4zM24.3 33.9h54.4v70.4H24.3zM18.6 104.3H82v4.5H18.6z" fill="#faf8ea"/><path d="M34.6 41h11.5v9.3H34.6zm22.4 0h11.5v9.3H57zM34.6 58.9h11.5v9.3H34.6zm22.4 0h11.5v9.3H57zM34.6 76.8h11.5v9.3H34.6zm22.4 0h11.5v9.3H57zM44.2 90.9h14.1V105H44.2z" fill="#183f31"/><circle cx="94.1" cy="89" r="28.8" fill="#163e31"/><circle cx="94.1" cy="89" r="25.5" fill="#ffc551"/><g fill="#183f31"><circle cx="85.5" cy="80.5" r="3.5"/><circle cx="102.7" cy="97.4" r="3.5"/></g><path d="m86.3 100.2 15.6-22.5" stroke="#183f31" stroke-width="4" stroke-linecap="round"/></svg>`;
fs.writeFileSync(path.join(dir, "hotel-discount.svg"), svg + "\n");
// The public dashboard is a single HTML file; embed its favicon so no missing
// GitHub Pages image upload or external icon service can break it.
const publicPath = path.join(__dirname, "..", "live-dashboard.html");
let html = fs.readFileSync(publicPath, "utf8");
const link = `<link rel="icon" type="image/png" sizes="32x32" href="data:image/png;base64,${rendered.get(32).toString("base64")}" data-hotel-favicon />`;
html = /<link\b[^>]*data-hotel-favicon[^>]*>/i.test(html) ? html.replace(/<link\b[^>]*data-hotel-favicon[^>]*>/i, link) : html.replace(/(<title>[^<]*<\/title>)/i, "$1\n" + link);
fs.writeFileSync(publicPath, html);
console.log("wrote favicon.ico, hotel-discount.svg and embedded public favicon");
