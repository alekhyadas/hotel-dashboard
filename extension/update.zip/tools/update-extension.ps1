<#
  Keeps this computer's copy of the Weekend Resort Deal Tracker up to date.

  The main computer publishes extension/update.zip and extension/version.json to
  your GitHub repo. This script (run every hour by a Windows scheduled task, see
  install-auto-update.ps1) checks version.json, and when it is newer than the
  manifest.json in this folder it downloads the zip, checks it, and copies the
  files over this folder. manifest.json is copied LAST: the extension notices a
  new manifest within about 30 seconds and reloads itself, and never in the
  middle of a scan.

  Safe to run by hand any time:
    powershell -ExecutionPolicy Bypass -File update-extension.ps1

  Settings live in update-config.json next to this script (written by the
  installer): {"repo": "username/repo-name", "token": ""}. The token is only
  needed if the repo is private. Nothing is ever uploaded from this computer.
#>
[CmdletBinding()]
param(
  [string]$Repo,
  [string]$Token,
  [string]$ApiBase = "https://api.github.com",
  [string]$ExtensionDir
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $ExtensionDir) { $ExtensionDir = Split-Path -Parent $here }
$configPath = Join-Path $here "update-config.json"
$logPath = Join-Path $here "update.log"

function Write-Log([string]$Message) {
  $line = "{0}  {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Message
  Write-Output $line
  try {
    Add-Content -Path $logPath -Value $line -Encoding UTF8
    $all = Get-Content -Path $logPath -ErrorAction SilentlyContinue
    if ($all -and $all.Count -gt 300) { $all | Select-Object -Last 150 | Set-Content -Path $logPath -Encoding UTF8 }
  } catch { }
}

function Get-Remote([string]$RelPath, [string]$OutFile) {
  $headers = @{ Accept = "application/vnd.github.raw+json"; "User-Agent" = "hotel-deal-extension-updater" }
  if ($Token) { $headers["Authorization"] = "Bearer $Token" }
  Invoke-WebRequest -Uri "$ApiBase/repos/$Repo/contents/$RelPath" -Headers $headers -OutFile $OutFile -UseBasicParsing | Out-Null
}

$work = Join-Path ([IO.Path]::GetTempPath()) ("hotel-ext-update-" + [Guid]::NewGuid().ToString("N"))
try {
  if (Test-Path $configPath) {
    $cfg = Get-Content -Raw -Path $configPath | ConvertFrom-Json
    if (-not $Repo -and $cfg.repo) { $Repo = [string]$cfg.repo }
    if (-not $Token -and $cfg.token) { $Token = [string]$cfg.token }
  }
  if (-not $Repo) { throw "No repo set. Run install-auto-update.ps1 first (or pass -Repo username/repo-name)." }

  $localManifestPath = Join-Path $ExtensionDir "manifest.json"
  if (-not (Test-Path $localManifestPath)) { throw "No manifest.json in $ExtensionDir, is this the extension folder?" }
  $localVersion = [version](Get-Content -Raw -Path $localManifestPath | ConvertFrom-Json).version

  New-Item -ItemType Directory -Path $work -Force | Out-Null

  $versionFile = Join-Path $work "version.json"
  try {
    Get-Remote "extension/version.json" $versionFile
  } catch {
    $code = $null
    if ($_.Exception.Response) { $code = [int]$_.Exception.Response.StatusCode }
    if ($code -eq 404) { Write-Log "Nothing published yet (no extension/version.json in $Repo). Is the main computer set up and has it run?"; exit 0 }
    throw
  }
  $remote = [IO.File]::ReadAllText($versionFile, [Text.Encoding]::UTF8) | ConvertFrom-Json
  $remoteVersion = [version]$remote.version

  if ($remoteVersion -le $localVersion) {
    Write-Log "Already up to date (this computer $localVersion, published $remoteVersion)."
    exit 0
  }

  Write-Log "New version $remoteVersion published (this computer has $localVersion). Downloading."
  $zipFile = Join-Path $work "update.zip"
  Get-Remote "extension/update.zip" $zipFile

  if ($remote.sha256) {
    # Use .NET directly: Get-FileHash is unavailable on some stripped-down
    # PowerShell installations. The SHA-256 check remains mandatory.
    $hashAlgorithm = [Security.Cryptography.SHA256]::Create()
    $hashStream = [IO.File]::OpenRead($zipFile)
    try { $actual = [BitConverter]::ToString($hashAlgorithm.ComputeHash($hashStream)).Replace('-', '').ToLowerInvariant() }
    finally { $hashStream.Dispose(); $hashAlgorithm.Dispose() }
    if ($actual -ne ([string]$remote.sha256).ToLower()) { throw "Downloaded zip does not match its checksum (got $actual). Not installing." }
  }

  Add-Type -AssemblyName System.IO.Compression.FileSystem
  $extract = Join-Path $work "files"
  [IO.Compression.ZipFile]::ExtractToDirectory($zipFile, $extract)

  $newManifestPath = Join-Path $extract "manifest.json"
  if (-not (Test-Path $newManifestPath)) { throw "The zip has no manifest.json. Not installing." }
  $newManifest = Get-Content -Raw -Path $newManifestPath | ConvertFrom-Json
  if ($newManifest.manifest_version -ne 3 -or [version]$newManifest.version -ne $remoteVersion) {
    throw "The zip's manifest ($($newManifest.version)) does not match version.json ($remoteVersion). Not installing."
  }
  foreach ($need in @($newManifest.background.service_worker, $newManifest.action.default_popup)) {
    if ($need -and -not (Test-Path (Join-Path $extract $need))) { throw "The zip is missing $need. Not installing." }
  }

  # Everything except manifest.json first, then manifest.json, so the extension
  # only reloads once all the files it needs are already in place.
  $root = (Resolve-Path $extract).Path.TrimEnd('\')
  $copied = 0
  Get-ChildItem -Path $extract -Recurse -File | Where-Object { $_.FullName -ne (Resolve-Path $newManifestPath).Path } | ForEach-Object {
    $rel = $_.FullName.Substring($root.Length + 1)
    $dest = Join-Path $ExtensionDir $rel
    New-Item -ItemType Directory -Path (Split-Path -Parent $dest) -Force | Out-Null
    Copy-Item -Path $_.FullName -Destination $dest -Force
    $copied++
  }
  Copy-Item -Path $newManifestPath -Destination $localManifestPath -Force
  $copied++

  Write-Log "Updated $localVersion -> $remoteVersion ($copied files). Chrome reloads the extension by itself within about a minute."
  exit 0
} catch {
  Write-Log ("Update check failed: " + $_.Exception.Message)
  exit 1
} finally {
  if (Test-Path -LiteralPath $work) {
    $cleanupTarget = [IO.Path]::GetFullPath($work)
    $cleanupRoot = [IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\') + '\'
    if ($cleanupTarget.StartsWith($cleanupRoot, [StringComparison]::OrdinalIgnoreCase) -and
        [IO.Path]::GetFileName($cleanupTarget) -match '^hotel-ext-update-[a-f0-9]{32}$') {
      Remove-Item -LiteralPath $cleanupTarget -Recurse -Force -ErrorAction SilentlyContinue
    }
  }
}
