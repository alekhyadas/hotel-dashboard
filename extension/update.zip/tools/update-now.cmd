@echo off
rem Double-click this on ANY computer to install the newest extension version right now
rem (instead of waiting for the hourly update). The extension reloads itself within about 30 seconds.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0update-extension.ps1" %*
echo.
pause
