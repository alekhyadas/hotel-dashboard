/* Additive worker services for Plan & verify. Durable jobs survive MV3 suspension.
 * Private notes, budgets and outcomes never enter GitHub's public snapshots. */
var TripWorker = (() => {
  "use strict";
  let serial = Promise.resolve(), ticking = false;
  const locked = (fn) => { const p = serial.then(fn, fn); serial = p.catch(() => {}); return p; };
  const getWorkspace = async () => (await chrome.storage.local.get("tripWorkspace")).tripWorkspace || {};
  const allOffers = async () => {
    const all = await chrome.storage.local.get(null);
    const hidden = new Set((all.blockedHotels || []).map(groupKeyOf));
    return TripTools.offers(all, all.tripWorkspace).filter((o) => !hidden.has(o.groupKey));
  };
  async function saveWorkspace(patch) {
    if (patch.preferences) {
      const p = patch.preferences;
      if (!Array.isArray(p.required) || p.required.length > 20 || p.required.some((s) => typeof s !== "string" || s.length > 80)) throw new Error("Use at most 20 short amenity names.");
      if (![p.minRating, p.minReviews, p.maxTravelHours].every(Number.isFinite) || p.minRating < 0 || p.minRating > 5 || p.minReviews < 0 || p.minReviews > 1000000 || p.maxTravelHours < 0 || p.maxTravelHours > 168) throw new Error("Check the rating, reviews and travel-time requirements.");
    }
    if (patch.budget) {
      const b = patch.budget;
      if (![b.maxTotal, b.guests, b.transport, b.foodPerPersonDay, b.extras].every((n) => Number.isFinite(n) && n >= 0 && n <= 10000000) || !Number.isInteger(b.guests) || b.guests < 1 || b.guests > 30) throw new Error("Enter a valid budget and 1–30 people.");
    }
    if (patch.route) {
      const r = patch.route;
      if (!Array.isArray(r.ids) || r.ids.length > 7 || r.ids.some((id) => typeof id !== "string" || id.length > 1500) || !Array.isArray(r.legs) || r.legs.length > 6 || r.legs.some((l) => !(l.hours === null || Number.isFinite(l.hours) && l.hours >= 0 && l.hours <= 72) || !Number.isFinite(l.cost) || l.cost < 0 || l.cost > 1000000)) throw new Error("Use up to seven stays and valid travel estimates.");
    }
    return locked(async () => {
      const w = await getWorkspace();
      for (const k of ["preferences", "budget", "route"]) if (Object.hasOwn(patch, k)) w[k] = patch[k];
      await chrome.storage.local.set({ tripWorkspace: w });
      return { ok: true };
    });
  }
  async function noteOffer(id, patch) {
    const o = (await allOffers()).find((o) => o.id === id);
    if (!o) throw new Error("This stay is no longer tracked. Refresh the page.");
    return locked(async () => {
      const w = await getWorkspace();
      w.properties ||= {};
      const prior = w.properties[o.propertyId] || {};
      const allowed = {};
      if (patch.notes !== undefined) allowed.notes = String(patch.notes).slice(0, 3000);
      if (patch.address !== undefined) allowed.address = String(patch.address).slice(0, 300);
      if (patch.providerUrl !== undefined) {
        const url = TripTools.safeUrl(patch.providerUrl);
        if (patch.providerUrl && !url) throw new Error("Use a public HTTPS booking-page URL.");
        allowed.providerUrls = { ...(prior.providerUrls || {}), [id]: url };
      }
      if (patch.travelHours !== undefined) {
        const n = patch.travelHours === "" || patch.travelHours === null ? null : Number(patch.travelHours);
        if (n !== null && (!Number.isFinite(n) || n < 0 || n > 168)) throw new Error("Travel time must be between 0 and 168 hours.");
        allowed.travelHours = n;
      }
      if (patch.facts) {
        allowed.facts = { ...(prior.facts || {}) };
        for (const k of ["pool", "parking", "balcony", "wifi", "filmingPermission", "quietRecording", "roomView", "renovation"]) {
          if (Object.hasOwn(patch.facts, k) && [true, false, null].includes(patch.facts[k])) allowed.facts[k] = patch.facts[k];
        }
      }
      if (patch.review) {
        const r = patch.review;
        if (!TripTools.validDate(r.at) || r.at > TripTools.day() || !TripTools.safeUrl(r.url) || !String(r.text || "").trim()) throw new Error("Add review text, its actual date, and a public HTTPS source link.");
        const review = { text: String(r.text).slice(0, 1000), at: r.at, url: TripTools.safeUrl(r.url), author: String(r.author || "").slice(0, 100) };
        allowed.reviews = [...(prior.reviews || []), review].slice(-30);
      }
      if (patch.removeReview !== undefined) allowed.reviews = (prior.reviews || []).filter((_, i) => i !== Number(patch.removeReview));
      w.properties[o.propertyId] = { ...prior, ...allowed, updatedAt: new Date().toISOString() };
      await chrome.storage.local.set({ tripWorkspace: w });
      return { ok: true };
    });
  }
  async function alias(groups, unlink = false) {
    const list = await allOffers();
    const selected = [...new Map(list.filter((o) => groups.includes(o.groupKey)).map((o) => [o.groupKey, o])).values()];
    if (selected.length < (unlink ? 1 : 2) || selected.length > 8) throw new Error("Select at least two properties to link, or one to unlink.");
    if (!unlink && new Set(selected.map((o) => TripTools.norm(o.destination))).size !== 1) throw new Error("Only link properties in the same destination.");
    return locked(async () => {
      const w = await getWorkspace(); w.aliases ||= {}; w.properties ||= {};
      const canonical = selected[0].propertyId;
      const oldIds = new Set(selected.map((o) => o.propertyId));
      if (unlink) {
        for (const o of selected) {
          delete w.aliases[o.groupKey];
          for (const outcome of w.outcomes || []) if (outcome.groupKey === o.groupKey) outcome.propertyId = o.groupKey;
        }
      }
      else {
        // Re-link the full sets, so correcting one match cannot split an existing set silently.
        for (const [key, id] of Object.entries(w.aliases)) if (oldIds.has(id)) w.aliases[key] = canonical;
        for (const o of selected) w.aliases[o.groupKey] = canonical;
        for (const outcome of w.outcomes || []) if (oldIds.has(outcome.propertyId)) outcome.propertyId = canonical;
        // Preserve each source's notes when profiles are joined, without inventing shared facts.
        const notes = selected.map((o) => w.properties[o.propertyId]?.notes).filter(Boolean);
        const reviews = selected.flatMap((o) => w.properties[o.propertyId]?.reviews || []);
        const profiles = selected.map((o) => w.properties[o.propertyId] || {}), facts = {};
        for (const key of new Set(profiles.flatMap((p) => Object.keys(p.facts || {})))) {
          const values = [...new Set(profiles.map((p) => p.facts?.[key]).filter((v) => v === true || v === false))];
          facts[key] = values.length === 1 ? values[0] : null;
        }
        w.properties[canonical] = { ...(w.properties[canonical] || {}), facts,
          providerUrls: Object.assign({}, ...profiles.map((p) => p.providerUrls || {})),
          notes: [...new Set(notes)].join("\n\n").slice(0, 6000), reviews: [...new Map(reviews.map((r) => [JSON.stringify(r), r])).values()].slice(-30) };
      }
      await chrome.storage.local.set({ tripWorkspace: w }); return { ok: true };
    });
  }
  async function outcome(id, type) {
    if (!["booked", "wrong_price", "great_stay", "would_not_return", "clear"].includes(type)) throw new Error("Unknown feedback type.");
    const o = (await allOffers()).find((o) => o.id === id);
    if (!o) throw new Error("Stay not found.");
    return locked(async () => {
      const w = await getWorkspace();
      w.outcomes = (w.outcomes || []).filter((x) => type === "clear" ? x.propertyId !== o.propertyId : !(x.offerId === id && x.type === type));
      if (type !== "clear") w.outcomes.push({ offerId: id, groupKey: o.groupKey, propertyId: o.propertyId, type, price: o.price, at: new Date().toISOString() });
      w.outcomes = w.outcomes.slice(-1000);
      await chrome.storage.local.set({ tripWorkspace: w }); return { ok: true };
    });
  }
  async function saveQuote(id, data) {
    const o = (await allOffers()).find((o) => o.id === id);
    if (!o) throw new Error("Stay no longer tracked.");
    const number = (v, min, max, label, integer = false) => { const n = Number(v); if (!Number.isFinite(n) || n < min || n > max || integer && !Number.isInteger(n)) throw new Error(`Invalid ${label}.`); return n; };
    const url = TripTools.safeUrl(data.url);
    if (!url || !String(data.roomType || "").trim()) throw new Error("Add the room type and the booking source URL you checked.");
    if (!["breakfast", "room_only", "unknown"].includes(data.meal) || !["free", "non_refundable", "unknown"].includes(data.cancellation)) throw new Error("Invalid room conditions.");
    const quote = { v: 1, currency: "INR", basis: o.quote?.basis || "unknown", base: o.price,
      total: data.total === "" ? null : number(data.total, 300, 10000000, "stay total"),
      roomType: String(data.roomType).trim().slice(0, 120), adults: number(data.adults, 1, 30, "adults", true),
      children: number(data.children, 0, 20, "children", true), rooms: number(data.rooms, 1, 20, "rooms", true),
      meal: data.meal, cancellation: data.cancellation, cancellationDeadline: String(data.cancellationDeadline || "").slice(0, 100) || null,
      checkin: o.checkin, checkout: o.checkout, userObserved: true, sourceUrl: url, evidence: ["Room conditions entered by you from the linked booking page."] };
    return locked(async () => {
      const w = await getWorkspace(); w.manualQuotes ||= {};
      w.manualQuotes[id] = { quote, observedPriceAt: o.updatedAt, at: new Date().toISOString() };
      w.manualQuotes = Object.fromEntries(Object.entries(w.manualQuotes).sort((a, b) => b[1].at.localeCompare(a[1].at)).slice(0, 1000));
      await chrome.storage.local.set({ tripWorkspace: w }); return { ok: true };
    });
  }
  async function saveWatches(data) {
    const s = await getSettings();
    const names = (s.destinations || []).map((d) => d.name);
    const known = new Set(names);
    const positive = (v, min, max, label) => { const n = Number(v); if (!Number.isInteger(n) || n < min || n > max) throw new Error(`${label}: enter ${min}–${max}.`); return n; };
    for (const key of ["tripWatch", "skyscannerWatch"]) {
      const d = data[key]; if (!d) continue;
      if (!Array.isArray(d.destinations) || d.destinations.some((n) => !known.has(n))) throw new Error("Select known destinations.");
      if (!TripTools.validDate(d.until) || d.enabled && (d.until < TripTools.day() || d.until > TripTools.addDays(TripTools.day(), 366))) throw new Error("Enabled watch end dates must be within the next year.");
      const weekdays = [...new Set(d.weekdays.map(Number))];
      if (d.enabled && !weekdays.length || weekdays.some((n) => !Number.isInteger(n) || n < 0 || n > 6)) throw new Error("Choose at least one valid weekday for each enabled watch.");
      s[key] = { ...(s[key] || {}), enabled: !!d.enabled, destinations: d.destinations, until: d.until, weekdays };
      if (key === "skyscannerWatch") {
        const ids = {};
        for (const [name, id] of Object.entries(d.entityIds || {})) {
          if (!known.has(name) || !/^\d{3,20}$/.test(String(id))) throw new Error("Skyscanner place IDs must be numbers for known destinations.");
          ids[name] = String(id);
        }
        s[key].entityIds = { ...(s[key].entityIds || {}), ...ids };
        if (s[key].enabled && s[key].destinations.some((n) => !s[key].entityIds[n])) throw new Error("Add a Skyscanner entity ID for each watched destination.");
      }
    }
    const brandNames = [...new Set(String(data.brandNames || "").split(/\n|,/).map((n) => n.trim()).filter(Boolean))];
    if (brandNames.some((n) => n.length < 3 || n.length > 100) || brandNames.length > 30) throw new Error("Use up to 30 brand names, each 3–100 characters.");
    if (data.brandEnabled && !brandNames.length) throw new Error("Enter a brand name or switch brand watch off.");
    s.brandWatch = { ...(s.brandWatch || {}), enabled: !!data.brandEnabled, names: brandNames, refreshDays: positive(data.brandDays, 1, 90, "Brand lookahead") };
    await saveSettings(s);
    return { ok: true };
  }
  // Self-contained function, executed only in a user-opened verification tab with explicit host access.
  function readBookingPage() {
    const text = (document.body?.innerText || "").slice(0, 60000);
    const blocked = /verify (?:that )?you are human|captcha|access denied|unusual traffic|press (?:and|&) hold/i.test(text.slice(0, 2500));
    const params = new URLSearchParams(location.search);
    const date = (v) => /^\d{4}-\d{2}-\d{2}$/.test(v || "") ? v : null;
    const typeHas = (obj, types) => [].concat(obj?.["@type"] || []).some((t) => types.includes(t));
    const nodes = [];
    function walk(x, depth = 0) {
      if (!x || typeof x !== "object" || depth > 12 || nodes.length > 400) return;
      if (Array.isArray(x)) { x.forEach((v) => walk(v, depth + 1)); return; }
      nodes.push(x); for (const v of Object.values(x)) if (v && typeof v === "object") walk(v, depth + 1);
    }
    for (const script of document.querySelectorAll('script[type="application/ld+json"]')) { try { walk(JSON.parse(script.textContent)); } catch (_) {} }
    const hotel = nodes.find((n) => typeHas(n, ["Hotel", "Resort", "LodgingBusiness"]));
    const room = nodes.find((n) => typeHas(n, ["HotelRoom", "Room"]) && n.offers);
    const offer = room ? [].concat(room.offers || []).find((n) => n && typeof n === "object" && n.priceCurrency === "INR") : null;
    const heading = document.querySelector("h1")?.innerText || hotel?.name || "";
    const occupancy = params.get("roomStayQualifier")?.match(/^(\d+)e(\d+)e$/);
    return { url: location.href, hotelName: heading, blocked, text: room ? `${room.name ? "Room type: " + room.name + "\n" : ""}${String(offer?.description || "")}` : "",
      structuredPrice: offer && Number(offer.price) >= 300 ? Number(offer.price) : null,
      availability: /(?:\/|^)(?:InStock|LimitedAvailability|OnlineOnly)$/.test(String(offer?.availability || "")) ? true : /(?:\/|^)(?:SoldOut|OutOfStock|Discontinued)$/.test(String(offer?.availability || "")) ? false : null,
      checkin: date(params.get("checkin") || params.get("check_in") || params.get("checkin_date")),
      checkout: date(params.get("checkout") || params.get("check_out") || params.get("checkout_date")),
      adults: Number(params.get("adults") || params.get("adult") || occupancy?.[1]) || null,
      children: occupancy ? Number(occupancy[2]) : params.has("children") && /^\d+$/.test(params.get("children")) ? Number(params.get("children")) : null,
      rooms: Number(params.get("rooms") || params.get("room")) || (occupancy ? 1 : null),
      // Do not conflate a site's aggregate lowest price with an identified room offer.
      hasRoom: !!room, status: document.readyState,
    };
  }
  async function verify(id, override) {
    const o = (await allOffers()).find((o) => o.id === id);
    if (!o || o.checkin < TripTools.day()) throw new Error("Choose an upcoming tracked stay.");
    const raw = override || o.url, url = TripTools.safeUrl(raw);
    if (!url) throw new Error("Add the actual booking offer URL in this stay's notes first.");
    const u = new URL(url);
    if (/^(www\.)?makemytrip\.com$/.test(u.hostname)) {
      u.searchParams.set("checkin", formatDateAs(o.checkin, MMT_DATE_FORMATS[0]));
      u.searchParams.set("checkout", formatDateAs(o.checkout, MMT_DATE_FORMATS[0]));
    }
    const origin = u.origin + "/*";
    if (!await chrome.permissions.contains({ origins: [origin] })) throw new Error("Allow this booking site's access using Verify now.");
    return locked(async () => {
      const { tripVerifyJobs = {} } = await chrome.storage.local.get("tripVerifyJobs");
      if (Object.values(tripVerifyJobs).some((j) => j.offer.id === id && Date.now() - j.startedAt < 120000)) return { ok: true, message: "A verification tab is already open for this stay." };
      if (Object.keys(tripVerifyJobs).length >= 3) throw new Error("Finish or close an existing verification tab first (maximum 3).");
      const tab = await chrome.tabs.create({ url: u.href, active: true });
      tripVerifyJobs[tab.id] = { offer: { ...o, history: [] }, startedAt: Date.now() };
      await chrome.storage.local.set({ tripVerifyJobs });
      await chrome.alarms.create("tripVerify", { delayInMinutes: 0.5 });
      return { ok: true, message: "Booking tab opened. Leave it open; the result appears here within a minute. No booking is made." };
    });
  }
  async function checkJobs() {
    return locked(async () => {
      const { tripVerifyJobs = {}, tripVerifications = {} } = await chrome.storage.local.get(["tripVerifyJobs", "tripVerifications"]);
      let pending = false;
      for (const [tabId, j] of Object.entries(tripVerifyJobs)) {
        let result = null;
        try {
          const tab = await chrome.tabs.get(Number(tabId));
          if (Date.now() - j.startedAt < 10000 || tab.status !== "complete" && Date.now() - j.startedAt < 90000) { pending = true; continue; }
          const url = TripTools.safeUrl(tab.url);
          if (!url || !await chrome.permissions.contains({ origins: [new URL(url).origin + "/*"] })) throw new Error("The booking page redirected to a site without access. Check it manually.");
          const values = await chrome.scripting.executeScript({ target: { tabId: Number(tabId) }, func: readBookingPage });
          result = values[0]?.result;
          if (result) {
            if (/^(www\.)?makemytrip\.com$/.test(new URL(result.url).hostname)) {
              const dates = mmtDatesFromUrl(new URL(result.url).search);
              if (dates) Object.assign(result, dates);
            }
            result.quote = result.hasRoom ? TripTools.readQuote(result.text, result.structuredPrice, result) : null;
          }
          tripVerifications[j.offer.id] = TripTools.verificationVerdict(j.offer, result);
        } catch (e) {
          tripVerifications[j.offer.id] = { offerSignature: TripTools.signature(j.offer), checkedAt: new Date().toISOString(), status: "unknown", reason: String(e.message || e).slice(0, 240) };
        }
        delete tripVerifyJobs[tabId];
      }
      const keep = Object.entries(tripVerifications).sort((a, b) => String(b[1].checkedAt).localeCompare(String(a[1].checkedAt))).slice(0, 1000);
      await chrome.storage.local.set({ tripVerifyJobs, tripVerifications: Object.fromEntries(keep) });
      if (pending) await chrome.alarms.create("tripVerify", { delayInMinutes: 0.5 });
    });
  }
  async function rememberPost(event, chatId, messageId, text) {
    if (!messageId) return;
    return locked(async () => {
      const { tripPosts = {} } = await chrome.storage.local.get("tripPosts");
      const id = `${chatId}:${messageId}`;
      tripPosts[id] = { event, chatId, messageId, original: text, text, savedAt: Date.now() };
      const keep = Object.entries(tripPosts).sort((a, b) => b[1].savedAt - a[1].savedAt).slice(0, 200);
      await chrome.storage.local.set({ tripPosts: Object.fromEntries(keep) });
    });
  }
  async function updatePosts() {
    const s = await getSettings();
    if (isHelper(s) || !s.telegramBotToken) return;
    const { tripPosts = {} } = await chrome.storage.local.get("tripPosts");
    if (!Object.keys(tripPosts).length) return;
    const list = await allOffers(); let count = 0;
    for (const p of Object.values(tripPosts)) {
      if (count >= 5 || p.nextTry > Date.now() || p.savedAt < Date.now() - 7 * TripTools.DAY) continue;
      const e = p.event;
      const o = list.find((o) => o.groupKey === groupKeyOf(e) && o.checkin === e.checkin && o.checkout === e.checkout);
      if (!o) continue;
      const f = TripTools.freshness(o);
      const suffix = f.status === "expired" ? "Stay date passed — this offer has ended." : f.status !== "fresh" ? "Price needs refreshing — availability is unconfirmed." : o.price !== e.price ? `Latest observed room rate: ${formatINR(o.price)}. Final total and room conditions must be checked.` : "";
      const text = p.original.slice(0, 3500) + (suffix ? "\n\nUpdate: " + suffix : "");
      if (text === p.text) continue;
      count++;
      try {
        const r = await fetch(`https://api.telegram.org/bot${s.telegramBotToken}/editMessageText`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ chat_id: p.chatId, message_id: p.messageId, text }) });
        if (r.ok) { p.text = text; p.attempts = 0; }
        else { p.attempts = (p.attempts || 0) + 1; p.nextTry = Date.now() + Math.min(24 * TripTools.HOUR, 60000 * 2 ** Math.min(p.attempts, 10)); }
      } catch (_) { p.nextTry = Date.now() + 5 * 60000; }
    }
    await locked(async () => {
      const current = (await chrome.storage.local.get("tripPosts")).tripPosts || {};
      for (const [key, p] of Object.entries(tripPosts)) if (current[key]) current[key] = p;
      await chrome.storage.local.set({ tripPosts: current });
    });
  }
  async function ownerCommand(text, chatId, settings) {
    if (String(chatId) !== String(settings.telegramChatId) || isHelper(settings)) return false;
    const m = /^\/(control|tripoffers|favorites|favorite|unfavorite|target|pause|resume)(?:@\w+)?(?:\s+(.+))?\s*$/i.exec(text.trim());
    if (!m) return false;
    const command = m[1].toLowerCase(), args = (m[2] || "").trim();
    let reply;
    if (command === "control") reply = "Private controls (owner only):\n/tripoffers — numbered stays\n/favorites — saved hotels\n/favorite 2 — save stay #2 from /tripoffers\n/unfavorite 2 — remove that hotel's favorite\n/target 2 3500 — room-rate target for that hotel\n/pause 20 — pause scans for 20 minutes\n/resume — resume scans\n\nCommands work while Chrome and this computer are running.";
    else if (command === "pause" || command === "resume") {
      const min = command === "resume" ? 0 : Number(args || 20);
      if (!Number.isInteger(min) || min < 0 || min > 1440) reply = "Use /pause followed by 1–1440 minutes, or /resume.";
      else {
        await chrome.storage.local.set({ scanPausedUntil: min ? Date.now() + min * 60000 : 0 });
        if (!min) {
          const { scanProgress } = await chrome.storage.local.get("scanProgress");
          if (scanProgress?.running) await chrome.alarms.create("scanStepAlarm", { when: Date.now() + 1000 });
        }
        reply = min ? `Scans paused for ${min} minutes. A page already open can finish.` : "Scans resumed.";
      }
    } else if (command === "tripoffers") {
      const list = (await allOffers()).filter((o) => TripTools.freshness(o).status === "fresh").sort((a, b) => a.price - b.price).slice(0, 15);
      await chrome.storage.local.set({ tripOwnerMenu: { at: Date.now(), ids: list.map((o) => o.id) } });
      reply = list.length ? list.map((o, i) => `${i + 1}. ${o.hotelName} (${o.destination}) ${o.checkin}: ${formatINR(o.price)} room rate, final total ${TripTools.payable(o.quote, o).known ? formatINR(TripTools.payable(o.quote, o).total) : "unverified"}`).join("\n") + "\n\nUse /favorite 2 or /target 2 3500. Numbers stay valid for one hour." : "No fresh tracked stays. Run a scan first.";
    } else if (command === "favorites") {
      const { favoriteHotels = [] } = await chrome.storage.local.get("favoriteHotels");
      reply = favoriteHotels.length ? favoriteHotels.slice(0, 40).map((f) => `${f.hotelName} (${f.destination})${f.targetPrice ? " — target " + formatINR(f.targetPrice) : ""}`).join("\n") : "No favorites yet. Use /tripoffers, then /favorite 2.";
    } else {
      const { tripOwnerMenu } = await chrome.storage.local.get("tripOwnerMenu");
      const bits = args.split(/\s+/), index = Number(bits[0]) - 1;
      const id = Number.isInteger(index) ? tripOwnerMenu?.ids[index] : null;
      const o = id && (await allOffers()).find((o) => o.id === id);
      if (!o || Date.now() - tripOwnerMenu.at > TripTools.HOUR) reply = "Send /tripoffers for a fresh numbered list first.";
      else if (command === "target" && !(Number(bits[1]) >= 300 && Number(bits[1]) <= 10000000)) reply = "Use /target 2 3500 (a room-rate target of at least ₹300).";
      else if (o.source === "skyscanner") reply = "For automatic room-rate targets, choose a MakeMyTrip or Goibibo offer from /tripoffers. Skyscanner offers can be inspected in Plan & verify.";
      else {
        await locked(async () => {
          const { favoriteHotels = [] } = await chrome.storage.local.get("favoriteHotels");
          const existing = favoriteHotels.find((f) => groupKeyOf(f) === o.groupKey);
          const rest = favoriteHotels.filter((f) => groupKeyOf(f) !== o.groupKey);
          if (command !== "unfavorite") rest.push({ ...(existing || {}), source: o.source, hotelName: o.hotelName, destination: o.destination, targetPrice: command === "target" ? Number(bits[1]) : existing?.targetPrice ?? null });
          await chrome.storage.local.set({ favoriteHotels: rest });
        });
        reply = command === "unfavorite" ? `${o.hotelName} removed from favorites.` : `${o.hotelName} saved${command === "target" ? " with room-rate target " + formatINR(Number(bits[1])) : " to favorites"}.`;
      }
    }
    await sendTelegramText(settings, chatId, reply); return true;
  }
  async function helperExcluded(settings) {
    if (!isHelper(settings) || !settings.githubToken || !settings.githubRepo) return [];
    const cached = (await chrome.storage.local.get("tripLeaseCache")).tripLeaseCache;
    if (cached && cached.repo === settings.githubRepo && Date.now() - cached.fetchedAt < 60000) return cached.until > Date.now() ? cached.destinations || [] : [];
    try {
      const data = await githubGetFile(settings.githubRepo, "helper/trip-takeover.json", settings.githubToken);
      const lease = typeof data === "string" ? JSON.parse(data) : data;
      await chrome.storage.local.set({ tripLeaseCache: { repo: settings.githubRepo, fetchedAt: Date.now(), until: lease?.until || 0, destinations: lease?.destinations || [] } });
      return lease?.until > Date.now() ? lease.destinations || [] : [];
    } catch (_) { return []; } // existing helper scanning remains available if GitHub is down
  }
  async function failoverTick() {
    const s = await getSettings();
    if (isHelper(s)) return;
    const st = await chrome.storage.local.get(["tripFailover", "helperLive", "scanProgress", "favoriteRefreshProgress", "scanPausedUntil", "activeScan", "scanPageLog"]);
    if (!st.tripFailover || !s.githubToken || !s.githubRepo) return;
    if (st.tripFailover.pending && st.scanProgress?.running) {
      const lease = { destinations: [st.tripFailover.pending.place], until: Date.now() + 3 * TripTools.HOUR, owner: "main", at: new Date().toISOString() };
      await githubPutFile(s.githubRepo, "helper/trip-takeover.json", JSON.stringify(lease), "Renew destination takeover", s.githubToken);
      return;
    }
    if (st.scanProgress?.running || st.favoriteRefreshProgress?.running || st.scanPausedUntil > Date.now()) return;
    if (st.tripFailover.pending) {
      // Completion is recorded only after a finished takeover scan, never at dispatch.
      const p = st.tripFailover.pending;
      const pages = TripTools.smokeReport(st.scanPageLog, p.at).filter((page) => page.place === p.place && page.site === "makemytrip");
      const done = st.scanProgress?.finishedAt && Date.parse(st.scanProgress.finishedAt) >= p.at && st.scanProgress.completed >= st.scanProgress.total && !st.scanProgress.stopRequested && st.scanProgress.currentLabel === "Idle" && pages.length >= st.scanProgress.total && pages.every((page) => page.passed);
      if (done) st.tripFailover.completed = { ...(st.tripFailover.completed || {}), [p.place]: st.scanProgress.finishedAt };
      st.tripFailover.attempted = { ...(st.tripFailover.attempted || {}), [p.place]: new Date().toISOString() };
      delete st.tripFailover.pending;
      await chrome.storage.local.set({ tripFailover: st.tripFailover });
      await githubPutFile(s.githubRepo, "helper/trip-takeover.json", JSON.stringify({ destinations: [], until: 0, owner: "main" }), "Release completed destination takeover", s.githubToken);
    }
    if (!st.tripFailover.enabled) return;
    const [place] = TripTools.failoverCandidates(s, st.helperLive, st.tripFailover);
    if (!place) return;
    const lease = { destinations: [place], until: Date.now() + 3 * TripTools.HOUR, owner: "main", at: new Date().toISOString() };
    // Publish the lease before opening a page; a returning helper skips this destination.
    await githubPutFile(s.githubRepo, "helper/trip-takeover.json", JSON.stringify(lease), "Temporary destination takeover", s.githubToken);
    const r = await startScan(["makemytrip"], { auto: true, ignoreScanList: true, destinationName: place });
    if (r?.started) {
      st.tripFailover.pending = { place, at: Date.now() };
      await chrome.storage.local.set({ tripFailover: st.tripFailover });
    } else {
      await githubPutFile(s.githubRepo, "helper/trip-takeover.json", JSON.stringify({ ...lease, until: 0 }), "Release unused destination takeover", s.githubToken);
    }
  }
  async function tick() {
    if (ticking) return; ticking = true;
    try { await checkJobs(); await updatePosts(); await failoverTick(); }
    catch (e) { await recordError("plan-verify", e); }
    finally { ticking = false; }
  }
  async function message(m) {
    if (m.type === "TRIP_SAVE") return saveWorkspace(m.patch || {});
    if (m.type === "TRIP_NOTE") return noteOffer(m.id, m.patch || {});
    if (m.type === "TRIP_ALIAS") return alias(m.groups || [], !!m.unlink);
    if (m.type === "TRIP_OUTCOME") return outcome(m.id, m.outcome);
    if (m.type === "TRIP_QUOTE") return saveQuote(m.id, m.data || {});
    if (m.type === "TRIP_WATCHES") return locked(() => saveWatches(m.data || {}));
    if (m.type === "TRIP_VERIFY") return verify(m.id, m.url);
    if (m.type === "TRIP_FAILOVER") return locked(async () => { const { tripFailover = {} } = await chrome.storage.local.get("tripFailover"); await chrome.storage.local.set({ tripFailover: { ...tripFailover, enabled: !!m.enabled } }); return { ok: true }; });
    if (m.type === "TRIP_SMOKE") {
      const since = Date.now();
      const r = await startScan([m.site === "goibibo" ? "goibibo" : "makemytrip"], { destinationName: m.destination, smokeTest: true });
      if (r?.started) await chrome.storage.local.set({ tripSmoke: { since, destination: m.destination, site: m.site, version: chrome.runtime.getManifest().version } });
      return { ok: !!r?.started, message: r?.started ? "One search page queued. Its live result appears below when finished." : r?.message || r?.reason || "A scan is already running. Try again when it finishes." };
    }
    return null;
  }
  chrome.runtime.onMessage.addListener((m, sender, reply) => {
    if (!m?.type?.startsWith("TRIP_") || sender.id !== chrome.runtime.id || !String(sender.url || "").startsWith(chrome.runtime.getURL(""))) return false;
    message(m).then(reply, (e) => reply({ ok: false, error: String(e.message || e) })); return true;
  });
  chrome.alarms.onAlarm.addListener((a) => { if (a.name === "tripMaintenance" || a.name === "tripVerify") tick(); });
  const install = () => keepAlarm("tripMaintenance", { periodInMinutes: 5 });
  chrome.runtime.onInstalled.addListener(install);
  chrome.runtime.onStartup.addListener(install);
  install(); // keepAlarm preserves the countdown on ordinary worker restarts.
  return { ownerCommand, rememberPost, helperExcluded, tick, message, readBookingPage };
})();
