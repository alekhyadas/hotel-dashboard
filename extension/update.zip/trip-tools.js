/* Plan & verify: pure, additive data model. Unknown facts remain unknown.
 * Legacy hist:/sky: records are never rewritten or joined by this module. */
var TripTools = (() => {
  "use strict";
  const HOUR = 3600000, DAY = 24 * HOUR;
  const money = (v) => typeof v === "number" && Number.isFinite(v) && v >= 0 ? v : null;
  const norm = (s) => String(s || "").normalize("NFKC").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim();
  const day = (ms = Date.now()) => new Date(ms + 330 * 60000).toISOString().slice(0, 10);
  function nights(a, b) {
    if (!validDate(a) || !validDate(b)) return null;
    const n = (Date.parse(b) - Date.parse(a)) / DAY;
    return Number.isInteger(n) && n > 0 && n <= 365 ? n : null;
  }
  function validDate(s) { return /^\d{4}-\d{2}-\d{2}$/.test(s || "") && !isNaN(Date.parse(s)) && new Date(s).toISOString().slice(0, 10) === s; }
  function addDays(s, n) { return validDate(s) ? new Date(Date.parse(s) + n * DAY).toISOString().slice(0, 10) : null; }
  function safeUrl(raw) {
    try {
      const u = new URL(raw);
      if (u.protocol !== "https:" || u.username || u.password || !u.hostname.includes(".") || /(^|\.)(localhost|local|internal)$|^[\d.:]+$|\[|\]/i.test(u.hostname)) return null;
      return u.href;
    } catch (_) { return null; }
  }
  const amount = (s) => { const n = Number(String(s).replace(/,/g, "")); return Number.isFinite(n) && n >= 0 ? n : null; };
  function urlContext(search, dates = {}) {
    const p = new URLSearchParams(search);
    const occupancy = p.get("roomStayQualifier")?.match(/^(\d+)e(\d+)e$/);
    return { ...dates, adults: Number(p.get("adults") || p.get("adult") || occupancy?.[1]) || null,
      rooms: Number(p.get("rooms") || p.get("room")) || (occupancy ? 1 : null),
      children: occupancy ? Number(occupancy[2]) : p.has("children") && /^\d+$/.test(p.get("children")) ? Number(p.get("children")) : null };
  }
  function readQuote(text, price, context = {}) {
    const t = String(text || "").slice(0, 12000);
    const total = /(?:grand total|total payable|total amount|total for (?:your |the )?stay)\s*[:\-]?\s*(?:INR|Rs\.?|₹)\s*([\d,]+(?:\.\d{1,2})?)/i.exec(t);
    const taxes = /\+\s*(?:INR|Rs\.?|₹)\s*([\d,]+(?:\.\d{1,2})?)\s*(?:tax(?:es)?|fees)/i.exec(t);
    const room = /(?:room (?:type|category)|accommodation type)\s*[:\-]\s*([^\n|]{3,90})/i.exec(t);
    const basis = /per (?:room\s*per\s*)?night|a night|\/night/i.test(t) ? "night" : /for (?:the |your )?(?:entire )?stay|per stay/i.test(t) ? "stay" : "unknown";
    const taxIncluded = /(?:includes?|inclusive of|including|all)\s+(?:all\s+)?taxes(?:\s+and\s+fees)?/i.test(t) ? true : /exclud(?:es|ing)\s+tax|taxes?\s+(?:extra|not included)/i.test(t) ? false : null;
    const meal = /breakfast\s+(?:not included|excluded)|room only|without breakfast/i.test(t) ? "room_only" : /breakfast\s+(?:is\s+)?included|includes?\s+breakfast|free breakfast/i.test(t) ? "breakfast" : "unknown";
    const cancellation = /non[ -]?refundable|no free cancellation/i.test(t) ? "non_refundable" : /free cancellation|fully refundable/i.test(t) ? "free" : "unknown";
    const deadline = /free cancellation\s+(?:until|before|till)\s+([^\n|]{3,70})/i.exec(t);
    const positiveInt = (n) => Number.isInteger(n) && n > 0 && n <= 100 ? n : null;
    return {
      v: 1, currency: "INR", base: money(price), basis, total: total ? amount(total[1]) : null,
      taxes: taxes ? amount(taxes[1]) : null, taxIncluded,
      feesIncluded: /(?:includes?|inclusive of|including|all)\s+(?:all\s+)?taxes\s+(?:and|&)\s+fees/i.test(t) ? true : null,
      // A tax figure beside a nightly rate is not assumed to be for the whole stay.
      taxesBasis: taxes && /tax(?:es)?[^\n]{0,30}(?:per night|a night|\/night)/i.test(t) ? "night" : "unknown",
      roomType: room ? room[1].trim() : null, meal, cancellation,
      cancellationDeadline: deadline ? deadline[1].trim() : null,
      adults: positiveInt(context.adults), rooms: positiveInt(context.rooms),
      children: Number.isInteger(context.children) && context.children >= 0 ? context.children : null,
      checkin: context.checkin || null, checkout: context.checkout || null,
      evidence: [total && total[0], taxes && taxes[0], room && room[0], deadline && deadline[0]].filter(Boolean).map((s) => s.slice(0, 160)),
    };
  }
  function payable(q, stay) {
    q = q || {};
    const n = nights(stay.checkin, stay.checkout), rooms = q.rooms;
    if (money(q.total) !== null && q.total >= 300) return { total: q.total, known: true, label: "Observed stay total", nights: n };
    let subtotal = null;
    if (q.basis === "stay") subtotal = money(q.base);
    if (q.basis === "night" && n && rooms) subtotal = money(q.base) === null ? null : q.base * n * rooms;
    if (subtotal !== null && q.taxIncluded === true && q.feesIncluded === true) return { total: subtotal, known: true, label: "Observed rate includes taxes and fees", nights: n };
    return { total: null, subtotal, known: false, label: subtotal === null ? "Total not verified" : "Room subtotal; final taxes and fees unknown", nights: n };
  }
  function variant(q) {
    q = q || {};
    return [q.currency || "INR", q.basis || "unknown", norm(q.roomType) || "?", q.adults ?? "?", q.children ?? "?", q.rooms ?? "?", q.meal || "unknown", q.cancellation || "unknown", norm(q.cancellationDeadline) || "?", q.taxIncluded ?? "?", q.feesIncluded ?? "?"].join("|");
  }
  function rateKey(q) {
    if (!q?.roomType || q.adults == null || q.children == null || q.rooms == null || !["room_only", "breakfast"].includes(q.meal) || !["free", "non_refundable"].includes(q.cancellation) || q.cancellation === "free" && !q.cancellationDeadline) return null;
    return variant(q);
  }
  function comparableHistory(points, q) {
    const key = rateKey(q);
    return (points || []).filter((p) => key ? p.rateKey === key : !p.rateKey);
  }
  function comparison(a, b) {
    const missing = [], differences = [];
    for (const k of ["checkin", "checkout"]) if (a[k] !== b[k]) differences.push(k);
    for (const k of ["roomType", "adults", "children", "rooms", "meal", "cancellation", "currency"]) {
      const av = a.quote && a.quote[k], bv = b.quote && b.quote[k];
      if (av == null || bv == null || av === "unknown" || bv === "unknown") missing.push(k);
      else if (norm(av) !== norm(bv)) differences.push(k);
    }
    if (a.quote?.cancellation === "free" && b.quote?.cancellation === "free") {
      if (!a.quote.cancellationDeadline || !b.quote.cancellationDeadline) missing.push("cancellation deadline");
      else if (norm(a.quote.cancellationDeadline) !== norm(b.quote.cancellationDeadline)) differences.push("cancellation deadline");
    }
    const ap = payable(a.quote, a), bp = payable(b.quote, b);
    if (!ap.known || !bp.known) missing.push("final total");
    const equivalent = !missing.length && !differences.length;
    return { equivalent, missing, differences, saving: equivalent ? ap.total - bp.total : null, label: differences.length ? "Different rate conditions" : missing.length ? "Comparison unconfirmed" : "Equivalent rate conditions" };
  }
  function freshness(o, nowMs = Date.now(), verification) {
    const lead = (Date.parse(o.checkin) - Date.parse(day(nowMs))) / DAY;
    if (o.checkin < day(nowMs)) return { status: "expired", label: "Stay has passed", ageHours: null };
    const validVerification = verification && verification.offerSignature === signature(o);
    if (validVerification && verification.status === "unavailable") return { status: "unavailable", label: "Reported unavailable", ageHours: null };
    if (validVerification && verification.status === "changed") return { status: "changed", label: "Booking total changed; refresh this offer", ageHours: null };
    const at = Date.parse(validVerification && verification.status === "confirmed" && verification.checkedAt || o.updatedAt);
    const ageHours = (nowMs - at) / HOUR;
    const ttl = lead <= 3 ? 6 : lead <= 14 ? 24 : 48;
    const fresh = Number.isFinite(ageHours) && ageHours >= -0.1 && ageHours <= ttl;
    return { status: fresh ? "fresh" : "stale", ageHours: Number.isFinite(ageHours) ? Math.max(0, ageHours) : null, expiresAt: Number.isFinite(at) ? new Date(at + ttl * HOUR).toISOString() : null,
      label: fresh ? `Checked ${ageHours < 1 ? Math.max(0, Math.round(ageHours * 60)) + " min" : Math.round(ageHours) + " h"} ago` : "Needs refreshing" };
  }
  function signature(o) { return JSON.stringify([o.id, o.price, o.updatedAt, o.checkin, o.checkout, variant(o.quote), o.quote?.total]); }
  function evidence(o, nowMs = Date.now(), verification) {
    const points = (o.history || []).filter((p) => p.dv === 1 && Number.isFinite(p.price) && Number.isFinite(Date.parse(p.at)) && Date.parse(p.at) <= nowMs);
    const days = new Set(points.map((p) => day(Date.parse(p.at)))).size;
    const rateKnown = !!o.quote?.roomType && ["breakfast", "room_only"].includes(o.quote?.meal) && ["free", "non_refundable"].includes(o.quote?.cancellation) && o.quote?.adults != null && o.quote?.children != null && o.quote?.rooms != null;
    const f = freshness(o, nowMs, verification);
    const checked = verification?.status === "confirmed" && verification.offerSignature === signature(o) && nowMs - Date.parse(verification.checkedAt) <= HOUR;
    const level = f.status !== "fresh" ? "low" : checked && days >= 3 && rateKnown && payable(o.quote, o).known ? "high" : days >= 2 ? "some" : "new";
    return { level, days, readings: points.length, roomMatched: rateKnown, bookingChecked: checked,
      label: `${days} independent day${days === 1 ? "" : "s"}; ${checked ? "booking page checked" : "booking unconfirmed"}` };
  }
  function offers(entries, workspace = {}) {
    const out = [];
    for (const [id, r] of Object.entries(entries || {})) {
      if (!(id.startsWith("hist:") || id.startsWith("sky:")) || !r?.hotelName || !validDate(r.checkin) || !nights(r.checkin, r.checkout)) continue;
      const points = (r.prices || []).filter((p) => p.dv === 1 && typeof p.price === "number" && p.price >= 300);
      const p = points[points.length - 1];
      if (!p) continue;
      const groupKey = `${r.source}:::${r.hotelName}:::${r.destination}`;
      const manual = workspace.manualQuotes?.[id];
      const cheaperUnknown = r.source === "skyscanner" && p.cheapest != null && p.cheapest < p.price;
      const quote = manual && manual.observedPriceAt === p.at ? manual.quote : r.quote || { v: 1, base: p.cheapest || p.price, basis: r.source === "skyscanner" ? "night" : "unknown", currency: "INR", meal: !cheaperUnknown && r.breakfast === true ? "breakfast" : "unknown", cancellation: !cheaperUnknown && r.freeCancel === true ? "free" : "unknown" };
      out.push({ id, groupKey, propertyId: workspace.aliases?.[groupKey] || groupKey, hotelName: r.hotelName, source: r.source, destination: r.destination,
        checkin: r.checkin, checkout: r.checkout, price: p.cheapest || p.price, updatedAt: p.at,
        rating: money(r.rating), reviewCount: money(r.reviewCount), amenities: r.amenities || [],
        url: safeUrl(r.url), provider: cheaperUnknown ? "Cheapest provider unconfirmed (Skyscanner)" : p.provider || r.source, quote: { ...quote, checkin: r.checkin, checkout: r.checkout }, history: comparableHistory(points, quote),
        address: r.address || null, latitude: r.latitude ?? null, longitude: r.longitude ?? null,
      });
    }
    return out;
  }
  function identityCandidates(list) {
    const buckets = new Map(), result = [];
    for (const o of list) {
      const k = `${norm(o.destination)}|${norm(o.hotelName)}`;
      if (!buckets.has(k)) buckets.set(k, new Map());
      buckets.get(k).set(o.groupKey, o);
    }
    for (const map of buckets.values()) {
      const group = [...map.values()];
      if (group.length > 1 && new Set(group.map((o) => o.propertyId)).size > 1) result.push(group);
    }
    return result.slice(0, 30); // Suggestions, never automatic identity assertions.
  }
  function preferenceMatch(o, prefs = {}, note = {}, outcomes = []) {
    const rejected = [], unknown = [];
    const amenities = new Set((o.amenities || []).map(norm));
    for (const key of prefs.required || []) {
      const v = note.facts?.[key];
      const found = v === true || [...amenities].some((a) => a === norm(key));
      if (v === false) rejected.push(key); else if (!found) unknown.push(key);
    }
    if (prefs.minReviews > 0 && (o.reviewCount == null || o.reviewCount < prefs.minReviews)) (o.reviewCount == null ? unknown : rejected).push("review count");
    if (prefs.minRating > 0 && (o.rating == null || o.rating < prefs.minRating)) (o.rating == null ? unknown : rejected).push("guest rating");
    if (prefs.maxTravelHours > 0 && (note.travelHours == null || note.travelHours > prefs.maxTravelHours)) (note.travelHours == null ? unknown : rejected).push("travel time");
    if (outcomes.some((x) => x.propertyId === o.propertyId && x.type === "would_not_return") && prefs.excludeDisliked !== false) rejected.push("you would not return");
    if (o.quote?.meal !== "breakfast" && prefs.breakfast) (o.quote?.meal === "room_only" ? rejected : unknown).push("breakfast");
    if (o.quote?.cancellation !== "free" && prefs.freeCancellation) (o.quote?.cancellation === "non_refundable" ? rejected : unknown).push("free cancellation");
    return { rejected, unknown, ok: !rejected.length && (!prefs.strictUnknown || !unknown.length) };
  }
  function budget(o, assumptions = {}) {
    const p = payable(o.quote, o), n = nights(o.checkin, o.checkout);
    const guests = Number(assumptions.guests) || 2;
    const transport = money(Number(assumptions.transport)) ?? 0;
    const foodPerPersonDay = money(Number(assumptions.foodPerPersonDay)) ?? 0;
    const extras = money(Number(assumptions.extras)) ?? 0;
    const occupancyMatches = o.quote?.adults != null && o.quote?.children != null && o.quote.adults + o.quote.children === guests;
    const nonHotel = transport + foodPerPersonDay * guests * (n || 1) + extras;
    const estimate = p.known ? p.total + nonHotel : p.subtotal != null ? p.subtotal + nonHotel : null;
    return { estimate, hotel: p.total, nonHotel, totalVerified: p.known && occupancyMatches, guests, nights: n,
      withinBudget: p.known && occupancyMatches && money(Number(assumptions.maxTotal)) > 0 ? estimate <= Number(assumptions.maxTotal) : null,
      label: !occupancyMatches ? "Trip estimate incomplete: quote occupancy does not match the number of people" : p.known ? "Trip estimate (transport and food are your estimates)" : "Incomplete estimate; hotel taxes/fees unverified" };
  }
  function flexibleDates(list, reference, radius = 3) {
    return list.filter((o) => o.propertyId === reference.propertyId && nights(o.checkin, o.checkout) === nights(reference.checkin, reference.checkout) && Math.abs(Date.parse(o.checkin) - Date.parse(reference.checkin)) <= Math.min(14, Math.max(0, radius)) * DAY)
      .sort((a, b) => (payable(a.quote, a).total ?? Infinity) - (payable(b.quote, b).total ?? Infinity) || a.price - b.price).slice(0, 14);
  }
  function changeReason(previous, next) {
    if (!previous) return { kind: "first", label: "First observed rate" };
    if (variant(previous.quote) !== variant(next.quote)) return { kind: "conditions_changed", label: "Room, occupancy or rate conditions changed; not a verified price drop" };
    const q = next.quote || {};
    if (!q.roomType || q.adults == null || q.children == null || q.rooms == null || q.meal === "unknown" || q.cancellation === "unknown") return { kind: "unconfirmed", label: "Price changed; equivalent room conditions unconfirmed" };
    return { kind: next.price < previous.price ? "drop" : next.price > previous.price ? "rise" : "same", label: "Same recorded rate conditions" };
  }
  function appendObservation(previous = [], o, nowMs = Date.now()) {
    const row = { price: o.price, quote: o.quote, at: new Date(nowMs).toISOString() };
    const last = previous[previous.length - 1];
    if (last && last.price === row.price && variant(last.quote) === variant(row.quote) && nowMs - Date.parse(last.at) < 15 * 60000) return previous;
    return [...previous, { ...row, change: changeReason(last, row) }].slice(-90);
  }
  function planRoute(stops, legs = []) {
    const issues = [];
    if (!stops.length) return { issues: ["Select your first stay."], hotelTotal: null, estimate: null };
    let hotelTotal = 0;
    stops.forEach((o, i) => {
      if (nights(o.checkin, o.checkout) !== 1) issues.push(`${o.hotelName}: select a one-night stay.`);
      const total = payable(o.quote, o).total;
      if (total === null) issues.push(`${o.hotelName}: final total unverified.`); else hotelTotal += total;
      if (i && stops[i - 1].checkout !== o.checkin) issues.push(`Dates do not connect before ${o.hotelName}.`);
      if (i && stops[i - 1].propertyId === o.propertyId) issues.push(`${o.hotelName}: consecutive stops are the same property.`);
      if (i && !(Number(legs[i - 1]?.hours) > 0)) issues.push(`Add travel time before ${o.hotelName}.`);
      if (i && Number(legs[i - 1]?.hours) > 3) issues.push(`${o.hotelName}: travel exceeds the usual 11:00 checkout to 14:00 check-in gap (confirm hotel times).`);
    });
    const transport = legs.reduce((sum, l) => sum + Math.max(0, Number(l.cost) || 0), 0);
    const known = stops.every((o) => payable(o.quote, o).known);
    return { issues: [...new Set(issues)], hotelTotal: known ? hotelTotal : null, transport, estimate: known ? hotelTotal + transport : null };
  }
  function reviewFlags(reviews, nowMs = Date.now()) {
    const categories = { cleanliness: /dirty|unclean|cockroach|bed\s*bug|mould|mold/i, construction: /construction|renovation|drilling/i, noise: /noisy|loud music|sleepless|noise/i, photos: /misleading photo|nothing like (?:the )?photo|photos? (?:are|were) (?:fake|misleading)/i };
    const result = [];
    for (const [category, re] of Object.entries(categories)) {
      const matching = (reviews || []).filter((r) => {
        const ms = Date.parse(r.at);
        return Number.isFinite(ms) && nowMs >= ms && nowMs - ms <= 180 * DAY && safeUrl(r.url) && re.test(r.text || "");
      });
      const unique = [...new Map(matching.map((r) => [(r.author || "") + "|" + r.at + "|" + norm(r.text), r])).values()];
      if (unique.length >= 2) result.push({ category, count: unique.length, reviews: unique.slice(0, 3) });
    }
    return result; // Keyword flags are review excerpts, not a factual finding about the hotel.
  }
  function failoverCandidates(settings, live, state = {}, nowMs = Date.now()) {
    if (settings.deviceRole === "helper" || !settings.helpersEnabled || !state.enabled) return [];
    const assigned = new Map();
    for (const st of Object.values(live || {})) {
      if (st.role !== "helper") continue;
      for (const place of st.scanDestinations || []) {
        if (!assigned.has(norm(place))) assigned.set(norm(place), []);
        assigned.get(norm(place)).push(st);
      }
    }
    return (settings.destinations || []).filter((d) => {
      const devices = assigned.get(norm(d.name)) || [];
      if (!devices.length || !d.mmtCode) return false;
      // Every assigned helper must be stale. Unknown timestamps never prove failure.
      if (!devices.every((s) => /^\d+\.\d+\.\d+$/.test(s.version || "") && (Number(s.version.split(".")[0]) > 2 || Number(s.version.split(".")[0]) === 2 && Number(s.version.split(".")[1]) >= 1) && Number.isFinite(Date.parse(s.at)) && nowMs - Date.parse(s.at) > 6 * HOUR && !(Date.parse(s.scan?.pausedUntil) > nowMs))) return false;
      const last = state.completed?.[d.name];
      const attempted = state.attempted?.[d.name];
      if (attempted && nowMs - Date.parse(attempted) < 6 * HOUR) return false;
      return !last || nowMs - Date.parse(last) > 24 * HOUR;
    }).map((d) => d.name);
  }
  function smokeReport(pages, sinceMs = 0) {
    return (pages || []).filter((p) => Date.parse(p.at) >= sinceMs).map((p) => ({
      ...p, passed: (p.found ?? p.foundCount ?? p.hotels ?? 0) > 0 && !p.blocked && !p.incomplete && !p.unreadable && !p.hidden && !p.mismatched,
    }));
  }
  function verificationVerdict(o, result, nowMs = Date.now()) {
    const base = { checkedAt: new Date(nowMs).toISOString(), offerSignature: signature(o), url: safeUrl(result?.url), status: "unknown" };
    if (!result || result.blocked) return { ...base, reason: result?.blocked ? "Booking site asked for a human check. Open the tab to continue manually." : "Could not read the booking page." };
    if (result.checkin !== o.checkin || result.checkout !== o.checkout) return { ...base, reason: "Booking dates could not be matched to this stay." };
    const words = norm(o.hotelName).split(" ").filter((w) => w.length > 2);
    if (!words.length || !words.every((w) => norm(result.hotelName).split(" ").includes(w))) return { ...base, reason: "Property identity could not be matched on the booking page." };
    if (!result.quote || result.quote.base == null) return { ...base, reason: "No complete room offer was readable. Check the open booking tab." };
    const other = { ...o, quote: result.quote };
    const c = comparison(o, other);
    if (!c.equivalent) return { ...base, quote: result.quote, reason: `${c.label}: ${[...c.differences, ...c.missing].join(", ")}.` };
    if (result.availability === false) return { ...base, status: "unavailable", quote: result.quote, reason: "The matched room offer is explicitly marked unavailable on the booking page." };
    if (result.availability !== true) return { ...base, quote: result.quote, reason: "Rate conditions matched, but room availability could not be confirmed." };
    const total = payable(result.quote, o).total;
    const expected = payable(o.quote, o).total;
    if (Math.abs(total - expected) > 1) return { ...base, status: "changed", quote: result.quote, total, reason: "The booking page shows a different total for the matching rate." };
    return { ...base, status: "confirmed", quote: result.quote, total, reason: "Property, dates, room conditions and payable total matched on the booking page." };
  }
  return { HOUR, DAY, norm, day, nights, validDate, addDays, safeUrl, urlContext, readQuote, payable, variant, rateKey, comparableHistory, comparison, freshness, signature, evidence, offers, identityCandidates, preferenceMatch, budget, flexibleDates, changeReason, appendObservation, planRoute, reviewFlags, failoverCandidates, smokeReport, verificationVerdict };
})();
if (typeof module !== "undefined" && module.exports) module.exports = TripTools;
