/* Dashboard companion. All user/site text is escaped. No credentials go to
 * the public dashboard; private phone actions use the existing owner's bot. */
(() => {
  "use strict";
  const root = document.getElementById("trip-root");
  if (!root) return;
  const T = TripTools;
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const fmt = (n) => n == null ? "Unverified" : formatINR(n);
  const $ = (id) => root.querySelector(`#${id}`);
  const selected = (a, b) => a === b ? " selected" : "";
  const checked = (b) => b ? " checked" : "";
  const conditions = (q = {}) => [q.roomType || "Room unknown", q.meal === "breakfast" ? "Breakfast included" : q.meal === "room_only" ? "Room only" : "Meals unknown", q.cancellation === "free" ? `Free cancellation${q.cancellationDeadline ? " until " + q.cancellationDeadline : "; deadline unknown"}` : q.cancellation === "non_refundable" ? "Non-refundable" : "Cancellation unknown", q.adults != null ? `${q.adults} adults, ${q.children ?? "?"} children, ${q.rooms ?? "?"} rooms` : "Occupancy unconfirmed"].join(" · ");
  let store = {}, w = {}, settings = {}, list = [], candidates = [], focus = null, page = 0;
  let filters = { destination: "", date: "", radius: 3, showStale: false, showRejected: false, query: "" };
  let loading = false, dirty = false, pendingFocus = false, pendingSection = null;
  const msg = async (m) => {
    const r = await chrome.runtime.sendMessage(m);
    if (!r || r.ok === false) throw new Error(r?.error || r?.message || "The extension is restarting. Reopen the dashboard and try again.");
    return r;
  };
  function status(text, error = false) {
    const el = $("trip-status");
    if (el) { el.textContent = text; el.classList.toggle("trip-error", error); el.scrollIntoView({ block: "nearest" }); }
  }
  function note(o) { return w.properties?.[o.propertyId] || {}; }
  function match(o) { return T.preferenceMatch(o, w.preferences, note(o), w.outcomes); }
  function filtered(ignoreDates = false) {
    return list.filter((o) => {
      if (o.checkin < T.day()) return false;
      if (filters.destination && o.destination !== filters.destination) return false;
      if (filters.query && !T.norm(o.hotelName).includes(T.norm(filters.query))) return false;
      if (!ignoreDates && filters.date && Math.abs(Date.parse(o.checkin) - Date.parse(filters.date)) > filters.radius * T.DAY) return false;
      if (!filters.showStale && T.freshness(o, Date.now(), store.tripVerifications?.[o.id]).status !== "fresh") return false;
      if (!filters.showRejected && (!match(o).ok || (w.outcomes || []).some((x) => x.offerId === o.id && x.type === "wrong_price" && Date.parse(x.at) >= Date.parse(o.updatedAt)))) return false;
      if (w.budget?.maxTotal > 0 && T.budget(o, w.budget).withinBudget === false) return false;
      return true;
    }).sort((a, b) => {
      const feedback = (o) => (w.outcomes || []).some((x) => x.propertyId === o.propertyId && x.type === "great_stay") ? 1 : 0;
      return feedback(b) - feedback(a) || (T.payable(a.quote, a).total ?? Infinity) - (T.payable(b.quote, b).total ?? Infinity) || a.price - b.price;
    });
  }
  function factsSelect(key, label, facts = {}) {
    const v = facts[key] === true ? "yes" : facts[key] === false ? "no" : "unknown";
    return `<label>${esc(label)}<select name="fact-${key}"><option value="unknown"${selected(v, "unknown")}>Unknown</option><option value="yes"${selected(v, "yes")}>Confirmed yes</option><option value="no"${selected(v, "no")}>Confirmed no</option></select></label>`;
  }
  function profileHtml() {
    const p = w.preferences || {}, b = w.budget || {};
    return `<details class="trip-section" id="trip-preferences"><summary>Preferences &amp; budget</summary><form id="trip-profile" class="trip-form">
      <div class="trip-fields"><label>Required amenities (comma separated)<input name="required" value="${esc((p.required || []).join(", "))}" placeholder="pool, parking, balcony"></label>
      <label>Minimum guest rating<input name="minRating" type="number" min="0" max="5" step="0.1" value="${esc(p.minRating ?? 0)}"></label>
      <label>Minimum reviews<input name="minReviews" type="number" min="0" max="1000000" value="${esc(p.minReviews ?? 0)}"></label>
      <label>Maximum travel hours (0 = any)<input name="maxTravelHours" type="number" min="0" max="168" step="0.5" value="${esc(p.maxTravelHours ?? 0)}"></label></div>
      <div class="trip-checks"><label><input type="checkbox" name="breakfast"${checked(p.breakfast)}>Breakfast included</label><label><input type="checkbox" name="freeCancellation"${checked(p.freeCancellation)}>Free cancellation</label><label><input type="checkbox" name="strictUnknown"${checked(p.strictUnknown)}>Require evidence for every requirement</label><label><input type="checkbox" name="excludeDisliked"${checked(p.excludeDisliked !== false)}>Exclude hotels I would not return to</label></div>
      <div class="trip-fields"><label>Maximum trip budget ₹ (0 = any)<input name="maxTotal" type="number" min="0" max="10000000" value="${esc(b.maxTotal ?? 0)}"></label><label>People<input name="guests" type="number" min="1" max="30" value="${esc(b.guests ?? 2)}"></label><label>Return transport estimate ₹<input name="transport" type="number" min="0" max="1000000" value="${esc(b.transport ?? 0)}"></label><label>Food per person per night ₹<input name="foodPerPersonDay" type="number" min="0" max="100000" value="${esc(b.foodPerPersonDay ?? 0)}"></label><label>Other trip costs ₹<input name="extras" type="number" min="0" max="1000000" value="${esc(b.extras ?? 0)}"></label></div>
      <p class="hint">Transport, food and other costs are your estimates. Offers with unknown hotel totals remain marked incomplete; they cannot be certified within budget.</p><button type="submit">Save requirements &amp; budget</button></form></details>`;
  }
  function watchesHtml() {
    const tw = { ...TRIP_WATCH_DEFAULTS, ...(settings.tripWatch || {}) }, sw = { ...SKYSCANNER_WATCH_DEFAULTS, ...(settings.skyscannerWatch || {}) }, bw = { ...BRAND_WATCH_DEFAULTS, ...(settings.brandWatch || {}) };
    const destinations = settings.destinations || [];
    const watch = (key, label, value) => `<fieldset><legend>${label}</legend><label><input type="checkbox" name="${key}-enabled"${checked(value.enabled)}>Enabled</label><div class="trip-checks">${destinations.map((d) => `<label><input type="checkbox" name="${key}-dest" value="${esc(d.name)}"${checked(value.destinations.includes(d.name))}>${esc(d.name)}</label>`).join("")}</div><div class="trip-checks">${["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d, i) => `<label><input type="checkbox" name="${key}-day" value="${i}"${checked(value.weekdays.includes(i))}>${d}</label>`).join("")}</div><label>Watch through<input name="${key}-until" type="date" value="${esc(value.until)}" required></label></fieldset>`;
    return `<details class="trip-section" id="trip-watches-panel"><summary>Brand, trip &amp; Skyscanner watches</summary><form id="trip-watches" class="trip-form"><fieldset><legend>Brand watch</legend><label><input name="brand-enabled" type="checkbox"${checked(bw.enabled)}>Enabled</label><label>Brand names (one per line)<textarea name="brand-names" rows="3">${esc(bw.names.join("\n"))}</textarea></label><label>Look ahead days<input name="brand-days" type="number" min="1" max="90" value="${esc(bw.refreshDays)}" required></label></fieldset>${watch("tw", "One-night trip watch", tw)}${watch("sw", "Skyscanner watch", sw)}<label>Skyscanner place IDs (one Destination=ID per line)<textarea name="sky-ids" rows="3" placeholder="Mandarmoni=218058830">${esc(Object.entries(sw.entityIds || {}).map(([n, id]) => n + "=" + id).join("\n"))}</textarea></label><p class="hint">Find the place ID in Skyscanner's search address (entity_id). Saving updates future scans; a scan already running finishes its current queue.</p><button type="submit">Save watches</button></form></details>`;
  }
  function offerCard(o, count) {
    const p = T.payable(o.quote, o), f = T.freshness(o, Date.now(), store.tripVerifications?.[o.id]), e = T.evidence(o, Date.now(), store.tripVerifications?.[o.id]);
    const m = match(o), b = T.budget(o, w.budget);
    return `<article class="trip-card"><div class="trip-card-head"><div><h3>${esc(o.hotelName)}</h3><p>${esc(o.destination)} · ${esc(o.checkin)} → ${esc(o.checkout)}</p></div><div class="trip-money"><strong>${fmt(p.known ? p.total : o.price)}</strong><span>${p.known ? "stay total" : "observed room rate"}</span></div></div><div class="trip-tags"><span class="trip-tag ${f.status === "fresh" ? "trip-good" : "trip-warning"}">${esc(f.label)}</span><span class="trip-tag">${count} tracked offer${count === 1 ? "" : "s"}</span><span class="trip-tag">${esc(o.provider)}</span></div><p>${esc(conditions(o.quote))}</p><p class="hint">${esc(p.label)} · ${esc(e.label)}</p>${m.unknown.length ? `<p class="hint">Requirements unconfirmed: ${esc(m.unknown.join(", "))}</p>` : ""}${m.rejected.length ? `<p class="trip-error">Does not meet: ${esc(m.rejected.join(", "))}</p>` : ""}${w.budget?.maxTotal > 0 ? `<p>Trip estimate: ${fmt(b.estimate)}${b.totalVerified ? "" : " + unknown hotel costs"}</p>` : ""}<button type="button" class="secondary-btn" data-open="${esc(o.id)}">View offers, verify &amp; plan</button></article>`;
  }
  function routeHtml() {
    const ids = w.route?.ids || [], stops = ids.map((id) => list.find((o) => o.id === id)).filter(Boolean), legs = w.route?.legs || [];
    const route = T.planRoute(stops, legs);
    return `${!stops.length ? `<section class="trip-section trip-plan-empty"><div class="trip-empty-icon" aria-hidden="true">↗</div><h3>A good trip starts with one stay.</h3><p>Find a hotel you like, open its details, and choose Add to trip.</p><button type="button" data-action="discover">Find a stay</button></section>` : ""}<details class="trip-section" id="trip-route-panel"${stops.length ? " open" : ""}><summary>${stops.length ? `Your itinerary · ${stops.length} stay${stops.length === 1 ? "" : "s"}` : "Suggest an itinerary"}</summary><p class="hint">Add stays below, or suggest a sequence from currently visible fresh offers. Travel times and costs are entered by you; confirm each hotel's actual check-in/check-out times.</p><div class="trip-fields"><label>First night<input id="trip-route-start" type="date" min="${T.day()}" value="${esc(stops[0]?.checkin || filters.date || T.day())}"></label><label>Number of nights<input id="trip-route-nights" type="number" min="1" max="7" value="${Math.max(2, stops.length)}"></label><button type="button" data-action="suggest-route">Suggest sequence</button></div><ol>${stops.map((o, i) => `<li><button class="trip-link" type="button" data-open="${esc(o.id)}">${esc(o.hotelName)}</button> · ${esc(o.destination)} · ${esc(o.checkin)} · ${fmt(T.payable(o.quote, o).total)}<button class="trip-link" data-remove-stop="${i}">Remove</button></li>`).join("")}</ol><form id="trip-legs" class="trip-form">${stops.slice(1).map((o, i) => `<div class="trip-fields"><span>To ${esc(o.hotelName)}</span><label>Travel hours<input name="hours-${i}" type="number" min="0" max="72" step="0.25" value="${esc(legs[i]?.hours ?? "")}"></label><label>Transport cost ₹<input name="cost-${i}" type="number" min="0" max="1000000" value="${esc(legs[i]?.cost ?? 0)}"></label></div>`).join("")}${stops.length > 1 ? '<button type="submit">Save travel estimates</button>' : ""}</form><p><b>Hotels + between-hotel transport: ${fmt(route.estimate)}</b> (food, travel to/from home and other costs are additional).</p>${route.issues.length ? `<ul class="hint">${route.issues.map((s) => `<li>${esc(s)}</li>`).join("")}</ul>` : ""}${ids.length !== stops.length ? '<p class="trip-error">Some selected offers are no longer tracked. Rebuild the plan before booking.</p>' : ""}<button type="button" class="secondary-btn" data-action="export-plan">Download trip plan</button></details>`;
  }
  function reliabilityHtml() {
    const smoke = store.tripSmoke, rows = T.smokeReport(store.scanPageLog, smoke?.since || Date.now()).filter((p) => !smoke || p.place === smoke.destination && p.site === smoke.site).slice(-5);
    const options = (settings.destinations || []).map((d) => `<option>${esc(d.name)}</option>`).join("");
    const fk = store.tripFailover;
    return `<details class="trip-section" id="trip-system"><summary>Live checks, helper recovery &amp; private phone controls</summary><div class="trip-fields"><label>Test destination<select id="trip-smoke-dest">${options}</select></label><label>Site<select id="trip-smoke-site"><option value="makemytrip">MakeMyTrip</option><option value="goibibo">Goibibo</option></select></label><button data-action="smoke" type="button">Check one live search page</button></div><p class="hint">Uses the regular scanner for one page. Checks dates, prices, visibility and completeness; it does not prove a checkout total.</p>${smoke ? `<p>Last test: ${esc(smoke.destination)} · ${esc(smoke.site)} · v${esc(smoke.version)}</p>${rows.length ? rows.map((r) => `<p class="${r.passed ? "trip-success" : "trip-error"}">${r.passed ? "Passed" : "Needs attention"}: ${esc(r.found)} hotel prices, ${r.mismatched || 0} date mismatches${r.blocked ? ", site blocked" : ""}${r.incomplete ? ", incomplete listing" : ""}${r.hidden ? ", hidden window" : ""}${r.unreadable ? ", unreadable page" : ""}</p>`).join("") : '<p class="hint">Waiting for the scan result. Use Refresh after it finishes.</p>'}` : ""}<hr><label><input id="trip-failover" type="checkbox"${checked(fk?.enabled)}>Main computer may take over a helper destination after all assigned helpers stop reporting for 6 hours</label><p class="hint">Requires helper sharing and GitHub. Runs only while the main computer is idle, respects scan pauses, and publishes a temporary destination lease. Helpers need this version to observe the lease.</p><button data-action="failover" class="secondary-btn" type="button">Save helper recovery setting</button>${fk?.pending ? `<p>Taking over ${esc(fk.pending.place)}.</p>` : ""}<hr><h3>Manage your tracker from your phone</h3><p>In your existing Telegram bot send <code>/control</code>. Only the private chat matching your configured owner chat ID can change favorites, targets or scan pauses. Chrome must be running.</p><p><code>/tripoffers</code> · <code>/favorite 2</code> · <code>/target 2 3500</code> · <code>/pause 20</code> · <code>/resume</code></p><p class="hint">Additional booking sites request access only when you click Verify now. You can revoke those extra grants below; existing scanner access is retained.</p><div id="trip-permissions"></div><button data-action="permissions" class="secondary-btn" type="button">Show extra booking-site access</button></details>`;
  }
  function matchesHtml() {
    candidates = T.identityCandidates(list);
    const profiles = [...new Map(list.map((o) => [o.groupKey, o])).values()].sort((a, b) => a.hotelName.localeCompare(b.hotelName));
    const opts = profiles.map((o) => `<option value="${esc(o.groupKey)}">${esc(o.hotelName)} — ${esc(o.destination)} (${esc(o.source)})</option>`).join("");
    return `<details class="trip-section"><summary>Link the same property across booking sites</summary><p class="hint">Check the addresses/maps before linking. Similar names alone do not prove a match. Linking combines the profile view; original site histories remain separate. You can undo a link.</p>${candidates.map((pair, i) => `<p>${esc(pair[0].hotelName)} (${esc(pair[0].destination)}): ${esc(pair.map((o) => o.source).join(" / "))} <button class="secondary-btn" data-candidate="${i}">I checked: same property</button></p>`).join("") || '<p class="hint">No exact-name suggestions. Use the manual selectors for spelling differences.</p>'}<div class="trip-fields"><label>First property<select id="trip-link-a">${opts}</select></label><label>Second property<select id="trip-link-b">${opts}</select></label></div><button data-action="link" class="secondary-btn" type="button">Link selected properties</button> <button data-action="unlink" class="secondary-btn" type="button">Unlink first property</button></details>`;
  }
  function quoteHtml(o) {
    const q = o.quote || {};
    return `<details><summary>Record room conditions you checked</summary><form id="trip-quote" class="trip-form"><p class="hint">These are your observations, labelled as such. They apply only to this stay's current price reading and expire when it is rescanned.</p><div class="trip-fields"><label>Exact room type<input name="roomType" required maxlength="120" value="${esc(q.roomType || "")}"></label><label>Final stay total ₹ (blank = unknown)<input name="total" type="number" min="300" max="10000000" value="${esc(q.total ?? "")}"></label><label>Adults<input name="adults" type="number" min="1" max="30" value="${esc(q.adults ?? 2)}" required></label><label>Children<input name="children" type="number" min="0" max="20" value="${esc(q.children ?? 0)}" required></label><label>Rooms<input name="rooms" type="number" min="1" max="20" value="${esc(q.rooms ?? 1)}" required></label><label>Meals<select name="meal">${[["unknown", "Unknown"], ["room_only", "Room only"], ["breakfast", "Breakfast included"]].map(([k, v]) => `<option value="${k}"${selected(q.meal, k)}>${v}</option>`).join("")}</select></label><label>Cancellation<select name="cancellation">${[["unknown", "Unknown"], ["free", "Free cancellation"], ["non_refundable", "Non-refundable"]].map(([k, v]) => `<option value="${k}"${selected(q.cancellation, k)}>${v}</option>`).join("")}</select></label><label>Cancellation deadline (exact wording)<input name="cancellationDeadline" maxlength="100" value="${esc(q.cancellationDeadline || "")}"></label><label>Booking page you checked<input name="url" type="url" value="${esc(q.sourceUrl || note(o).providerUrls?.[o.id] || o.url || "")}" required></label></div><button type="submit">Save observed room quote</button></form></details>`;
  }
  function inspectorHtml() {
    const o = list.find((x) => x.id === focus); if (!o) return "";
    const n = note(o), v = store.tripVerifications?.[o.id], e = T.evidence(o, Date.now(), v), comparable = list.filter((x) => x.propertyId === o.propertyId && x.checkin === o.checkin && x.checkout === o.checkout);
    const flex = T.flexibleDates(list, o, filters.radius).filter((x) => x.checkin >= T.day());
    const flags = T.reviewFlags(n.reviews), allNotes = [...new Set(list.filter((x) => x.propertyId === o.propertyId).map((x) => x.groupKey))].flatMap((key) => {
      const meta = store.hotelMeta?.[key]; return (meta?.googleReviewList || []).map((r) => ({ ...r, url: meta.googleUrl }));
    });
    const record = store[o.id], history = record?.rateHistory || [], total = T.payable(o.quote, o);
    const fallbackHistory = o.history.slice(-12).map((p) => ({ ...p, change: { label: "Room conditions were not recorded for this reading" } }));
    return `<section id="trip-inspector" class="trip-section trip-inspector"><div class="trip-card-head"><div><p class="trip-place-label">${esc(o.destination)} · ${esc(o.checkin)} → ${esc(o.checkout)}</p><h2 tabindex="-1">${esc(o.hotelName)}</h2></div><button class="secondary-btn" data-action="close">Back to my trip</button></div><div class="trip-stay-price"><strong>${fmt(total.known ? total.total : o.price)}</strong><span>${total.known ? "total for this stay" : "room rate · final total not checked"}</span></div>${o.quote.userObserved ? '<p class="hint">Room conditions entered by you from a booking page.</p>' : ""}<div class="trip-actions"><button data-action="add-stop" type="button">Add to trip</button>${o.url ? `<a class="trip-book-link" href="${esc(o.url)}" target="_blank" rel="noopener noreferrer">Open booking site ↗</a>` : ""}<button data-action="verify" type="button" class="secondary-btn">Check this offer</button></div>${v ? `<p class="${v.status === "confirmed" && v.offerSignature === T.signature(o) ? "trip-success" : "hint"}">${v.offerSignature === T.signature(o) ? esc(v.status + ": " + v.reason) : "An older verification does not apply to this price reading."}</p>` : '<p class="hint">Booking availability has not been confirmed. The checker leaves the booking tab open for you.</p>'}
      <details class="trip-price-details"><summary>Compare prices &amp; nearby dates</summary><p class="hint">${esc(conditions(o.quote))}. ${esc(e.label)}.</p><h3>Same property, same dates</h3><div class="trip-scroll"><table class="trip-table"><thead><tr><th>Source</th><th>Rate</th><th>Stay total</th><th>Comparison with selected offer</th><th></th></tr></thead><tbody>${comparable.map((x) => { const c = T.comparison(o, x); return `<tr><td>${esc(x.provider)}</td><td>${fmt(x.price)}</td><td>${fmt(T.payable(x.quote, x).total)}</td><td>${x.id === o.id ? "Selected offer" : esc(c.label + (c.saving != null ? `; difference ${fmt(Math.abs(c.saving))}` : "; " + [...c.differences, ...c.missing].join(", ")))}</td><td><button class="trip-link" data-open="${esc(x.id)}">Select</button></td></tr>`; }).join("")}</tbody></table></div>
      <h3>Nearby dates (±${filters.radius} days)</h3><div class="trip-scroll"><table class="trip-table"><thead><tr><th>Night</th><th>Source</th><th>Rate</th><th>Stay total</th><th>Conditions</th></tr></thead><tbody>${flex.map((x) => `<tr><td><button class="trip-link" data-open="${esc(x.id)}">${esc(x.checkin)}</button></td><td>${esc(x.provider)}</td><td>${fmt(x.price)}</td><td>${fmt(T.payable(x.quote, x).total)}</td><td>${esc(conditions(x.quote))}</td></tr>`).join("")}</tbody></table></div>
      </details>${quoteHtml(o)}<details><summary>Price history</summary><p class="hint">Room/meal/occupancy changes are labelled separately. Legacy readings retain their original history.</p><ul>${(history.length ? history.slice(-12) : fallbackHistory).slice().reverse().map((p) => `<li>${esc(p.at)} · ${fmt(p.price)} · ${esc(p.change?.label || "Observed rate")} ${p.quote?.roomType ? "(" + esc(p.quote.roomType) + ")" : ""}</li>`).join("")}</ul></details>
      <details><summary>Your stay feedback</summary><div class="trip-actions">${[["booked", "Booked"], ["wrong_price", "Price was wrong"], ["great_stay", "Great stay"], ["would_not_return", "Wouldn't return"], ["clear", "Clear feedback"]].map(([k, label]) => `<button class="secondary-btn" data-outcome="${k}">${label}</button>`).join("")}</div><p class="hint">${esc((w.outcomes || []).filter((x) => x.offerId === o.id).map((x) => x.type.replace(/_/g, " ")).join(" · ") || "No feedback recorded.")}</p>
      </details><details><summary>Notes &amp; filming checklist</summary><form id="trip-notes" class="trip-form"><div class="trip-fields"><label>Property address (for identity checks)<input name="address" maxlength="300" value="${esc(n.address || o.address || "")}"></label><label>Travel hours from home<input name="travelHours" type="number" min="0" max="168" step="0.25" value="${esc(n.travelHours ?? "")}"></label><label>Actual booking-provider URL for this offer<input name="providerUrl" type="url" value="${esc(n.providerUrls?.[o.id] || "")}" placeholder="Paste the cheaper provider's dated offer URL"></label>${[["pool", "Pool"], ["parking", "Parking"], ["balcony", "Balcony"], ["wifi", "Usable Wi-Fi"], ["filmingPermission", "Filming permission"], ["quietRecording", "Quiet recording areas"], ["roomView", "Good room view"], ["renovation", "Renovation in progress"]].map(([k, label]) => factsSelect(k, label, n.facts)).join("")}</div><label>Notes<textarea name="notes" rows="3" maxlength="3000">${esc(n.notes || "")}</textarea></label><button type="submit">Save private checklist</button></form></details>
      <details><summary>Recent review evidence (${(n.reviews || []).length} dated snippets)</summary><p class="hint">Flags need at least two distinct dated reviews within 180 days. Keyword flags require your judgment; they are not verified findings.</p>${flags.map((f) => `<p class="trip-warning">${esc(f.category)} mentioned in ${f.count} recent snippets</p>`).join("")}${(n.reviews || []).map((r, i) => `<blockquote>${esc(r.text)}<footer>${esc(r.at)} · <a href="${esc(r.url)}" target="_blank" rel="noopener noreferrer">Review source</a> <button class="trip-link" data-remove-review="${i}">Remove</button></footer></blockquote>`).join("")}${allNotes.map((r) => `<blockquote>${esc(r.text)}<footer>${esc(r.when || "Date unknown")}${T.safeUrl(r.url) ? ` · <a href="${esc(r.url)}" target="_blank" rel="noopener noreferrer">Google source</a>` : ""} · not included in dated flags</footer></blockquote>`).join("")}<form id="trip-review" class="trip-form"><label>Review excerpt<textarea name="text" rows="2" maxlength="1000" required></textarea></label><div class="trip-fields"><label>Actual review date<input name="at" type="date" max="${T.day()}" required></label><label>Reviewer name (optional)<input name="author" maxlength="100"></label><label>Review source link<input name="url" type="url" required></label></div><button type="submit">Add review evidence</button></form></details></section>`;
  }
  async function render() {
    if (loading) return; loading = true;
    const open = [...root.querySelectorAll("details[open]")].map((d) => d.id || d.querySelector("summary")?.textContent);
    try {
      [store, settings] = await Promise.all([chrome.storage.local.get(null), getSettings()]);
      w = store.tripWorkspace || {};
      const hidden = new Set((store.blockedHotels || []).map((b) => `${b.source}:::${b.hotelName}:::${b.destination}`));
      list = T.offers(store, w).filter((o) => !hidden.has(o.groupKey));
      const current = filtered(), profiles = new Map();
      for (const o of current) { if (!profiles.has(o.propertyId)) profiles.set(o.propertyId, []); profiles.get(o.propertyId).push(o); }
      const groups = [...profiles.values()], pages = Math.max(1, Math.ceil(groups.length / 12)); page = Math.min(page, pages - 1);
      const places = [...new Set(list.map((o) => o.destination))].sort();
      root.innerHTML = `<div class="trip-heading"><div><h2>${focus ? "Stay details" : "My trip"}</h2><p>${focus ? "Check the details, then add it to your trip." : "Your stays, in order. Add a hotel when you find one you like."}</p></div><button data-action="refresh" class="secondary-btn">Refresh</button></div><p id="trip-status" role="status" aria-live="polite"></p>${inspectorHtml()}${routeHtml()}${profileHtml()}<details class="trip-section" id="trip-browse"><summary>Find and compare more stays</summary><div class="trip-section"><div class="trip-fields"><label>Destination<select id="trip-filter-place"><option value="">All destinations</option>${places.map((p) => `<option${selected(filters.destination, p)}>${esc(p)}</option>`).join("")}</select></label><label>Hotel name<input id="trip-filter-query" value="${esc(filters.query)}" placeholder="Any hotel"></label><label>Preferred check-in<input id="trip-filter-date" type="date" min="${T.day()}" value="${esc(filters.date)}"></label><label>Flexible days either side<select id="trip-filter-radius">${[0, 1, 2, 3, 7, 14].map((n) => `<option value="${n}"${selected(filters.radius, n)}>${n}</option>`).join("")}</select></label><button data-action="filter" class="secondary-btn">Apply filters</button></div><div class="trip-checks"><label><input id="trip-show-stale" type="checkbox"${checked(filters.showStale)}>Include prices needing refresh</label><label><input id="trip-show-rejected" type="checkbox"${checked(filters.showRejected)}>Include offers outside my requirements / reported wrong</label></div><p class="hint">${groups.length} properties · ${current.length} offers match. ${list.filter((o) => o.checkin >= T.day() && T.freshness(o).status !== "fresh").length} upcoming prices need refreshing. Confirmed totals sort ahead of unverified room rates.</p></div><div class="trip-grid">${groups.slice(page * 12, page * 12 + 12).map((g) => offerCard(g[0], g.length)).join("") || '<p class="hint">No matching fresh stays. Run a scan, widen the dates, or include prices needing refresh.</p>'}</div><div class="trip-actions"><button data-page="-1" class="secondary-btn"${page ? "" : " disabled"}>Previous</button><span>Page ${page + 1} / ${pages}</span><button data-page="1" class="secondary-btn"${page < pages - 1 ? "" : " disabled"}>Next</button></div></details><details class="trip-section" id="trip-advanced"><summary>Advanced tools &amp; watches</summary>${matchesHtml()}${watchesHtml()}${reliabilityHtml()}</details>`;
      for (const d of root.querySelectorAll("details")) if (open.includes(d.id || d.querySelector("summary")?.textContent)) d.open = true;
      if (pendingSection) {
        const panel = $(pendingSection);
        if (panel) {
          for (let el = panel; el && el !== root; el = el.parentElement) if (el.tagName === "DETAILS") el.open = true;
          panel.scrollIntoView({ block: "start" });
          panel.querySelector("input, select, button")?.focus({ preventScroll: true });
        }
        pendingSection = null;
      }
      if (pendingFocus) {
        const inspector = $("trip-inspector");
        if (inspector) {
          if ($("trip-browse")) $("trip-browse").open = false;
          inspector.scrollIntoView({ block: "start" });
          inspector.querySelector("h2")?.focus({ preventScroll: true });
        } else status("This stay is no longer available in your tracked data. Choose another stay.", true);
        pendingFocus = false;
      }
      dirty = false;
    } catch (e) { if (!$("trip-status")) root.innerHTML = '<p id="trip-status" role="status"></p>'; status(e.message, true); }
    finally { loading = false; }
  }
  function download(name, content, type = "text/plain") {
    const url = URL.createObjectURL(new Blob([content], { type })); const a = document.createElement("a"); a.href = url; a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(url), 10000);
  }
  root.addEventListener("input", () => { dirty = true; });
  root.addEventListener("submit", async (e) => {
    e.preventDefault(); const form = e.target, d = Object.fromEntries(new FormData(form)), btn = form.querySelector('button[type="submit"]');
    if (btn) btn.disabled = true;
    try {
      if (form.id === "trip-profile") await msg({ type: "TRIP_SAVE", patch: { preferences: { required: d.required.split(",").map(T.norm).filter(Boolean).slice(0, 20), minRating: Number(d.minRating), minReviews: Number(d.minReviews), maxTravelHours: Number(d.maxTravelHours), breakfast: !!d.breakfast, freeCancellation: !!d.freeCancellation, strictUnknown: !!d.strictUnknown, excludeDisliked: !!d.excludeDisliked }, budget: Object.fromEntries(["maxTotal", "guests", "transport", "foodPerPersonDay", "extras"].map((k) => [k, Number(d[k])])) } });
      if (form.id === "trip-notes") await msg({ type: "TRIP_NOTE", id: focus, patch: { notes: d.notes, address: d.address, providerUrl: d.providerUrl, travelHours: d.travelHours, facts: Object.fromEntries(Object.entries(d).filter(([k]) => k.startsWith("fact-")).map(([k, v]) => [k.slice(5), v === "yes" ? true : v === "no" ? false : null])) } });
      if (form.id === "trip-review") await msg({ type: "TRIP_NOTE", id: focus, patch: { review: d } });
      if (form.id === "trip-quote") await msg({ type: "TRIP_QUOTE", id: focus, data: d });
      if (form.id === "trip-legs") await msg({ type: "TRIP_SAVE", patch: { route: { ...w.route, legs: (w.route?.ids || []).slice(1).map((_, i) => ({ hours: d[`hours-${i}`] === "" ? null : Number(d[`hours-${i}`]), cost: Number(d[`cost-${i}`]) })) } } });
      if (form.id === "trip-watches") {
        const fd = new FormData(form), watch = (key) => ({ enabled: fd.has(key + "-enabled"), destinations: fd.getAll(key + "-dest"), weekdays: fd.getAll(key + "-day").map(Number), until: d[key + "-until"] });
        const entityIds = {}; for (const line of d["sky-ids"].split("\n").map((s) => s.trim()).filter(Boolean)) { const i = line.lastIndexOf("="); if (i < 1) throw new Error("Use Destination=ID, one per line."); entityIds[line.slice(0, i).trim()] = line.slice(i + 1).trim(); }
        await msg({ type: "TRIP_WATCHES", data: { brandEnabled: !!d["brand-enabled"], brandNames: d["brand-names"], brandDays: d["brand-days"], tripWatch: watch("tw"), skyscannerWatch: { ...watch("sw"), entityIds } } });
      }
      await render(); status("Saved on this computer.");
    } catch (e) { status(e.message, true); } finally { if (btn?.isConnected) btn.disabled = false; }
  });
  root.addEventListener("click", async (event) => {
    const b = event.target.closest("button"); if (!b || b.type === "submit" && b.form || b.disabled) return;
    const a = b.dataset.action;
    try {
      if (b.dataset.open) { focus = b.dataset.open; pendingFocus = true; await render(); $("trip-inspector")?.scrollIntoView({ block: "start", behavior: "smooth" }); return; }
      if (b.dataset.page) { page += Number(b.dataset.page); await render(); return; }
      if (b.dataset.outcome) { await msg({ type: "TRIP_OUTCOME", id: focus, outcome: b.dataset.outcome }); await render(); status("Feedback saved."); return; }
      if (b.dataset.removeReview !== undefined) { await msg({ type: "TRIP_NOTE", id: focus, patch: { removeReview: Number(b.dataset.removeReview) } }); await render(); return; }
      if (b.dataset.removeStop !== undefined) { const route = { ids: [...(w.route?.ids || [])], legs: [] }; route.ids.splice(Number(b.dataset.removeStop), 1); await msg({ type: "TRIP_SAVE", patch: { route } }); await render(); return; }
      if (b.dataset.candidate !== undefined) { await msg({ type: "TRIP_ALIAS", groups: candidates[Number(b.dataset.candidate)].map((o) => o.groupKey) }); await render(); status("Profiles linked. Source histories preserved."); return; }
      if (b.dataset.revoke) { const removed = await chrome.permissions.remove({ origins: [b.dataset.revoke] }); await permissionsHtml(); status(removed ? "Extra site access removed." : "Chrome retained this site's existing access."); return; }
      if (a === "discover") { document.querySelector('.tab-btn[data-tab="today"]')?.click(); return; }
      if (a === "refresh") { await render(); return; }
      if (a === "close") { focus = null; await render(); return; }
      if (a === "filter") { filters = { destination: $("trip-filter-place").value, date: $("trip-filter-date").value, radius: Number($("trip-filter-radius").value), query: $("trip-filter-query").value, showStale: $("trip-show-stale").checked, showRejected: $("trip-show-rejected").checked }; page = 0; await render(); return; }
      if (a === "verify") {
        const o = list.find((o) => o.id === focus), url = T.safeUrl(note(o).providerUrls?.[o.id] || o.quote?.sourceUrl || o.url);
        if (!url) throw new Error("Add the actual booking-provider URL in this offer's private notes first.");
        // Request within this user gesture, before any asynchronous background message.
        const allowed = await chrome.permissions.request({ origins: [new URL(url).origin + "/*"] });
        if (!allowed) throw new Error("Booking-site access was not granted. You can still open and check the offer manually.");
        b.disabled = true; const r = await msg({ type: "TRIP_VERIFY", id: focus, url }); status(r.message); b.disabled = false; return;
      }
      if (a === "add-stop") {
        const o = list.find((o) => o.id === focus);
        if (T.nights(o.checkin, o.checkout) !== 1) throw new Error("Choose a one-night stay for the hotel-hopping plan.");
        const ids = [...new Set([...(w.route?.ids || []), focus])]; if (ids.length > 7) throw new Error("A plan supports up to seven one-night stays.");
        ids.sort((a, b) => (list.find((o) => o.id === a)?.checkin || "").localeCompare(list.find((o) => o.id === b)?.checkin || ""));
        await msg({ type: "TRIP_SAVE", patch: { route: { ids, legs: [] } } }); focus = null; await render(); $("trip-route-panel").open = true; status("Stay added to your trip. Enter travel estimates between hotels."); return;
      }
      if (a === "suggest-route") {
        const start = $("trip-route-start").value, count = Number($("trip-route-nights").value), ids = [];
        if (!T.validDate(start) || start < T.day() || !Number.isInteger(count) || count < 1 || count > 7) throw new Error("Choose an upcoming first night and 1–7 nights.");
        let previous = null;
        for (let i = 0; i < count; i++) {
          const choices = filtered(true).filter((o) => o.checkin === T.addDays(start, i) && T.nights(o.checkin, o.checkout) === 1 && o.propertyId !== previous && T.freshness(o).status === "fresh");
          const chosen = choices[0]; if (!chosen) throw new Error(`No fresh matching one-night stay for ${T.addDays(start, i)}. Scan that date or add stops manually.`);
          ids.push(chosen.id); previous = chosen.propertyId;
        }
        await msg({ type: "TRIP_SAVE", patch: { route: { ids, legs: [] } } }); await render(); $("trip-route-panel").open = true; status("Sequence suggested. Verify offers and add travel times before booking."); return;
      }
      if (a === "export-plan") {
        const stops = (w.route?.ids || []).map((id) => list.find((o) => o.id === id)).filter(Boolean), result = T.planRoute(stops, w.route?.legs || []);
        const lines = ["Hotel-hopping plan", "Generated " + new Date().toISOString(), ...stops.map((o, i) => `${i + 1}. ${o.hotelName}, ${o.destination}\n${o.checkin} → ${o.checkout}\nStay total: ${fmt(T.payable(o.quote, o).total)}; observed room rate: ${fmt(o.price)}\n${conditions(o.quote)}\n${o.url || ""}${i ? "\nTravel from previous hotel: " + (w.route?.legs?.[i - 1]?.hours ?? "unknown") + " hours; ₹" + (w.route?.legs?.[i - 1]?.cost ?? "unknown") : ""}`), "Hotels + between-hotel transport estimate: " + fmt(result.estimate), "Food, travel to/from home and other costs are additional.", ...result.issues.map((s) => "Check: " + s)];
        download("hotel-trip-plan.txt", lines.join("\n\n")); status("Trip plan downloaded."); return;
      }
      if (a === "link" || a === "unlink") { await msg({ type: "TRIP_ALIAS", groups: a === "unlink" ? [$("trip-link-a").value] : [$("trip-link-a").value, $("trip-link-b").value], unlink: a === "unlink" }); await render(); status(a === "unlink" ? "Profile link removed." : "Profiles linked. Source histories preserved."); return; }
      if (a === "failover") { await msg({ type: "TRIP_FAILOVER", enabled: $("trip-failover").checked }); status("Helper recovery setting saved."); return; }
      if (a === "smoke") { b.disabled = true; const r = await msg({ type: "TRIP_SMOKE", destination: $("trip-smoke-dest").value, site: $("trip-smoke-site").value }); await render(); status(r.message); return; }
      if (a === "permissions") await permissionsHtml();
    } catch (e) { b.disabled = false; status(e.message, true); }
  });
  async function permissionsHtml() {
    const grants = await chrome.permissions.getAll(), manifest = chrome.runtime.getManifest();
    const required = new Set(manifest.host_permissions || []);
    $("trip-permissions").innerHTML = (grants.origins || []).filter((o) => !required.has(o)).map((o) => `<p>${esc(o)} <button class="secondary-btn" data-revoke="${esc(o)}">Remove extra access</button></p>`).join("") || '<p class="hint">No extra booking-site access granted.</p>';
  }
  document.querySelectorAll(".tab-btn").forEach((b) => b.addEventListener("click", () => {
    if (b.dataset.tab === "plan") { if (!pendingFocus && !pendingSection) focus = null; render(); }
  }));
  document.addEventListener("trip:open", (e) => {
    if (typeof e.detail?.id !== "string") return;
    focus = e.detail.id; pendingFocus = true;
    document.querySelector('.tab-btn[data-tab="plan"]')?.click();
    render();
  });
  document.addEventListener("trip:section", (e) => {
    const sections = { preferences: "trip-preferences", watches: "trip-watches-panel", system: "trip-system" };
    if (!sections[e.detail?.section]) return;
    focus = null; pendingSection = sections[e.detail.section];
    document.querySelector('.tab-btn[data-tab="plan"]')?.click();
    render();
  });
  chrome.storage.onChanged.addListener((changes, area) => { if (area === "local" && changes.tripVerifications && !dirty && !root.classList.contains("hidden")) render(); });
})();
